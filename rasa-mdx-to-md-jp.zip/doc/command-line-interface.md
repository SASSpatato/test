---
id: command-line-interface
sidebar_label: Command Line Interface
title: Command Line Interface
description: Command line interface for open source chatbot framework Rasa. Learn how to train, test and run your machine learning-based conversational AI assistants
abstract: The command line interface (CLI) gives you easy-to-remember commands for common tasks. This page describes the behavior of the commands and the parameters you can pass to them.
---

## カンニングペーパー

| 命令 | 影響 |
| --- | --- |
| rasa init | サンプルのトレーニングデータ、アクション、および構成ファイルを含む新しいプロジェクトを作成します。 |
| rasa train | NLU データとストーリーを使用してモデルをトレーニングし、トレーニングされたモデルを ./models に保存します。 |
| rasa interactive | 対話式学習セッションを開始し、アシスタントとチャットして新しいトレーニング・データを作成します。 |
| rasa shell | トレーニング済みのモデルをロードし、コマンドラインでアシスタントと会話できるようにします。 |
| rasa run | トレーニング済みモデルでサーバーを起動します。 |
| rasa run actions | Rasa SDKを使用してアクション・サーバーを起動します。 |
| rasa visualize | ストーリーを視覚的に表現します。 |
| rasa test | トレーニング済みの Rasa モデルを test_ で始まるファイルでテストします。 |
| rasa test e2e | 受け入れテストとして機能するアクション サーバーと完全に統合されたエンドツーエンドのテストを実行します。 |
| rasa data split nlu | NLU トレーニング データの 80/20 分割を実行します。 |
| rasa data split stories | rasa data split nlu と同じようにしますが、ストーリー データに対して行います。 |
| rasa data convert | トレーニングデータを異なる形式間で変換します。 |
| rasa data migrate | 2.0 ドメインを 3.0 形式に移行します。 |
| rasa data validate | ドメイン、NLU、会話データの不整合をチェックします。 |
| rasa export | トラッカーストアからイベントブローカーに会話をエクスポートします。 |
| rasa evaluate markers | 既存のトラッカーストアからマーカーを抽出します。 |
| rasa marker upload | マーカー設定を Analytics Data Pipeline にアップロードする |
| rasa license | ライセンス情報を表示します。 |
| rasa -h | 使用可能なすべてのコマンドを表示します。 |

> [!NOTE] 
> Windows で次のような文字エンコーディングの問題が発生した場合 `UnicodeEncodeError: 'charmap' codec can't encode character ...` 、または端末に色付きのメッセージが正しく表示されない場合は、実行するコマンドの先頭に `winpty` を追加してください。たとえば、`rasa init` の代わりに `winpty rasa init`

## ログレベル

Rasa は、いくつかの異なるレベル (警告、情報、エラーなど) でログ メッセージを生成します。オプションのコマンドライン引数として `--verbose` (`-v` と同じ) または `--debug` (`-vv` と同じ) を使用して、表示するログのレベルを制御できます。これらの引数の意味の詳細については、以下の各コマンドを参照してください。

CLI 引数に加えて、いくつかの環境変数を使用すると、より詳細な方法でログ出力を制御できます。これらの環境変数を使用すると、Matplotlib、Pika、Kafkaなどの外部ライブラリによって作成されたメッセージのログレベルを構成できます。これらの変数は、[Python の標準ログレベル](https://docs.python.org/3/library/logging.html#logging-levels)に従います。現在、次の環境変数がサポートされています。

1.  LOG_LEVEL_LIBRARIES: これは、Rasaが使用するメインライブラリのログレベルを構成するための一般的な環境変数です。Tensorflow、`asyncio`、APScheduler、SocketIO、Matplotlib、RabbitMQ、Kafkaをカバーしています。
2.  LOG_LEVEL_MATPLOTLIB: これは、Matplotlibのみのログレベルを設定するための特殊な環境変数です。
3.  LOG_LEVEL_RABBITMQ: これは、`AMQP` ライブラリに対してのみログレベルを構成するための特殊な環境変数であり、現時点では aio_pika および `aiormq` からのログレベルを処理します。
4.  LOG_LEVEL_KAFKA: これは、kafka のみのログレベルを設定するための特殊な環境変数です。
5.  LOG_LEVEL_PRESIDIO: これは、Presidio のみのログレベルを設定するための特殊な環境変数であり、現時点では `presidio_analyzer` と `presidio_anonymizer` のログレベルを処理します。
6.  LOG_LEVEL_FAKER: Faker専用のログレベルを設定するための特殊な環境変数です。

一般構成 (`LOG_LEVEL_LIBRARIES`) は、ライブラリ レベルの特定の構成 (`LOG_LEVEL_MATPLOTLIB`、`LOG_LEVEL_RABBITMQ` など) よりも優先度が低くなります。CLI パラメーターは、処理される最下位レベルのログ メッセージを設定します。これは、変数を予測可能な結果と一緒に使用できることを意味します。例として:

```bash
LOG_LEVEL_LIBRARIES=ERROR LOG_LEVEL_MATPLOTLIB=WARNING LOG_LEVEL_KAFKA=DEBUG rasa shell --debug
```

上記のコマンドを実行すると、次のように表示されます。

*   デフォルトで`DEBUG`レベル以上のメッセージ(`--debug`による)
*   Matplotlibの`WARNING`レベル以上のメッセージ
*   kafka の `DEBUG` レベル以上のメッセージ
*   構成されていない他のライブラリーの `ERROR` レベル以上のメッセージ

CLI 設定は処理する最下位レベルのログメッセージを設定するため、次のコマンドはログレベルを `INFO` に設定し (`--verbose` のため)、デバッグメッセージは表示されません (ライブラリレベルの設定は効果がありません)。

```bash
LOG_LEVEL_LIBRARIES=DEBUG LOG_LEVEL_MATPLOTLIB=DEBUG rasa shell --verbose
```

余談ですが、CLI ログ レベルはルート ロガー (重要なハンドラーである `coloredlogs` ハンドラーがあります) のレベルを設定します。つまり、環境変数がライブラリロガーを下位レベルに設定した場合でも、ルートロガーはそのライブラリからのメッセージを拒否します。指定しない場合、CLI ログ レベルは `INFO` に設定されます。

## カスタムログ設定

> [!info] 
> 3.4 の新機能Rasa CLI には、YAML ファイルを値として受け入れる新しい引数 `--logging-config-file` が含まれるようになりました。

これで、ロギング フォーマッタまたはハンドラを別の YAML ファイルで設定できるようになりました。ロギング構成 YAML ファイルは、[Python 組み込みディクショナリ スキーマ](https://docs.python.org/3/library/logging.config.html#dictionary-schema-details)に従う必要があり、そうでない場合は検証に失敗します。このファイルを引数として `--logging-config-file` CLI オプションに渡し、任意の rasa コマンドで使用できます。

## ラサ・イニット

このコマンドは、いくつかのトレーニング データの例を使用して完全なアシスタントを設定します。

```bash
rasa init
```

次のファイルが作成されます。

```bash
.
├── actions
│   ├── __init__.py
│   └── actions.py
├── config.yml
├── credentials.yml
├── data
│   ├── nlu.yml
│   └── stories.yml
├── domain.yml
├── endpoints.yml
├── models
│   └── <timestamp>.tar.gz
└── tests
   └── test_stories.yml
```

このデータを使用して初期モデルをトレーニングするかどうかを尋ねられます。「いいえ」と答えると、`モデル`ディレクトリは空になります。

デフォルトの CLI コマンドはどれもこのプロジェクトのセットアップを想定しているため、これが開始する最良の方法です。`rasa train`、`rasa shell`、`rasa test` を実行できます 追加の構成なし。

## rasa train

次のコマンドは、Rasa モデルをトレーニングします。

```bash
rasa train
```

ディレクトリに既存のモデルがある場合 (デフォルトでは `models/` の下)、モデルの変更された部分のみが再トレーニングされます。たとえば、NLU トレーニング データを編集し、他に何も編集しない場合は、NLU 部分のみがトレーニングされます。

NLU または対話モデルを個別にトレーニングする場合は、 `RASA トレイン NLU` または `RASA トレイン コア`。これらのうちの 1 つに対してのみトレーニング データを提供すると、`rasa train` はデフォルトでこれらのコマンドのいずれかにフォールバックします。

`RASA Train`は、トレーニング済みモデルを-`-out`, `models/`で定義されたディレクトリにデフォルトで保存します。モデルの名前はデフォルトで`<timestamp>.tar.gz`です。モデルに別の名前を付けたい場合は、`--fixed-model-name` フラグを使用して名前を指定できます。

既定では、検証はモデルをトレーニングする前に実行されます。検証をスキップする場合は、`--skip-validation` フラグを使用できます。検証の警告で失敗する場合は、`--fail-on-validation-warnings` フラグを使用できます。`--validation-max-history` は、`rasa data validate` の `--max-history` 引数に似ています。

次の引数を使用して、トレーニング プロセスを構成できます。

データ拡張の仕組みとフラグの値の選択方法については、[[./policies.md#データ拡張|データ拡張]] のセクションを参照してください。`TEDPolicy` は、データ拡張の影響を受ける唯一のポリシーであることに注意してください。

`--epoch-fraction` 引数の詳細については、次の [[#段階的なトレーニング]] のセクションを参照してください。

### 段階的なトレーニング

> [!info] 2.2 の新機能この機能は実験的です。
> コミュニティからフィードバックを得るために実験的な機能を導入していますので、ぜひ試してみてください。ただし、この機能は将来変更または削除される可能性があります。フィードバック(肯定的または否定的)がある場合は、[Rasaフォーラム](https://forum.rasa.com)で共有してください。

アシスタントのパフォーマンスを向上させるには、[CDD](./conversation-driven-development.md)を練習することが役立ちます また、ユーザーがアシスタントとどのように話したかに基づいて、新しいトレーニング例を追加します。`rasa train --finetune` を使用して、すでにトレーニング済みのモデルでパイプラインを初期化し、追加のトレーニング例を含む新しいトレーニングデータセットでさらに微調整できます。これにより、新しいモデルのトレーニング時間が短縮されます。

デフォルトでは、コマンドは`models/`ディレクトリ内の最新のモデルを取得します。改善したい特定のモデルがある場合は、 を実行し `rasa train --finetune <path to model to finetune>` てパスを指定できます。モデルを微調整するには、通常、ゼロからのトレーニングと比較して、`DIETClassifier`、`ResponseSelector`、`TEDPolicy`などの機械学習コンポーネントをトレーニングするのに必要なエポックが少なくなります。以前よりも少ないエポックを定義するモデル構成を微調整に使用するか、`フラグ --epoch-fraction` を使用します。`--epoch-fraction` は、モデル構成ファイル内の各機械学習コンポーネントに指定されたエポックの一部を使用します。たとえば、`DIETClassifier` が 100 エポックを使用するように構成されている場合、`--epoch-fraction 0.5` を指定すると、微調整に 50 エポックのみが使用されます。

NLU のみまたは対話管理のみのモデルを微調整することもできます。 `rasa train nlu --finetune` と `rasa train core --finetune` をそれぞれ行います。

モデルを微調整できるようにするには、次の条件を満たす必要があります。

1.  提供される構成は、微調整中のモデルのトレーニングに使用される構成とまったく同じである必要があります。変更できるパラメータは、個々の機械学習コンポーネントとポリシーの`エポック`のみです。
    
2.  ベースモデルがトレーニングされるラベルのセット(インテント、アクション、エンティティ、スロット)は、微調整に使用されるトレーニングデータに存在するものとまったく同じである必要があります。つまり、増分トレーニング中にトレーニングデータに新しいインテント、アクション、エンティティ、またはスロットラベルを追加することはできません。既存のラベルごとに新しいトレーニング例を追加できます。トレーニング データでラベルを追加または削除した場合は、パイプラインを最初からトレーニングする必要があります。
    
3.  微調整するモデルは、現在インストールされているrasaバージョン`のMINIMUM_COMPATIBLE_VERSION`で学習されます。
    

## RASAインタラクティブ

対話型学習セッションを開始するには、以下を実行します。

```bash
rasa interactive
```

これにより、最初にモデルがトレーニングされ、次にインタラクティブなシェルセッションが開始されます。その後、アシスタントに話しかけながら、アシスタントの予測を修正できます。[[./policies.md#UnexpecTED インテント ポリシー|`UnexpecTEDIntentPolicy`]] がパイプラインに含まれている場合、[[./default-actions.md#action_unlikely_intent|`action_unlikely_intent`]]は、任意の会話ターンでトリガーできます。その後、次のメッセージが表示されます。

```
 The bot wants to run 'action_unlikely_intent' to indicate that the last user message was unexpected at this point in the conversation. Check out UnexpecTEDIntentPolicy docs to learn more.
```

メッセージに記載されているように、これは、現在のトレーニング ストーリーのセットに従って予期しない会話パスを探索したことを示しているため、このパスをトレーニング ストーリーに追加することをお勧めします。他のボットアクションと同様に、このアクションの実行を確認または拒否することを選択できます。

`--model` 引数を使用してトレーニング済みモデルを指定すると、トレーニングはスキップされ、代わりにそのモデルが読み込まれます。

対話型学習中に、Rasaは現在の会話とトレーニングデータからいくつかの同様の会話をプロットし、現在地を追跡するのに役立ちます。セッションが開始されるとすぐに、[http://localhost:5005/visualization.html](http://localhost:5005/visualization.html) でビジュアライゼーションを表示できます。この図の生成には時間がかかる場合があります。ビジュアライゼーションをスキップするには、 を実行します `rasa interactive --skip-visualization` 。

> [!info]
> 3.5 メタデータが含まれていない事前学習済みモデルで対話型学習を実行するで導入した`assistant_id`キーを追加`assistant_id`はエラーで終了します。その場合は、`config.yml`に一意の識別子値を持つ必要なキーを追加し、トレーニングを再実行します。

次の引数を使用して、対話型学習セッションを構成できます。

## ラサシェル

チャットセッションを開始するには、以下を実行します。

```bash
rasa shell
```

デフォルトでは、これにより最新のトレーニング済みモデルがロードされます。`--model` フラグを使用して、読み込む別のモデルを指定できます。

NLU のみのモデルでシェルを開始すると、`rasa シェル`は入力したメッセージに対して予測されたインテントとエンティティを出力します。

結合された Rasa モデルをトレーニングしたが、モデルがテキストからインテントとエンティティとして抽出するもののみを確認する場合は、`コマンド rasa shell nlu` を使用できます。

デバッグのログ・レベルを上げるには、次を実行します。

```bash
rasa shell --debug
```

> [!note] 
> 外部チャネルで見られる一般的なグリーティングやセッション開始の動作を確認するには、`明示的に /session_start` 最初のメッセージとして。それ以外の場合は、セッション開始動作が「 [セッション構成](./domain.md#session-configuration)。

次の引数を使用して、コマンドを構成できます。ほとんどの議論は`rasa run`と重複します。これらの引数の詳細については、[[#rasa run]]を参照してください。

-`-connector`引数は、`rasaシェル`を実行するときに常に`cmdline`に設定されることに注意してください。つまり、資格情報ファイル内のすべての資格情報は無視され、`--connector`引数に独自の値を指定した場合、それも無視されます。

## rasa run

トレーニング済みモデルを実行しているサーバーを起動するには、以下を実行します。

```bash
rasa run
```

デフォルトでは、Rasa サーバーは通信に HTTP を使用します。SSL との通信を保護し、HTTPS でサーバーを実行するには、有効な証明書と対応する秘密鍵ファイルを提供する必要があります。これらのファイルは、`rasa run` コマンドの一部として指定できます。作成時に鍵ファイルをパスワードで暗号化した場合は、`--ssl-password` も追加する必要があります。

```bash
rasa run --ssl-certificate myssl.crt --ssl-keyfile myssl.key --ssl-password mypassword
```

Rasa はデフォルトで、使用可能な各ネットワーク インターフェイスをリッスンします。`-i` コマンドラインオプションを使用して、これを特定のネットワークインターフェイスに制限できます。

```bash
rasa run -i 192.168.69.150
```

Rasaはデフォルトで、資格情報ファイルで指定されたすべてのチャネルに接続します。1 つのチャネルに接続し、資格情報ファイル内の他のすべてのチャネルを無視するには、`--connector` 引数にチャネルの名前を指定します。

```bash
rasa run --connector rest
```

チャネルの名前は、資格情報ファイルで指定した名前と一致する必要があります。サポートされているチャネルについては、[メッセージングと音声チャネルに関するページ](./messaging-and-voice-channels.md)を参照してください。

次の引数を使用して、Rasaサーバーを構成できます。

追加のパラメータの詳細については、[モデルストレージ](./model-storage.md)を参照してください。すべてのエンドポイントの詳細なドキュメントについては、Rasa [HTTP API](./http-api.md)のページを参照してください。

## rasa run actions

Rasa SDKを使用してアクションサーバーを起動するには、以下を実行します。

```bash
rasa run actions
```

次の引数を使用して、サーバー設定を調整できます。

## rasa visualize

ブラウザーでストーリーのグラフを生成するには、次を実行します。

```bash
rasa visualize
```

ストーリーがデフォルトのロケーション `data/` 以外の場所にある場合は、`--stories` フラグを使用してその場所を指定できます。

次の引数を使用して、このコマンドを構成できます。

## rasa test

テスト データでモデルを評価するには、次のコマンドを実行します。

```bash
rasa test
```

これにより、`test_` プレフィックスを持つファイルで定義したエンドツーエンドのストーリーで、最新のトレーニング済みモデルがテストされます。別のモデルを使用する場合は、`--model` フラグを使用して指定できます。

ダイアログ モデルと NLU モデルを個別に評価するには、次のコマンドを使用します。

```bash
rasa test core
```

そして

```bash
rasa test nlu
```

各テストタイプの特定の引数の詳細については、[[./testing-your-assistant.md#NLU モデルの評価|NLUモデルの評価]]と[[./testing-your-assistant.md#対話モデルの評価|対話管理モデルの評価]]。

`rasa テスト`では、次の引数を使用できます。

## RASAテストE2E

> [!warning] Rasa Proのみ

> [!info]
> 3.5 の新機能エンドツーエンドのテストを使用して、ダイアログ管理やカスタムアクションなど、アシスタント全体をテストできるようになりました。

トレーニングされたモデルで [[./testing-your-assistant.md#エンドツーエンドのテスト|エンドツーエンドのテスト]] を実行するには、次のコマンドを実行します。

```bash
rasa test e2e
```

これにより、エンドツーエンドのテストケースで最新のトレーニング済みモデルがテストされます。別のモデルを使用する場合は、`--model` フラグを使用して指定できます。

`rasa test e2e` では、以下の引数を使用できます。

```text
usage: rasa test e2e [-h] [-v] [-vv] [--quiet] [--logging-config-file LOGGING_CONFIG_FILE] [--fail-fast] [-o] [--remote-storage REMOTE_STORAGE] [-m MODEL] [--endpoints ENDPOINTS] [path-to-test-cases]

Runs end-to-end testing.

optional arguments:
  -h, --help            show this help message and exit
  -o, --e2e-results     Results file containing end-to-end testing summary. (default: None)
  --remote-storage REMOTE_STORAGE
                        Set the remote location where your Rasa model is stored, e.g. on AWS. (default: None)
  -m MODEL, --model MODEL
                        Path to a trained Rasa model. If a directory is specified, it will use the latest model in this directory. (default: models)
  --endpoints ENDPOINTS
                        Configuration file for the model server and the connectors as a yml file. (default: endpoints.yml)

Python Logging Options:
  You can control level of log messages printed. In addition to these arguments, a more fine grained configuration can be achieved with environment variables. See online documentation for more info.

  -v, --verbose         Be verbose. Sets logging level to INFO. (default: None)
  -vv, --debug          Print lots of debugging statements. Sets logging level to DEBUG. (default: None)
  --quiet               Be quiet! Sets logging level to WARNING. (default: None)
  --logging-config-file LOGGING_CONFIG_FILE
                        If set, the name of the logging configuration file will be set to the given name. (default: None)

Testing Settings:
  path-to-test-cases    Input file or folder containing end-to-end test cases. (default: tests/e2e_test_cases.yml)
  --fail-fast           Fail the test suite as soon as a unit test fails. (default: False)
```

## RASAデータ分割

NLU トレーニングデータのトレーニングとテストの分割を作成するには、次のコマンドを実行します。

```bash
rasa data split nlu
```

これにより、既定でトレーニング/テスト データの 80/20 分割が作成されます。トレーニングデータ、分数、および出力ディレクトリは、次の引数を使用して指定できます。

取得アクション用の NLG データがある場合、これは別のファイルに保存されます。

```bash
ls train_test_split

      nlg_test_data.yml     test_data.yml
      nlg_training_data.yml training_data.yml
```

ストーリーを分割するには、次のコマンドを使用できます。

```bash
rasa data split stories
```

`split nlu`コマンドと同じ引数を持ちますが、ストーリーを含むyamlファイルをロードし、ランダム分割を実行します。ディレクトリ`train_test_split`には、トレーニングパーツとテストパーツを含むプレフィックス`train_`または`test_`で処理されたすべての yaml ファイルが含まれます。

## RASAデータ変換NLU

NLU データを

*   LUIS データ形式、
*   WIT データ形式、
*   Dialogflow データ形式、または
*   JSON

宛先

*   YAML または
*   JSON

コンバーターを起動するには、次のコマンドを実行します。

```bash
rasa data convert nlu
```

入力ファイルまたはディレクトリ、出力ファイルまたはディレクトリ、および出力形式は、次の引数を使用して指定できます。

## RASAデータ移行

ドメインは、2.0 と 3.0 の間で形式が変更された唯一のデータ ファイルです。2.0 ドメインを 3.0 形式に自動的に移行できます。

移行を開始するには、次のコマンドを実行します。

```bash
rasa data migrate
```

入力ファイルまたはディレクトリと出力ファイルまたはディレクトリは、次の引数を使用して指定できます。

```bash
rasa data migrate -d DOMAIN --out OUT_PATH
```

引数が指定されていない場合、デフォルトのドメインパス (`domain.yml`) が入力ファイルと出力ファイルの両方に使用されます。

このコマンドは、2.0ドメインファイルを`original_domain`というラベルの付いた別の`original_domain.yml`ファイルまたはディレクトリにもバックアップします。

移行されたドメインのスロットには、これらのスロットがフォームの`required_slots`の一部である場合、これらのスロットには [[./domain.md#マッピング条件|マッピング条件]] が含まれます。

> [!caution] 
> 無効なドメインファイルが提供されている場合、またはそれらがすでに 3.0 形式である場合、元のファイルにスロットまたはフォームがない場合、またはスロットまたはフォームセクションが複数のドメインファイルに分散している場合、例外が発生し、移行プロセスが終了します。これは、ドメインファイル内の移行されたセクションの重複を避けるために行われます。すべてのスロットまたはフォームの定義が 1 つのファイルにグループ化されていることを確認してください。

このコマンドの詳細については、次のコマンドを実行します。

```bash
rasa data migrate --help
```

## RASAデータ検証

ドメイン、NLU データ、またはストーリー データに間違いや不整合がないか確認できます。データを検証するには、次のコマンドを実行します。

```bash
rasa data validate
```

バリデーターは、データ内のエラー、たとえば、同一のトレーニング例を持つ 2 つのインテントを検索します。バリデーターは、同じ対話履歴から異なるアシスタントアクションが続くストーリーがあるかどうかもチェックします。ストーリー間の競合により、モデルは対話の正しいパターンを学習できなくなります。

> [!info] 
> 3.5で導入された`assistant_id`キーの検索バリデーターは、`assistant_id`キーが設定ファイルに存在するかどうかをチェックし、このキーが見つからない場合、またはデフォルト値が変更されていない場合は警告を発行します。

`config.yml` ファイル内の 1 つ以上のポリシーに`max_history`値を渡す場合は、`--max-history <max_history>` フラグを使用してバリデーターコマンドでそれらの最小値を指定します。

次のコマンドを実行して、ストーリー構造のみを検証することもできます。

```bash
rasa data validate stories
```

> [!note] 
> `rasa data validate` を実行しても、[ルール](./rules.md)がストーリーと整合性があるかどうかはテスト**されません**。ただし、トレーニング中、`RulePolicy` はルールとストーリー間の競合をチェックします。そのような対立は訓練を中止します。
> 
> また、エンドツーエンドのストーリーを使用する場合、すべての競合がキャプチャされない可能性があります。具体的には、2 つのユーザー入力の結果、トークンは異なるが、特徴付けはまったく同じである場合、これらの入力の後に競合するアクションが存在する可能性がありますが、ツールによって報告されません。

未使用のインテントや応答などの軽微な問題でも検証を中断するには、`--fail-on-warnings` フラグを使用します。

> [!caution] ストーリー名を確認する
> `rasa data validate stories` コマンドは、すべてのストーリー名が一意であることを前提としています。

`rasa data validate` は、データファイルやドメインファイルの場所を指定するなど、追加の引数を付けて使用できます。

## RASAエクスポート

イベントブローカーを使用してトラッカーストアからイベントをエクスポートするには、以下を実行します。

```bash
rasa export
```

環境ファイルの場所、公開するイベントの最小タイムスタンプと最大タイムスタンプ、および公開する会話 ID を指定できます。

> [! tip] 
> 会話を Rasa X/Enterprise にインポートするこのコマンドは、古い会話を Rasa X/Enterprise にインポートして注釈を付けるために最も一般的に使用されます。[Rasa X/Enterprise への会話のインポート](https://rasa.com/docs/rasa-enterprise/installation-and-setup/deploy#1-import-existing-conversations-from-rasa-open-source)の詳細については、こちらをご覧ください。

## RASAはマーカーを評価する

> [!caution]
> この機能は現在実験段階であり、将来的に変更または削除される可能性があります。フォーラムでフィードバックを共有して、本番環境に対応できるようにしてください。

次のコマンドは、マーカー設定ファイルで定義した[マーカー](./markers.md)を[トラッカーストア](./tracker-stores.md)に保存されている既存のダイアログに適用し、抽出されたマーカーとサマリー統計を含む`.csv`ファイルを生成します。

```bash
rasa evaluate markers all extracted_markers.csv
```

次の引数を使用して、マーカー抽出プロセスを構成します。

```
usage: rasa evaluate markers [-h] [-v] [-vv] [--quiet] [--config CONFIG] [--no-stats | --stats-file-prefix [STATS_FILE_PREFIX]] [--endpoints ENDPOINTS] [-d DOMAIN] output_filename {first_n,sample,all} ...

positional arguments:
  output_filename       The filename to write the extracted markers to (CSV format).
  {first_n,sample,all}
    first_n             Select trackers sequentially until N are taken.
    sample              Select trackers by sampling N.
    all                 Select all trackers.

optional arguments:
  -h, --help            show this help message and exit
  --config CONFIG       The config file(s) containing marker definitions. This can be a single YAML file, or a directory that contains several files with marker definitions in it. The content of these files will be read and
                        merged together. (default: markers.yml)
  --no-stats            Do not compute summary statistics. (default: True)
  --stats-file-prefix [STATS_FILE_PREFIX]
                        The common file prefix of the files where we write out the compute statistics. More precisely, the file prefix must consist of a common path plus a common file prefix, to which suffixes `-overall.csv` and
                        `-per-session.csv` will be added automatically. (default: stats)
  --endpoints ENDPOINTS
                        Configuration file for the tracker store as a yml file. (default: endpoints.yml)
  -d DOMAIN, --domain DOMAIN
                        Domain specification. This can be a single YAML file, or a directory that contains several files with domain specifications in it. The content of these files will be read and merged together. (default:
                        domain.yml)

Python Logging Options:
  -v, --verbose         Be verbose. Sets logging level to INFO. (default: None)
  -vv, --debug          Print lots of debugging statements. Sets logging level to DEBUG. (default: None)
  --quiet               Be quiet! Sets logging level to WARNING. (default: None)
```

## RASAマーカーのアップロード

> [!warning] Rasa Proのみ

> [!info] 
> 3.6 の新機能このコマンドは Rasa Pro 3.6.0 から使用でき、[Rasa Analytics Data Pipeline](./monitoring/analytics/getting-started-with-analytics.md) が必要です。

このコマンドは、[マーカー](./markers.md)とその[リアルタイム処理](./monitoring/analytics/realtime-markers.md)に適用されます。このコマンドを実行すると、マーカー設定ファイルがドメインファイルに対して検証され、設定が Analytics Data Pipeline にアップロードされます

```
usage: rasa markers upload [-h] [-v] [-vv] [--quiet]
                           [--logging-config-file LOGGING_CONFIG_FILE]
                           [--config CONFIG]
                           [--rasa-pro-services-url RASA_PRO_SERVICES_URL]
                           [-d DOMAIN]

optional arguments:
  -h, --help            show this help message and exit
  --config CONFIG       The marker configuration file(s) containing marker
                        definitions. This can be a single YAML file, or a
                        directory that contains several files with marker
                        definitions in it. The content of these files will be
                        read and merged together. (default: markers.yml)
  --rasa-pro-services-url RASA_PRO_SERVICES_URL
                        The URL of the Rasa Pro Services instance to upload
                        markers to.Specified URL should not contain a trailing
                        slash. (default: )
  -d DOMAIN, --domain DOMAIN
                        Domain specification. This can be a single YAML file,
                        or a directory that contains several files with domain
                        specifications in it. The content of these files will
                        be read and merged together. (default: domain.yml)

Python Logging Options:
  You can control level of log messages printed. In addition to these
  arguments, a more fine grained configuration can be achieved with
  environment variables. See online documentation for more info.

  -v, --verbose         Be verbose. Sets logging level to INFO. (default:
                        None)
  -vv, --debug          Print lots of debugging statements. Sets logging level
                        to DEBUG. (default: None)
  --quiet               Be quiet! Sets logging level to WARNING. (default:
                        None)
  --logging-config-file LOGGING_CONFIG_FILE
                        If set, the name of the logging configuration file
                        will be set to the given name. (default: None)

Description:
  The `rasa markers upload` command allows you to upload markers to the Rasa Pro Services. Markers are custom conversational events that provide additional context for analysis and insights generation. By uploading markers, you can enable real-time analysis and enhance the performance of your Rasa Assistant.

Examples:
  Upload Markers to Rasa Pro Services:
    rasa markers upload --config markers.yml --rasa-pro-services-url https://example.com/rasa-pro -d domain.yml

```

## RASAライセンス

> [!warning] Rasa Proのみ

> [!info] 3.3 の新機能
> 
> このコマンドが導入されました。

`rasa ライセンス`を使用して、Rasa Pro のライセンスに関する情報、特にサードパーティの依存関係ライセンスに関する情報を表示します。

考えられるすべての引数のリストは次のとおりです。

```
usage: rasa license [-h] [-v] [-vv] [--quiet] [--logging-config-file LOGGING_CONFIG_FILE]

Display licensing information.

options:
  -h, --help            show this help message and exit

Python Logging Options:
  You can control level of log messages printed. In addition to these arguments, a more fine grained configuration can be achieved with environment variables. See online documentation for more info.

  -v, --verbose         Be verbose. Sets logging level to INFO. (default: None)
  -vv, --debug          Print lots of debugging statements. Sets logging level to DEBUG. (default: None)
  --quiet               Be quiet! Sets logging level to WARNING. (default: None)
  --logging-config-file LOGGING_CONFIG_FILE
                        If set, the name of the logging configuration file will be set to the given name. (default: None)
```