---
id: domain
sidebar_label: Domain
title: Domain
abstract: The domain defines the universe in which your assistant operates. It specifies the intents, entities, slots, responses, forms, and actions your bot should know about. It also defines a configuration for conversation sessions.
---

以下は、ドメインの完全な例です。 [concertbot](https://github.com/RasaHQ/rasa/tree/main/examples/concertbot)の例:

## 複数のドメイン ファイル

ドメインは、単一の YAML ファイルとして定義することも、ディレクトリ内の複数のファイルに分割することもできます。複数のファイルに分割すると、ドメインの内容が読み取られ、自動的にマージされます。

[[./command-line-interface.md#rasa train|command line interface]] を使用すると、次のコマンドを実行して、分割ドメイン ファイルを使用してモデルをトレーニングできます。

```bash
rasa train --domain path_to_domain_directory
```

## 意図

ドメイン ファイルの`インテント` キーには、[NLU データ](./nlu-training-data.md)と [[./training-data-format.md#会話トレーニング データ|会話トレーニング データ]] で使用されるすべてのインテントが一覧表示されます。

### 特定のインテントのエンティティの無視

特定のインテントのすべてのエンティティを無視するには、次のようにドメイン ファイルのインテントに `use_entities: []` パラメーターを追加します。

```yaml-rasa
intents:
  - greet:
      use_entities: []
```

一部のエンティティを無視したり、特定のエンティティのみを明示的に考慮したりするには、次の構文を使用できます。

```yaml-rasa
intents:
- greet:
    use_entities:
      - name
      - first_name
- farewell:
    ignore_entities:
      - location
      - age
      - last_name
```

`use_entities`*または*`ignore_entities`できるのは、1 つのインテントに対してのみです。

これらのインテントの除外されたエンティティは特徴付けされないため、次のアクション予測には影響しません。これは、取得されるエンティティを気にしないインテントがある場合に便利です。

`use_entities`や`ignore_entities`なしでインテントをリストした場合 パラメーターを指定すると、エンティティは通常どおり特徴付けられます。

エンティティ自体の `influence_conversation` フラグを `false` に設定することで、すべてのインテントのエンティティを無視することもできます。詳細については[エンティティのセクション](#エンティティ)を参照してください。

インテントの除外されたエンティティは特徴付けされないため、次のアクション予測には影響しません。これは、取得されるエンティティを気にしないインテントがある場合に便利です。

このパラメータを使用せずに、 エンティティに対して `false` `influence_conversation`すると、すべてのエンティティが通常どおり特徴付けられます。

> [!note] 
> これらのエンティティがスロットを介したアクション予測に影響を与えないようにするには、[[./domain.md#スロットと会話の動作|`influence_conversation: false`]] パラメータを使用します。

## エンティティ

> [!info] 3.1 の新機能
> 3.1 以降、エンティティで `influence_conversation` フラグを使用できます。フラグを `false` に設定して、エンティティを意図に対して特徴付けすべきではないことを宣言できます。これは、ドメイン内のすべてのインテントの`ignore_entities`リストにエンティティを追加するための省略構文です。フラグはオプションであり、デフォルトの動作は変更されません。

`[エンティティ`] セクションには、NLU パイプライン内の任意の[エンティティ抽出ツール](./components.md)で抽出できるすべてのエンティティが一覧表示されます。

例えば：

```yaml-rasa
entities:
   - PERSON           # entity extracted by SpacyEntityExtractor
   - time             # entity extracted by DucklingEntityExtractor
   - membership_type  # custom entity extracted by DIETClassifier
   - priority         # custom entity extracted by DIETClassifier
```

複数のドメインファイルを使用する場合、エンティティは任意のドメインファイルで指定でき、任意のドメインファイル内の任意のインテントで使用または無視できます。

機能 [[./nlu-training-data.md#エンティティ、ロール、およびグループ|エンティティの役割とグループ]]このセクションでは、エンティティの役割とグループもリストする必要があります。

例えば：

```yaml-rasa
entities:
   - city:            # custom entity extracted by DIETClassifier
       roles:
       - from
       - to
   - topping:         # custom entity extracted by DIETClassifier
       groups:
       - 1
       - 2
   - size:            # custom entity extracted by DIETClassifier
       groups:
       - 1
       - 2
```

既定では、エンティティはアクション予測に影響を与えます。抽出されたエンティティが特定のインテントの会話に影響を与えないようにするには、[[#特定のインテントのエンティティの無視]]。各インテントの`ignore_entities`フラグの下にエンティティをリストせずに、すべてのインテントのエンティティを無視するには、エンティティでフラグ`influence_conversation`を`false`に設定します。

```yaml-rasa
entities:
- location:
    influence_conversation: false
```

この構文は、エンティティを`ignore_entities`に追加するのと同じ効果があります ドメイン内のすべてのインテントのリスト。

`明示的にinfluence_conversation: true`を設定しても、動作は変更されません。これがデフォルト設定です。

## スロット

スロットはボットのメモリです。これらは、ユーザーが提供した情報 (出身都市など) や、外界について収集された情報 (データベース クエリの結果など) を保存するために使用できるキー値ストアとして機能します。

スロットは、ドメインのスロットセクションで、その名前 [[domain.md#スロットタイプ|タイプ]] と、その名前と方法を [[domain.md#スロットと会話の動作|スロットと会話の動作]] で定義します。次の例では、名前が "slot_name" のスロットを定義し、`テキスト`を入力し、スロット マッピング `from_entity`を定義します。

```yaml
slots:
  slot_name:
    type: text
    mappings:
    - type: from_entity
      entity: entity_name
```

### スロットと会話の動作

スロットが会話に影響を与えるかどうかを指定できます。 `influence_conversation`プロパティ。

会話に影響を与えずにスロットに情報を格納する場合は、スロットを定義するときに `influence_conversation: false` を設定します。

次の例では、ユーザーの年齢に関する情報を格納するスロット`年齢`を定義しますが、会話の流れには影響*しません*。これは、アシスタントが次のアクションを予測するたびにスロットの値を無視することを意味します。

```yaml
slots:
  age:
    type: text
    # this slot will not influence the predictions
    # of the dialogue policies
    influence_conversation: false
```

スロットを定義するときに、`influence_conversation`を省略するか、`true` に設定すると、スロット タイプが `any` でない限り、そのスロットは次のアクション予測に影響を与えます。スロットが会話にどのように影響するかは、その [[./domain.md#スロットタイプ|スロット タイプ]] によって異なります。

次の例では、会話に影響を与えるスロット`home_city`を定義します。[[domain.md#テキストスロット|テキストスロット]] は、スロットに値があるかどうかに応じてアシスタントの動作に影響します。`テキスト`スロットの特定の値(*バンガロール*、*ニューヨーク*、*香港*など)は違いを生みません。

```yaml
slots:
  # this slot will influence the conversation depending on
  # whether the slot is set or not
  home_city:
    type: text
    influence_conversation: true
```

例として、「天気はどうですか?」と「バンガロールの天気はどうですか?」という 2 つの入力について考えてみましょう。会話は、`home_city` スロットが NLU によって自動的に設定されたかどうかに基づいて分岐する必要があります。スロットがすでに設定されている場合、ボットは`action_forecast`アクションを予測できます。スロットが設定されていない場合は、`home_city`を取得する必要があります。 天気を予測する前に情報。

### スロットタイプ

#### テキストスロット

*   **種類**
    
    `text`
    
*   **用途**
    
    テキスト値の格納。
    
*   **例**
    
    ```yaml-rasa
    slots:
       cuisine:
          type: text
          mappings:
          - type: from_entity
            entity: cuisine
    ```
    
*   **形容**
    
    `influence_conversation` が `true` に設定されている場合、スロットが設定されているかどうかに応じてアシスタントの動作が変化します。異なるテキストは、それ以上会話に影響を与えません。これは、次の 2 つのストーリーが等しいことを意味します。
    
    ```yaml-rasa
    stories:
    - story: French cuisine
      steps:
      - intent: inform
      - slot_was_set:
        - cuisine: french
    
    - story: Vietnamese cuisine
      steps:
      - intent: inform
      - slot_was_set:
        - cuisine: vietnamese
    ```
    

#### ブールスロット

*   **種類**
    
    `bool`
    
*   **用途**
    
    `true` または `false` の値を格納します。
    
*   **例**
    
    ```yaml-rasa
    slots:
       is_authenticated:
          type: bool
          mappings:
          - type: custom
    ```
    
*   **形容**
    
    `influence_conversation` が `true` に設定されている場合、スロットが空か、`true` に設定されているか、`false` に設定されているかに応じて、アシスタントの動作が変化します。空の`ブール` スロットは、スロットが `false`です。
    

#### カテゴリ スロット

*   **種類**
    
    `categorical`
    
*   **用途**
    
    N 個の値のいずれかを取ることができるスロットを格納します。
    
*   **例**
    
    ```yaml-rasa
    slots:
      risk_level:
        type: categorical
        values:
          - low
          - medium
          - high
        mappings:
        - type: custom
    ```
    
*   **形容**
    
    `influence_conversation` を `true` に設定すると、アシスタントの動作はスロットの具体的な値に応じて変化します。これは、上記の例のスロットの値が`低い`かどうかによって、アシスタントの動作が異なることを意味します。 `中、``または高`。
    
    デフォルト値`__other__`がユーザー定義値に自動的に追加されます。スロットの`値`で明示的に定義されていないすべての値 は`__other__`にマッピングされます。 `__other__` はユーザー定義値として使用しないでください。その場合、表示されていないすべての値がマッピングされるデフォルトとして動作します。
    

#### フロートスロット

*   **種類**
    
    `float`
    
*   **用途**
    
    実数の格納。
    
*   **例**
    
    ```yaml-rasa
    slots:
      temperature:
        type: float
        min_value: -100.0
        max_value:  100.0
        mappings:
        - type: custom
    ```
    
*   **デフォルト**
    
    `max_value=1.0`、`min_value=0.0`
    
*   **形容**
    
    `influence_conversation` を `true` に設定すると、スロットの値に応じてアシスタントの動作が変化します。値が `min_value` から `max_value`、数値の特定の値が使用されます。`min_value` より下回るすべての値は `min_value` として扱われ、それを超えるすべての値が扱われます `max_value`は`max_value`として扱われます。したがって、`max_value` を `1` に設定すると、スロット値 `2` と `3.5` に差はありません。
    

#### リストスロット

*   **種類**
    
    `list`
    
*   **用途**
    
    値のリストの格納。
    
*   **例**
    
    ```yaml-rasa
    slots:
      shopping_items:
        type: list
        mappings:
        - type: from_entity
          entity: shopping_item
    ```
    
*   **形容**
    
    `influence_conversation` が `true` に設定されている場合、リストが空であるかどうかに応じてアシスタントの動作が変化します。スロットに格納されているリストの長さは、ダイアログには影響しません。リストの長さがゼロかゼロでないかのみが重要です。
    

#### 任意のスロット

*   **種類**
    
    `any`
    
*   **用途**
    
    任意の値を格納します (辞書やリストなど、任意のタイプにすることができます)。
    
*   **例**
    
    ```yaml-rasa
    slots:
      shopping_items:
        type: any
        mappings:
        - type: custom
    ```
    
*   **形容**
    
    タイプ `any` のスロットは、会話中は常に無視されます。プロパティ このスロットタイプでは、`influence_conversation`を`true`に設定することはできません。会話に影響を与えるカスタムデータ構造を保存する場合は、[[domain.md#カスタムスロットタイプ|カスタムスロットタイプ]]を使用します。
    

#### カスタムスロットタイプ

レストランの予約システムでは、最大 6 人の予約しか処理できない場合があります。この場合、スロットの*値は*、次に選択したアクションに影響を与える必要があります (指定されているかどうかだけでなく)。これを行うには、カスタムスロットクラスを定義します。

次のコードは、`NumberOfPeopleSlot` というカスタム スロット クラスを定義しています。特徴付けは、このスロットの値をベクトルに変換する方法を定義し、Rasa 機械学習モデルが処理できるようにします。`NumberOfPeopleSlot` には 3 つの可能な「値」があり、長さ `2` のベクトルで表すことができます。

|  |  |
| --- | --- |
| (0,0) | まだ設定されていません |
| (1,0) | 1 から 6 の間 |
| (0,1) | 6以上 |

```python
from rasa.shared.core.slots import Slot

class NumberOfPeopleSlot(Slot):

    def feature_dimensionality(self):
        return 2

    def as_feature(self):
        r = [0.0] * self.feature_dimensionality()
        if self.value:
            if self.value <= 6:
                r[0] = 1.0
            else:
                r[1] = 1.0
        return r
```

カスタムスロットクラスは、カスタムアクションコードとは別に、独立したPythonモジュールとして実装できます。カスタムスロットのコードを「__init__.py」という空のファイルと一緒にディレクトリに保存して、Python モジュールとして認識されるようにします。その後、カスタムスロットクラスをモジュールパスで参照できます。

たとえば、上記のコードをボットプロジェクトに関連するディレクトリである「addons/my_custom_slots.py」に保存したとします。

```bash
└── rasa_bot
    ├── addons
    │   ├── __init__.py
    │   └── my_custom_slots.py
    ├── config.yml
    ├── credentials.yml
    ├── data
    ├── domain.yml
    ├── endpoints.yml
```

カスタムスロットタイプのモジュールパスは `addons.my_custom_slots.NumberOfPeopleSlot` です。モジュール パスを使用して、ドメイン ファイル内のカスタム スロット タイプを参照します。

```yaml-rasa
slots:
  people:
    type: addons.my_custom_slots.NumberOfPeopleSlot
    influence_conversation: true
    mappings:
    - type: custom
```

カスタムスロットクラスを Rasa で使用できるようになったので、`人`スロットの値に基づいて分岐するトレーニングストーリーを追加します。`人々が` 1 から 6 までの値を持つ場合に 1 つのストーリーを書き、6 より大きい値の場合に 1 つのストーリーを書くことができます。ストーリーはすべて同じ方法で機能化されるため、これらの範囲内の任意の値を選択してストーリーに配置できます (上記の機能化の表を参照)。

```yaml-rasa
stories:
- story: collecting table info
  steps:
  # ... other story steps
  - intent: inform
    entities:
    - people: 3
  - slot_was_set:
    - people: 3
  - action: action_book_table

- story: too many people at the table
  steps:
  # ... other story steps
  - intent: inform
    entities:
    - people: 9
  - slot_was_set:
    - people: 9
  - action: action_explain_table_limit
```

### スロットマッピング

> [!info] 3.0 の新機能
> 3.0 以降、スロットマッピングはドメインの`スロット`セクションで定義されています。この変更により、自動入力を介してスロットを設定する暗黙的なメカニズムが削除され、ユーザーメッセージごとにスロットを設定する新しい明示的なメカニズムに置き換えられます。`domain.yml`の `slots` セクションで、各スロットのスロットマッピングを明示的に定義する必要があります。以前のバージョンから移行する場合は、[[./migration-guide.md#スロットマッピング|migration guide]] を読んでアシスタントを更新してください。

Rasaには、最新のユーザーメッセージに基づいてスロットを埋めるための4つの事前定義されたマッピングが付属しています。

定義済みのマッピングに加えて、[[./domain.md#カスタムスロットマッピング|カスタムスロットマッピング]]を定義できます。すべてのカスタムスロットマッピングには、`カスタム`タイプのマッピングが含まれている必要があります。

スロット マッピングは、ドメイン ファイル内のキー `マッピング`の下にあるディクショナリの YAML リストとして指定されます。スロットマッピングは、ドメインにリストされている順序で優先順位が付けられます。適用するために最初に見つかったスロットマッピングは、スロットを埋めるために使用されます。

デフォルトの動作では、ダイアログのコンテキストに関係なく、すべてのユーザーメッセージの後にスロットマッピングが適用されます。スロットマッピングをフォームのコンテキスト内でのみ適用するには、[[./domain.md#マッピング条件|マッピング条件]]を参照してください。フォームのコンテキストで`from_entity`スロットマッピングを適用する場合、追加のデフォルト制限が 1 つあります。詳細は[[./domain.md#独自の`from_entity`マッピングマッチング|独自の`from_entity`マッピングマッチング]]を参照してください。

オプションのパラメーター `intent` と `not_intent` のインテントのリストを定義することもできます。

#### from_entity

`from_entity`スロットマッピングは、抽出されたエンティティに基づいてスロットを埋めます。次のパラメータが必要です。

*   `entity`: スロットを埋めるエンティティ

次のパラメーターはオプションであり、マッピングを適用するタイミングをさらに指定するために使用できます。

*   `intent`: このインテントが予測された場合にのみマッピングを適用します。
*   `not_intent`: このインテントが予測されたときにマッピングを適用しません
*   `role`: 抽出されたエンティティにこのロールがある場合にのみマッピングを適用します
*   `group`: 抽出されたエンティティがこのグループに属している場合にのみマッピングを適用します。

```yaml-rasa
entities:
- entity_name
slots:
  slot_name:
    type: any
    mappings:
    - type: from_entity
      entity: entity_name
      role: role_name
      group: group name
      intent: intent_name
      not_intent: excluded_intent
```

##### 独自の`from_entity`マッピングマッチング

フォームのコンテキストで`from_entity`スロットマッピングを適用することには、意図的な制限があります。フォームがアクティブな場合、`from_entity`スロットマッピングは、次の条件の 1 つ以上が満たされた場合にのみ適用されます。

1.  `from_entity` マッピングを持つスロットがフォームによって要求されました
2.  アクティブフォームの`required_slots`のうち、抽出されたエンティティのすべての属性(エンティティ名、ロール、グループなど)を含む特定の`from_entity`マッピングを持つのは、1つだけです。これは、フォームの**一意のエンティティ マッピング**と呼ばれます。抽出されたエンティティは、マッピングが`required_slots`のリスト内で一意でない場合、無視されます。

この制限は、フォームが複数の必須スロットに同じ抽出されたエンティティ値で埋められないようにするために存在します。

たとえば、次の例では、エンティティの`日付`はスロット`arrival_date`を一意に設定し、`ロール`を持つエンティティ`都市`はスロット`departure_city`を一意に設定し、ロールを持つエンティティ`都市`はスロット`arrival_city``を一意`に設定するため、これらのスロットが要求されていなくても、対応するスロットに合わせるために使用できます。ただし、役割のないエンティティ`都市`は、要求するスロットによって`、departure_city`スロットと`arrival_city`スロットの両方を埋めることができるため、スロット`arrival_date`を要求したときにエンティティ`都市`を抽出すると、フォームでは無視される。

```yaml-rasa
slots:
  departure_city:
    type: text
    mappings:
    - type: from_entity
      entity: city
      role: from
    - type: from_entity
      entity: city
  arrival_city:
    type: text
    mappings:
    - type: from_entity
      entity: city
      role: to
    - type: from_entity
      entity: city
  arrival_date:
    type: any
    mappings:
    - type: from_entity
      entity: date
forms:
  your_form:
    required_slots:
    - departure_city
    - arrival_city
    - arrival_date
```

一意の`from_entity`マッピング制約は、アクティブなフォームの`required_slots`にないスロットを埋めること**を妨げない**ことに注意してください。これらのマッピングは、マッピングの一意性に関係なく、通常どおり適用されます。スロットマッピングの適用範囲を特定の形式に制限するには、[[./domain.md#マッピング条件|マッピング条件]]を参照してください。

#### from_text

`from_text` マッピングでは、最後のユーザー発話のテキストを使用してスロットを埋めます `slot_name`。`intent_name`が `None` の場合、インテント名に関係なくスロットがいっぱいになります。それ以外の場合、ユーザーの意図が`intent_name`の場合にのみスロットが埋まります。

メッセージの意図が`excluded_intent`の場合、スロットマッピングは適用されません。

```yaml-rasa
slots:
  slot_name:
    type: text
    mappings:
    - type: from_text
      intent: intent_name
      not_intent: excluded_intent
```

> [!note] 
> `from_text`スロットマッピングを使用するときに 2.x フォームの動作を維持するには、`active_loop` キーと `requested_slot` キーの両方が定義されている [[./domain.md#マッピング条件|マッピング条件]] を使用する必要があります。

#### from_intent

`from_intent`マッピングは、ユーザーの意図が`intent_name`の場合、スロット`slot_name`を値`my_value`で埋めます。パラメータイン`テント`を指定しない場合、インテントがパラメータの下にリストされていない限り、メッセージのインテントに関係なくスロットマッピング`not_intent`適用されます。

次のパラメーターは必須です。

*   `value`: スロット`slot_name`を埋める値

次のパラメーターはオプションであり、マッピングを適用するタイミングをさらに指定するために使用できます。

*   `intent`: このインテントが予測された場合にのみマッピングを適用します。
*   `not_intent`: このインテントが予測されたときにマッピングを適用しません

パラメーターの`インテント`を定義しないことを選択した場合、インテントが`not_intent`パラメーターの下にリストされていない限り、メッセージのインテントに関係なくスロットマッピングが適用されることに注意してください。

```yaml-rasa
slots:
  slot_name:
    type: any
    mappings:
    - type: from_intent
      value: my_value
      intent: intent_name
      not_intent: excluded_intent
```

#### from_trigger_intent

`from_trigger_intent`マッピングは、スロット`slot_name`を値`my_value`で埋めます フォームがインテント`intent_name`を含むユーザーメッセージによってアクティブ化された場合。 メッセージの意図が `excluded_intent`。

```yaml-rasa
slots:
  slot_name:
    type: any
    mappings:
    - type: from_trigger_intent
      value: my_value
      intent: intent_name
      not_intent: excluded_intent
```

### マッピング条件

フォームのコンテキスト内でのみスロットマッピングを適用するには、スロットマッピングの`条件`キーでフォームの名前を指定します。条件には、`active_loop`キーでマッピングを適用できるフォーム名がリストされます。

> [!info] 3.6 の新機能
> スロットマッピングでは、フォームがアクティブでない場合にのみスロットを埋める必要があることを示すために、`active_loop` の値として `null` を指定できるようになりました。`requested_slot` は `active_loop: null` と組み合わせて使用することはできません。

条件には、`requested_slot`の名前を含めることもできます。`requested_slot`が記載されていない場合、フォームによって要求されているスロットに関係なく、関連情報が抽出されるとスロットが設定されます。

```yaml-rasa
slots:
  slot_name:
    type: text
    mappings:
    - type: from_text
      intent: intent_name
      conditions:
      - active_loop: your_form
        requested_slot: slot_name
      - active_loop: another_form
```

> [!note] 
> `条件`がスロットマッピングに含まれていない場合、スロットマッピングは、フォームがアクティブかどうかに関係なく適用されます。スロットがフォームの`required_slots`にリストされている限り、フォームがアクティブ化されたときにスロットが空の場合、フォームはスロットの入力を求めます。

### カスタムスロットマッピング

カスタムスロットマッピングは、事前定義されたマッピングがユースケースに適合しない場合に、[スロット検証アクション](./slot-validation-actions.md)を使用して定義できます。このスロットマッピングは、次のように`カスタムタイプに`定義する必要があります。

```yaml
slots:
  day_of_week:
    type: text
    mappings:
    - type: custom
      action: action_calculate_day_of_week
```

また、`カスタム`スロットマッピングを使用して、タイプをリストし、特定のアクションをリストしないことで、会話の過程で任意のカスタムアクションによって埋められるスロットをリストすることもできます。例えば：

```yaml
slots:
  handoff_completed:
    type: boolean
    mappings:
    - type: custom
```

このスロットは、ユーザーターンごとに更新されるわけではなく、`SlotSet`イベントを返すカスタムアクションが予測された場合にのみ更新されます。

### 初期スロット値

ドメイン ファイル内のスロットの初期値を指定できます。

```yaml-rasa
slots:
  num_fallbacks:
    type: float
    initial_value: 0
    mappings:
    - type: custom
```

## 応答

応答は、カスタム コードを実行したり、イベントを返したりせずにユーザーにメッセージを送信するアクションです。これらの応答は、`応答`キーの下のドメイン ファイルで直接定義でき、ボタンや添付ファイルなどのリッチ コンテンツを含めることができます。応答とその定義方法の詳細については、「[応答」](./responses.md)を参照してください。

## フォーム

フォームは、アシスタントがユーザーから情報を収集するのを支援することを目的とした特別なタイプのアクションです。ドメイン ファイルの`フォーム` キーでフォームを定義します。フォームとその定義方法の詳細については、「[フォーム」](./forms.md)を参照してください。

## アクション

[アクションは](./actions.md)、ボットが実際に実行できるものです。たとえば、アクションは次のようになります。

*   ユーザーに応答し、
    
*   外部 API 呼び出しを行う
    
*   データベースをクエリする、または
    
*   何でも!
    

すべての[カスタム アクション](./custom-actions.md)は、アクション`に`リストする必要のないレスポンスを除き、すでに `response:` の下にリストされているため、ドメインにリストする必要があります。

### ドメインを受け取るアクションを選択する

> [!info] 3.4.3 の新機能
> アクションがドメインを受け取るかどうかを制御できます。

これを行うには、まずエンドポイント設定で選択的ドメインを有効にする必要があります。 `endpoints.yml action_endpoint`。

```YAML
# endpoints.yml
action_endpoint:
 url: "http://localhost:5055/webhook" # URL to your action server
 enable_selective_domain: true
```

**カスタムアクションの選択ドメインを有効にすると、ドメインは、必要と明示されているカスタムアクションにのみ送信されます。** rasa-sdk [[./action-server/validation-action.md#formvalidationaction クラス|`FormValidationAction`]] 親クラスは、常にドメインが送信されるため、このルールの例外です。アクションにドメインが必要かどうかを指定するには、`domain.yml` のアクションのリストでカスタムアクションに `{send_domain: true}` を追加します。

```YAML
# domain.yml
actions:
  - action_hello_world: {send_domain: True} # will receive domain
  - action_calculate_mass_of_sun # will not receive domain
  - validate_my_form # will receive domain
```

## セッション構成

会話セッションは、アシスタントとユーザーの間の対話を表します。会話セッションは、次の 3 つの方法で開始できます。

1.  ユーザーはアシスタントとの会話を開始します。
    
2.  ユーザーが、構成可能な非アクティブ期間の後に最初のメッセージを送信するか、または
    
3.  手動セッション開始は、`/session_start` インテントメッセージでトリガーされます。
    

`session_config` キーでドメインで新しい会話セッションがトリガーされるまでの非アクティブ期間を定義できます。

使用可能なパラメータは次のとおりです。

*   `session_expiration_time`は、新しいセッションが開始されるまでの非アクティブ時間を分単位で定義します。
*   `carry_over_slots_to_new_session` 既存のセットスロットを新しいセッションに引き継ぐかどうかを決定します。

デフォルトのセッション構成は次のようになります。

```yaml-rasa
session_config:
  session_expiration_time: 60  # value in minutes, 0 means infinitely long
  carry_over_slots_to_new_session: true  # set to false to forget slots between sessions
```

つまり、ユーザーが 60 分間非アクティブ状態が続いた後に最初のメッセージを送信すると、新しい会話セッションがトリガーされ、既存のスロットが新しいセッションに引き継がれます。`session_expiration_time`の値を`0`に設定すると、セッションが終了しないことを意味します(会話の最初に`action_session_start`アクションがトリガーされることに注意してください)。

> [!note] 
> セッションの開始により、デフォルトのアクション`action_session_start`がトリガーされます。デフォルトの実装では、既存のすべてのスロットが新しいセッションに移動します。すべての会話は`action_session_start`で始まることに注意してください。このアクションをオーバーライドすると、 たとえば、外部 API からのスロットでトラッカーを初期化するために使用されます call を呼び出したり、ボット メッセージで会話を開始したりします。のドキュメント [[./default-actions.md#カスタマイズ|セッション開始アクションのカスタマイズでは]]、その方法を示します。

## 設定

ドメイン ファイル内の`構成`キーは、`store_entities_as_slots` パラメーターを保持します。このパラメータは、ストーリーを読んでトラッカーに変換するコンテキストでのみ使用されます。パラメータが `True` に設定されている場合、該当するエンティティがストーリーに存在する場合、スロットはエンティティから暗黙的に設定されます。エンティティが`from_entity`スロットマッピングに一致する場合、`store_entities_as_slots`エンティティ値をそのスロットに配置するかどうかを定義します。したがって、このパラメーターは、ストーリーに明示的な`slot_was_set`ステップを手動で追加することをスキップします。デフォルトでは、この動作はオンになっています。

この機能をオフにするには、`store_entities_as_slots` パラメーターを `false` に設定します。

```yaml-rasa
config:
  store_entities_as_slots: false
```

> [!note] config.ymlをお探しですか?
> `config.yml`ファイルに関する情報をお探しの場合は、次のドキュメントを確認してください。 [モデル構成](./model-configuration.md)。