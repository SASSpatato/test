---
sidebar_label: Installing Rasa Open Source
title: Installing Rasa Open Source
description: Install Rasa Open Source on premises to enable local and customizable Natural Language Understanding and Dialogue Management.
---

## Rasa Open Sourceをインストールする

まず、`pip` のバージョンが最新であることを確認してください。

```bash
pip3 install -U pip
```

Rasa Open Sourceをインストールするには:

```bash
pip3 install rasa
```

> [!note]  
> テレメトリレポート Rasa Open Source を初めて実行すると、 収集されている匿名の使用状況データについて通知するメッセージ。 そのデータがどのように引き出され、そのデータが何に使用されるかについては、 [テレメトリのドキュメント](../telemetry/telemetry.md)。

**万丈！Rasa Open Source が正常にインストールされました。**

これで、次の方法で新しいプロジェクトを作成できるようになりました。

```bash
rasa init
```

最も重要な Rasa コマンドについては、[コマンド ライン インターフェイス](../command-line-interface.md)で学習できます。

## ソースからの構築

Rasa Open Sourceの開発版を使用したい場合は、GitHubから入手できます。

```bash
curl -sSL https://install.python-poetry.org | python3 -
git clone https://github.com/RasaHQ/rasa.git
cd rasa
poetry install
```

## 追加の依存関係

一部の機械学習アルゴリズムでは、追加の Python パッケージをインストールする必要があります。設置面積を小さくするために、既定ではインストールされません。

[モデルのチューニング](../tuning-your-model.md) のページは、アシスタントに適した構成を選択し、追加の依存関係について警告するのに役立ちます。

> [!tip]  
> 私にすべてをください!追加の依存関係が気にならない場合は、
> 
> ```bash
> pip3 install 'rasa[full]'
> ```
> 
> すべての構成に必要なすべての依存関係をインストールします。

### Python 3.10 の要件

*Linux を使用している場合*、`rasa[full]` をインストールする`と、トークナイザー`のインストール中に失敗する可能性があり、 `暗号化`。

これを解決するには、次の手順に従って Rust コンパイラをインストールする必要があります。

```bash
apt install rustc && apt install cargo
```

Rust コンパイラを初期化したら、コンソールを再起動してインストールを確認する必要があります。

```bash
rustc --version
```

PATH 変数が自動的に設定されていない場合は、次のコマンドを実行します。

```bash
export PATH="$HOME/.cargo/bin:$PATH"
```

*macOSを使用している場合は*、`rasa[full]`を(pip経由またはソースから)インストールすると、`トークナイザー`のインストール中に失敗する可能性があることに注意してください(問題については[、こちらで](https://github.com/huggingface/tokenizers/issues/1050)詳しく説明します)。

これを解決するには、次の手順に従って Rust コンパイラをインストールする必要があります。

```bash
brew install rustup
rustup-init
```

Rust コンパイラを初期化したら、コンソールを再起動してインストールを確認する必要があります。

```bash
rustc --version
```

PATH 変数が自動的に設定されていない場合は、次のコマンドを実行します。

```bash
export PATH="$HOME/.cargo/bin:$PATH"
```

### spaCyの依存関係

spaCy モデルの詳細については、[spaCy のドキュメント](https://spacy.io/usage/models)をご覧ください。

次のコマンドでインストールできます。

```bash
pip3 install 'rasa[spacy]'
python3 -m spacy download en_core_web_md
```

> [!tip] 
>  `zsh` を使用する ?zsh では、角括弧はコマンド ライン上のパターンとして解釈されます。角括弧でコマンドを実行するには、`pip3 install 'rasa[spacy]'` のように引数を角括弧で囲むか、`pip3 install rasa[spacy]` のように円記号を使用して角括弧をエスケープします。ドキュメントでは、どのシェルでも期待どおりに動作するため、ドキュメントで前者の方法(`pip3 install 'rasa[spacy]'`)を使用することをお勧めします

これにより、Rasa Open Source、spaCy、および英語用の言語モデルがインストールされますが、他の多くの言語も利用できます。spaCy のデフォルトの小型`en_core_web_sm`モデルではなく、少なくとも「中型」モデル (`_md`) を使用することをお勧めします。小規模なモデルでは、実行に必要なメモリは少なくなりますが、意図分類のパフォーマンスが低下する可能性があります。

### MITIEの依存関係

まず、

```bash
pip3 install git+https://github.com/mit-nlp/MITIE.git
pip3 install 'rasa[mitie]'
```

そして、 [MITIEモデル](https://github.com/mit-nlp/MITIE/releases/download/v0.4/MITIE-models-v0.2.tar.bz2)。必要なファイルは `total_word_feature_extractor.dat` です。これを保存する どこでも。MITIEを利用するには、 このファイルがどこにあるかを教えてください(この例では、 プロジェクトディレクトリの `data` フォルダー)。

## バージョンのアップグレード

インストールされているバージョンの Rasa Open Source を PyPI から最新バージョンにアップグレードするには:

```bash
pip3 install --upgrade rasa
```

特定のバージョンをダウンロードするには、バージョン番号を指定します。

```bash
pip3 install rasa==3.0
```