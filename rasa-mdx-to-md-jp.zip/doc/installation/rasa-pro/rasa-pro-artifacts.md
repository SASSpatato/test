---
sidebar_label: Rasa Pro Artifacts
title: Rasa Pro Artifacts
description: artifacts that ship with Rasa Pro.
---

*   **Rasa Pro**、Rasa Open Sourceのドロップイン代替品
*   **Rasa Pro サービス**、Rasa Open Source 上の柔軟なインフラストラクチャと API。Rasa Pro Servicesは、本番アシスタントとは別に、並行してデプロイする必要があります。

Rasa Proには、Rasa Open Sourceのすべての機能と追加機能を含む、Rasa Open Sourceのドロップイン代替品であるRasa Plus Pythonパッケージが含まれています。Rasa Proの機能は、Rasa Open Sourceとシームレスに統合されたプラグインアーキテクチャ上に構築されています。

たとえば、下の図では、Rasa Plus でフック実装としてトレースが実行されており、その仕様は Rasa Open Source で定義および登録されています。

![image](/static/img/rasa-plus-architecture.png)

フックは、`endpoints.yml`で指定されたトレースバックエンドを設定し、モデルのトレーニングとメッセージ処理アクションをインストルメント化します。その後、フックは、Rasa Open SourceコマンドラインのエントリポイントであるRasa Open Sourceメインモジュール内で呼び出されます。

プラグインアーキテクチャにより、Rasa Proは、同じ実行可能なコマンド名(`rasa`)を維持しながら、Rasa Open Source引数パーサーの拡張を継続できます。