---
sidebar_label: Rasa Pro Installation
title: Rasa Pro Installation
description: Install Rasa Pro in your production environment to create an enterprise ready Rasa deployment.
---

このセクションでは、Rasa Open Sourceのドロップイン代替エンタープライズ対応バージョンである**Rasa Pro**を開発環境にインストールする方法を学習します。

デプロイの詳細については、次のセクションを参照してください。

*   [本番環境での Rasa Pro のデプロイ](../../deploy/deploy-rasa)
*   [本番環境でのRasa Pro Servicesのデプロイ](../../deploy/deploy-rasa-pro-services)

Rasa Pro と Rasa Pro Services の異なるバージョン間の互換性の詳細については、[互換性マトリックス](../../compatibility-matrix.md)を参照してください。

## セットアップ競争

Rasa Proをインストールするには、アクセス資格情報と使用するためのライセンスが必要です。以下の手順は、資格情報とライセンスがあることを前提としています。

Rasa Proは、Rasa Open Sourceのドロップイン代替およびエンタープライズ対応バージョンです。追加機能はプラグインを通じて提供され、既存のRasa Open Source CLIコマンドとパラメータを以前どおりに使用し続けることができます。

Rasa Open Source の代わりに Rasa Pro をインストールしても、Rasa Open Source を中心に構築した既存のスクリプト、自動化、または機能が壊れることはありません。

### Python パッケージのインストール

Rasa Pro Python パッケージの名前は `rasa-plus` です。`rasa-plus` pythonパッケージとDockerコンテナは、GCPアーティファクトレジストリでホストされています。前提条件として、次のものが必要です。

*   をクリックして Google Cloud CLI [をインストールし](https://cloud.google.com/sdk/docs/install)ます。
*   を使用して、使用しているユーザーまたはサービスアカウントに、リポジトリにアクセスするために必要な権限があることを確認します。

#### 認証のセットアップ

認証するには、Rasa が提供するサービス アカウント キー ファイルを使用して Google Cloud で認証する必要があります。

サービス アカウント キーを使用して GCP で認証します。

```sh
gcloud auth activate-service-account --key-file=service-account.json
```

キーリングをインストールしてから、GCP Artifact Registry をサポートするバックエンドをインストールしてから、Pip が GCP Artifact Registry で認証できるようにキーリングを設定します。

```sh
pip install keyring
pip install keyrings.google-artifactregistry-auth
```

バックエンドが正しくインストールされていることを確認する

```sh
keyring --list-backends
```

結果には`、ChainerBackend` と `GooglePythonAuth` が含まれます。

#### `pip` を使用したインストール

`.pypirc` ファイルに次の設定を入力します。これは次の場所にあります。

*   LinuxおよびMacOS:`$HOME / .pypirc`
*   Windows: `%USERPROFILE%.pypirc`

```
[distutils]
index-servers =
    rasa-plus-py

[rasa-plus-py]
repository: https://europe-west3-python.pkg.dev/rasa-releases/rasa-plus-py/

```

次に、これらの特定の設定を pip 構成ファイルに追加します。この場所は、ユーザーごとのファイルを更新するか、使用している仮想環境に固有のファイルを更新するかによって異なります。

オペレーティングシステムユーザーに関連付けられているファイルの場合:

*   Linux: `$HOME/.config/pip/pip.conf` または `$HOME/.pip/pip.conf`
*   MacOS: `/Library/Application Support/pip/pip.conf` または `$HOME/.config/pip/pip.conf`
*   Windows: `%APPDATA%pippip.ini` または `%USERPROFILE%pippip.ini`

仮想環境の場合:

*   LinuxおよびmacOS:`$VIRTUAL_ENV / pip.conf`
*   Windows: `%VIRTUAL_ENV%pip.ini`

```
[global]
extra-index-url = https://europe-west3-python.pkg.dev/rasa-releases/rasa-plus-py/simple/

```

最後に、`pip install rasa-plus`を実行できるはずです。

#### `詩`でインストールする

`詩`で`rasa-plus`をインストールするには、インストールする前にアーティファクトレジストリURLを`rasa-plus`に関連付ける必要があります。`potry` を GCP 認証設定で動作させるには、potry を最新のマイナー (`1.2.0`) にアップグレードする必要があることに注意してください。次の手順に進みます。

1.  走る `poetry self add "keyrings.google-artifactregistry-auth"`
2.  このセクションを `pyproject.toml` に追加します。

```toml
[[tool.poetry.source]]
name = "rasa-plus"
url = "https://europe-west3-python.pkg.dev/rasa-releases/rasa-plus-py/simple"
default = false
secondary = true

```

3.  `poetry install` を実行します。

### Docker イメージのインストール

Rasa Pro Docker イメージの名前は `rasa-plus` です。Docker イメージは、GCP アーティファクト レジストリでホストされています。前提条件として、次のものが必要です。

*   をクリックして Google Cloud CLI [をインストールし](https://cloud.google.com/sdk/docs/install)ます。
*   を使用して、使用しているユーザーまたはサービスアカウントに、リポジトリにアクセスするために必要な権限があることを確認します。

認証するには、Rasa が提供するサービス アカウント キー ファイルを使用して Google Cloud で認証する必要があります。

```bash
gcloud auth activate-service-account --key-file=${KEYFILE}
gcloud auth configure-docker europe-west3-docker.pkg.dev
docker pull europe-west3-docker.pkg.dev/rasa-releases/rasa-plus/rasa-plus
```

### 中間リポジトリの使用

独自の中間リポジトリを使用してライブラリや依存関係(Artifactory や Nexus Repository Manager など)をキャッシュする場合は、GCP Artifact Registry で認証できる一連の静的認証情報を生成する必要がある場合があります。

前提条件として、次のものが必要です。

*   をクリックして Google Cloud CLI [をインストールし](https://cloud.google.com/sdk/docs/install)ます。
*   を使用して、使用しているユーザーまたはサービスアカウントに、リポジトリにアクセスするために必要な権限があることを確認します。

資格情報を生成するには、次のコマンドを実行します。

```sh
gcloud artifacts print-settings python 
    --project=rasa-releases 
    --repository=rasa-plus-py 
    --location=europe-west3 
    --json-key=service-account.json
```

資格情報は出力で確認できます。ユーザー名は`_json_key_base64`で、パスワードは base64 でエンコードされた長い文字列になります。

### ランタイム構成

Rasa Pro は env var `RASA_PRO_LICENSE`でライセンスを検索します。このenv varは端末で一時的に設定できますが、Rasa Proを実行するたびに設定しなくても済むように、永続的に設定することをお勧めします。

バッシュ:

```sh
## Temporary
export RASA_PRO_LICENSE=<your-license-string>

## Persistent
echo "export RASA_PRO_LICENSE=<your-license-string>" >> ~/.bashrc
## If you're using a different flavor of bash e.g. Zsh, replace .bashrc with your shell's initialization script e.g. ~/.zshrc
```

Windows Powershell:

```powershell
## Temporary
$env: RASA_PRO_LICENSE=<your-license-string>

## Persistent
[System.Environment]::SetEnvironmentVariable('RASA_PRO_LICENSE','<your-license-string>')
```

その後、通常どおり [`rasa` CLI](https://rasa.com/docs/rasa/command-line-interface) を使用できます。

```sh
rasa init
```

> [!note]  
> ローカル開発環境で Jaeger をバックエンドとして使用したトレースを有効にした後に `rasa train` または `rasa run` を実行すると、このエラー `OSError: [Errno 40] Message too long` が発生することがあります。
> 
> これは、ローカル開発環境の OS が UDP パケット サイズを制限していることが原因である可能性があります。現在の UDP パケット サイズは、macOS で `sysctl net.inet.udp.maxdgram` を実行することで確認できます。UDP パケットサイズを増やすには、 を実行します `sudo sysctl -w net.inet.udp.maxdgram=65535` 。

万丈！これで、開発環境に Rasa Pro が正常にインストールされました。運用環境のデプロイの詳細については、以下を参照してください。

*   [本番環境での Rasa Pro のデプロイ](../../deploy/deploy-rasa)
*   [本番環境でのRasa Pro Servicesのデプロイ](../../deploy/deploy-rasa-pro-services)