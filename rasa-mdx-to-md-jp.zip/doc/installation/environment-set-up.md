---
sidebar_label: Setting up your environment
title: Setting up your environment
description: How to set up your environment before installing Rasa
---

## 1. Python環境のセットアップ

Python 環境がすでに構成されているかどうかを確認します。

```bash
python3 --version
pip3 --version
```

> [!note]  Python3 対応バージョン 
> 現在、rasa は `Python バージョン 3.7`、`3.8`、`3.9`、`3.10` をサポートしています。Python `3.10` はバージョン `3.4.x` 以降でのみサポートされていることに注意してください。さらに、Python `3.10` を使用した Apple Silicon への rasa インストールは `3.4.x` では機能しませんが、`3.5.x` 以降でサポートされます。

これらのパッケージが既にインストールされている場合、これらのコマンドには各手順のバージョン番号が表示され、次の手順にスキップできます。

それ以外の場合は、以下の手順に従ってインストールしてください。

**Ubuntuの**

`apt` を使用して関連するパッケージを取得し、`pip` を使用して virtualenv をインストールします。

```bash
sudo apt update
sudo apt install python3-dev python3-pip
```

**macOSの**

[Homebrew](https://brew.sh) パッケージ マネージャーをまだインストールしていない場合は、インストールします。

完了したら、Python3 をインストールできます。

```bash
brew update
brew install python
```

**ウィンドウズ**

Python が依存関係をコンパイルできるように、Microsoft VC++ コンパイラがインストールされていることを確認します。コンパイラは[Visual Studio](https://visualstudio.microsoft.com/visual-cpp-build-tools/)から取得できます。インストーラーをダウンロードし、リストで VC++ ビルド ツール を選択します。Windows 用の [Python 3](https://www.python.org/downloads/windows/) (64 ビット版) をインストールします。

```bat
C:> pip3 install -U pip
```

## 2. 仮想環境のセットアップ

この手順は省略可能ですが、Python プロジェクトを分離することを強くお勧めします 仮想環境を使用します。次のようなツール [virtualenv](https://virtualenv.pypa.io/en/latest/) と [virtualenvwrapper](https://virtualenvwrapper.readthedocs.io/en/latest/) は、システム全体にパッケージをインストールするよりもクリーンな分離された Python 環境を提供します (依存関係の競合を防ぐため)。また、root 権限なしでパッケージをインストールすることもできます。

**Ubuntuの**

Python インタープリターを選択し、それを保持する `./venv` ディレクトリを作成して、新しい仮想環境を作成します。

```bash
python3 -m venv ./venv
```

仮想環境をアクティブ化します。

```bash
source ./venv/bin/activate
```

**macOSの**

Python インタープリターを選択し、それを保持する `./venv` ディレクトリを作成して、新しい仮想環境を作成します。

```bash
python3 -m venv ./venv
```

仮想環境をアクティブ化します。

```bash
source ./venv/bin/activate
```

**ウィンドウズ**

Python インタプリタを選択し、それを保持する `.venv` ディレクトリを作成して、新しい仮想環境を作成します。

```bat
C:> python3 -m venv ./venv
```

仮想環境をアクティブ化します。

```bat
C:> .venvScriptsactivate
```

## M1 / M2 (Apple Silicon) の制限事項

Apple Silicon への Rasa インストール*では、*デフォルトでは [Apple Metal](https://developer.apple.com/metal/) は使用されません。 Apple Silicon で GPU を使用すると、 [`DIETClassifier`](../components.md#dietclassifier)と[[policies#TEDポリシー|`TEDPolicy`]]を劇的に。ただし、オプションの依存関係をインストールして自分でテストしたり、`pip3 install 'rasa[metal]'` を使用して他のコンポーネントで試したりすることもできます。

現在、Rasa のすべての依存関係が Apple Silicon をネイティブにサポートしているわけではありません。これにより、次の制限が生じます。

*   Apple Silicon では Duckling を Docker コンテナとして実行することはできません。[アヒルの子エンティティ抽出器](../components.md#ducklingentityextractor)を使用する場合は、 アヒル。この進捗状況は、 ア[ヒルの子プロジェクト](https://github.com/facebook/duckling/issues/695)。
*   Apple Silicon 上の Rasa は、[`ConveRTFeaturizer` コンポーネント](../components.md#convertfeaturizer)またはそれを含むパイプラインをサポートしていません。このコンポーネントは、現在 `tensorflow-text` に依存しています。 は Apple Silicon では利用できません。この進捗状況は、 [Tensorflow Text プロジェクト](https://github.com/tensorflow/text/issues/823)。