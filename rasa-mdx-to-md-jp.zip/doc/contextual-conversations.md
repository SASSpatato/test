---
id: contextual-conversations
sidebar_label: Contextual Conversations
title: Contextual Conversations
abstract: Taking context into account is often key to providing a good user experience. This page is a guide to creating contextual conversation patterns.
---

コンテキスト会話では、会話の前のステップを超えた何かが、次に何が起こるべきかに影響します。たとえば、ユーザーが「いくつ?」と尋ねた場合、メッセージだけでは、ユーザーが何について尋ねているのかは明らかではありません。アシスタントが「メールが届きました!」と言う文脈では、応答は「メールボックスに 5 つの文字があります」になる可能性があります。未払いの請求書に関する会話の文脈では、「延滞請求書が 3 つあります」という応答が返ってくる可能性があります。アシスタントは、次のアクションを選択するために、前のアクションを知っている必要があります。

コンテキストを意識した会話アシスタントを作成するには、会話履歴が次の応答にどのように影響するかを定義する必要があります。

たとえば、ユーザーがサンプルのコンサートボットに開始方法を尋ねると、ボットは音楽が好きかどうかに基づいて異なる応答をします。

音楽が好きなユーザーとの会話:

どうすれば始められますか?コンサートや会場探しのお手伝いをします。音楽は好きですか?はい素晴らしい！「コンサートを探してくれ」とか「良い会場は何か」などと聞いてみてください。

音楽が好きではないユーザーとの会話:

どうすれば始められますか?コンサートや会場探しのお手伝いをします。音楽は好きですか?いいえああ違います！

## コンテキスト会話パターンの作成に関するステップバイステップガイド

### 1. スロットの定義

[スロット](domain.md#slots)はアシスタントの記憶です。スロットには、アシスタントが後で参照する必要がある情報が格納され、`slot_was_set`イベントに基づいて会話の流れを指示できます。さまざまな [[domain.md#スロットタイプ|スロットの種類]] があり、それぞれが独自の方法で会話フローに影響を与えます。

コンサートボットの例では、`likes_music`スロットはブールスロットです。それが真の場合、ボットはイントロメッセージを送信します。falseの場合、ボットは別のメッセージを送信します。スロットとそのタイプをドメインで定義します。

```yaml-rasa
slots:
  likes_music:
    type: bool
    mappings:
    - type: custom
```

### 2. ストーリーの作成

[ストーリーは](./stories.md)、会話がどのように進むべきかを示す例です。上記の例では、コンサートボットは、次の 2 つのストーリーのために、音楽が好きなユーザーとそうでないユーザーに対して異なる反応を示します。

```yaml-rasa
stories:
  - story: User likes music
    steps:
    - intent: how_to_get_started
    - action: utter_get_started
    - intent: affirm
    - action: action_set_music_preference
    - slot_was_set:
      - likes_music: True
    - action: utter_awesome

  - story: User doesn't like music
    steps:
    - intent: how_to_get_started
    - action: utter_get_started
    - intent: deny
    - action: action_set_music_preference
    - slot_was_set:
      - likes_music: False
    - action: utter_goodbye
```

これらのストーリーは、ユーザーの意図 (`肯定`または`否定`) に基づいて異なります。ユーザーの意図に基づいて、カスタム アクションは会話をさらに指示するスロットを設定します。

### 3. TEDPolicy の構成

コンテキストを考慮してストーリーを追加するだけでなく、機械学習ポリシーは、モデルが目に見えない会話パスに一般化するのに役立ちます。**機械学習ポリシーを使用することは、アシスタントの制御を手放すことを意味するものではないことを理解することが重要です。**ルールベースのポリシーが予測を行うことができる場合、その予測は常により高い [[./policies.md#ポリシーの優先順位|ポリシーの優先順位]] を持ち、次のアクションを予測します。

[TEDPolicy](https://blog.rasa.com/unpacking-the-ted-policy-in-rasa-open-source/) は、予期しないユーザーの行動を処理するために作られています。たとえば、以下の会話([Rasa X/Enterprise](https://rasa.com/docs/rasa-enterprise/user-guide/review-conversations/)での会話から抽出)では、次のようになります。

```yaml-rasa
stories:
- story: Story from conversation with a2baab6c83054bfaa8d598459c659d2a on November 28th 2019
  steps:
  - checkpoint: STORY_START
  - intent: greet
  - action: action_greet_user
  - slot_was_set:
    - shown_privacy: true
  - intent: ask_whoisit
  - action: action_chitchat
  - intent: ask_whatspossible
  - action: action_chitchat
  - intent: telljoke
  - action: action_chitchat
  - intent: how_to_get_started
    entities:
    - product: enterprise
  - slot_was_set:
    - product: enterprise
  - action: utter_explain_enterprise
  - action: utter_also_explain_nlucore
  - intent: affirm
  - action: utter_explain_nlu
  - action: utter_explain_core
  - action: utter_direct_to_step2
```

ここでは、ユーザーが最初にいくつかのおしゃべりタスクを完了し、最終的にRasa X / Enterpriseをどのように使い始めることができるかを尋ねていることがわかります。TEDPolicyは、Rasa X/Enterpriseをユーザーに説明する必要があると正しく予測し、最初にすべての適格な質問をすることなく、ユーザーを入門の道に連れて行きます。

機械学習ポリシーはこの状況に一般化されているため、このストーリーをトレーニング データに追加して、ボットを継続的に改善し、将来的にモデルの一般化を改善する必要があります。[Rasa X/Enterprise](https://rasa.com/docs/rasa-enterprise/) は、ボットを改善し、よりコンテキストに応じたものにするのに役立つツールです。

#### 設定`max_history`

通常、アシスタントに関連するコンテキストは一定量のみです。[[policies.md#マックス履歴|`max_history`]]は、Rasa 対話管理ポリシーのハイパーパラメーターで、次に実行するアクションを決定するためにモデルがダイアログのステップ数を制御します。

以下のストーリーでは、ユーザーが3回連続で助けを求めています。最初の 2 回はボットが同じメッセージを送信しますが、3 回目は人間にメッセージを渡します

```yaml-rasa
stories:
  - story: user persists in asking for help
    steps:
    - intent: help
    - action: utter_help
    - intent: help
    - action: utter_help
    - intent: help
    - action: action_human_handoff
```

モデルがこのパターンを学習するには、少なくとも前の4つのステップ、つまり4つのステップの`max_history`を知る必要があります。`max_history`が 3 の場合、モデルには、ユーザーがすでに 2 つのヘルプ リクエストを送信していることを確認するのに十分なコンテキストがなく、人間の引き継ぎアクションを予測することはありません。

`max_history`を設定するには、次のように構成ファイルのポリシー設定に渡します。

```yaml-rasa
policies:
  - name: "TEDPolicy"
    max_history: 5
```

アシスタントが次に何をすべきかを正確に予測するために必要なコンテキストを最も多く考慮できるように、`max_history`が十分に高く設定されていることを確認する必要があります。詳細については、[フィーチャライザー](policies.md#フィーチャライザー)に関するドキュメントを参照してください。

## 概要

アシスタントがコンテキストに応じた会話を行えるようにするために適用できる概念の概要を次に示します。

- [ ] コンテキストに応じた会話用のストーリーを書く
- [ ] スロットを使用して、後で使用するためにコンテキスト情報を格納します
- [ ] ボットが必要とするコンテキストの量に応じて、ポリシーのmax_historyを適切に設定します
- [ ] TEDPolicy を使用して、目に見えない会話パスに一般化する