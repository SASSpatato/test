---
id: model-storage
sidebar_label: Model Storage
title: Model Storage
abstract: |
  Models can be stored in different places after you trained your assistant. This
  page explains how to configure Rasa to load your models.
---

トレーニング済みモデルは、次の 3 つの異なる方法で読み込むことができます。

1.  ローカルディスクからモデルをロードします([[./model-storage.md#ディスクからモデルをロード|ディスクからモデルをロード]])
    
2.  独自の HTTP サーバーからモデルを取得します ([[./model-storage.md#サーバーからモデルをロード|サーバーからモデルをロード]])
    
3.  S3 などのクラウドストレージからモデルをフェッチします ([[./model-storage.md#クラウドからモデルを読み込む|クラウドからモデルをロード]])
    

デフォルトでは、RasaのCLIのすべてのコマンドは、ローカルディスクからモデルをロードします。

## ディスクからモデルをロード

デフォルトでは、モデルはローカルディスクからロードされます。モデルへのパスは、`--model` パラメーターで指定できます。

```bash
rasa run --model models/20190506-100418.tar.gz
```

最新のモデルをディレクトリにロードする場合は、ファイルの代わりにディレクトリを指定できます。

```bash
rasa run --model models/
```

Rasaは、そのディレクトリ内のすべてのモデルをチェックし、最後にトレーニングされたモデルをロードします。

`--model` 引数を指定しない場合、Rasa は `models/` ディレクトリでモデルを探します。次の 2 つの呼び出しは、同じモデルを読み込みます。

```bash
# this command will load the same model
rasa run --model models/
# ... as this command (using defaults)
rasa run
```

## サーバーからモデルをロード

サーバーからモデルを定期的にフェッチしてデプロイするように Rasa サーバーを構成できます。

### Rasaの設定方法

HTTP サーバーを別の URL からモデルを取得するように構成するには、`endpoints.yml`に追加します。

```yaml-rasa
models:
  url: http://my-server.com/models/default
  wait_time_between_pulls: 10   # In seconds, optional, default: 100
```

サーバーは、`wait_time_between_pulls`ごとに圧縮されたモデルの`URL`を照会します お代わり。

サーバーの起動時にのみモデルをプルする場合は、プル間の時間を`null`に設定できます。

```yaml-rasa
models:
  url: http://my-server.com/models/default
  wait_time_between_pulls: null  # fetches model only once
```

### サーバーの設定方法

Rasa は、 `endpoints.yml`、たとえば上記の例 `http://my-server.com/models/default` で。任意の URL を使用できます。`GET` リクエストには、最後にダウンロードしたモデルのモデル ハッシュを含む `If-None-Match` ヘッダーが含まれます。Rasa Open Sourceからサーバーへのリクエストの例は、次のようになります。

```bash
curl --header "If-None-Match: d41d8cd98f00b204e9800998ecf8427e" http://my-server.com/models/default
```

この `GET` 要求に対するサーバーの応答は、次のいずれかである必要があります。

*   ステータスコード`200`、圧縮されたRasaモデル、およびモデルのハッシュへの応答に`ETag`ヘッダーを設定します。
*   ステータスコード `304` で、`If-None-Match` ヘッダーは、サーバーが返すモデルと一致します。

Rasa は、キャッシュに `If-None-Match` ヘッダーと `ETag` ヘッダーを使用します。ヘッダーを設定すると、同じモデルを何度も再ダウンロードする必要がなくなり、帯域幅とコンピューティング リソースが節約されます。

## クラウドからモデルを読み込む

リモートストレージからモデルを取得するように Rasa サーバーを構成することもできます。

```bash
rasa run --model 20190506-100418.tar.gz --remote-storage aws
```

圧縮されたモデルは、クラウド ストレージからダウンロードされ、解凍され、デプロイされます。Rasa は、以下からのモデルの読み込みをサポートします。

*   [アマゾンS3](https://aws.amazon.com/s3/)、
*   [Google Cloud Storage、](https://cloud.google.com/storage/)
*   [Azure Storage](https://azure.microsoft.com/services/storage/) と
*   [[./model-storage.md#その他のリモートストレージ|その他のリモートストレージ]]。

モデルは、ストレージ サービスのルート フォルダーに格納する必要があります。現在、クラウドストレージ上のパスを手動で指定することはできません。

### Amazon S3 ストレージ

Amazon S3 は、`pip3` を使用して追加の依存関係としてインストールする必要がある `boto3` パッケージを使用してサポートされます。

```bash
pip3 install boto3
```

Rasaがモデルを認証してダウンロードできるようにするには、ストレージを必要とするコマンドを実行する前に、次の環境変数を設定する必要があります。

*   `AWS_SECRET_ACCESS_KEY`: AWS S3 シークレットアクセスキーを含む環境変数
    
*   `AWS_ACCESS_KEY_ID`: AWS S3 アクセスキー ID を含む環境変数
    
*   `AWS_DEFAULT_REGION`: AWS S3 バケットのリージョンを指定する環境変数
    
*   `BUCKET_NAME`: S3 バケットを指定する環境変数
    
*   `AWS_ENDPOINT_URL`: AWS S3 リクエストに使用する完全な URL。完全な URL ("http/https" スキームを含む) を指定する必要があります (`例: https://s3.amazonaws.com`)。バケット名を`環境変数BUCKET_NAME`設定すると、バケットまたはオブジェクトの URL を `AWS_ENDPOINT_URL` に指定しないでください。
    

すべての環境変数を設定したら、 `remote-storage` オプションを `aws` に設定します。

```bash
rasa run --model 20190506-100418.tar.gz --remote-storage aws
```

### Google クラウド ストレージ

Google Cloud Storage(GCS)は、`pip3`を使用して追加の依存関係としてインストールする必要がある`google-cloud-storage`パッケージを使用してサポートされます。

```bash
pip3 install google-cloud-storage
```

Google App Engine または Compute Engine で Rasa を実行している場合、認証認証情報はすでに設定されています(同じプロジェクト内の GCS 用)。この場合、追加の環境変数の設定をスキップできます。

ローカルで実行している場合、または GAE または GCE の外部のマシンで実行している場合は、認証の詳細を Rasa に手動で提供する必要があります。

1.  [GCS のドキュメント](https://cloud.google.com/docs/authentication/getting-started#auth-cloud-implicit-python)を確認する をクリックし、「サービスアカウントの作成」の説明に従い、 「環境変数の設定」
2.  GCS の手順を完了したら、GCS にアクセスできるサービス アカウント キー ファイルのパスに呼び出される `GOOGLE_APPLICATION_CREDENTIALS` 環境変数を設定する必要があります。

すべての環境変数が設定されたら、 `remote-storage` オプションを `gcs` に設定します。

```bash
rasa run --model 20190506-100418.tar.gz --remote-storage gcs
```

### Azure ストレージ

Azure Storage は、`pip3` を使用して追加の依存関係としてインストールする必要がある `azure-storage-blob` パッケージを使用してサポートされます。

```bash
pip3 install azure-storage-blob
```

Rasaがモデルを認証してダウンロードできるようにするには、ストレージを必要とするコマンドを実行する前に、次の環境変数を設定する必要があります。

*   `AZURE_CONTAINER`: Azure コンテナー名を含む環境変数
    
*   `AZURE_ACCOUNT_NAME`: Azure アカウント名を含む環境変数
    
*   `AZURE_ACCOUNT_KEY`: アカウントキーを含む環境変数
    

すべての環境変数を設定したら、 `remote-storage` オプションを `Azure` に設定します。

```bash
rasa run --model 20190506-100418.tar.gz --remote-storage azure
```

### その他のリモートストレージ

他の Cloud Storage を使用する場合は、[`rasa.nlu.persistor.Persistor`](https://github.com/RasaHQ/rasa/blob/3.6.x/reference/rasa/nlu/persistor) クラスの独自の Python 実装を提供できます。

`リモートストレージ`オプションをパーシスタント実装のモジュールパスに設定して、Rasaサーバーを起動できます。

```bash
rasa run --remote-storage <your module>.<class name>
```