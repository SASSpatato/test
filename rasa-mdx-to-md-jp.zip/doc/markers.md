---
id: markers
sidebar_label: Markers
title: Markers
description: Find out how to mark points of interest in dialogues using Marker conditions.
abstract: Markers are conditions used to describe and mark points of interest in dialogues.
---

> [!caution]
> 
> この機能は現在実験段階であり、将来的に変更または削除される可能性があります。フォーラムでフィードバックを共有して、本番環境に対応できるようにしてください。

> [!danger] 非推奨 
> Rasa Open Source の今後のリリース バージョン 3.7 では、この実験的な機能を削除します。Rasa Proのマーカー機能に関するドキュメントについては、[ここをクリックして](./monitoring/analytics/realtime-markers.md)ください

## 概要

マーカーは、ボットを評価するためのダイアログ内の関心のあるポイントを記述およびマークできる条件です。

Rasa では、ダイアログは、実行されたボット アクション、検出されたインテント、設定されたスロットを含む一連のイベントとして表されます。マーカーを使用すると、このようなイベントの条件を記述できます。条件が満たされると、関連するイベントにマークが付けられ、さらなる分析または検査が行われます。

マーカーにはいくつかのダウンストリーム アプリケーションがあります。たとえば、**ダイアログの完了**や**タスクの成功**など、ボットの**主要業績評価指標 (KPI)** を定義および測定するために使用できます。[カーボンボット](https://rasa.com/blog/using-conversation-tags-to-measure-carbon-bots-success-rate/)を取る たとえば、ユーザーが飛行による二酸化炭素排出量を相殺するのに役立ちます。Carbon Botの場合、ダイアログの完了を「必須のスロットがすべて埋まっている」と定義できます。 タスクの成功は、「すべての必須スロットが埋められ、炭素推定値が正常に計算された」と評価されます。これらの重要なイベントが発生したときにマークを付けることで、Carbon Botの成功率を測定できます。

マーカーを使用すると、重要なイベントを表示してさらに検査することで**、対話を診断**することもできます。たとえば、Carbon Bot はスロット`のtravel_departure`と`travel_destination`を正常に設定する傾向がありますが、`travel_flight_class`スロットの設定に失敗する傾向があります。マーカーを定義して、この動作が発生する頻度を定量化し、関連するダイアログをレビュー用に表示できます。 [会話駆動型開発 (CDD)。](./conversation-driven-development.md)

マーカー定義は、マーカー構成ファイル内の `YAML` で記述されます。たとえば、Carbon Botの対話の完了とタスクの成功を定義するマーカーは次のとおりです。

```yaml
marker_dialogue_completion:
  and:
    - slot_was_set: travel_departure
    - slot_was_set: travel_destination
    - slot_was_set: travel_flight_class

marker_task_success:
  description: "Measure task success where all required slots are set and the custom action was triggered"
  and:
    - slot_was_set: travel_departure
    - slot_was_set: travel_destination
    - slot_was_set: travel_flight_class
    - action: provide_carbon_estimate
```

そして、以下は、`travel_flight_class`を除くすべての必須スロットが設定されているダイアログを表示するためのマーカーです。

```yaml
marker_dialogue_mandatory_slot_failure:
  and:
    - slot_was_set: travel_departure
    - slot_was_set: travel_destination
    - not:
      - slot_was_set: travel_flight_class
```

次のセクションでは、マーカー定義の記述方法、既存のダイアログに適用する方法、および出力形式について説明します。

## マーカーの定義

マーカーは、`YAML`で記述されたマーカー構成ファイルで定義する必要があります。各マーカーには**一意の識別子**が必要であり、少なくとも 1 つの**イベント条件**で構成されます。マーカーには**演算子**を含めることもでき、より微妙な動作を表現したり、イベント条件を組み合わせたりすることができます。

次のマーカー定義について考えてみましょう。

```yaml
marker_mood_expressed:
  description: "Mood expressed was either unhappy or great"
  or:
    - intent: mood_unhappy
    - intent: mood_great
```

一意のマーカー識別子は`marker_mood_expressed`です。このマーカー定義には、1 つの演算子 `or` と 2 つのイベント条件 `intent (mood_unhappy` と `intent: mood_great)` が含まれています。

このマーカーは、ユーザーが`mood_unhappy`または`mood_great`を表現したダイアログのすべてのポイントで当てはまります。より正確には、マーカーは、`mood_unhappy`または`mood_great`に等しい`インテント`を持つ`UserUttered()`であるすべてのイベントに対してtrueになります。

### イベント条件

次のイベント条件ラベルがサポートされています。

*   `action`: 指定されたボットアクションが実行されました。
*   `インテント`: 指定されたユーザーインテントが検出されました。
*   `slot_was_set`: 指定されたスロットが設定されました。

ラベルの否定形式もサポートされています。

*   `not_action`: イベントは指定されたボット アクションではありません。
*   `not_intent`: イベントは指定されたユーザーインテントではありません。
*   `slot_was_not_set`:指定したスロットが設定されていません。

### 演算子

次の演算子がサポートされています。

*   `および`: リストされたすべての条件が適用されます。
*   `または`: 記載されている条件のいずれかが適用されます。
*   `not`: 条件は適用されませんでした。この演算子は 1 つの条件のみを受け入れます。
*   `seq`: 指定された順序で適用される条件のリストで、その間に任意の数のイベントが発生します。
*   `at_least_once`: リストされたマーカー定義は少なくとも 1 回発生しました。最初に出現した場合にのみマークされます。
*   `never`: リストされたマーカー定義は発生しません。

### マーカー設定

以下は、複数のマーカー定義を含むマーカー構成ファイルの例です。この例は、ムードボット用に作成され、ラベルの使用を説明するために新しいスロット`名`が付けられ`slot_was_set`。

```yaml
marker_name_provided:
  description: "slot `name` was provided"
  slot_was_set: name

marker_mood_expressed:
  or:
    - intent: mood_unhappy
    - intent: mood_great

marker_cheer_up_failed:
  seq:
    - intent: mood_unhappy
    - action: utter_cheer_up
    - action: utter_did_that_help
    - intent: deny

marker_bot_not_challenged:
  description: "Example of a negated marker, it can be used to surface conversations without bot_challenge intent"
  never:
    - intent: bot_challenge

marker_cheer_up_attempted:
  at_least_once:
    - action: utter_cheer_up

marker_mood_expressed_and_name_not_provided:
  and:
    - or:
      - intent: mood_unhappy
      - intent: mood_great
    - not:
      - slot_was_set: name
```

次の点に注意してください。

*   各マーカーには、`marker_name_provided`などの一意の識別子(または名前)があります。
    
*   各マーカーには、ドキュメントに使用できるオプションの`記述`キーを含めることができます。
    
*   マーカー定義には、`marker_name_provided` に示すように 1 つの条件を含めることができます。
    
*   マーカー定義には、`marker_mood_expressed`、`marker_cheer_up_failed`、`marker_bot_not_challenged`、`およびmarker_cheer_up_attempted`に示すように、条件のリストを持つ単一の演算子を含めることができます。
    
*   マーカー定義には、 に `marker_mood_expressed_and_name_not_provided` 示すようにネストされた演算子を含めることができます。
    
*   イベント条件に割り当てられた値は、ボットの`domain.yml`ファイルに従って有効である必要があります。たとえば、`marker_mood_expressed` では、インテント `mood_unhappy` と `mood_unhappy` はどちらもムードボットの`domain.yml`ファイルにリストされているインテントです。
    

> [![注] 既存のマーカー名を別のマーカーの定義で再利用することはできません。

## マーカーの抽出

> [!note] 
> Rasa Proはマーカーのリアルタイム処理に対応しており、[リアルタイムマーカー](monitoring/analytics/realtime-markers.md)の詳細を読む

マーカーは、トラッカーストアにすでに保存されているダイアログから抽出されます。ボットとの対話をトラッカーストアに保存する方法については、[トラッカーストア](./tracker-stores.md)のページを参照してください。

マーカー設定ファイルでマーカー定義を作成し、いくつかのダイアログをトラッカーストアに保存したら、次のコマンドを実行してマーカーをトラッカーに適用できます。

```bash
rasa evaluate markers all --config markers.yml extracted_markers.csv
```

このスクリプトは、マーカー構成ファイル `markers.yml` で指定したマーカー定義を処理します。スクリプトは、抽出されたマーカーを指定された出力ファイル `extracted_markers.csv` に出力します。また、2 つの要約統計ファイルも生成されます。出力ファイルの形式については、次のセクションで説明します。

既定では、スクリプトはボットの`domain.yml` ファイルに対してマーカー定義を検証します。別のドメインファイルを指定するには、オプションの `--domain` 引数を使用します。

デフォルトでは、スクリプトはボットの`endpoint.yml`内のトラッカーストアを処理します。ただし、オプションの `--endpoint` 引数を使用して、別のエンドポイント ファイルを指定できます。

トラッカーの読み込み戦略は、`all`、`sample_n`、`first_n`の3種類でサポートされています。オプション`「すべて」`は、トラッカーストア内のすべてのトラッカーを処理します。他の 2 つの戦略は、`N` トラッカーのサブセットを順次 (`first_n` を使用) または置換せずに均一にサンプリング (`sample_n` を使用) のいずれかで処理します。サンプリング戦略では、ランダムシードを設定することもできます。各戦略の使用方法の詳細については、`<strategy>` を `all`、`first_n`、`および sample_n` のいずれかに置き換えて、次のコマンドを入力します。

```bash
rasa evaluate markers <strategy> --help
```

> [!note] 
> トラッカーストア内の各トラッカーには、複数のセッションを含めることができます。スクリプトは各セッションを個別に処理し、`session_idx`ごとにインデックスを作成します。

次の 2 つのセクションでは、抽出されたマーカーと計算された統計量の形式について説明します。

### 抽出されたマーカー

マーカー構成ファイルで定義されているマーカーごとに、次の情報が抽出されます。

1.  マーカーが適用された**イベントのインデックス**。
2.  マーカーが適用された**イベントの前のユーザーターン数**。各 `UserUttered` イベントはユーザー ターンとして扱われます。

**イベントのインデックス**と**先行するユーザーターンの数**は、どちらも、タスクの成功などの重要なイベントに到達するまでにかかった時間を示します。イベントのインデックスは、新しいセッションの開始やカスタム アクションの実行など、ダイアログの一部ではないイベントを含むすべてのイベントをカウントします。一方、先行するユーザーターンの数は、特にエンドユーザーの視点から、対話の長さをより直感的に示します。

前のユーザーターンの数を使用して、ボットを評価および改善できます。たとえば、ユーザーが発話を複数回言い換える必要があり、会話が長くなったとします。ダイアログは最終的にタスクの成功に達する可能性がありますが、ダイアログを表示すると、ボットが理解できなかった発話を特定できます。その後、これらの困難な発話を追加のトレーニング データとして使用して、[会話駆動型開発 (CDD)](./conversation-driven-development.md) の一部としてボットをさらに改善できます。

> [!note] 
> `at_least_once`演算子を使用して定義されたマーカーの場合、上記の情報は最初の出現に対してのみ抽出されます。

抽出されたマーカーは、スクリプトで指定した`.csv`ファイル (`extracted_markers.csv` など) に表形式で保存されます。抽出されたマーカー出力ファイルには、次の列が含まれます。

*   `sender_id`:トラッカーから取得。
*   `session_idx`: `0` から始まる整数のインデックス作成セッション。
*   `marker`: 一意のマーカー識別子。
*   `event_idx`: `0` から始まる整数のインデックス イベント。
*   `num_preceding_user_turns`: マーカーが適用されたイベントの前のユーザーターン数を示す整数。

抽出されたマーカー出力ファイルの例を次に示します (`marker_mood_expressed` と `marker_cheer_up_failed` の 2 つのマーカーを含むマーカー構成ファイルの場合)。

```
sender_id,session_idx,marker,event_idx,num_preceding_user_turns
3c1afa1ed72c4116ba6670a1668f1b4a,0,marker_mood_expressed,2,0
4d55093e9696452c8d1157fa33fd54b2,0,marker_mood_expressed,7,1
4d55093e9696452c8d1157fa33fd54b2,0,marker_cheer_up_failed,14,2
c00b3de97713427d85524c4374125db1,0,marker_mood_expressed,2,0
```

各行は、`マーカー`列の下に指定されたマーカーの出現を、`sender_id`と`session_idx`ごとに表します。

### 計算統計

デフォルトでは、このコマンドは収集された情報に関する要約統計を計算します。統計計算を無効にするには、オプションのフラグ `--no-stats` を使用します。

このスクリプトは、次の統計を計算します。

1.  **各セッションおよび各マーカーについて**: マーカーが適用されたイベントに先立つ算術平均、中央値、最小、および最大ユーザーターン数を含む「セッションごとの統計」。
2.  **すべてのセッションと各マーカーについて**:
    1.  任意のセッションでマーカーが適用されたイベントに先立つ算術平均、中央値、最小、および最大ユーザーターン数を含む全体的な統計。
    2.  セッションの数と、各マーカーが少なくとも 1 回適用されたセッションの割合。

結果は、`stats-overall.csv`と`stats-per-session.csv`の表形式で保存されます。オプションの引数 `--stats-file-prefix` を使用して、ファイル名のプレフィックス`統計`を変更できます。たとえば、次のスクリプトは、`my-statistics-overall.csv` と `my-statistics-per-session.csv` のファイルを生成します。

```bash
rasa evaluate markers all --stats-file-prefix "my-statistics" extracted_markers.csv
```

2 つの統計ファイルには、次の列が含まれています。

*   `sender_id`:トラッカーから取得。統計がすべてのセッションで計算される場合、これは`すべて`に等しくなります。
*   `session_idx`: `0` から始まる整数のインデックス作成セッション。統計がすべてのセッションで計算された場合、これは `nan` (数値ではない) に等しくなります。
*   `marker`: 一意のマーカー識別子。
*   `統計:` 計算された統計の説明。
*   `value`: 計算された統計の整数または浮動小数点値。統計が利用できない場合、`値は``nan`(数値ではない)に等しくなります。

出力`stats-per-session.csv`例を次に示します。

```
sender_id,session_idx,marker,statistic,value
3c1afa1ed72c4116ba6670a1668f1b4a,0,marker_cheer_up_failed,count(number of preceding user turns),0
4d55093e9696452c8d1157fa33fd54b2,0,marker_cheer_up_failed,count(number of preceding user turns),1
c00b3de97713427d85524c4374125db1,0,marker_cheer_up_failed,count(number of preceding user turns),0
3c1afa1ed72c4116ba6670a1668f1b4a,0,marker_cheer_up_failed,max(number of preceding user turns),nan
4d55093e9696452c8d1157fa33fd54b2,0,marker_cheer_up_failed,max(number of preceding user turns),2
c00b3de97713427d85524c4374125db1,0,marker_cheer_up_failed,max(number of preceding user turns),nan
3c1afa1ed72c4116ba6670a1668f1b4a,0,marker_cheer_up_failed,mean(number of preceding user turns),nan
4d55093e9696452c8d1157fa33fd54b2,0,marker_cheer_up_failed,mean(number of preceding user turns),2.0
c00b3de97713427d85524c4374125db1,0,marker_cheer_up_failed,mean(number of preceding user turns),nan
3c1afa1ed72c4116ba6670a1668f1b4a,0,marker_cheer_up_failed,median(number of preceding user turns),nan
4d55093e9696452c8d1157fa33fd54b2,0,marker_cheer_up_failed,median(number of preceding user turns),2.0
c00b3de97713427d85524c4374125db1,0,marker_cheer_up_failed,median(number of preceding user turns),nan
3c1afa1ed72c4116ba6670a1668f1b4a,0,marker_cheer_up_failed,min(number of preceding user turns),nan
4d55093e9696452c8d1157fa33fd54b2,0,marker_cheer_up_failed,min(number of preceding user turns),2
c00b3de97713427d85524c4374125db1,0,marker_cheer_up_failed,min(number of preceding user turns),nan
3c1afa1ed72c4116ba6670a1668f1b4a,0,marker_mood_expressed,count(number of preceding user turns),1
4d55093e9696452c8d1157fa33fd54b2,0,marker_mood_expressed,count(number of preceding user turns),1
c00b3de97713427d85524c4374125db1,0,marker_mood_expressed,count(number of preceding user turns),1
3c1afa1ed72c4116ba6670a1668f1b4a,0,marker_mood_expressed,max(number of preceding user turns),0
4d55093e9696452c8d1157fa33fd54b2,0,marker_mood_expressed,max(number of preceding user turns),1
c00b3de97713427d85524c4374125db1,0,marker_mood_expressed,max(number of preceding user turns),0
3c1afa1ed72c4116ba6670a1668f1b4a,0,marker_mood_expressed,mean(number of preceding user turns),0.0
4d55093e9696452c8d1157fa33fd54b2,0,marker_mood_expressed,mean(number of preceding user turns),1.0
c00b3de97713427d85524c4374125db1,0,marker_mood_expressed,mean(number of preceding user turns),0.0
3c1afa1ed72c4116ba6670a1668f1b4a,0,marker_mood_expressed,median(number of preceding user turns),0.0
4d55093e9696452c8d1157fa33fd54b2,0,marker_mood_expressed,median(number of preceding user turns),1.0
c00b3de97713427d85524c4374125db1,0,marker_mood_expressed,median(number of preceding user turns),0.0
3c1afa1ed72c4116ba6670a1668f1b4a,0,marker_mood_expressed,min(number of preceding user turns),0
4d55093e9696452c8d1157fa33fd54b2,0,marker_mood_expressed,min(number of preceding user turns),1
c00b3de97713427d85524c4374125db1,0,marker_mood_expressed,min(number of preceding user turns),0
```

使用不可統計の値は `nan` であることに注意してください。たとえば、トラッカー `3c1afa1ed72c4116ba6670a1668f1b4a` セッション `0` で`marker_cheer_up_failed`発生しなかったため、前のユーザー ターンの`最小``数、``最大`数、`中央値`、平均数は `nan` に等しくなります。

出力`stats-overall.csv`例を次に示します。

```
sender_id,session_idx,marker,statistic,value
all,nan,-,total_number_of_sessions,3
all,nan,marker_cheer_up_failed,number_of_sessions_where_marker_applied_at_least_once,1
all,nan,marker_cheer_up_failed,percentage_of_sessions_where_marker_applied_at_least_once,33.333
all,nan,marker_mood_expressed,number_of_sessions_where_marker_applied_at_least_once,3
all,nan,marker_mood_expressed,percentage_of_sessions_where_marker_applied_at_least_once,100.0
all,nan,marker_cheer_up_failed,count(number of preceding user turns),1
all,nan,marker_cheer_up_failed,mean(number of preceding user turns),2.0
all,nan,marker_cheer_up_failed,median(number of preceding user turns),2.0
all,nan,marker_cheer_up_failed,min(number of preceding user turns),2
all,nan,marker_cheer_up_failed,max(number of preceding user turns),2
all,nan,marker_mood_expressed,count(number of preceding user turns),3
all,nan,marker_mood_expressed,mean(number of preceding user turns),0.333
all,nan,marker_mood_expressed,median(number of preceding user turns),0.0
all,nan,marker_mood_expressed,min(number of preceding user turns),0
all,nan,marker_mood_expressed,max(number of preceding user turns),1
```

各行はすべてのセッションの統計を計算するため、`sender_id`は `all` に等しく、`session_idx`は `nan` に等しいことに注意してください。

## CLI コマンドの設定

[[./command-line-interface.md#RASAはマーカーを評価する|CLI ページ]] マーカー抽出と統計計算プロセスの設定の詳細については、を参照してください。