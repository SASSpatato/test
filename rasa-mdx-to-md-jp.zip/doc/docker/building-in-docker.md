---
id: building-in-docker
sidebar_label: Building a Rasa Assistant in Docker
title: Building a Rasa Assistant in Docker
description: Learn how to build a Rasa assistant in Docker.
---

Rasaプロジェクトをまだ持っていない場合は、RasaをインストールしなくてもDockerでビルドできます ローカルマシンで。満足のいくモデルが既にある場合は、 [Rasa Assistant のデプロイ](../deploy/introduction.md) モデルのデプロイ方法を学習します。

## Docker のインストール

Dockerがインストールされているかどうかわからない場合は、以下を実行して確認できます。

```bash
docker -v
# Docker version 18.09.2, build 6247962
```

Docker がマシンにインストールされている場合、出力にはインストールされているバージョンの Docker が表示されます。コマンドが機能しない場合は、Dockerをインストールする必要があります。詳細については、「[Docker のインストール」](https://docs.docker.com/install/)を参照してください。

## Rasa プロジェクトのセットアップ

プロジェクトをゼロから開始するのと同じように、`rasa init` コマンドを使用してプロジェクトを作成します。唯一の違いは、イメージ`rasa / rasa`を使用して、Dockerコンテナ内でRasaを実行することです。プロジェクトを初期化するには、以下を実行します。

```bash

{`docker run -v $(pwd):/app rasa/rasa:${variables.release}-full init --no-prompt`}
```

このコマンドはどういう意味ですか?

*   -v $(pwd):/app は、現在の作業ディレクトリを Docker コンテナの作業ディレクトリにマウントします。つまり、コンピューターで作成したファイルはコンテナー内に表示され、コンテナーで作成されたファイルはコンピューターに同期されます。
*   rasa/rasa は、実行する Docker イメージの名前です。'{variables.release}-full' はタグの名前で、バージョンと依存関係を指定します。
*   Dockerイメージには、エントリポイントとしてrasaコマンドがあるため、rasa initを入力する必要はなく、initだけで十分です。

このコマンドを実行すると、大量の出力が生成されます。何が起こるかは次のとおりです。

*   Rasa プロジェクトが作成されます
    
*   初期モデルは、プロジェクトのトレーニング データを使用してトレーニングされます。
    

コマンドが正しく完了したことを確認するには、作業ディレクトリの内容を確認します。

```bash
ls -1
```

最初のプロジェクト ファイルと、トレーニングされたモデルを含む`モデル` ディレクトリがすべてそこにある必要があります。

> [!note]  
> 権限エラーが発生した場合は、コンテナに`ルート`権限を与えないようにするために、ベストプラクティスとして `rasa/rasa` イメージがユーザー `1001` として実行されていることが原因である可能性があります。したがって、これらのコンテナによって作成されたすべてのファイルは、ユーザー `1001` が所有します。コンテナを別のユーザーとして実行する場合は、[Docker のドキュメント](https://docs.docker.com/edge/engine/reference/commandline/run/)を参照してください。

## アシスタントと話す

新しくトレーニングされたアシスタントと話すには、次のコマンドを実行します。

```bash

{`docker run -it -v $(pwd):/app rasa/rasa:${variables.release}-full shell`}
```

これにより、アシスタントとチャットできるシェルが開始されます。このコマンドにはフラグ `-it` が含まれており、これは Docker を対話的に実行しており、コマンド ラインを介して入力できることを意味します。`rasa shell`や`rasa interactive`など、対話型入力を必要とするコマンドの場合は、`-it`フラグを渡す必要があります。

## モデルのトレーニング

トレーニングデータを編集したり、`config.yml`ファイルを編集したりする場合は、Rasa モデルを再トレーニングする必要があります。これを行うには、次のコマンドを実行します。

```bash

{`docker run -v $(pwd):/app rasa/rasa:${variables.release}-full train --domain domain.yml --data data --out models`}
```

このコマンドで何が起こっているかは次のとおりです。

*   -v $(pwd):/app: Rasaがトレーニングデータでモデルをトレーニングできるように、プロジェクトディレクトリをDockerコンテナにマウントします
*   rasa/rasa:{variables.release}-full: タグ '{variables.release}-full' を付けた Rasa イメージを使用します。
*   train: コンテナ内でrasa trainコマンドを実行します。詳細については、[[command-line-interface]]を参照してください。

この場合、ドメイン ファイルの場所、トレーニング データ、およびモデル出力ディレクトリの値も渡して、これらをカスタマイズする方法を示しています。デフォルト値を渡すため、これらを省略することもできます。

## モデルのカスタマイズ

### タグの選択

すべての rasa/rasa イメージ タグはバージョン番号で始まります。現在のバージョンは{variables.release}です。タグは次のとおりです。

*   `{version}`
    
*   `{version}-full`
    
*   `{version}-spacy-en`
    
*   `{version}-spacy-de`
    
*   `{version}-spacy-it`
    
*   `{version}-mitie-en`
    

`{version}-full` タグには、考えられるすべてのパイプライン依存関係が含まれているため、`config.yml` 依存関係の欠落を心配することなく、好きなように。プレーンな `{version}` タグには、`rasa init` によって作成されたデフォルトのパイプラインを実行するために必要なすべての依存関係が含まれています。

イメージをできるだけ小さくするために、異なる依存関係がインストールされた `rasa/rasa` イメージの異なるタグも公開します。[[installing-rasa-open-source#追加の依存関係|Additional Dependencies]] を使用して、パイプラインに固有の依存関係情報を確認してください。たとえば、spaCy または MITIE の事前トレーニング済みの単語ベクトルを持つコンポーネントを使用している場合は、対応するタグを選択する必要があります。

モデルにどのタグにも含まれていない依存関係 (たとえば、別の spaCy 言語モデル) がある場合は、`rasa/rasa` イメージを拡張する Docker イメージを構築できます。

> [!note] 
>  [DockerHub](https://hub.docker.com/r/rasa/rasa/) では、Rasa Docker イメージのすべてのバージョンとタグのリストを確認できます。

> [!caution] 
> `最新の`タグは、最新の安定版のビルドに対応しています。

### カスタムコンポーネントの追加

`config.yml`でカスタム NLU コンポーネントまたはポリシーを使用している場合は、モジュール ファイルを Docker コンテナに追加する必要があります。これを行うには、ファイルをマウントするか、独自のカスタムイメージに含めます(たとえば、カスタムコンポーネントまたはポリシーに追加の依存関係がある場合)。環境変数 `PYTHONPATH=$PYTHONPATH:<directory of your module>` を設定して、モジュールが Python モジュールの検索パスにあることを確認します。

### カスタムアクションの追加

より高度なアシスタントを作成するには、[[actions#カスタムアクション|カスタムアクション]]。上記の例を続けて、ユーザーを元気づけるためにジョークを伝えるアクションを追加することができます。

Rasa SDK を使用して、`アクション/actions.py` を編集してカスタム アクションを作成します。

```python
import requests
import json
from rasa_sdk import Action


class ActionJoke(Action):
  def name(self):
    return "action_joke"

  def run(self, dispatcher, tracker, domain):
    request = requests.get('http://api.icndb.com/jokes/random').json()  # make an api call
    joke = request['value']['joke']  # extract a joke from returned json response
    dispatcher.utter_message(text=joke)  # send the message back to the user
    return []
```

`data/stories.yml` で、`utter_cheer_up` in をカスタムアクションaction_jokeに置き換えます`。` この新しいアクションを使用するようにボットに指示します。

`domain.yml`で、新しいアクションを含むカスタムアクションのセクションを追加します。

```yaml-rasa
actions:
  - action_joke
```

ドメインとストーリーを更新した後、モデルを再トレーニングする必要があります。

```bash

{`docker run -v $(pwd):/app rasa/rasa:${variables.release}-full train`}
```

アクションは、Rasaサーバーとは別のサーバーで実行されます。まず、2 つのコンテナーを接続するネットワークを作成します。

```bash
docker network create my-project
```

その後、次のコマンドを使用してアクションを実行できます。

```bash

{`docker run -d -v $(pwd)/actions:/app/actions --net my-project --name action-server rasa/rasa-sdk:${variables.rasa_sdk_version}`}
```

このコマンドで何が起こっているかは次のとおりです。

*   `-d`: コンテナをデタッチモードで実行し、同じウィンドウで rasa コンテナを実行できるようにします。
    
*   `-v $(pwd):/app`: アクション サーバーが`アクション` フォルダー内のコードを実行できるように、プロジェクト ディレクトリを Docker コンテナーにマウントします
    
*   `net my-project`: rasa コンテナが見つけられるように、特定のネットワークでサーバーを実行します
    
*   `--name action-server`: rasa サーバーが参照する特定の名前をサーバーに付けます
    
*   `rasa/rasa-sdk:{variables.rasa_sdk_version}` : タグ {`${variables.rasa_sdk_version}`} の付いた Rasa SDK イメージを使用します。
    

アクションサーバーはデタッチモードで実行されているため、コンテナを停止する場合は、`docker stop action-server` を使用して停止します。また、`いつでもdocker ps`を実行して、現在実行されているすべてのコンテナーを確認することもできます。

Rasa サーバーにアクション サーバーを使用するように指示するには、その場所を Rasa に伝える必要があります。このエンドポイントを`endpoints.yml`に追加し、サーバーに指定した `--name` (この例では `action-server`) を参照します。

```yaml-rasa
action_endpoint:
  url: "http://action-server:5055/webhook"
```

これで、`シェル`コマンドを使用してボットと再度会話できます。

```bash

{`docker run -it -v $(pwd):/app -p 5005:5005 --net my-project rasa/rasa:${variables.release}-full shell`}
```

> [!note]  
> `アクションサーバー`コンテナを停止して再起動すると、次のようなエラーが表示されることがあります。
> 
> ```
> docker: Error response from daemon: Conflict. The container name "/action-server" is
> already in use by container "f7ffc625e81ad4ad54cf8704e6ad85123c71781ca0a8e4b862f41c5796c33530".
> You have to remove (or rename) that container to be able to reuse that name.
> ```
> 
> その場合は、その名前の (停止した) コンテナーがすでにあることを意味します。次の方法で削除できます。
> 
> ```bash
> docker rm action-server
> ```

## アシスタントのデプロイ

あなたの幸せな道を処理できる最小限の実行可能なアシスタントができるまで、ボットに取り組みます。その後、モデルをデプロイして、実際のテスト ユーザーからフィードバックを得る必要があります。そのためには、[[deploy/introduction|推奨デプロイ方法]]のいずれかを使用して、作成したモデルをデプロイできます。