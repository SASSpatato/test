---
id: deploying-in-docker-compose
sidebar_label: Deploying a Rasa Assistant in Docker Compose
title: Deploying a Rasa Assistant in Docker Compose
description: Use Docker Compose to deploy a Rasa assistant
---

## Docker のインストール

Dockerがインストールされているかどうかわからない場合は、以下を実行して確認できます。

```bash
docker -v && docker-compose -v
# Docker version 18.09.2, build 6247962
# docker-compose version 1.23.2, build 1110ad01
```

Docker がマシンにインストールされている場合、出力にはインストールされているバージョンの Docker と Docker Compose が表示されます。コマンドが機能しない場合は、Dockerをインストールする必要があります。詳細については、[Docker のインストール](https://docs.docker.com/install/)を参照してください。

## チャネルの設定

AI アシスタントを運用環境で実行するには、必要な `credentials.yml`における[メッセージングと音声チャネル](../messaging-and-voice-channels.md)。たとえば、REST チャネルを追加するには、`credentials.yml`でこのセクションのコメントを解除します。

```yaml-rasa
rest:
  # you don't need to provide anything here - this channel doesn't
  # require any credentials
```

REST チャネルは、`/webhooks/rest/webhook` エンドポイントで受信要求に対してボットを開きます。

## Docker Compose を使用して複数のサービスを実行する

Docker Compose は、複数のコマンドを実行したりネットワークを構成したりすることなく、複数のコンテナーを一緒に実行する簡単な方法を提供します。これは、アクション・サーバーも持つアシスタントをデプロイする場合に不可欠です。

まず、`docker-compose.yml` というファイルを作成します。

```bash
touch docker-compose.yml
```

次のコンテンツをファイルに追加します。

```yaml

{`version: '3.0'
services:
  rasa:
    image: rasa/rasa:${variables.release}-full
    ports:
      - 5005:5005
    volumes:
      - ./:/app
    command:
      - run`}
```

このファイルは、使用する Docker Compose 仕様のバージョンで始まります。各コンテナーは、`docker-compose.yml`内の`サービス`として宣言されます。最初のサービスは、Rasaサーバーを実行する`rasa`サービスです。

アクション・サーバーを追加するには、アクション・サーバー・コードのイメージを追加します。アクション・サーバー・イメージをデプロイする方法については、[[deploy-action-server#アクション サーバー イメージの構築|アクションサーバーイメージの構築]]を参照してください。

```yaml

{`version: '3.0'
services:
  rasa:
    image: rasa/rasa:${variables.release}-full
    ports:
      - 5005:5005
    volumes:
      - ./:/app
    command:
      - run
  app:
    image: 
    expose: 5055`}
```

`expose: 5005` は、`rasa` サービスがそのポート上の`アプリ` サービスに到達できるようにするものです。そのエンドポイントにアクション要求を送信するように `rasa` サービスに指示するには、そのエンドポイントを `endpoints.yml` に追加します。

```yaml-rasa
action_endpoint:
  url: http://app:5055/webhook
```

`docker-compose.yml`で設定されたサービスを実行するには、次のコマンドを実行します。

```bash
docker-compose up
```

その後、[[#チャネルの設定]] に対応する Webhook エンドポイントで、ポート 5005 への要求を介してボットと対話できるようになります。

```bash
curl -XPOST http://localhost:5005/webhooks/rest/webhook 
  -H "Content-type: application/json" 
  -d '{"sender": "test", "message": "hello"}'
```

## トラッカーストアの設定

デフォルトでは、すべての会話はメモリに保存されます。つまり、すべての Rasa サーバーを再起動するとすぐに会話が失われます。 会話を継続したい場合は、別の [トラッカーストア](../tracker-stores.md)。

トラッカーストアをDocker Composeデプロイメントに追加するには、`docker-compose.yml`に新しいサービスを追加し、新しいサービスを指して新しいトラッカーストアを追加するように`endpoints.yml`を変更する必要があります。その方法の詳細については、トラッカーストアのドキュメントを参照してください。

*   [SQLTrackerStore (SQLTrackerStore)](../tracker-stores.md#sqltrackerstore)
    
*   [RedisTrackerストア](../tracker-stores.md#RedisTrackerStore)
    
*   [モンゴトラッカーストア](../tracker-stores.md#モンゴトラッカーストア)
    
*   [[tracker-stores#カスタムトラッカーストア|カスタムトラッカーストア]]