---
slug: /
sidebar_label: Introduction
title: Introduction to Rasa Open Source & Rasa Pro
hide_table_of_contents: true
description: Learn more about open-source natural language processing library Rasa for conversation handling, intent classification and entity extraction in on premise chatbots.
---

2,500万回以上ダウンロードされたRasa Open Sourceは、チャットおよび音声ベースのAIアシスタントを構築するための最も人気のあるオープンソースフレームワークです。

Rasa Proは、オープンソースの会話型AIフレームワークを活用したオープンコア製品で、分析、セキュリティ、オブザーバビリティ機能が追加されています。

Rasa Proは、当社のエンタープライズソリューションであるRasa Platformの一部です。Rasa Platform を構成する別の製品は、Rasa X/Enterprise です。これは、会話型 AI チームが AI アシスタントを大規模にレビューおよび改善することをサポートするローコード ユーザー インターフェイスです。Rasa Proと一緒に使用する必要があります。Rasa X/Enterprise の詳細については、[Rasa X/Enterprise のドキュメント](https://rasa.com/docs/rasa-enterprise)を参照してください。

また、リリースおよびメンテナンスポリシーの詳細については、[Rasa 製品のリリースおよびメンテナンスポリシーをご覧ください](https://rasa.com/rasa-product-release-and-maintenance-policy/)。

![[static/img/introduction.png]]

## Rasaオープンソース

Rasa Open Source は、会話を理解して保持し、一連の API を介してメッセージング チャネルやサードパーティ システムに接続できるオープンソースの会話型 AI プラットフォームです。仮想 (デジタル) アシスタントまたはチャットボットを作成するための構成要素を提供します。

## ラサプロ

> [!warning] Rasa Proのみ

Rasa Proは、セキュリティ、可観測性、スケールに関する企業のニーズに対応するために構築された、Rasaの商用プロコード製品です。[詳しくはこちらをご覧ください](./rasa-pro.md)。

コンテンツがRasa Proにのみ適用される場合は、以下のラベルが表示されます。

つまり、そのセクションで詳しく説明されている機能にアクセスするには、Rasa Pro ライセンスが必要です。