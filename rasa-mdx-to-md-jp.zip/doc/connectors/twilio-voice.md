---
id: twilio-voice
sidebar_label: Twilio Voice
title: Twilio Voice
description: Deploy a Rasa IVR assistant via the Twilio Voice connector
---

Twilio Voice コネクタを使用して、Twilio の電話番号または Twilio SIP ドメインへの電話に応答できます。

## Twilioでの実行

### Twilio の電話番号に接続する

Twilio から Rasa アシスタントに通話を転送するには、電話番号の Webhook を更新する必要があります。Twilioアカウントの[電話番号](https://www.twilio.com/console/phone-numbers/incoming)セクションに移動し、Rasaに接続する電話番号を選択します。画面上の `音声とファックス` セクションを見つけます。`A CALL COMES IN` セクションで、Rasa ボットの Webhook URL (例: `https://<host>:<port>/webhooks/twilio_voice/webhook` ) を追加し、ホストとポートをデプロイに適した値に置き換えます。ページの下部にある `[保存]` をクリックします。

![[twilio-set-webhook.png]]

### Twilio SIP ドメインに接続する

Twilio Voice チャネルを Twilio SIP ドメインに接続することもできます。次のコマンドをフォローできます。 Twilio SIP 要求を Twilio SIP ドメインに転送するための [Twilio 送信 SIP](https://www.twilio.com/docs/voice/api/sending-sip) ガイド。SIPドメインを設定したら、着信通話をRasaに転送する必要があります。Twilio コンソールで、[SIP ドメインに移動します。](https://console.twilio.com/develop/voice/manage/sip-domains?frameUrl=/console/voice/sip/endpoints) 節。使用するSIPドメインを選択します。`Call Control Configuration` セクションを見つけて、Rasa ボットの Webhook URL (例: `https://<host>:<port>/webhooks/twilio_voice/webhook` ) を追加し、ホストとポートをデプロイに適した値に置き換えます。ページの下部にある `[保存]` をクリックします。

![[twilio-set-sip-webhook.png]]

## Rasaでのチャネルの設定

`credentials.yml` ファイルで、`twilio_voice` チャネルが追加されていることを確認します。`credentials.yml`内には、アシスタントの動作を制御するために設定できるパラメーターが多数あります。各パラメータの定義の例を以下に示します。Twilio テキスト チャネルとは異なり、音声チャネルに Twilio 資格情報を追加する必要はありません。`拡張`値と`assistant_voice`値を変更すると、Twilio からコストが増加する可能性があります。これらの設定の詳細については、以下のドキュメントを参照してください。

```yaml
twilio_voice:
  initial_prompt: "hello"
  assistant_voice: "woman"
  reprompt_fallback_phrase: "I didn't get that could you repeat?"
  speech_timeout: "5"
  speech_model: "default"
  enhanced: "false"
```

## パラメータ定義

### 初期プロンプト

Twilio が新しいコールを受信し、これを Rasa に転送すると、Twilio はユーザー メッセージを提供しません。この場合、Rasaはユーザーが「Hello」というメッセージを送信したかのように動作します。この動作は、`initial_prompt` パラメーターを目的の入力に設定することで、`credentials.yml` ファイルで構成できます。`initial_prompt`値がRasaに送信され、応答がユーザーに読み上げられ、音声会話が開始されます。音声チャネルを介してユーザーに挨拶する方法は、テキスト チャネルとは異なる場合があります。回答を確認し、必要に応じて [[responses#チャネル固有の応答変動|チャネル固有のバリエーション]] を作成することを検討する必要があります。

### アシスタントの音声

アシスタントが話す音声の種類を指定することで、アシスタントに個性を加えることができます。の `credentials.yml`ファイルには、アシスタントの音声の種類を指定するオプションを追加`assistant_voice`できます。サポートされている音声のリストについては、[Twilio のドキュメント](https://www.twilio.com/docs/voice/twiml/say#voice)を参照してください。デフォルトでは、Twilio の`女性`の声が使用されます。`Polly`の使用には追加料金が発生することに注意してください 声。Twilio のドキュメントには、 [ポリーの価格。](https://www.twilio.com/docs/voice/twiml/say/text-speech#pricing)

### フォールバックフレーズの再プロンプト

ユーザーが会話の前のメッセージを確認し、時間をかけて返信できるテキスト チャネルとは異なり、音声チャネルでは、会話が一時停止するとユーザーが混乱する可能性があります。会話中に長い一時停止が検出されると、Rasa はボットからの最後の発話を繰り返して、ユーザーに応答を求めます。前のボット発話を識別できない場合は、`reprompt_fallback_phrase`で定義されたメッセージが送信されます。デフォルトでは、これは「申し訳ありませんが、それを理解できませんでした。言い換えてもらえますか」に設定されています。

### 音声タイムアウト

Twilio が発信者から音声を収集する期間。このパラメータは、数値または「auto」に設定する必要があります。番号が指定されている場合、アシスタントは指定された時間の音声を収集します。`speech_timeout`が "auto" に設定されている場合、Twilio は一時停止が検出されるまで音声を収集します。このパラメータのデフォルト設定は「auto」です。`speech_timeout`の詳細については、 [Twilio のドキュメント](https://www.twilio.com/docs/voice/twiml/gather#speechtimeout)。`speech_timeout="auto"` に注意してください。 とは互換性があります `speech_model='numbers_and_commands'` 。互換性のない `speech_model`は`speech_timeout`とともに使用されます。

### 音声モデル

`speech_model` パラメーターを調整すると、Twilio の音声からテキストへの変換の精度を高めることができます。有効な値は、`default`、`numbers_and_commands`、`および phone_call` です。デフォルト設定は「デフォルト」です。`speech_model`の詳細については、 [Twilio のドキュメント](https://www.twilio.com/docs/voice/twiml/gather#speechmodel)。

### 強化

`enhanced` を `true` に設定すると、Twilio のプレミアム音声モデルを使用して、文字起こし結果の精度を向上させることができます。このパラメーターを `true` に設定すると、Twilio の文字起こしコストが高くなることに注意してください。このパラメータは、`speech_model` パラメータも `phone_call` に設定している場合にのみサポートされます。デフォルトでは`、拡張は`「false」に設定されています。`拡張`音声モデル オプションの詳細については、 [Twilio のドキュメント](https://www.twilio.com/docs/voice/twiml/gather#enhanced)。

## カスタム音声応答

画像、絵文字、略語を含むすべての応答に対して、音声 [[responses#チャネル固有の応答変動|channel specific responses]] を指定することを強くお勧めします。画像や絵文字などのビジュアルメディアは、音声アプリケーションにはうまく変換されません。これらの応答に代わる音声を使用すると、ユーザー エクスペリエンスを音声チャネルに合わせて調整できます。画像または絵文字のいずれかを含む応答が検出された場合、警告が発生します。画像または絵文字は応答から削除され、付随するテキストのみがユーザーへの応答に含まれます。

画像や絵文字を含む回答を確認するだけでなく、音声チャネルへの適用性について他のすべての回答も確認する必要があります。「e.g.」のような略語はうまく翻訳されません。音声応答では、略語の長手バージョンを使用する必要があります。ユーザーとのやり取りは、テキスト チャネルと音声チャネルで異なる場合があります。音声チャネルのスコープ内のすべての応答を確認し、音声固有の応答を提供することで、ユーザー エクスペリエンスを向上させることができます。