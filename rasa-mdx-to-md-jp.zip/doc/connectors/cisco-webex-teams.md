---
id: cisco-webex-teams
sidebar_label: Cisco Webex Teams
title: Cisco Webex Teams
description: Build a Rasa Chat Bot on Cisco Webex
---

資格情報を取得するには、まず Cisco Webex アプリを作成する必要があります。それらを取得したら、これらを`credentials.yml`に追加できます。

## 資格情報の取得

**Cisco Webex Teams 資格情報を取得する方法:**

ボットを設定する必要があります。ボットの作成方法については、[Cisco Webex for Developers のドキュメント](https://developer.webex.com/docs/bots)を参照してください。

Cisco Webex Teams を使用してボットを作成したら、Cisco Webex Teams で会議室を作成する必要があります。次に、ルームにユーザーを追加するのと同じ方法で、ルームにボットを追加します。

作成したルームのルームIDを書き留める必要があります。このルームIDは、`credentials.yml`ファイルの`ルーム`変数で使用されます。

以下のリンクから部屋IDを確認してください `https://developer.webex.com/endpoint-rooms-get.html`

OAuth & 権限セクションで、Webex がメッセージを転送する Rasa エンドポイントの URL を追加します。Cisco Webex Teams メッセージを受信するためのエンドポイントは です ホスト `http://<host>:<port>/webhooks/webexteams/webhook` とポートを、実行中の Rasa サーバーの適切な値に置き換えます。

## Cisco Webex Teams での実行

Webex Teams 資格情報を`credentials.yml`に追加します。

```yaml-rasa
webexteams:
  access_token: "YOUR-BOT-ACCESS-TOKEN"
  room: "YOUR-CISCOWEBEXTEAMS-ROOM-ID"
```

Rasa サーバーを再起動して、新しいチャネル エンドポイントを Cisco Webex Teams がメッセージの送信に使用できるようにします。

> [!note] 
>  `room` キーワード引数を設定しない場合、メッセージは送信したユーザーに配信されます。