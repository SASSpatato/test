---
id: twilio
sidebar_label: Twilio
title: Twilio
description: Deploy a Rasa assistant through text message or WhatsApp via the Twilio connector
---

Twilio コネクタを使用して、テキスト メッセージで使用できるアシスタントをデプロイできます。

## 資格情報の取得

資格情報を取得するには、まず Twilio アプリを作成する必要があります。それらを取得したら、これらを`credentials.yml`に追加できます。

**Twilio 資格情報を取得する方法:** Twilio アカウントを設定する必要があります。

1.  Twilio アカウントを作成したら、新しいプロジェクトを作成する必要があります。ここで選択すべき基本的な重要な製品は、`プログラマブル SMS` です。
    
2.  プロジェクトを作成したら、のダッシュボードに移動します。 `プログラム可能なSMS`をクリックし、`開始する`をクリックします。手順に従って、電話番号をプロジェクトに接続します。
    
3.  これで、`アカウント SID`、`認証トークン`、`およびcredentials.yml`で購入した電話番号を使用できます。
    
4.  Webhook URL を構成するには、 電話番号 [Twilio](https://www.twilio.com/console/phone-numbers/incoming) ダッシュボードで電話番号を選択します。`メッセージング` セクションを見つけて、Webhook URL (ホストとポートを実行中の Rasa サーバーの適切な値に置き換えるなど `https://<host>:<port>/webhooks/twilio/webhook` ) を `A MESSAGE COMES IN` 設定に追加します。
    

詳細については、「[Twilio REST API](https://www.twilio.com/docs/iam/api)」を参照してください。

### WhatsAppへの接続

Twilio を介して Rasa アシスタントを WhatsApp にデプロイできます。ただし、そのためにはWhatsApp [Business](https://www.whatsapp.com/business/)プロフィールが必要です。Whatsapp Business プロファイルを Twilio で購入した電話番号に関連付けて、[Twilio API for WhatsApp](https://www.twilio.com/docs/whatsapp/api) にアクセスします。

[Twilio API のドキュメント](https://www.twilio.com/docs/whatsapp/api#using-phone-numbers-with-whatsapp)によると、使用する電話番号には、以下で説明する`credentials.yml`で whatsapp: というプレフィックスを付ける必要があります。

## Twilioでの実行

Twilio 資格情報を`credentials.yml`に追加します。

```yaml-rasa
twilio:
  account_sid: "ACbc2dxxxxxxxxxxxx19d54bdcd6e41186"
  auth_token: "e231c197493a7122d475b4xxxxxxxxxx"
  twilio_number: "+440123456789"  # if using WhatsApp: "whatsapp:+440123456789"
```

Rasa サーバーを再起動して、Twilio がメッセージの送信先に新しいチャネルエンドポイントを使用できるようにします。

### Twilioコネクタを使用してWhatsappから位置データを受信する

このチャネルのユーザーから位置データ(WhatsAppの位置情報)を受け取る方法は以下の通りです。

1.  "locationData" という名前のインテントを作成し、緯度と経度にそれぞれ 2 つのエンティティとスロットを定義します。

```yaml-rasa
intents:
  - locationData

slots:
   Latitude:
     type: text
     mappings:
     - type: from_entity
       entity: Latitude

   Longitude:
     type: text
     mappings:
     - type: from_entity
       entity: Longitude

entities:
  - Latitude
  - Longitude

```

2.  ユーザーがロケーション メッセージを送信すると、locationData インテントがトリガーされ、エンティティからスロットが設定されます。エンティティはチャネルによって処理されるため、エンティティのトレーニング データを提供する必要はありません。