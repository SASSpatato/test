---
id: facebook-messenger
sidebar_label: Facebook Messenger
title: Facebook Messenger
description: Build a Rasa Chat Bot on Facebook Messenger
---

## Facebookのセットアップ

まず、Facebook Messenger に接続するための資格情報を取得するために、Facebook ページとアプリを設定する必要があります。それらを取得したら、これらを`credentials.yml`に追加できます。

### 資格情報の取得

**Facebookの資格情報を取得する方法:** Facebookアプリとページを設定する必要があります。

1.  アプリを作成するには、 [開発者向けFacebook](https://developers.facebook.com/) をクリックし、[**マイアプリ**] → **[新しいアプリを追加**] をクリックします。


2.  アプリのダッシュボードに移動し、[**製品]** で [**メッセンジャー**] セクションを見つけて [**セットアップ**] をクリックします。下にスクロールして トークン**生成をクリックし**、リンクをクリックしてアプリの新しいページを作成します。


3.  ページを作成し、ドロップダウンメニューで選択します。 **トークンの生成**。表示される**ページアクセストークン**は、 `page-access-token` は後で必要です。


4.  アプリダッシュボードの [**設定**] → **[基本**] で**アプリシークレット**を見つけます。これがあなたの`秘密`になります。


5.  収集した`シークレット`と `page-access-token` を `credentials.yml`、選択した文字列を含む `verify` というフィールドを追加します。rasa `run` を `--credentials credentials.yml`オプションを使用します。


6.  **Webhook** を設定し、少なくとも**メッセージング**と **messaging_postback**サブスクリプション。コールバック URL を挿入します ( のように `https://<host>:<port>/webhooks/facebook/webhook` なります) ホストとポートを、実行中の Rasa サーバーの適切な値に置き換えます。

    
    `検証`に一致する必要がある検証**トークン**を挿入します。 `credentials.yml`にエントリーします。
    

> [!note]  https の設定 
> Facebook Messenger は `https` 経由でエンドポイントにのみメッセージを転送するため、適切な措置を講じて設定に追加してください。ボットのローカル テストについては、「[[messaging-and-voice-channels#ローカルマシンでのチャネルのテスト|ローカルマシンでのチャネルのテスト]]を参照してください。

詳細な手順については、 [メッセンジャードキュメント](https://developers.facebook.com/docs/graph-api/webhooks)。

### Facebook Messenger での実行

Facebook の資格情報を`credentials.yml`に追加します。

```yaml-rasa
facebook:
  verify: "rasa-bot"
  secret: "3e34709d01ea89032asdebfe5a74518"
  page-access-token: "EAAbHPa7H9rEBAAuFk4Q3gPKbDedQnx4djJJ1JmQ7CAqO4iJKrQcNT0wtD"
```

Rasa サーバーを再起動して、Facebook Messenger がメッセージを送信できる新しいチャネルエンドポイントを使用できるようにします。

## サポートされている応答添付ファイル

Facebook Messenger チャネルでは、一般的なテキスト、画像、カスタム応答に加えて、次の追加の応答添付ファイルもサポートされています。

*   [ボタン](https://developers.facebook.com/docs/messenger-platform/send-messages/buttons) は、他の Rasa ボタンと同じ構造になっています。Facebook API は、 3 にメッセージで送信できるボタン。3 つ以上のボタンが メッセージが表示された場合、Rasa は提供されたすべてのボタンを無視します。
    
*   [クイック返信](https://developers.facebook.com/docs/messenger-platform/send-messages/quick-replies) 会話中に最大 13 個のボタンのセットを表示する方法を提供します。 タイトルとオプションの画像が表示され、コンポーザーの上に目立つように表示されます。また、 クイック返信を使用して、ユーザーのメールアドレスまたは電話番号をリクエストします。
    
    ```yaml-rasa
    utter_fb_quick_reply_example:
       - text: Hello World!
         quick_replies:
           - title: Text quick reply
             payload: /example_intent
           - title: Image quick reply
             payload: /example_intent
             image_url: http://example.com/img/red.png
           # below are Facebook provided quick replies
           # the title and payload will be filled
           # with the user's information from their profile
           - content_type: user_email
             title:
             payload:
           - content_type: user_phone_number
             title:
             payload:
    ```
    

> [!note]  
> Facebook Messenger のクイック返信とボタンの両方のタイトルには、文字数制限があります。

20.  20 文字を超えるタイトルは切り捨てられます。

*   [元素](https://developers.facebook.com/docs/messenger-platform/send-messages/template/generic) 最大 10 個のコンテンツ要素まで水平方向にスクロール可能なリストを作成する方法を提供します。 ボタンや画像などをテキストと一緒に 1 つのメッセージに統合します。
    
    ```yaml-rasa
    utter_fb_element_example:
       - text: Hello World!
         elements:
           - title: Element Title 1
             subtitle: Subtitles are supported
             buttons: # note the button limit still applies here
               - title: Example button A
                 payload: /example_intent
               - title: Example button B
                 payload: /example_intent
               - title: Example button C
                 payload: /example_intent
           - title: Element Title 2
             image_url: http://example.com/img/red.png
             buttons:
               - title: Example button D
                 payload: /example_intent
               - title: Example button E
                 payload: /example_intent
               - title: Example button F
                 payload: /example_intent
    ```