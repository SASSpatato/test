---
id: your-own-website
sidebar_label: Your Own Website
title: Your Own Website
description: Deploy and Run a Rasa Chat Bot on a Website
---

既存の Web サイトがあり、それに Rasa アシスタントを追加したい場合は、[[#チャットウィジェット|Rasa Chat Widget]] は、HTML スニペットを追加することで既存の Web ページに組み込むことができるウィジェットです。

または、独自のチャット ウィジェットを作成することもできます。

## REST チャネル

`RestInput` チャネルと `CallbackInput` チャネルは、カスタム統合に使用できます。メッセージを投稿し、応答メッセージを直接受信したり、Webhook を介して非同期に受信したりできる URL を提供します。

### Rest入力

REST チャネルは、ユーザー メッセージを投稿し、応答としてアシスタントのメッセージを受信できる REST エンドポイントを提供します。

REST チャネルをcredentials.ymlに追加します。

```yaml-rasa
rest:
  # you don't need to provide anything here - this channel doesn't
  # require any credentials
```

Rasaサーバーを再起動します をクリックして、REST チャネルをメッセージを受信できるようにします。その後、次の宛先にメッセージを送信できます。 `http://<host>:<port>/webhooks/rest/webhook` 、ホストとポートを実行中の Rasa サーバーの適切な値に置き換えます。

#### 要求と応答の形式

`残りの`入力チャネルを使用可能にした後`、メッセージを` `http://<host>:<port>/webhooks/rest/webhook` を次の形式で指定します。

```json
{
  "sender": "test_user",  // sender ID of the user sending the message
  "message": "Hi there!"
}
```

Rasa からの応答は、ボット応答の JSON 本文になります。

```json
[
  {"text": "Hey Rasa!"}, {"image": "http://example.com/image.jpg"}
]
```

### コールバック入力

コールバック チャネルは REST チャネルと非常によく似ていますが、メッセージを送信する HTTP リクエストにボット メッセージを直接返す代わりに、ボット メッセージを送信するために指定できる URL を呼び出します。

コールバックチャネルを使用するには、`credentials.yml`に認証情報を追加します。

```yaml-rasa
callback:
  # URL to which Core will send the bot responses
  url: "http://localhost:5034/bot"
```

Rasa サーバーを再起動して、新しいチャネル・エンドポイントがメッセージを受信できるようにします。その後、 に `http://<host>:<port>/webhooks/callback/webhook` メッセージを送信できます。

#### 要求と応答の形式

`コールバック`入力を使用可能にした後`、メッセージを` 次の形式 `http://<host>:<port>/webhooks/callback/webhook` で指定します。

```json
{
  "sender": "test_user",  // sender ID of the user sending the message
  "message": "Hi there!"
}
```

成功した場合、応答は`成功`になります。Rasa はユーザーにメッセージを送信する準備ができたら、`POST` を使用して`credentials.yml`で指定された `URL` を呼び出します ボットの応答の JSON 本文を含むリクエスト:

```json
[
  {"text": "Hey Rasa!"}, {"image": "http://example.com/image.jpg"}
]
```

## Websocket チャネル

SocketIO チャネルは WebSocket を使用し、リアルタイムです。SocketIO チャネルを使用するには、`資格情報をcredentials.yml`に追加します。

```yaml-rasa
socketio:
  user_message_evt: user_uttered
  bot_message_evt: bot_uttered
  session_persistence: true/false
```

最初の 2 つの構成値は、socket.io 経由でメッセージを送受信するときに Rasa が使用するイベント名を定義します。

ソケット クライアントは、metadata という名前のオブジェクトを渡して、チャネルにメタデータを提供できます。metadata_key設定を使用して代替キーを構成できます。たとえば、クライアントが customData という名前のキーにメタデータを渡す場合、設定は次のようになります。

```yaml-rasa
socketio:
  metadata_key: customData
```

Rasa サーバーを再起動して、新しいチャネル・エンドポイントがメッセージを受信できるようにします。その後、 に `http://<host>:<port>/socket.io` メッセージを送信できます。

> [!note] 
> セッションの永続性に注意デフォルトでは、SocketIO チャネルはソケット ID を `sender_id`として使用するため、ページがリロードされるたびにセッションが再起動されます。`session_persistence` を `true` に設定して、それを回避できます。その場合、フロントエンドはセッションIDを生成し、`接続`イベントの直後に`{session_id: [session_id]}`でイベント`session_request`を発行することで、それをRasa Coreサーバーに送信します。
> 
> [Webchat](https://github.com/botfront/rasa-webchat) の例では、このセッション作成メカニズム (バージョン >= 0.5.0) が実装されています。

> [!note]  
> SocketIO クライアント/サーバーの互換性: Rasa に接続する SocketIO クライアントのバージョンは、Rasa で使用される [python-socketio](https://github.com/miguelgrinberg/python-socketio) および [python-engineio](https://github.com/miguelgrinberg/python-engineio) パッケージのバージョンと互換性がある必要があります。お使いの Rasa のバージョンに関連する [`pyproject.toml`](https://github.com/RasaHQ/rasa/blob/main/pyproject.toml) ファイルと公式の `python-socketio` 互換性表を参照してください。

### JWT認証

SocketIO チャネルは、`credentials.yml` ファイルで`jwt_key`とオプションの`jwt_method`を定義することで、接続時に JWT 認証を実行するようにオプションで構成できます。

```yaml-rasa
socketio:
  user_message_evt: user_uttered
  bot_message_evt: bot_uttered
  session_persistence: true
  jwt_key: my_public_key
  jwt_method: HS256
```

最初に接続を要求するとき、クライアントはエンコードされたペイロードをキー`トークン`の下のJSONオブジェクトとして渡す必要があります。

```json
{
  "token": "jwt_encoded_payload"
}
```

### チャットウィジェット

SocketIOチャネルをセットアップしたら、公式のRasa Chat Widgetを任意のWebページで使用できます。以下をサイトのHTMLに貼り付け、RasaインスタンスのURLを`data-websocket-url`属性に貼り付けるだけです

```html
<div id="rasa-chat-widget" data-websocket-url="https://your-rasa-url-here/"></div>
<script src="https://unpkg.com/@rasahq/rasa-chat" type="application/javascript"></script>
```

Web サイトのウィジェットを完全にカスタマイズする方法など、詳細については、[完全なドキュメント](https://chat-widget-docs.rasa.com/)を参照してください。

または、ウィジェットを React アプリに埋め込む場合は、 [NPM パッケージリポジトリ内のライブラリ](https://www.npmjs.com/package/@rasahq/rasa-chat)。