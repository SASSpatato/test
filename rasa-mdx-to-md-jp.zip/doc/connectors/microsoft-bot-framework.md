---
id: microsoft-bot-framework
sidebar_label: Microsoft Bot Framework
title: Microsoft Bot Framework
description: Build a Rasa Chat Bot on Microsoft Bot Framework
---

資格情報を取得するには、まず Microsoft アプリを作成する必要があります。それらを取得したら、これらを`credentials.yml`に追加できます。

Microsoft Bot Framework がメッセージを送信するエンドポイント URL は、 のように `http://<host>:<port>/webhooks/botframework/webhook` なります ホストとポートを、実行中の Rasa サーバーの適切な値に置き換えます。

## Microsoft Bot Framework での実行

Botframework 資格情報を`credentials.yml`に追加します。

```yaml-rasa
botframework:
  app_id: "MICROSOFT_APP_ID"
  app_password: "MICROSOFT_APP_PASSWORD"
```

Rasa サーバーを再起動して、Microsoft Bot Framework がメッセージの送信先に新しいチャネル エンドポイントを使用できるようにします。