---
id: hangouts
sidebar_label: Google Hangouts Chat
title: Google Hangouts Chat
description: Build a Rasa Chat Bot on Google Hangouts Chat
---

## ハングアウト チャットの設定

このチャネルは、標準の Rasa REST チャネルと同様に機能します。チャネルからの要求ごとに、ボットは 1 つの応答を送信します。応答は、テキストまたはいわゆるカードとしてユーザーに表示されます (詳細については、「カード」セクションを参照してください)。

Rasa ボットを Google ハングアウト チャットに接続するには、まず Google Developer Console で Hangouts API を含むプロジェクトを作成する必要があります。そこでボットのエンドポイントを指定できます。このエンドポイントは `https://<host>:<port>/webhooks/hangouts/webhook` 、ホストとポートを実行中の Rasa サーバーの適切な値に置き換えます。

> [!note]  https を設定する 
> ハングアウト チャットは `https` 経由でエンドポイントにのみメッセージを転送するため、適切な対策を講じて設定に追加してください。ボットのローカル テストについては、[[messaging-and-voice-channels#ローカルマシンでのチャネルのテスト|ローカルマシンでのチャネルのテスト]]を参照してください。

Google Developer コンソールで、OAuth2 を使用する場合の OAuth2 認証の範囲を決定するプロジェクト ID(プロジェクト番号またはアプリ ID とも呼ばれます)を取得します。ハングアウト チャット API はリクエストごとにベアラー トークンを送信しますが、トークンを実際に検証するのはボット次第であるため、チャネルはこれがなくても機能します。詳しくは、[Google ハングアウトのドキュメント](https://developers.google.com/hangouts/chat)をご覧ください。検証を行う場合は、以下に示すように、`credentials.yml` ファイル内に`project_id`必ず含めてください。

ハングアウト チャットとボット間の非同期通信を実装する可能性は存在しますが、Rasa ボットは通常同期的な性質を持っているため、この機能はこのチャネルには含まれていません。

### ハングアウト チャットでの実行

ハングアウトの認証情報を`credentials.yml`に追加します。

```yaml-rasa
hangouts:
  # no credentials required here
```

OAuth2を使用する場合は、Google Developer Consoleから取得したプロジェクトIDを追加します。

```yaml-rasa
hangouts:
  project_id: "12345678901"
```

Rasa サーバーを再起動して、新しいチャネル エンドポイントを Google ハングアウトでメッセージの送信できるようにします。

### カードとインタラクティブカード

ハングアウト チャットでボット メッセージを表示するには、テキストまたはカードの 2 つの方法があります。受信した要求ごとに、ボットはすべてのメッセージを 1 つの応答で送信します。これらのメッセージの 1 つがカード (画像など) の場合、他のすべてのメッセージもカード形式に変換されます。

インタラクティブカードは、ボタンがクリックされたときなど、ユーザーインタラクションの`CARD_CLICKED`イベントをトリガーします。`actions.py` で via `dispatcher.utter_button_message()` など、インタラクティブ カードを作成するときに、`CARD_CLICKED` イベントで返され、`HangoutsInput` チャネルによって抽出される各ボタンのペイロードを指定できます(例: `buttons=[{"text":"Yes!", "payload":"/affirm"}, {"text":"Nope.", "payload":"/deny"}])` です。カードの更新はまだサポートされていません。

カードの詳細については、 [ハングアウトのドキュメント](https://developers.google.com/hangouts/chat/reference)。

### その他のハングアウト チャット イベント

`MESSAGE` と `CARD_CLICKED` の他に、ハングアウト チャットには `ADDED_TO_SPACE` と `REMOVED_FROM_SPACE` は、ボットがダイレクト メッセージまたはチャット ルーム スペースに追加または削除されたときにトリガーされます。これらのイベントのデフォルトのインテント名は、`HangoutsInput` コンストラクタ メソッドで変更できます。