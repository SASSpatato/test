---
id: mattermost
sidebar_label: Mattermost
title: Mattermost
description: Build a Rasa Chat Bot on Mattermost
---

資格情報を取得するには、まず mattermost アプリを作成する必要があります。それらを取得したら、これらを`credentials.yml`に追加できます。

## 資格情報の取得

Mattermost は現在、セキュリティを強化するためにボット アカウントを使用しています。そのため、ガイドを使用してボットを作成し、credentials.yml ファイルに必要なトークンを取得できます。

ボットアカウントの作成の詳細については、 [ボットの作成](https://docs.mattermost.com/developer/bot-accounts.html#bot-account-creation)。

既存のユーザーアカウントをボットアカウントに変換する方法については、 [ユーザーコンバージョン](https://docs.mattermost.com/developer/bot-accounts.html#how-do-i-convert-an-existing-account-to-a-bot-account)。

**送信 Webhook の設定方法:**

1.  Mattermost 発信 Webhook を作成するには、Mattermost チーム サイトにログインし、**メイン メニュー > 統合 > 発信 Webhooks** に移動します。
    
2.  **送信 Webhook の追加** をクリックします。
    
3.  ボットを入れるチャネルなどの詳細を入力します。**トリガーワード**セクションが`@yourbotname`で設定されていることを確認して、ボットが発言されたすべての内容でトリガーされないようにする必要があります。
    
4.  **コンテンツタイプ**はapplication`/json`に設定する必要があります。
    
5.  trigger **when** が値に設定されていることを確認してください。 **最初の単語はトリガーワードと完全に一致**します。
    
6.  コールバック URL を追加します ( のように `http://<host>:<port>/webhooks/mattermost/webhook` なります) ホストとポートを、実行中の Rasa サーバーの適切な値に置き換えます。
    

詳細な手順については、 [マターモストドキュメント](https://docs.mattermost.com/guides/developer.html)。

## Mattermostでの実行

Mattermostの認証情報を`credentials.yml`に追加します。

```yaml-rasa
mattermost:
  url: "https://chat.example.com/api/v4"
  token: "xxxxx" #  the token for the bot account from creating the bot step.
  webhook_url: "https://server.example.com/webhooks/mattermost/webhook"  # this should match the callback url from step 6
```

Rasaサーバーを再起動して、Mattermostがメッセージの送信先に新しいチャネルエンドポイントを使用できるようにします。