---
id: slack
sidebar_label: Slack
title: Slack
description: Build a Rasa Chat Bot on Slack
---

ボットを Slack に接続するには、メッセージの送信 (API 資格情報を使用) とメッセージを受信する (Webhook を使用) するように設定する必要があります。

## メッセージの送信

Rasa プロジェクトのルート フォルダー `credentials.yml`新しいファイルを作成します (`rasa init` を使用した場合、このファイルはすでに存在しているはずなので、編集するだけです)。ファイルに次の行を追加します。

```yaml-rasa
slack:
  slack_channel: "CA003L0XZ"    # channel ID, not a channel name!
  slack_token: "xoxb-XXX"       # token obtained in the next step
  slack_signing_secret: "YYY"   # secret obtained in the next step
```

`slack_channel`は、ダイレクト メッセージやアプリのメンションをリッスンする既定の動作 (*@app_name*) に加えて、ボットが通信のためにリッスンする必要があるチャネルまたは個人にすることができます。チャンネル ID を取得するには、Slack でチャンネルを右クリックし、**リンクをコピー**を選択します。id は URL の最後のコンポーネントになります。

次のいくつかのステップでは、Slack アプリを作成して、 `slack_token`と`slack_signing_secret`:

1.  アプリを作成するには、[Your Apps](https://api.slack.com/apps "The Your Apps section of your Slack interface")に移動し、**新しいアプリの作成**をクリックします。
    
    ![[slack-create-app.png]]
    
    **[アプリ名**] を入力し、アプリを試してビルドする**開発ワークスペース**を選択します。
    
2. **OAuth & Permissions** に移動し、**Scopes** まで下にスクロールします。スコープは、ワークスペースで操作を行うアクセス許可をアプリに付与します。
    
    開始するには、少なくとも次のスコープを追加する必要があります。
    
    *   `app_mentions:read`、
    *   `チャンネル:ヒストリー[じーど:ひきり]`
    *   `チャット:書き込み、`
    *   `グループ:ヒストリー、`
    *   `im:history`、
    *   `mpim:history` と
    *   `リアクション:書き込み[リアクション:write]`
    
    ![[slack-scopes.png]]
    
    Slacks API のドキュメントには、[利用可能なすべてのスコープのリストと説明](https://api.slack.com/scopes)があります。
    
3.  **OAuth とアクセス許可** ページで、**ワークスペースにアプリをインストール** をクリックして、ボットをワークスペースに追加します。
    
    ![[slack-install-app.png]]
    
    追加すると、Slack はボット **ユーザーの OAuth アクセス トークン**を表示し、`slack_token`の値として `credentials.yml` に追加する必要があります。
    
    ```yaml-rasa
    slack:
      slack_channel: "your-channel" # choose a channel for your bot
      slack_token: "xoxb-XXX"       # token obtained in the next step
      slack_signing_secret: "YYY"   # secret obtained in the next step
    ```
    
    トークンは `xoxb` で始まる必要があります。
    
4.  基本**情報**にアクセスして**、署名の秘密**を収集します。
    
    ![[slack-secret.png]]
    
    署名シークレットを `slack_signing_secret` の値として`credentials.yml`にコピーします。
    
    ```yaml-rasa
    slack:
      slack_channel: "your-channel" # choose a channel for your bot
      slack_token: "xoxb-XXX"       # token obtained in the next step
      slack_signing_secret: "YYY"   # secret obtained in the next step
    ```
    

この設定により、ボットはメッセージを送信できるようになります。それでは、メッセージを受信して反応するための設定に移りましょう。

## メッセージの受信

続行する前に、[[slack#メッセージの送信|Sending Messages]] を呼び出し、`Slack` 認証情報を credentials.yml ファイルに追加しました。

メッセージを受信するには、Slack がボットに到達して新しいメッセージについて通知するための公開されている URL が必要です。ローカルで実行している場合は、[[messaging-and-voice-channels#ローカルマシンでのチャネルのテスト|ngrokを使用したチャネルのテスト]]を使用できます。

1.  メッセージを受信するようにボットを構成するには、ボットが実行されている必要があります。ボットを起動します (例:
    
    ```bash
    rasa run
    ```
    
    ローカルで実行している場合は、ngrok (またはパブリック URL を取得する別のツール) も実行されていることを確認してください。
    
2.  Slack UI を使用してボットに直接メッセージを送信するには、**App Home** にアクセスし、 一番下までスクロールし、 `Allow users to send Slash commands and messages from the messages tab.`
    
    変更を有効にする前に、Slack アプリを終了して再度開く必要がある場合があります。
    
    ![[slack-app-home.png]]
    
1.  **イベント サブスクリプション** に移動し、**イベントを有効にする** をオンにして、Webhook を設定します。
    
    リクエスト URL として、ボットのパブリック URL を入力し、`/webhooks/slack/webhook` を追加します。 `<host>` を URL に `https://<host>/webhooks/slack/webhook` 置き換えます。ngrok を使用している場合、URL は `https://92832de0.ngrok.io/webhooks/slack/webhook` のようになります。
    
    `localhost` の URL は使用できません。
    
    ![[slack-request-url.png]]
    
2.  最後のステップとして、同じページで**ボットイベントをサブスクライブ**する必要があります。次のイベントを追加する必要があります。
    
    *   `message.channels`、
    *   `message.groups、`
    *   `message.im` と
    *   `message.mpim` です。
    
    ![[slack-events.png]]
    
    これらのイベントを追加した後は、ページの下部にある **変更を保存** をクリックしてください。
    
    (メッセージの送信を設定するときにアプリに必要なすべての権限を付与しなかった場合は、**アプリを再インストール**するように求められます。それ以外の場合は、Slack が「**成功」**で変更を確認します。
    

> [!note] 
>  チャンネルへの招待[Slack ドキュメント](https://api.slack.com/authentication/basics#calling)に従って、ボットがアクセスする必要があるチャネルにボットを招待してください。これを行うには、チャネルで `/invite` を使用します。

これでボットの準備が整い、新しいメッセージに関する Webhook 通知を受け取ります。

## オプション: 対話型コンポーネント

完了したら[[slack#メッセージの送信|メッセージの送信]]と[[slack#メッセージの受信|Receiving Messages]] ボットの準備が整いました。Slack の[インタラクティブ コンポーネント](https://api.slack.com/block-kit/interactivity) (ボタンまたはメニュー) を使用する場合は、追加の設定を行う必要があります。

[**インタラクティブ性とショートカット]** ページを開き、[**インタラクティブ性**] をオンに切り替えます。その後、[[slack#メッセージの受信|Receiving Messages]](例: `https://<host>/webhooks/slack/webhook` .

![[slack-interactivity.png]]

## 追加の Slack オプション

Slack接続のすべての構成パラメーターの完全な概要は次のとおりです。

```yaml-rasa
slack:
  slack_channel: "CA003L0XZ"    # channel ID, not a channel name!
  slack_token: "xoxb-XXX"       # token obtained in the next step
  slack_signing_secret: "YYY"   # secret obtained in the next step
  proxy: "http://myProxy.online"  # Proxy Server to route your traffic through. This configuration is optional. Only HTTP proxies are supported
  slack_retry_reason_header: "x-slack-retry-reason"  # Slack HTTP header name indicating reason that slack send retry request. This configuration is optional.
  slack_retry_number_header: "x-slack-retry-num"  # Slack HTTP header name indicating the attempt number. This configuration is optional.
  errors_ignore_retry: None  # Any error codes given by Slack included in this list will be ignored. Error codes are listed [here](https://api.slack.com/events-api#errors).
  use_threads: False  # If set to True, bot responses will appear as a threaded message in Slack. This configuration is optional and set to False by default.
  conversation_granularity: "sender" # sender allows 1 conversation per user (across channels), channel allows 1 conversation per user per channel, thread allows 1 conversation per user per thread. This configuration is optional and set to sender by default.
```

変更後、必ず Rasa サーバーを再起動してください。 変更を有効にする`credentials.yml`。