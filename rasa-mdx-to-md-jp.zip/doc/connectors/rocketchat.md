---
id: rocketchat
sidebar_label: RocketChat
title: RocketChat
description: Build a Rasa Chat Bot on Rocketchat
---

## 資格情報の取得

**Rocket.Chatのセットアップ方法:**

1.  メッセージの投稿に使用するユーザーを作成し、その資格情報を資格情報ファイルに設定します。
    
2.  管理者としてログインして、Rocket.Chat の発信 Webhook を作成します。 Rocket.Chat に移動し、 **管理 > 統合 > 新規統合**。
    
3.  [**送信 Webhook**] を選択します。
    
4.  [**イベント トリガー]** セクションを **[メッセージ送信済み]** の値に設定します。
    
5.  ボットが必要なチャネルを含む詳細を入力します 聞く。オプションで、 単語**セクション**を`@yourbotname`でトリガーして、ボットが発言されたすべての内容でトリガーされないようにします。
    
6.  **[URL]** セクションで、URL を `http://<host>:<port>/webhooks/rocketchat/webhook` 、ホストとポートを実行中の Rasa サーバーの適切な値に置き換えます。
    

Rocket.Chat Webhook の詳細については、 [Rocket.Chatガイド](https://docs.rocket.chat/use-rocket.chat/workspace-administration/integrations)。

## RocketChatでの実行

RocketChat 認証情報を`credentials.yml`に追加します。

```yaml-rasa
rocketchat:
  user: "yourbotname"
  password: "YOUR_PASSWORD"
  server_url: "https://demo.rocket.chat"
```

Rasaサーバーを再起動して、RocketChatがメッセージを送信できる新しいチャネルエンドポイントを使用できるようにします。