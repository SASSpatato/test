---
id: audiocodes-voiceai-connect
sidebar_label: Audiocodes VoiceAI Connect
title: Audiocodes VoiceAI Connect
description: Build a Rasa Voice Bot on Audiocodes VoiceAI Connect
---

このチャネルを使用して、Rasa アシスタントを [Audiocodes VoiceAI 接続](https://www.audiocodes.com/solutions-products/voiceai/voiceai-connect)に接続します。

## 資格情報の取得

資格情報を取得するには、[VoiceAI 接続ポータル](https://voiceaiconnect.audiocodes.io/)でボットを作成します。

1.  左側のサイドバーで [ボット]を選択します。
2.  **+** 記号をクリックして、新しいボットを作成します。
3.  Bot Framework として **Rasa** を選択します
4.  ボットの URL を設定し、トークン値を選択します。

> [!info]  
> ローカルでテストするときにトンネリング ソリューションを使用してボット URL を設定する ローカル マシンでチャネルをテストするときに必要なボット URL を生成する方法については、こちら [[messaging-and-voice-channels#ローカルマシンでのチャネルのテスト|section]] にアクセスしてください。

## 資格情報の設定

上記で選択したトークン値が`credentials.yml`で使用されます。

```yaml
rasa_plus.channels.audiocodes.AudiocodesInput:
    token: <token>
```

オプションのパラメータを指定することもできます。

| パラメーター | 既定値 | 形容 |
| --- | --- | --- |
| token | デフォルト値なし | Rasa アシスタントと VoiceAI Connect 間の通話を認証するためのトークン |
| use_websocket | true | true の場合、Rasa は Web ソケットを介してメッセージを送信します。false に設定すると、Rasa は http API 呼び出しを介してメッセージを送信します。 |
| keep_alive | 120 | 数秒で。進行中の会話ごとに、VoiceAI Connect は会話が Rasa 側でまだアクティブであることを定期的に確認します。 |

次に、Rasa サーバーを再始動して、新しいチャネル・エンドポイントを使用可能にします。

## 使い

### ユーザーからのメッセージの受信

ユーザーが電話で話すと、VoiceAI Connect は、他のチャネルと同様に、テキスト メッセージを (音声テキスト変換エンジンで処理した後) アシスタントに送信します。このメッセージはNLUによって解釈され、ルール、ストーリー、フォームで会話を推進できます。

### ユーザーへのメッセージの送信

ボットは、他のチャネルと同様にテキスト メッセージで応答します。テキスト読み上げエンジンはテキストを変換し、音声メッセージとしてユーザーに配信します。

次に例を示します。

```yaml
utter_greet:
    - text: 'Hello! isn’t every life and every work beautiful?'
```

> [!note]  テキスト 
> メッセージのみが許可されます。画像、添付ファイル、ボタンは音声チャンネルでは使用できません。

### 会話イベントの処理

音声以外のイベントもボットで処理できます。以下にいくつかの例を示します。

| 出来事 | 意 | 形容 |
| --- | --- | --- |
| start | vaig_event_start | VoiceAI は、電話に出たときにこのインテントを送信します。一般に、その意図に対する応答は、歓迎メッセージまたは挨拶メッセージです。呼び出しコンテキストはエンティティを通じて提供されます |
| end | vaig_event_end | VoiceAI は、通話が終了するとこのインテントを送信します。これを使用して、通話情報を更新するアクションを呼び出すことができます。 |
| DTMF | vaig_event_DTMF | VoiceAI は、DTMF トーンを受信したとき (つまり、ユーザーが電話機のキーボードの数字を押す) ときにこのインテントを送信します。送信された数字は、値エンティティで渡されます |

一般的なパターンでは、`イベントが送信`されるたびに、ボットはエンティティ内のコンテキスト情報を含む `vaig_event_<event>` インテントを受け取ります。

ボットへの呼び出しが開始されたときにグリーティング メッセージを送信する簡単なルールを次に示します。

```yaml
- rule: New call
  steps:
      - intent: vaig_event_start
      - action: utter_greet
```

イベントの完全なリストについては、[VoiceAI Connect のドキュメント](https://techdocs.audiocodes.com/voice-ai-connect/#VAIG_Combined/voiceai_connect.htm?TocPath=VoiceAI%2520Connect%257C_____0)を確認してください。

### 通話の設定

Rasa から VoiceAI Connect にイベントを送信して、現在の通話設定を変更できます。たとえば、ユーザーが 5 秒以上沈黙したときに通知を受け取ったり、VoiceAI Connect による DTMF 数字の送信方法をカスタマイズしたりする必要がある場合があります。

通話設定イベントはカスタムメッセージとともに送信され、現在の会話(場合によってはメッセージ)に固有です。つまり、すべての会話に同じ動作が適用されるように、ストーリーやルールの一部である必要があります。

これらのRasa応答は何も発せず、音声ゲートウェイを設定するだけです。たとえば、プレフィックスに `utter_config_<what_it_does>` を付けるなど、名前を異なって指定することをお勧めします

サポートされているすべてのイベントは、[VoiceAI Connect のドキュメント](https://techdocs.audiocodes.com/voice-ai-connect/#VAIG_Combined/voiceai_connect.htm?TocPath=VoiceAI%2520Connect%257C_____0)に詳細に記載されています。ここでは、カスタムメッセージとイベントの使用を説明するために、1つの例を見ていきます。

#### 例: PIN コードの変更

この例では、ユーザーが PIN コードを変更できるようにするフローを作成します。

```yaml
- rule: Set pin code
  steps:
  # User says "I want to change my pin code"
  - intent: set_pin_code
  # Send the noUserInput configuration event
  - action: utter_config_no_user_input
  # Send the DTMF format configuration event
  - action: utter_config_dtmf_pin_code 
  # A standard Rasa form to collect the pin code from the user
  - action: pin_code_form 
  - ...
```

ドメインには、`utter_config_<config_event>` の応答を追加できます。

[`noUserInput` イベント](https://techdocs.audiocodes.com/voice-ai-connect/#VAIG_Combined/inactivity-detection.htm?TocPath=Bot%2520integration%257CReceiving%2520notifications%257C_____3)

```yaml
  utter_config_no_user_input:
  - custom:
      type: event
      name: config
      sessionParams:
        # If user stays silent for 5 seconds or more, the notification will be sent
        userNoInputTimeoutMS: 5000
        # If you want to allow for more than one notification during a call
        userNoInputRetries: 2
        # Enable the noUserInput notification
        userNoInputSendEvent: true
```

[`DTMF` イベント](https://techdocs.audiocodes.com/voice-ai-connect/#VAIG_Combined/receive-dtmf.htm?TocPath=Bot%2520integration%257CReceiving%2520notifications%257C_____2)

```yaml
   utter_config_dtmf_pin_code:
  - custom:
      type: event
      name: config
      sessionParams:
        # Enable grouped collection (i.e will send all digits in a single payload)
        dtmfCollect: true
        # If more than 5 secs have passed since a digit was pressed, 
        # the input is considered completed and will be sent to the bot
        dtmfCollectInterDigitTimeoutMS: 5000
        # If 6 digits are collected, VoiceAI will send those 6 digits
        # even if the user keeps pressing buttons
        dtmfCollectMaxDigits: 6
        # If the user presses '#' the input is considered complete
        dtmfCollectSubmitDigit: "#"
```

これで、`pin_code_form`の`pin_code`スロットを設定して、`vaig_event_DTMF`インテントを持つ`値`エンティティからピンコードを抽出できます。

```yaml
  pin_code:
    type: text
    influence_conversation: false
    mappings:
    - type: from_entity
      entity: value
      intent: vaig_event_DTMF
      not_intent: vaig_event_noUserInput
      conditions:
      - active_loop: pin_code_form
        requested_slot: pin_code
```

`not_intent` フィールドで`vaig_event_noUserInput`がどのように宣言されたかに注目してください。

`vaig_event_noUserInput`インテントは、ユーザーが設定に従って沈黙しているときに VoiceAI Connect によって送信されるため、ルールまたはストーリーから会話を取得し、失敗を適切に処理できるように、フォームを非アクティブ化する必要があります。

次の例では、`pin_code_form`ループがアクティブなときに`vaig_event_noUserInput`インテントを受信した場合(つまり、ユーザーが沈黙のままである)に現在のフローをキャンセルします。

```yaml
- rule: Set pin code - happy path
  steps:
  - intent: set_pin_code
  - action: utter_config_no_user_input
  - action: utter_config_dtmf_pin_code
  - action: pin_code_form
  - active_loop: pin_code_form
  - active_loop: null
  - slot_was_set:
    - requested_slot: null
  - action: utter_pin_code_changed
  - action: action_pin_code_cleanup

- rule: Set pin code - no response - cancel.
  condition:
  - active_loop: pin_code_form
  steps:
  - intent: vaig_event_noUserInput
  - action: utter_cancel_set_pin_code
  - action: action_deactivate_loop
  - active_loop: null
```