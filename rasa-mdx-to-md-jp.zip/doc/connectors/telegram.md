---
id: telegram
sidebar_label: Telegram
title: Telegram
description: Build a Rasa Chat Bot on Telegram
---

資格情報を取得するには、まず Telegram ボットを作成する必要があります。それらを取得したら、これらを`credentials.yml`に追加できます。

## 資格情報の取得

**Telegram 資格情報の取得方法:** Telegram ボットを設定する必要があります。

1.  ボットを作成するには、[ボットの父](https://web.telegram.org/#/im?p=@BotFather)に移動し、「`/newbot`」と入力して指示に従います。Telegramがメッセージを送信するURLは次のようになります `http://<host>:<port>/webhooks/telegram/webhook` 、ホストとポートを実行中の Rasa サーバーの適切な値に置き換えます。
    
2.  最後に`access_token`を取得し、設定したユーザー名が`認証`になります。
    
3.  グループ設定でボットを使用する場合は、`/setprivacy` と入力してグループ プライバシー モードを有効にすることをお勧めします。その後、ボットはユーザーのメッセージが `/bot` で始まる場合にのみリッスンします。
    

詳細については、[Telegram HTTP API](https://core.telegram.org/bots/api) をご覧ください。

## Telegramで実行する

Telegram 資格情報を`credentials.yml`に追加します。

```yaml-rasa
telegram:
  access_token: "490161424:AAGlRxinBRtKGb21_rlOEMtDFZMXBl6EC0o"
  verify: "your_bot"
  webhook_url: "https://your_url.com/webhooks/telegram/webhook"
```

Rasa サーバーを再起動して、Telegram がメッセージを送信するために新しいチャネル エンドポイントを使用できるようにします。

> [!note]  
> `/start` メッセージの処理会話の開始時に、ユーザーは Telegram の [開始] ボタンを押します。これにより、*コンテンツ /start* が送信されるメッセージがトリガーされます。ボットが nlu トレーニング データ ファイルで特定のインテントを設計して、このイントロ メッセージを処理できることを確認します。次に、この`開始`インテントをストーリーまたはルールとともにドメインに追加して処理します。

## サポートされている応答添付ファイル

標準の`テキスト:`応答に加えて、このチャネルは[Telegram API](https://core.telegram.org/bots/api/#message)の次のコンポーネントもサポートしています。

*   `button` 引数:
    *   button_type: インライン |縦型 |答える
*   `カスタム`引数:
    *   写真
    *   オーディオ
    *   文書
    *   ステッカー
    *   ビデオ
    *   video_note
    *   animation
    *   声
    *   メディア
    *   緯度、経度(場所)
    *   緯度、経度、タイトル、住所(会場)
    *   phone_number
    *   game_short_name
    *   アクション

例：

```yaml-rasa

  utter_ask_transfer_form_confirm:
  - buttons:
    - payload: /affirm
      title: Yes
    - payload: /deny
      title: No, cancel the transaction
    button_type: vertical
    text: Would you like to transfer {currency}{amount_of_money} to {PERSON}?
    image: "https://i.imgur.com/nGF1K8f.jpg"
```

```yaml-rasa
  utter_giraffe_sticker:
  - text: Here's my giraffe sticker!
    custom:
      sticker: "https://github.com/TelegramBots/book/raw/master/src/docs/sticker-fred.webp"
```