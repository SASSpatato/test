---
id: custom-connectors
sidebar_label: Custom Connectors
title: Custom Connectors
description: Deploy and Run a Rasa Chat Bot on a custom chat interface
---

独自のカスタムチャネルコネクタをPythonクラスとして実装できます。クラスを `rasa.core.channels.rest.RestInput` テンプレートとして使用できます。

カスタム コネクタ クラスは、サブクラス `rasa.core.channels.channel.InputChannel` 化する必要があります 少なくとも`ブループリント`と`名前`のメソッドを実装します。

## `名前`メソッド

`name` メソッドは、コネクタの Webhook の URL プレフィックスを定義します。また、[[responses#チャネル固有の応答変動|channel specific response variations]] で使用するチャネル名と、[トリガー インテント エンドポイント](https://www.rasa.com/docs/rasa/pages/http-api#operation/triggerConversationIntent)の `output_channel` クエリ パラメーターに渡す名前も定義します。

たとえば、カスタムチャネルの名前が `myio` の場合、`name` メソッドを次のように定義します。

```python
from rasa.core.channels.channel import InputChannel

class MyIO(InputChannel):
    def name() -> Text:
        """Name of your custom channel."""
        return "myio"
```

`myio` チャネルに固有の応答バリエーションを次のように記述します。

```yaml-rasa
responses:
  utter_greet:
    - text: Hi! I'm the default greeting.
    - text: Hi! I'm the custom channel greeting
      channel: myio
```

呼び出すカスタムチャネルに与えるWebhookは、 `http://<host>:<port>/webhooks/myio/webhook` 、ホストとポートを実行中の Rasa サーバーの適切な値に置き換えます。

## `ブループリント`方式

`ブループリント`メソッドは、[サニックなブループリント](https://sanicframework.org/en/guide/best-practices/blueprints.html#overview)を作成する必要があります Sanic サーバーに接続できます。 ブループリントには、ルート `/` の `health` とルート `/webhook` の `receive` の 2 つのルートが必要です (以下のカスタム チャネルの例を参照)。

`受信`エンドポイントの実装の一環として、ユーザー メッセージを処理するように Rasa に指示する必要があります。これを行うには、

```python
    on_new_message(
      rasa.core.channels.channel.UserMessage(
        text,
        output_channel,
        sender_id
      )
    )
```

`on_new_message` を呼び出すと、ユーザー メッセージが [`handle_message`](https://github.com/RasaHQ/rasa/blob/c922253fe890bb4903329d4ade764e0711d384ec/rasa/core/agent.py#L511_) メソッドに送信されます。

`UserMessage` オブジェクトの詳細については、[こちらを参照してください](https://www.rasa.com/docs/rasa/reference/rasa/core/channels/channel#usermessage-objects)。

`output_channel`引数は、 [`OutputChannel`](https://www.rasa.com/docs/rasa/reference/rasa/core/channels/channel#outputchannel-objects) クラスを使用します。できます 特定のチャットチャネルのメソッドを使用して独自の出力チャネルクラスを実装します (テキストや画像を送信するメソッドなど)または、 [`CollectingOutputChannel (出力チャネルの収集)`](https://www.rasa.com/docs/rasa/reference/rasa/core/channels/channel#collectingoutputchannel-objects) ボットがメッセージを処理している間に Rasa が作成するボット応答を収集し、 エンドポイント応答の一部として。これは、`RestInput` の方法です。 チャネルが実装されています。独自の出力を作成して使用する方法の例については、 channel、他の 出力チャネル、`たとえばrasa.core.channels.slack`の`SlackBot`。

`CollectingOutputChannel` を使用するカスタム チャネル コネクタの簡略化された例を次に示します。

```python
import asyncio
import inspect
from sanic import Sanic, Blueprint, response
from sanic.request import Request
from sanic.response import HTTPResponse
from typing import Text, Dict, Any, Optional, Callable, Awaitable, NoReturn

import rasa.utils.endpoints
from rasa.core.channels.channel import (
    InputChannel,
    CollectingOutputChannel,
    UserMessage,
)

class MyIO(InputChannel):
    def name() -> Text:
        """Name of your custom channel."""
        return "myio"

    def blueprint(
        self, on_new_message: Callable[[UserMessage], Awaitable[None]]
    ) -> Blueprint:

        custom_webhook = Blueprint(
            "custom_webhook_{}".format(type(self).__name__),
            inspect.getmodule(self).__name__,
        )

        @custom_webhook.route("/", methods=["GET"])
        async def health(request: Request) -> HTTPResponse:
            return response.json({"status": "ok"})

        @custom_webhook.route("/webhook", methods=["POST"])
        async def receive(request: Request) -> HTTPResponse:
            sender_id = request.json.get("sender") # method to get sender_id 
            text = request.json.get("text") # method to fetch text
            input_channel = self.name() # method to fetch input channel
            metadata = self.get_metadata(request) # method to get metadata

            collector = CollectingOutputChannel()
            
            # include exception handling

            await on_new_message(
                UserMessage(
                    text,
                    collector,
                    sender_id,
                    input_channel=input_channel,
                    metadata=metadata,
                )
            )

            return response.json(collector.messages)

        return custom_webhook
```

## メッセージのメタデータ

カスタムアクションでフロントエンドからの追加情報を使用する必要がある場合は、ユーザーメッセージの`メタデータ`キーを使用してこの情報を渡すことができます。この情報は、必要に応じて、Rasaサーバーを介してアクションサーバーにユーザーメッセージに付随し、`トラッカー`に保存されます。メッセージメタデータは、NLU の分類やアクション予測に直接影響しません。

`InputChannel` クラスの`既定の get_metadata` 実装では、**すべてのメタデータが無視されます**。カスタムコネクタでメタデータを抽出するには、`get_metadata`メソッドを実装します。`SlackInput` チャネルは、チャネルの応答形式に従ってメタデータを抽出する`get_metadata`メソッドの 1 つの例を提供します。

## カスタムチャネルの資格情報

カスタムチャネルを使用するには、`credentials.yml` という資格情報構成ファイルでそのチャネルの資格情報を指定する必要があります。この資格情報ファイルには、カスタム チャネルの**モジュール パス** (チャネル名ではない) と、必要な構成パラメーターが含まれている必要があります。

たとえば、`ファイル addons/custom_channel.py` に保存された `MyIO` というカスタム コネクタ クラスの場合、モジュール パスは `addons.custom_channel になります。MyIO`で、資格情報は次のようになります。

```yaml-rasa
addons.custom_channel.MyIO:
  username: "user_name"
  another_parameter: "some value"
```

Rasa サーバーにカスタムチャネルを認識させるには、起動時に Rasa サーバーへの`credentials.yml`パスをコマンドライン引数 `--credentials` で指定します。

## カスタム・コネクタWebhookのテスト

カスタムコネクタをテストするには、次の形式の json 本文を使用してメッセージを Webhook に `POST` します。

```json
{
  "sender": "test_user",  // sender ID of the user sending the message
  "message": "Hi there!",
  "metadata": {}  // optional, any extra info you want to add for processing in NLU or custom actions
}
```

ローカルで実行されているRasaサーバーの場合、curlリクエストは次のようになります。

```bash
curl --request POST 
     --url http://localhost:5005/webhooks/myio/webhook 
     --header 'Content-Type: application/json' 
     --data '{
            "sender": "test_user",
            "message": "Hi there!",
            "metadata": {}
          }'
```