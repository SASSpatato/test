---
id: http-api
sidebar_label: HTTP API
title: Rasa HTTP API
description: Read about Rasa's HTTP API that has endpoints for conversations, training models, and configuring your bot.
abstract: You can use the HTTP API to interact with a running Rasa server. With the API, you can train models,
  send messages, run tests, and more.
---

> [!tip] API エンドポイントをお探しですか?
> 利用可能なすべてのエンドポイントとその要求および応答形式の [API 仕様](/pages/http-api)を確認してください。

## HTTP API の有効化

デフォルトでは、Rasa サーバーを実行しても API エンドポイントは有効になりません。ボットとの対話は、公開されている `Webhooks/<channel>/Webhook` エンドポイントを介して発生する可能性があります。

会話トラッカーやその他のボットエンドポイントとの直接対話のために API を有効にするには、実行コマンドに `--enable-api` パラメーターを追加します。

```bash
rasa run --enable-api
```

NLU のみのモデルでサーバーを起動すると、使用可能なすべてのエンドポイントを呼び出すことができるわけではないことに注意してください。一部のエンドポイントでは、要求を処理するためにトレーニングされた対話モデルが必要なため、409 ステータス コードが返されます。

> [!注意] 
> サーバーへのアクセスを制限するか (ファイアウォールを使用するなど)、認証方法を有効にして、サーバーを必ず保護してください。[[./http-api.md#セキュリティに関する考慮事項|セキュリティに関する考慮事項]]。

デフォルトでは、HTTP サーバーは 1 つのプロセスとして実行されます。`SANIC_WORKERS` 環境変数を使用して、ワーカー プロセスの数を変更できます。ワーカーの数は、使用可能なCPUコアの数に設定することをお勧めします(詳細については、[Sanicのドキュメント](https://sanicframework.org/en/guide/deployment/running.html#workers)を確認してください)。これは、 `RedisLockStore` ([「ストアのロック」](./lock-stores.md)を参照)。

> [!注意]
> [[./connectors/your-own-website.md#websocket チャネル|SocketIO チャネル]] は複数のワーカー プロセスをサポートしていません。

## セキュリティに関する考慮事項

Rasa Serverを外部に直接公開するのではなく、Nginxなどを介して接続することをお勧めします。

ただし、次の 2 つの認証方法が組み込まれています。

### トークンベースの認証

プレーンテキストトークンを使用してサーバーを保護するには、サーバーの起動時に引数 `--auth-token thisismysecret` にトークンを指定します。

```bash
rasa run 
    --enable-api 
    --auth-token thisismysecret
```

サーバーに要求を送信するクライアントは、トークンをクエリ パラメーターとして渡す必要があり、送信しないと要求は拒否されます。たとえば、サーバーからトラッカーを取得するには、次のようにします。

```bash
curl -XGET localhost:5005/conversations/default/tracker?token=thisismysecret
```

### JWT ベースの認証

JWT ベースの認証を使用するには、サーバーの起動時に引数 `--jwt-secret thisismysecret` に JWT シークレットを指定します。

```bash
rasa run 
    --enable-api 
    --jwt-secret thisismysecret
```

非対称アルゴリズムを使用して JWT トークンに署名する場合は、JWT 秘密キーを `--jwt-private-key` CLI 引数に指定できます。公開鍵を `--jwt-secret` 引数に渡し、`アルゴリズムを --jwt-method` 引数に指定する必要があります。

```bash
rasa run 
    --enable-api 
    --jwt-secret <public_key> 
    --jwt-private-key <private_key> 
    --jwt-method RS512
```

サーバーへのクライアント要求には、このシークレットと `HS256` アルゴリズムを使用して署名された有効な JWT トークンが `Authorization` ヘッダーに含まれている必要があります。

```text
"Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ"
                 "zdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIi"
                 "wiaWF0IjoxNTE2MjM5MDIyfQ.qdrr2_a7Sd80gmCWjnDomO"
                 "Gl8eZFVfKXA6jhncgRn-I"
```

トークンのペイロードには、ユーザーキーの下にオブジェクトが含まれている必要があり、`ユーザー`キーには`ユーザー名`属性と`ロール`属性が含まれている必要があります。JWT トークンのペイロードの例を次に示します。

```json
{
    "user": {
        "username": "<sender_id>",
        "role": "user"
    }
}
```

`ロール`が`管理者`の場合、すべてのエンドポイントにアクセスできます。`ロール`が`ユーザー`の場合、`sender_id` パラメーターを持つエンドポイントには、`sender_id`がペイロードの`ユーザー名`プロパティと一致する場合にのみアクセスできます。

```bash
rasa run 
    -m models 
    --enable-api 
    --jwt-secret thisismysecret
```

トークンを作成してエンコードするには、[JWT デバッガー](https://jwt.io/)などのツール、[または PyJWT](https://pyjwt.readthedocs.io/en/latest/) などの Python モジュールを使用できます。