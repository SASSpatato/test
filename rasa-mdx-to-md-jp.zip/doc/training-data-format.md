---
id: training-data-format
sidebar_label: Training Data Format
title: Training Data Format
description: Description of the YAML format for training data
abstract: This page describes the different types of training data
  that go into a Rasa assistant and how this training data is structured.
---

## 概要

Rasaは、NLUデータ、ストーリー、ルールを含むすべてのトレーニングデータを管理するための統合された拡張可能な方法として[YAML](https://yaml.org/spec/1.2/spec.html)を使用します。

トレーニング データは任意の数の YAML ファイルに分割でき、各ファイルには NLU データ、ストーリー、ルールの任意の組み合わせを含めることができます。トレーニングデータパーサーは、最上位のキーを使用してトレーニングデータ型を決定します。

[[glossary.md#[ドメイン](./domain.md)|ドメイン]]はトレーニング データと同じ YAML 形式を使用し、複数のファイルに分割したり、1 つのファイルに結合したりすることもできます。ドメインには、[応答](responses.md)と[フォーム](forms.md)の定義が含まれています。ドメイン ファイルの書式設定方法については、[ドメインのドキュメント](domain.md)を参照してください。

> [!注] レガシーフォーマット 
> Markdown データ形式をお探しですか?Rasa 3.0 では削除されましたが、[マークダウン NLU データ](https://legacy-docs-v1.rasa.com/nlu/training-data-format/)と[マークダウン ストーリー](https://legacy-docs-v1.rasa.com/core/stories/)のドキュメントは引き続き見つかります。トレーニング データが Markdown 形式で残っている場合は、Rasa 2.x を使用してデータを Markdown から YAML に変換することをお勧めします。[[./migration-guide.md|移行ガイド]]では、その方法が説明されています。

### ハイレベル構造

各ファイルには、対応するトレーニング データを含む 1 つ以上の**キー**を含めることができます。1 つのファイルに複数のキーを含めることができますが、各キーは 1 つのファイルに 1 回しか表示できません。使用可能なキーは次のとおりです。

*   `version`
*   `nlu`
*   `stories`
*   `rules`

すべての YAML トレーニング データ ファイルで`バージョン` キーを指定する必要があります。トレーニングデータファイルでバージョンキーを指定しない場合、Rasaは、インストールしたRasaのバージョンでサポートされている最新のトレーニングデータ形式仕様を使用していると見なします。マシンにインストールしたバージョンよりも古い Rasa バージョンのトレーニング データ ファイルはスキップされます。現在、Rasa 3.x の最新のトレーニング データ形式仕様は 3.1 です。

### 例

すべてのトレーニングデータを1つのファイルに保持する短い例を次に示します。

```yaml-rasa
version: "3.1"

nlu:
- intent: greet
  examples: |
    - Hey
    - Hi
    - hey there [Sara](name)

- intent: faq/language
  examples: |
    - What language do you speak?
    - Do you only handle english?

stories:
- story: greet and faq
  steps:
  - intent: greet
  - action: utter_greet
  - intent: faq
  - action: utter_faq

rules:
- rule: Greet user
  steps:
  - intent: greet
  - action: utter_greet

```

テストストーリーを指定するには、テストストーリーを別のファイルに配置する必要があります。

```yaml-rasa
stories:
- story: greet and ask language
- steps:
  - user: |
      hey
    intent: greet
  - action: utter_greet
  - user: |
      what language do you speak
    intent: faq/language
  - action: utter_faq
```

[[#テストストーリー]] はストーリー トレーニング データと同じ形式を使用し、プレフィックス `test_` を付けて別のファイルに配置する必要があります。

> [!note] 
> `|` 記号 上記の例に示すように、`user` キーと `examples` キーの後には `|` (パイプ) 記号が続きます。YAML `|`では、インデントが保持された複数行の文字列を識別します。これにより`、「」、「``」`などの特殊記号をトレーニング例で引き続き使用できます。

## NLU トレーニング データ

[[glossary.md#[NLU](./nlu-training-data.md)|NLU]] トレーニング データは、次の方法で分類されたユーザーの発話の例で構成されます。 [[glossary.md#[意](./nlu-training-data.md)|意図]]。トレーニングの例には[[glossary.md#./training-data-format.md エンティティ 実体|エンティティ]]を含めることもできます。エンティティは、ユーザーのメッセージから抽出できる構造化された情報です。正規表現やルックアップテーブルなどの追加情報をトレーニングデータに追加して、モデルがインテントとエンティティを正しく識別できるようにすることもできます。

NLU トレーニング データは、`nlu` キーで定義されます。このキーの下に追加できる項目は次のとおりです。

*   [[#トレーニング例]] をユーザーの意図でグループ化 (オプションで注釈付き [[#エンティティ]] )

```yaml-rasa
nlu:
- intent: check_balance
  examples: |
    - What's my [credit](account) balance?
    - What's the balance on my [credit card account]{"entity":"account","value":"credit"}
```

*   [[#類義 語]]

```yaml-rasa
nlu:
- synonym: credit
  examples: |
    - credit card account
    - credit account
```

*   [[#正規表現]]

```yaml-rasa
nlu:
- regex: account_number
  examples: |
    - d{10,12}
```

*   [[#ルックアップテーブル]]

```yaml-rasa
nlu:
- lookup: banks
  examples: |
    - JPMC
    - Comerica
    - Bank of America
```

### トレーニング例

トレーニングの例は[[glossary.md#[意](./nlu-training-data.md)|intent]]ごとにグループ化され、 `examples` キー。通常、次のように、1 行に 1 つの例をリストします。

```yaml-rasa
nlu:
- intent: greet
  examples: |
    - hey
    - hi
    - whats up
```

ただし、カスタム NLU コンポーネントがあり、例のメタデータが必要な場合は、拡張形式を使用することもできます。

```yaml-rasa
nlu:
- intent: greet
  examples:
  - text: |
      hi
    metadata:
      sentiment: neutral
  - text: |
      hey there!
```

`メタデータ`キーには、例に関連付けられ、NLU パイプライン内のコンポーネントからアクセスできる任意のキー値データを含めることができます。上記の例では、センチメント メタデータをパイプライン内のカスタム コンポーネントでセンチメント分析に使用できます。

このメタデータは、インテントレベルで指定することもできます。

```yaml-rasa
nlu:
- intent: greet
  metadata:
    sentiment: neutral
  examples:
  - text: |
      hi
  - text: |
      hey there!
```

この場合、`メタデータ`キーの内容はすべてのインテント例に渡されます。

[[glossary.md#[取得インテント](./chitchat-faqs.md)|取得インテント]]を指定する場合、NLU の例は次のようになります。

```yaml-rasa
nlu:
- intent: chitchat/ask_name
  examples: |
    - What is your name?
    - May I know your name?
    - What do people call you?
    - Do you have a name for yourself?

- intent: chitchat/ask_weather
  examples: |
    - What's the weather like today?
    - Does it look sunny outside today?
    - Oh, do you mind checking the weather for me please?
    - I like sunny days in Berlin.
```

すべての取得インテントには、アシスタントの特定の応答キーを識別する接尾部が追加されています。上記の例では、`ask_name` と `ask_weather` がサフィックスです。接尾辞は、検索インテント名から `/` 区切り文字で区切られます。

> [!note] `/` の特別な意味 
> 上記の例に示されているように、`/` 記号は、検索インテントを関連する応答キーから分離するための区切り文字として予約されています。インテントの名前で使用しないように注意してください。

### エンティティ

[[glossary.md#./training-data-format.md エンティティ 実体|エンティティ]]、ユーザーのメッセージから抽出できる構造化された情報です。

エンティティは、エンティティの名前でトレーニング例で注釈が付けられます。エンティティ名に加えて、[[nlu-training-data.md#類義 語|synonyms]],[[nlu-training-data.md#エンティティ、ロール、およびグループ| roles or groups]] をエンティティに注釈を付けることができます。

トレーニング例では、エンティティの注釈は次のようになります。

```yaml-rasa
nlu:
- intent: check_balance
  examples: |
    - how much do I have on my [savings](account) account
    - how much money is in my [checking]{"entity": "account"} account
    - What's the balance on my [credit card account]{"entity":"account","value":"credit"}

```

エンティティに注釈を付けるために可能な完全な構文は次のとおりです。

```text
[<entity-text>]{"entity": "<entity name>", "role": "<role name>", "group": "<group name>", "value": "<entity synonym>"}
```

この表記では、`キーワード role`、`group`、`value` はオプションです。`値`フィールドは同義語を参照します。ラベル `roles` と `group` の目的を理解するには、[[nlu-training-data.md#エンティティ、ロール、およびグループ| entity roles and groups]] のセクションを参照してください。

### 類義 語

シノニムは、抽出されたエンティティを抽出されたリテラル テキスト以外の値にマッピングすることで、トレーニング データを正規化します。シノニムは、次の形式を使用して定義できます。

```yaml-rasa
nlu:
- synonym: credit
  examples: |
    - credit card account
    - credit account
```

エンティティの`値を`指定して、トレーニング例でシノニムをインラインで定義することもできます。

```yaml-rasa
nlu:
- intent: check_balance
  examples: |
    - how much do I have on my [credit card account]{"entity": "account", "value": "credit"}
    - how much do I owe on my [credit account]{"entity": "account", "value": "credit"}
```

同義語の詳細については、[[nlu-training-data.md#類義 語|NLU トレーニング データのページ]]をご覧ください。

### 正規表現

正規表現を使用すると、[`RegexFeaturizer`](components.md#regexfeaturizer) コンポーネントと [`RegexEntityExtractor`](components.md#regexentityextractor) コンポーネントを使用して、意図の分類とエンティティ抽出を改善できます。

正規表現を定義する形式は次のとおりです。

```yaml-rasa
nlu:
- regex: account_number
  examples: |
    - d{10,12}
```

ここでは、`正規`表現の名前account_number。`RegexFeaturizer` の機能として使用する場合、正規表現の名前は重要ではありません。`RegexEntityExtractor` を使用する場合、正規表現の名前は抽出するエンティティの名前と一致する必要があります。

各コンポーネントで正規表現を使用するタイミングと方法の詳細については、[[./nlu-training-data.md#正規表現|NLU トレーニング データ ページ]]。

### ルックアップテーブル

ルックアップテーブルは、大文字と小文字を区別しない正規表現パターンを生成するために使用される単語のリストです。形式は次のとおりです。

```yaml-rasa
nlu:
- lookup: banks
  examples: |
    - JPMC
    - Bank of America
```

トレーニングデータにルックアップテーブルを指定すると、そのテーブルの内容が 1 つの大きな正規表現に結合されます。この正規表現は、各トレーニング例をチェックして、ルックアップテーブルのエントリに一致するものが含まれているかどうかを確認するために使用されます。

ルックアップ テーブルの正規表現は、トレーニング データで直接指定された正規表現と同じように処理され、[RegexFeaturizer](components.md#regexfeaturizer) または [RegexEntityExtractor](components.md#regexentityextractor) で使用できます。ルックアップ テーブルの名前には、正規表現機能の名前と同じ制約が適用されます。

ルックアップテーブルの使用の詳細については、[[./nlu-training-data.md#ルックアップテーブル|NLU トレーニング データ ページ]]。

## 会話トレーニング データ

ストーリーとルールはどちらも、ユーザーと会話アシスタントの間の会話を表します。これらは、対話管理モデルのトレーニングに使用されます。[ストーリーは](stories.md)、機械学習モデルのトレーニングに使用されます 会話のパターンを特定し、目に見えない会話パスに一般化します。 [ルールは](rules.md)、常に同じパスをたどる必要がある会話の小さな部分を記述し、[[policies.md#ルールポリシー|ルールポリシー]]です。

### 物語

ストーリーは以下で構成されています。

*   `story`: ストーリーの名前。名前は任意であり、トレーニングでは使用されません。ストーリーの人間が読めるリファレンスとして使用できます。
*   `メタデータ`: 任意でオプションで、トレーニングでは使用されませんが、著者などのストーリーに関する関連情報を保存するために使用できます。
*   `ステップ`のリスト: ストーリーを構成するユーザーメッセージとアクション

例えば：

```yaml-rasa
stories:
- story: Greet the user
  metadata:
    author: Somebody
    key: value
  steps:
  # list of steps
  - intent: greet
  - action: utter_greet
```

各ステップは、次のいずれかになります。

*   [[#ユーザーメッセージ]] は、**インテント**と**エンティティ**で表されます。
*   [[#OR ステートメント]] で、その下に 2 つ以上のユーザー メッセージが含まれます。
*   ボット [[#アクション]]
*   [[#フォーム]]。
*   [[#スロット| スロットが設定されました]] イベント。
*   [[#チェックポイント]] は、ストーリーを別のストーリーに接続します。

#### ユーザーメッセージ

すべてのユーザーメッセージは、次の`インテント`で指定されます。 key とオプションの`エンティティ:` key。

ストーリーを書いている間、ユーザーが送信するメッセージの特定の内容に対処する必要はありません。代わりに、インテントとエンティティの組み合わせを使用して、ユーザーが同じ意味で送信できるすべてのメッセージを参照する NLU パイプラインからの出力を利用できます。

ユーザーメッセージは、次の形式に従います。

```yaml-rasa
stories:
- story: user message structure
  steps:
    - intent: intent_name  # Required
      entities:  # Optional
      - entity_name: entity_value
    - action: action_name
```

たとえば、文を表すには `I want to check my credit balance` ここで、`クレジット`はエンティティです。

```yaml-rasa
stories:
- story: story with entities
  steps:
  - intent: account_balance
    entities:
    - account_type: credit
  - action: action_credit_account_balance
```

ポリシーは、インテントとエンティティの両方の組み合わせに基づいて次のアクションを予測することを学習するため、ここにエンティティを含めることが重要です (ただし、この動作は [[#エンティティ|`use_entities`]]属性)。

#### アクション

ボットによって実行されるすべてのアクションは、`action:` キーの後にアクションの名前が続きます。ストーリーを書いていると、次の 2 種類のアクションに遭遇します。

1.  [応答](domain.md#応答): `utter_` から始めて、ユーザーに特定のメッセージを送信します。例えば。

```yaml-rasa
stories:
- story: story with a response
  steps:
  - intent: greet
  - action: utter_greet
```

2.  [カスタムアクション](custom-actions.md):`action_`から始めて、任意のコードを実行し、任意の数のメッセージを送信する(または送信しない)。

```yaml-rasa
stories:
- story: story with a custom action
  steps:
  - intent: feedback
  - action: action_store_feedback
```

#### フォーム

[フォーム](glossary.md#フォーム)は、必要なスロットのセットをループしてユーザーにこの情報を要求するロジックを含む、特定の種類のカスタムアクションです。[[forms.md#フォームの定義|フォームの定義]]、ドメインの`フォーム`セクションで定義します。定義したら、[原則](forms.md)としてフォームの[[glossary.md#幸せ/不幸な道|ハッピーパス]]を指定する必要があります。ストーリーにフォームの中断やその他の「不幸なパス」を含めて、モデルが目に見えない会話シーケンスに一般化できるようにする必要があります。ストーリーのステップとして、フォームは次の形式になります。

```yaml-rasa
stories:
- story: story with a form
  steps:
  - intent: find_restaurant
  - action: restaurant_form                # Activate the form
  - active_loop: restaurant_form           # This form is currently active
  - active_loop: null                      # Form complete, no form is active
  - action: utter_restaurant_found
```

`アクション`ステップはフォームをアクティブ化し、必要なスロットのループを開始します。`active_loop:restaurant_form` step は、現在アクティブなフォームがあることを示します。`slot_was_set` ステップと同様に、`フォーム` ステップはフォームをアクティブ**に設定**するのではなく、フォームが既にアクティブ化されている必要があることを示します。同様に、`active_loop: null` ステップは、後続のステップが実行される前にフォームをアクティブにしてはならないことを示します。

フォームは中断されてもアクティブなままにすることができます。この場合、中断は `action: <form を使用して > ステップをアクティブに`し、その後に `active_loop: <active form>` ステップが続きます。フォームの中断は次のようになります。

```yaml-rasa
stories:
- story: interrupted food
  steps:
    - intent: request_restaurant
    - action: restaurant_form
    - intent: chitchat
    - action: utter_chitchat
    - active_loop: restaurant_form
    - active_loop: null
    - action: utter_slots_values
```

#### スロット

スロットイベントは、キー `slot_was_set`の下にスロット名とオプションでスロットの値を指定します。

[スロットは](domain.md#スロット)ボットのメモリとして機能します。スロットは、デフォルトのアクション[`action_extract_slots`](./default-actions.md#action_extract_slots) ([[./domain.md#スロットマッピング|Slot Mappings]]) をドメインで指定するか、カスタムアクションによって指定します。それらは`、slot_was_set`ステップのストーリーによって**参照**されます。例えば：

```yaml-rasa
stories:
- story: story with a slot
  steps:
  - intent: celebrate_bot
  - slot_was_set:
    - feedback_value: positive
  - action: utter_yay
```

つまり、ストーリーでは、`feedback_value`の現在の値が必要です。 slot を`正に`すると、会話が指定されたとおりに続行されます。

スロットの値を含める必要があるかどうかは、[[domain.md#スロットタイプ|スロットタイプ]] と、その値がダイアログに影響を与えることができるかどうか、または影響を与えるべきかどうか。テキスト`スロットの場合`のように、値が重要でない場合は、スロットの名前のみをリストできます。

```yaml-rasa
stories:
- story: story with a slot
  steps:
  - intent: greet
  - slot_was_set:
    - name
  - action: utter_greet_user_by_name
```

デフォルトでは、スロットの初期値は `null` であり、これを使用してスロットが設定されていないかどうかを確認できます。

```yaml-rasa
stories:
- story: French cuisine
  steps:
  - intent: inform
  - slot_was_set:
    - cuisine: null
```

> [!note] スロットの仕組み
> ストーリーはスロット**を設定し**ません。スロットは、スロットマッピングが適用される場合のデフォルトのアクション`action_extract_slots`、`またはslot_was_set`ステップ**の前の**カスタムアクションによって設定する必要があります。

#### チェックポイント

チェックポイントは、ストーリーの先頭または末尾に `checkpoint:` キーで指定されます。

チェックポイントは、ストーリーをつなぐ方法です。それらは、ストーリーの最初のステップまたは最後のステップのいずれかです。それらがストーリーの最後のステップである場合、そのストーリーは、モデルのトレーニング時に同じ名前のチェックポイントで始まる他のストーリーに接続されます。チェックポイントで終わるストーリーと、同じチェックポイントで始まるストーリーの例を次に示します。

```yaml-rasa
stories:
- story: story_with_a_checkpoint_1
  steps:
  - intent: greet
  - action: utter_greet
  - checkpoint: greet_checkpoint

- story: story_with_a_checkpoint_2
  steps:
  - checkpoint: greet_checkpoint
  - intent: book_flight
  - action: action_book_flight
```

ストーリーの先頭のチェックポイントは、スロットの設定を条件にすることもできます。

```yaml-rasa
stories:
- story: story_with_a_conditional_checkpoint
  steps:
  - checkpoint: greet_checkpoint
    # This checkpoint should only apply if slots are set to the specified value
    slot_was_set:
    - context_scenario: holiday
    - holiday_name: thanksgiving
  - intent: greet
  - action: utter_greet_thanksgiving
```

チェックポイントは、トレーニング データを簡素化し、冗長性を減らすのに役立ちますが、過剰**に使用しないでください**。チェックポイントをたくさん使うと、すぐにストーリーが理解しにくくなることがあります。一連のステップが異なるストーリーで頻繁に繰り返される場合は、これらを使用するのが理にかなっていますが、チェックポイントのないストーリーの方が読み書きが簡単です。

#### OR ステートメント

`または`ステップは、複数のインテントまたはスロットイベントを同じ方法で処理する方法であり、インテントごとに個別のストーリーを記述しません。たとえば、ユーザーに何かを確認するように依頼する場合、`肯定`の意図と`感謝の`意図を同じように扱うことができます。`または`ステップを含むストーリーは、トレーニング時に複数の個別のストーリーに変換されます。たとえば、次のストーリーはトレーニング時に 2 つのストーリーに変換されます。

```yaml-rasa
stories:
- story: story with OR
  steps:
  - intent: signup_newsletter
  - action: utter_ask_confirm
  - or:
    - intent: affirm
    - intent: thanks
  - action: action_signup_newsletter
```

スロットイベントで `or` ステートメントを使用することもできます。以下は、ストーリーでは`、名前`スロットの現在の値が設定され、`joe` または `bob` のいずれかであることを意味します。このストーリーは、トレーニング時に 2 つのストーリーに変換されます。

```yaml-rasa
stories:
- story:
  steps:
  - intent: greet
  - action: utter_greet
  - intent: tell_name
  - or:
    - slot_was_set:
        - name: joe
    - slot_was_set:
        - name: bob
  # ... next actions
```

チェックポイントと同様に、ORステートメントは便利ですが、それらを多く使用している場合は、ドメインやインテントを再構築することをお勧めします。

> [!warning] 使いすぎないでください
>  これらの機能 (チェックポイントと OR ステートメントの両方) を使いすぎると、トレーニングが遅くなります。

### 準則

ルールは`ルール`キーの下にリストされ、ストーリーに似ています。ルールには`ステップ`もあります キーには、ストーリーと同じステップのリストが含まれています。ルールはさらに `conversation_started` キーと`条件`キーが含まれます。これらは、ルールを適用する条件を指定するために使用されます。

条件を持つルールは次のようになります。

```yaml-rasa
rules:
- rule: Only say `hey` when the user provided a name
  condition:
  - slot_was_set:
    - user_provided_name: true
  steps:
  - intent: greet
  - action: utter_greet
```

ルールの記述の詳細については、[[rules.md#ルールの作成|ルール]]

## テストストーリー

テスト ストーリーでは、メッセージが正しく分類されているかどうか、およびアクションの予測がチェックされます。

テスト ストーリーは [[#物語|story]] と同じ形式を使用しますが、ユーザー メッセージ ステップにユーザー メッセージの実際のテキストとエンティティの注釈`を指定するユーザーを含める`ことができます。テストストーリーの例を次に示します。

```yaml-rasa
stories:
- story: A basic end-to-end test
  steps:
  - user: |
     hey
    intent: greet
  - action: utter_ask_howcanhelp
  - user: |
     show me [chinese]{"entity": "cuisine"} restaurants
    intent: inform
  - action: utter_ask_location
  - user: |
     in [Paris]{"entity": "location"}
    intent: inform
  - action: utter_ask_price
```

次のコマンドを使用してテストを実行できます。

```bash
rasa test
```

テストについて詳しく知りたい場合は、 [アシスタントのテスト](testing-your-assistant.md)。

## エンドツーエンドのトレーニング

> [!info] 2.2 の新機能 
> エンドツーエンドのトレーニングは実験的な機能です。コミュニティからフィードバックを得るために実験的な機能を導入していますので、ぜひ試してみてください。ただし、この機能は将来変更または削除される可能性があります。フィードバック(肯定的または否定的)がある場合は、[Rasaフォーラム](https://forum.rasa.com)で共有してください。

[[stories.md#エンドツーエンドのトレーニング|End-to-end Training]]の場合、NLU パイプラインによって抽出されるメッセージの特定のインテントを処理する必要はありません。代わりに、`ユーザー` キーを使用して、ユーザー メッセージのテキストをストーリーに直接配置できます。

これらのエンドツーエンドのユーザーメッセージは、次の形式に従います。

```yaml-rasa
stories:
- story: user message structure
  steps:
    - user: the actual text of the user message
    - action: action_name
```

さらに、抽出できるエンティティタグを追加できます によって [[./policies.md#TEDポリシー|TEDポリシー]]。エンティティータグの構文は、 [[./training-data-format.md#エンティティ|NLU トレーニング データ]]。 たとえば、次のストーリーには、ユーザーの発話が含まれています `いつでも寿司に行けます`。NLU トレーニング データの構文を使用する `[sushi](料理)`では、`寿司`を`タイプの料理`のエンティティとしてマークできます。

```yaml-rasa
stories:
- story: story with entities
  steps:
  - user: I can always go for [sushi](cuisine)
  - action: utter_suggest_cuisine
```

同様に、`ボット` キーの後にボットに言わせたいテキストを使用して、ボットの発話をストーリーに直接配置できます。

ボットの発話のみを含むストーリーは、次のようになります。

```yaml-rasa
stories:
- story: story with an end-to-end response
  steps:
  - intent: greet
    entities:
    - name: Ivan
  - bot: Hello, a person with a name!
```

エンドツーエンドのストーリーを混在させることもできます。

```yaml-rasa
stories:
- story: full end-to-end story
  steps:
  - intent: greet
    entities:
    - name: Ivan
  - bot: Hello, a person with a name!
  - intent: search_restaurant
  - action: utter_suggest_cuisine
  - user: I can always go for [sushi](cuisine)
  - bot: Personally, I prefer pizza, but sure let's search sushi restaurants
  - action: utter_suggest_cuisine
  - user: Have a beautiful day!
  - action: utter_goodbye
```

Rasaのエンドツーエンドのトレーニングは、標準的なRasaアプローチと完全に統合されています。つまり、アクションやインテントによって定義されるステップと、ユーザーメッセージやボットの応答によって直接定義されるステップが混在している可能性があります。