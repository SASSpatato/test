---
id: stories
sidebar_label: Stories
title: Stories
description: Stories are used to teach Rasa real conversation designs to learn from providing the basis for a scalable machine learning dialogue management.
abstract: Stories are a type of training data used to train your assistant's dialogue management
  model. Stories can be used to train models that are able to generalize to unseen conversation paths.
---

## 形式

ストーリーは、ユーザーと AI アシスタントの間の会話の表現であり、ユーザー入力が意図 (および必要に応じてエンティティ) として表現され、アシスタントの応答とアクションがアクション名として表現される特定の形式に変換されます。

以下は、ラサのストーリー形式の対話の例です。

```yaml-rasa
stories:
- story: collect restaurant booking info  # name of the story - just for debugging
  steps:
  - intent: greet                         # user message with no entities
  - action: utter_ask_howcanhelp
  - intent: inform                        # user message with entities
    entities:
    - location: "rome"
    - price: "cheap"
  - action: utter_on_it                  # action that the bot should execute
  - action: utter_ask_cuisine
  - intent: inform
    entities:
    - cuisine: "spanish"
  - action: utter_ask_num_people
```

### ユーザーメッセージ

ストーリーを書いている間、ユーザーが送信するメッセージの特定の内容に対処する必要はありません。代わりに、NLU パイプラインからの出力を利用して、インテントとエンティティの組み合わせのみを使用して、ユーザーが送信できるすべてのメッセージを同じ意味で参照できます。

ポリシーは、インテントとエンティティの両方の組み合わせに基づいて次のアクションを予測することを学習するため、ここにエンティティを含めることが重要です (ただし、この動作は [[./domain.md#特定のインテントのエンティティの無視|use_entities]] 属性を使用して変更できます)。

### アクション

[応答](./responses.md)を含め、ボットによって実行されたすべてのアクションは、`アクション`キーの下のストーリーに一覧表示されます。

ドメインからの応答をストーリーにリストすることで、アクションとして使用できます。同様に、ドメインの`アクション`リストからカスタムアクションの名前を含めることで、ストーリーがカスタムアクションを呼び出す必要があることを示すことができます。

### イベント

トレーニング中、Rasa はアクションサーバーを呼び出しません。つまり、アシスタントのダイアログ管理モデルは、カスタムアクションが返すイベントを認識しません。

このため、スロットの設定やフォームの活性化/非活性化などのイベントは、 物語の一部として明示的に書き出されています。詳細については、 [イベント](./action-server/events.md)。

#### スロットイベント

スロットイベントは、ストーリーの`slot_was_set`の下に書き込まれます。このスロットがカスタムアクション内に設定されている場合は、カスタムアクションコールの直後に`slot_was_set`イベントを追加します。カスタムアクションでスロット値を `None` にリセットすると、対応するイベントは次のようになります。

```yaml-rasa
stories:
- story: set slot to none
  steps:
    # ... other story steps
    - action: my_custom_action
    - slot_was_set:
      - my_slot: null
```

#### フォームイベント

物語の形を扱う際に留意する必要があるイベントは3種類あります。

*   フォームアクションイベント(例:`-action:restaurant_form`)は、フォームを最初に起動するときの開始時と、フォームがすでにアクティブなときにフォームアクションを再開するときに使用されます。
    
*   フォームアクティベーションイベント(例: `- active_loop: restaurant_form` )は、最初のフォームアクションイベントの直後に使用されます。
    
*   フォームの非アクティブ化イベント (例: `- active_loop: null`) は、フォームの非アクティブ化に使用されます。
    

> [!NOTE] フォームストーリーを書く
> イベントの追加を忘れる落とし穴を回避するために、これらのストーリーの書き方は [[./writing-stories.md#対話型学習の使用|インタラクティブ学習]] を使用することです。

## チェックポイントと OR ステートメント

チェックポイントと OR ステートメントは、使用する場合は注意して使用する必要があります。通常、[Rules](./rules.md) または [[./components.md#応答セレクター|ResponseSelector]] を使用して、必要なものを実現するより良い方法があります。

### チェックポイント

チェックポイントを使用して、トレーニング データをモジュール化および簡素化できます。チェックポイントは便利ですが、**使いすぎないでください**。チェックポイントをたくさん使用すると、サンプルストーリーがすぐに理解しにくくなり、トレーニングが遅くなる可能性があります。

チェックポイントを含むストーリーの例を次に示します。

```yaml-rasa
stories:
- story: beginning of flow
  steps:
  - intent: greet
  - action: action_ask_user_question
  - checkpoint: check_asked_question

- story: handle user affirm
  steps:
  - checkpoint: check_asked_question
  - intent: affirm
  - action: action_handle_affirmation
  - checkpoint: check_flow_finished

- story: handle user deny
  steps:
  - checkpoint: check_asked_question
  - intent: deny
  - action: action_handle_denial
  - checkpoint: check_flow_finished

- story: finish flow
  steps:
  - checkpoint: check_flow_finished
  - intent: goodbye
  - action: utter_goodbye
```

> [!note] 
> 通常のストーリーとは異なり、チェックポイントはユーザー入力から始まることに限定されません。メインストーリーの適切なポイントにチェックポイントが挿入されている限り、最初のイベントはカスタムアクションまたは応答にもなります。

### OR ステートメント

短いストーリーを書いたり、複数のインテントやスロットイベントを同じ方法で処理したりする別の方法は、`or` ステートメントを使用することです。たとえば、ユーザーに何かを確認するように依頼し、`肯定`と`感謝`の意図を同じように扱う場合です。以下のストーリーは、トレーニング時に 2 つのストーリーに変換されます。

```yaml-rasa
stories:
- story:
  steps:
  # ... previous steps
  - action: utter_ask_confirm
  - or:
    - intent: affirm
    - intent: thankyou
  - action: action_handle_affirmation
```

スロットイベントで `or` ステートメントを使用することもできます。以下は、ストーリーで`名前`スロットの現在の値が設定され、`joe` または `bob` である必要があることを意味します。

```yaml-rasa
stories:
- story:
  steps:
  - intent: greet
  - action: utter_greet
  - intent: tell_name
  - or:
    - slot_was_set:
        - name: joe
    - slot_was_set:
        - name: bob
  # ... next actions
```

`OR` ステートメントは便利ですが、それらを多く使用している場合は、ドメインやインテントを再構築することをお勧めします。OR ステートメントを使いすぎると、トレーニングが遅くなります。

## テスト会話形式

テスト会話形式は、NLU データとストーリーの両方を 1 つのファイルに結合して評価する形式です。この形式について詳しくは、[アシスタントのテスト](./testing-your-assistant.md)を参照してください。

> [!caution] テストのみ
> この形式はテストにのみ使用され、トレーニングには使用できません。

## エンドツーエンドのトレーニング

> [!info] 2.2 の新機能 
> エンドツーエンドのトレーニングは実験的な機能です。コミュニティからフィードバックを得るために実験的な機能を導入していますので、ぜひ試してみてください。ただし、この機能は将来変更または削除される可能性があります。フィードバック(肯定的または否定的)がある場合は、[Rasaフォーラム](https://forum.rasa.com)で共有してください。

エンドツーエンドのトレーニングでは、NLU パイプラインによって抽出されたメッセージの特定の意図や、ドメインファイル内の個別の`utter_`応答を処理する必要はありません。代わりに、ユーザーメッセージやボットの応答のテキストをストーリーに直接含めることができます。エンドツーエンドのストーリーの書き方の詳細については、[[./training-data-format.md#エンドツーエンドのトレーニング|エンドツーエンドのトレーニング]] を参照してください。

エンドツーエンド形式のトレーニング データと、ラベル付きトレーニング データを混在させることができます。 `意図`と`アクション`の指定: ストーリーには、意図/アクションによって定義されるいくつかのステップと、ユーザーまたはボットの発話によって直接定義されるその他のステップを含めることができます。

ポリシーが実際のテキストを消費して予測できるため、これをエンドツーエンドのトレーニングと呼びます。エンドツーエンドのユーザー入力の場合、NLU パイプラインによって分類されたインテントと抽出されたエンティティは無視されます。

[[./policies.md#ルールポリシー|ルールポリシー]]および[[./policies.md#TEDポリシー|TED ポリシー]] は、エンドツーエンドのトレーニングを可能にします。

*   `RulePolicy は`、予測中に単純な文字列一致を使用します。つまり、ユーザーテキストに基づくルールは、ルール内のユーザーテキスト文字列と予測中の入力が同一である場合にのみ一致します。
    
*   `TEDPolicy` は、ユーザーのテキストを追加のニューラル ネットワークに渡して、テキストの非表示表現を作成します。堅牢なパフォーマンスを得るには、エンドツーエンドの対話ターンでさまざまなユーザーテキストをキャプチャするのに十分なトレーニングストーリーを提供する必要があります。
    

Rasa ポリシーは、次の発話選択のためにトレーニングされます。`utter_`応答を作成することの唯一の違いは、`TEDPolicy` がボットの発話をどのように特徴付けるかです。`utter_`アクションの場合、`TEDPolicy`はアクションの名前のみを表示しますが、`ボット`キーを使用して実際の発話を提供すると、 `TEDPolicy` は、NLU 構成に応じてテキスト入力として機能化します。これは、わずかに異なる状況で同様の発話が発生した場合に役立ちます。ただし、発話が異なればテキストが似ているため、`TEDPolicy` がこれらの発話を混乱させやすくなるため、学習が難しくなる可能性もあります。

エンドツーエンドのトレーニングには、`TEDPolicy`で大幅に多くのパラメーターが必要です。したがって、エンドツーエンドのモデルのトレーニングには、ストーリー内のエンドツーエンドのターンの数によっては、大量の計算リソースが必要になる場合があります。