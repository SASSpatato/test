---
id: llm-intent
sidebar_label: Intent Classification with LLMs
title: Using LLMs for Intent Classification
abstract: |-
  Intent classification using Large Language Models (LLM) and
  a method called retrieval augmented generation (RAG).
---

## 主な特徴

1.  **少数ショット学習**: インテント分類器は、インテントごとにいくつかの例のみでトレーニングできます。新しいインテントは、利用可能なトレーニング例がほんの一握りしかない場合でも、ブートストラップして統合できます。
2.  **高速トレーニング**: インテント分類子は、非常に迅速にトレーニングできます。
3.  **多言語**: インテント分類器は多言語データでトレーニングでき、多くの言語でメッセージを分類できますが、パフォーマンスは LLM によって異なります。

## 概要

LLM ベースのインテント分類器は、大規模言語モデル (LLM) を使用してインテントを分類する新しいインテント分類器です。LLM ベースのインテント分類器は、検索ベースのアプローチと生成ベースのアプローチの利点を組み合わせた検索拡張生成 (RAG) と呼ばれる方法に依存しています。

![[llm-IntentClassifier-docs.jpg]]

トレーニング中分類子で

1.  すべてのインテントの例を埋め込み、
2.  埋め込みをベクトルストアに格納します。

予測中、分類器

1.  現在のメッセージを埋め込み、
2.  埋め込みを使用して、ベクトル ストアで同様のインテントの例を検索します。
3.  取得された例は、現在のメッセージとの類似性に基づいてランク付けされ、
4.  最も類似したものは LLM プロンプトに含まれています。プロンプトは、LLM がメッセージの意図を予測するようにガイドします。
5.  LLM はインテントラベルを予測します。
6.  生成されたラベルは、ドメインのインテントにマッピングされます。LLM は、トレーニング データの一部ではないラベルを予測することもできます。この場合、最も類似した埋め込みを持つドメインからのインテントが予測されます。

## ボットでの LLM ベースのインテント分類子の使用

ボットで LLM ベースのインテント分類子を使用するには、 `LLMIntentClassifier` を `config.yml` ファイル内の NLU パイプラインに追加します。

```yaml-rasa
pipeline:
# - ...
  - name: rasa_plus.ml.LLMIntentClassifier
# - ...
```

LLM ベースのインテント分類子には、LLM モデル API へのアクセスが必要です。`/completions` エンドポイントをサポートする任意の OpenAI モデルを使用できます。サポートされているモデルとモデル プロバイダーのリストの拡大に取り組んでいます。

## カスタマイズ

LLM をカスタマイズするには、 `config.yml`ファイル。**すべてのパラメーターはオプションです。**

### フォールバック・インテント

フォールバックインテントは、LLM がトレーニングデータの一部ではなかったインテントを予測する場合に使用されます。フォールバック インテントを設定するには、次のパラメーターを `config.yml` ファイルに追加します。

```yaml-rasa
pipeline:
# - ...
  - name: rasa_plus.ml.LLMIntentClassifier
    fallback_intent: "out_of_scope"
# - ...
```

デフォルトは`out_of_scope`です。

### LLM / 埋め込み

LLM に使用される OpenAI モデルを選択するには、`llm.model_name` パラメータを`config.yml`ファイルに追加します。

```yaml-rasa
pipeline:
# - ...
  - name: rasa_plus.ml.LLMIntentClassifier
    llm:
      model_name: "text-davinci-003"
# - ...
```

デフォルトは`text-davinci-003`です。モデル名をジェネレーティブに設定する必要があります の補完 API を使用するモデル [オープンAI](https://platform.openai.com/docs/guides/text-generation/chat-completions-api)です。

Azure OpenAI Service を使用する場合は、[[llm-setup#Azure OpenAI Service の追加構成|Azure OpenAI Service]] セクションに挿入します。

> [!note]  他の LLM / 埋め込みの使用
> デフォルトでは、OpenAI は基盤となる LLM および埋め込みプロバイダーとして使用されます。
> 使用される LLM プロバイダーと埋め込みプロバイダーは、 `config.yml`ファイルを使用して別のプロバイダーを使用します (例: `cohere`:
> ```yaml-rasa
> pipeline:
> # - ...
> - name: rasa_plus.ml.LLMIntentClassifier
>   llm:
>     type: "cohere"
>   embeddings:
>      type: "cohere"
> # - ...
> ```
> 
> 詳細については、 [[llm-setup#その他のLLMプロバイダー|LLM と埋め込みに関する LLM セットアップ ページ]]



### 温度

温度パラメーターは、LLM 予測のランダム性を制御します。温度を設定するには、 `llm.temperature` パラメータを `config.yml` に追加します。 ファイル。

```yaml-rasa
pipeline:
# - ...
  - name: rasa_plus.ml.LLMIntentClassifier
    llm:
      temperature: 0.7
# - ...
```

デフォルトは `0.7` です。温度は 0 から 2 の間の浮動小数点である必要があります。気温が高いほど、予測はよりランダムになります。温度が低いほど、LLM が同じメッセージに対して同じインテントを予測する可能性が高くなります。

### プロンプト

プロンプトは、LLM がメッセージの意図を予測するようにガイドするために使用されるテキストです。プロンプトをカスタマイズするには、次のパラメーターを`config.yml`ファイルに追加します。

```yaml-rasa
pipeline:
# - ...
  - name: rasa_plus.ml.LLMIntentClassifier
    prompt: |
      Label a users message from a
      conversation with an intent. Reply ONLY with the name of the intent.

      The intent should be one of the following:
      {% for intent in intents %}- {{intent}}
      {% endfor %}
      {% for example in examples %}
      Message: {{example['text']}}
      Intent: {{example['intent']}}
      {% endfor %}
      Message: {{message}}
      Intent:
```

プロンプトは、プロンプトのカスタマイズに使用できる [Jinja2](https://jinja.palletsprojects.com/en/3.0.x/) テンプレートです。プロンプトでは、次の変数を使用できます。

*   `examples`: トレーニングデータから最も近い例のリスト。各例は、`キー text` と `intent` を含む辞書です。
*   `message`: 分類する必要があるメッセージ。
*   `intents`: トレーニングデータ内のすべてのインテントのリスト。

デフォルトのプロンプトテンプレートでは、次のプロンプトが表示されます。

```
Label a users message from a
conversation with an intent. Reply ONLY with 
the name of the intent.

The intent should be one of the following:
- affirm
- greet

Message: Hello
Intent: greet

Message: Yes, I am
Intent: affirm

Message: hey there
Intent:
```

### インテントの例の数

LLM がメッセージの意図を予測するガイドに使用される例の数は、`number_of_examples` パラメーターを `config.yml`ファイル:

```yaml-rasa
pipeline:
# - ...
  - name: rasa_plus.ml.LLMIntentClassifier
    number_of_examples: 3
# - ...
```

デフォルトは `10` です。例は、現在のメッセージとの類似性に基づいて選択されます。デフォルトでは、例は次のようにプロンプトに含まれています。

```
Message: Hello
Intent: greet

Message: Yes, I am
Intent: affirm
```

## セキュリティに関する考慮事項

インテント分類子は、OpenAI API を使用してインテントを分類します。これは、ユーザーの会話が分類のために OpenAI のサーバーに送信されることを意味します。

OpenAI によって生成された応答は、ボットのユーザーに送り返されません。ただし、ユーザーは、メッセージの分類が失敗するようなメッセージを作成できます。

分類に使用されるプロンプトは、プロンプト インジェクションを使用してユーザーに公開されません。これは、LLM から生成された応答が既存のインテントの 1 つにマッピングされ、プロンプトがユーザーに漏洩するのを防ぐためです。

より詳細な情報は、Rasaのウェビナーでご覧いただけます。 [企業におけるLLMセキュリティ](https://info.rasa.com/webinars/llm-security-in-the-enterprise-replay)。

## パフォーマンスの評価

1.  NLU データをトレーニング セットとテスト セットに分割し、現在のパイプラインのパフォーマンスを LLM ベースのパイプラインと比較して評価を実行します。
2.  すべてのデータに対して相互検証を実行して、LLM ベースのパイプラインのパフォーマンスをより確実に推定します。
3.  複数の構成 (たとえば、現在のパイプラインと LLM ベースのパイプラインなど) で `rasa test nlu` コマンドを使用して、パフォーマンスを比較します。
4.  LLM ベースのパイプラインのレイテンシーを現在のパイプラインのレイテンシーと比較して、速度に大きな違いがあるかどうかを確認します。