---
id: llm-intentless
sidebar_label: Intentless Dialogues with LLMs
title: Intentless Policy - LLMs for intentless dialogues
abstract: |
  The intentless policy uses large language models to drive a conversation
  forward without relying on intent predictions.
---

新しいインテントレスポリシーは、大規模言語モデル (LLM) を活用して既存の rasa コンポーネントを補完し、より簡単にします。

*   多くのインテント例を定義することなくアシスタントを構築する
*   メッセージが [インテントに適合しない](https://rasa.com/blog/were-a-step-closer-to-getting-rid-of-intents/) そして、行動方針を選択するには会話のコンテキストが必要です。

`IntentlessPolicy` を使用すると、質問応答ボットは、ユーザーが一連のユーザー メッセージにわたって質問を表現できるさまざまな方法を既に理解できます。

![[intentless-meaning-compounds.png]]

これには、ドメインファイルで適切な応答を定義するだけで済みます。

幻覚をなくすために、ポリシーはドメインファイルから送信する応答のみを選択します。新しいテキストは生成されません。

さらに、次の方法で LLM を制御できます。

*   プロンプトで使用される会話の例 (エンドツーエンドのストーリー) を提供します。
*   信頼度のしきい値を設定して、意図のないポリシーをいつ開始するかを決定します。

[このリポジトリ](https://github.com/RasaHQ/starter-pack-intentless-policy)には、 `IntentlessPolicy` です。これは、ポリシーを試し、延長するための良い出発点です。

## デモ

ウェ[ビナーのデモ](https://hubs.ly/Q01CLhyG0)では、このポリシーがすでにいくつかの高度な言語現象をすぐに処理できることを示しています。

ウェビナーの記録の例は、(`tests/e2e_test_stories.yml`) の[サンプル リポジトリ](https://github.com/RasaHQ/starter-pack-intentless-policy)で定義されているエンドツーエンド テストの一部でもあります。

## ボットへのインテントレス ポリシーの追加

`IntentlessPolicy` は`rasa_plus`パッケージの一部です。ボットに追加するには、`config.yml`に追加します。

```yaml-rasa
policies:
  # ... any other policies you have
  - name: rasa_plus.ml.IntentlessPolicy
```

## カスタマイズ

### NLU 予測との組み合わせ

インテントレスポリシーは、インテントを予測するNLUコンポーネントと組み合わせることができます。これは、ボットの一部にはインテントレス ポリシーを使用し、他のインテントには従来の NLU コンポーネントを使用する場合に便利です。

`nlu_abstention_threshold`は 0 から 1 までの値に設定できます。NLU 予測の信頼度がこのしきい値を下回っている場合、その信頼度が NLU 予測よりも高い場合、インテントレス ポリシーが使用されます。しきい値を超えると、NLU 予測が常に使用されます。

次の例は、`config.yml`のデフォルト設定を示しています。

```yaml-rasa
policies:
  # ... any other policies you have
  - name: rasa_plus.ml.IntentlessPolicy
    nlu_abstention_threshold: 0.9
```

設定されていない場合、`nlu_abstention_threshold` のデフォルトは `0.9` です。

### LLM / 埋め込み構成

生成と埋め込みに使用される openai モデルをカスタマイズできます。

#### 埋め込みモデル

デフォルトでは、OpenAIが埋め込みに使用されます。設定できます `config.yml embeddings.model_name` プロパティを使用して、使用される埋め込みモデルを変更します。

```yaml-rasa
policies:
  # ... any other policies you have
  - name: rasa_plus.ml.IntentlessPolicy
    embeddings: 
      model_name: text-embedding-ada-002
```

デフォルトは `text-embedding-ada-002` です。モデル名は、 [利用可能な埋め込みモデル.](https://platform.openai.com/docs/models/embeddings).

#### LLM モデル

デフォルトでは、OpenAI は LLM の生成に使用されます。設定できます `config.yml llm.model_name` プロパティを使用して、使用する OpenAI モデルを指定します。

```yaml-rasa
policies:
  # ... any other policies you have
  - name: rasa_plus.ml.IntentlessPolicy
    llm: 
      model_name: text-davinci-003
```

デフォルトは`text-davinci-003`です。モデル名は、利用可能な GPT-3 LLM モデルに設定する必要があります。

Azure OpenAI Service を使用する場合は、[[llm-setup#Azure OpenAI Service の追加構成|Azure OpenAI Service]] セクションに挿入します。

#### その他のLLM/埋め込み

デフォルトでは、OpenAI は基盤となる LLM および埋め込みプロバイダーとして使用されます。

使用される LLM プロバイダーと埋め込みプロバイダーは、 `config.yml`ファイルを使用して別のプロバイダーを使用します (例: `cohere`:

```yaml-rasa
policies:
  # ... any other policies you have
  - name: rasa_plus.ml.IntentlessPolicy
    llm: 
      type: "cohere"
    embeddings:
      type: "cohere"
```

詳細については、[[llm-setup#その他のLLMと埋め込み|LLM と埋め込みに関する LLM セットアップ ページ]]。

### その他のポリシー

パイプライン内のルールベースのポリシーについては、 `use_nlu_confidence_as_score: True` です。それ以外の場合、ルールベースのポリシーは常に信頼値 1.0 で予測を行い、NLU 予測からの不確実性を無視します。

```yaml-rasa
policies:
  - name: MemoizationPolicy
    max_history: 5
    use_nlu_confidence_as_score: True
  - name: RulePolicy
    use_nlu_confidence_as_score: True
  - name: rasa_plus.ml.IntentlessPolicy
```

意図のないポリシーは、他のポリシーが不確実な場合にのみ開始されるため、これは重要です。

*   信頼度の高い NLU 予測と一致するストーリー/ルールがある場合、 `RulePolicy` または `MemoizationPolicy` が使用されます。
    
*   信頼度の高い NLU 予測はあるが、一致するストーリー/ルールがない場合、 `IntentlessPolicy` が起動します。
    
*   NLU 予測の信頼度が低い場合は、`IntentlessPolicy` が起動します。
    
*   `IntentlessPolicy` 予測の信頼度が低い場合、`RulePolicy` は`core_fallback_threshold`に基づいてフォールバックをトリガーします。
    

![[intentless-policy-interaction.png]]

**TEDはどうですか?**

設定に TED も含められない理由はありません。しかし

*   TED は、非常に高い信頼値 (~0.99) で予測を行うことが多いため、`IntentlessPolicy` が行っていることを上書きすることがよくあります。
*   TED と `IntentlessPolicy` は同様の問題を解決しようとしているため、どちらか一方を使用するだけで、システムが推論しやすくなります。

## 意図のないポリシーの舵取り

インテントレス ポリシーを誘導するための最初のステップは、ドメイン ファイル内の応答を追加および編集することです。ドメインファイル内の応答は、インテントレスポリシーによって応答として選択できます。このホワイトリストにより、アシスタントが不適切な応答を発することは決してできません。

```yaml-rasa
utter_faq_4:
  - text:
      We currently offer 24 currencies, including USD, EUR, GBP, JPY, CAD, AUD,
      and more!
utter_faq_5:
  - text:
      Absolutely! We offer a feature that allows you to set up automatic
      transfers to your account while you're away. Would you like to learn more
      about this feature?
utter_faq_6:
  - text:
      You can contact our customer service team to have your PIN unblocked. You
      can reach them by calling our toll-free number at 1-800-555-1234.
```

`utter_` プレフィックスを持つ以外は、発話の名前付けは関係ありません。

2 番目のステップは、`data/e2e_stories.yml` に [[training-data-format#エンドツーエンドのトレーニング|end-to-end stories]] を追加することです。これらのストーリーは、LLM にドメインについて教えてくれるので、いつ何を言うべきかを判断できます。

```yaml
- story: currencies
  steps:
    - user: How many different currencies can I hold money in?
    - action: utter_faq_4

- story: automatic transfers travel
  steps:
    - user: Can I add money automatically to my account while traveling?
    - action: utter_faq_5

- story: user gives a reason why they can't visit the branch
  steps:
    - user: I'd like to add my wife to my credit card
    - action: utter_faq_10
    - user: I've got a broken leg
    - action: utter_faq_11
```

ストーリーと発話の組み合わせは、LLM を操縦するために使用されます。既存のポリシーとの違いは、このシステムを稼働させるために多くのインテント例を追加する必要がないことです。

## テスティング

このポリシーは通常の Rasa ポリシーであり、他のポリシーと同じ方法でテストできます。

### 対話形式でのテスト

トレーニングが完了したら、以下のコマンドを実行してアシスタントを対話式にテストできます。

```bash
rasa shell
```

実装するフローがすぐに機能しない場合は、インテントレスポリシーの例を変更するために try を追加できます。インテント、エンティティ、スロット、ルールなどの従来のRasaプリミティブを通常どおり追加および編集することもできることを忘れないでください。`IntentlessPolicy` は、従来のプリミティブの信頼度が低い場合にのみ開始されます。

### エンドツーエンドのストーリー

ベータ版の一環として、新しいエンドツーエンドのテストフレームワークのベータ版もリリースします。`rasa test e2e` コマンドを使用すると、ボットをエンドツーエンド、つまりユーザーの視点からテストできます。これを使用して、`IntentlessPolicy` のテストなど、さまざまな方法でボットをテストできます。

新しいテストフレームワークを使用するには、テストフォルダに一連のテストケースを定義する必要があります(`例:tests/e2e_test_stories.yml`)。テスト ケースはストーリーと同様の形式で定義されますが、ユーザーのメッセージとボットの応答が含まれます。次に例を示します。

```yaml
test_cases:
  - test_case: transfer charge
    steps:
      - user: how can I send money without getting charged?
      - utter: utter_faq_0
      - user: not zelle. a normal transfer
      - utter: utter_faq_7
```

**すべてのテストストーリーに一意の名前を付けてください。**設定後、 現在のシェルでの E2E テスト用のベータ機能フラグを `export RASA_PRO_BETA_E2E=true`の場合、 `rasa test e2e -f tests/e2e_test_stories.yml`

## セキュリティに関する考慮事項

インテントレス ポリシーは、OpenAI API を使用して応答を作成します。これは、ユーザーの会話が OpenAI のサーバーに送信されることを意味します。

OpenAI によって生成された応答は、ボットのユーザーに送り返されません。ただし、ユーザーは意図のないポリシーを誤解させるメッセージを作成できます。これらのケースは適切に処理され、フォールバックがトリガーされます。

分類に使用されるプロンプトは、プロンプト インジェクションを使用してユーザーに公開されません。これは、LLM から生成された応答がドメインからの既存の応答の 1 つにマッピングされ、プロンプトがユーザーに漏洩するのを防ぐためです。

より詳細な情報は、Rasaのウェビナーでご覧いただけます。 [企業におけるLLMセキュリティ](https://info.rasa.com/webinars/llm-security-in-the-enterprise-replay)。

## FAQ

### エンティティはどうですか?

エンティティは現在、インテントレスポリシーによって処理されません。従来のNLUのアプローチとスロットを使用して対処する必要があります。

### カスタムアクションはどうですか?

この時点で、インテントレス ポリシーは発話のみを予測でき、カスタム アクションは予測できません。カスタムアクションのトリガーは、ルールポリシーやメモ化ポリシーなどの従来のポリシーによって行う必要があります。