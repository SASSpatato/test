---
id: llm-setup
sidebar_label: Setting up LLMs
title: Setting up LLMs
abstract: |
  Instructions on how to setup and configure Large Language Models from
  OpenAI, Cohere, and other providers.
  Here you'll learn what you need to configure and how you can customize LLMs to work
  efficiently with your specific use case.
---

## 概要

このガイドでは、Azure OpenAI サービスに依存するデプロイを含め、OpenAI LLM を使用するように Rasa を構成するプロセスについて説明します。他の LLM プロバイダーの手順は、ページのさらに下にあります。

## 前提 条件

開始する前に、次のものがあることを確認してください。

*   OpenAI のサービスへのアクセス
*   OpenAIのAPIキーを生成する機能

## 構成

OpenAI と連携するように LLM を構成するには、いくつかの手順が必要です。次のサブセクションでは、これらの各手順と必要な操作の概要を説明します。

### APIトークン

API トークンは、Rasa インスタンスが OpenAI に接続して通信できるようにする重要な要素です。これは、両者間のシームレスな相互作用を確保するために正しく構成する必要があります。

API トークンを設定するには、次の手順に従います。

1.  まだアカウントを登録していない場合は、OpenAI プラットフォームでアカウントにサインアップしてください。
    
2.  OpenAI キー管理ページに移動し、「新しい秘密キーの作成」ボタンをクリックして、API キーの取得プロセスを開始します。
    
3.  API キーを環境変数として設定するには、ターミナルまたはコマンドプロンプトで次のコマンドを使用できます。
    
    **Linux/MacOS の場合**
    
    ```shell
    export OPENAI_API_KEY=<your-api-key>
    ```
    
    **ウィンドウズ**
    
    ```shell
    setx OPENAI_API_KEY <your-api-key>
    ```
    
    これは将来のcmdプロンプトウィンドウに適用されるため、その変数を使用するには新しいウィンドウを開く必要があります
    
    `<your-api-key>` を OpenAI プラットフォームから取得した実際の API キーに置き換えます。
    

### モデル構成

Rasaを使用すると、コンポーネントごとに異なるモデルを使用できます。たとえば、1 つのモデルをインテント分類に使用し、別のモデルを言い換えに使用できます。

コンポーネントごとにモデルを構成するには、各コンポーネントのページで説明されている次の手順に従います。

1.  [インテント分類用にモデルを構成する手順](./llm-intent.md)
2.  [言い換え用のモデルを構成する手順](./llm-nlg.md)

### Azure OpenAI Service の追加構成

Azure OpenAI Service を使用している場合は、構成する必要がある追加のパラメーターがあります。

*   `openai.api_type`: Azure OpenAI Service の使用を示すには、これを "azure" に設定する必要があります。
*   `openai.api_base`: これは Azure OpenAI インスタンスの URL である必要があります。例は次のようになります: "[https://docs-test-001.openai.azure.com/](https://docs-test-001.openai.azure.com/)" 。

これらのパラメータを設定するには、次の手順に従います。

1.  `openai.api_type`を環境変数として構成するには:
    
    **Linux/MacOS の場合**
    
    ```shell
    export OPENAI_API_TYPE="azure"
    ```
    
    **ウィンドウズ**
    
    ```shell
    setx OPENAI_API_TYPE "azure"
    ```
    
    これは将来のcmdプロンプトウィンドウに適用されるため、その変数を使用するには新しいウィンドウを開く必要があります
    
2.  `openai.api_base`を環境変数として構成するには:
    
    **Linux/MacOS の場合**
    
    ```shell
    export OPENAI_API_BASE=<your-azure-openai-instance-url>
    ```
    
    **ウィンドウズ**
    
    ```shell
    setx OPENAI_API_BASE <your-azure-openai-instance-url>
    ```
    
    これは将来のcmdプロンプトウィンドウに適用されるため、その変数を使用するには新しいウィンドウを開く必要があります
    

## その他のLLMと埋め込み

LLM と埋め込みプロバイダーは、コンポーネントごとに個別に構成できます。すべてのコンポーネントはデフォルトで OpenAI を使用します。

> [!important]  
> 別のLLM/埋め込みプロバイダーに切り替える場合は、追加のインストールとセットアップを行う必要があります。各プロバイダーの追加要件については、それぞれのセクションに記載されています。

> [!caution]  
> 現在、他の LLM プロバイダーのサポートの追加に取り組んでいます。代替LLMの構成と埋め込みプロバイダーはサポートされていますが、OpenAIでのみ機能をテストしています。

### LLM プロバイダーの構成

LLM プロバイダーは、各コンポーネントの `llm` プロパティを使用して構成できます。`llm.type` プロパティは、使用する LLM プロバイダーを指定します。

```yaml
pipeline:
  - name: "rasa_plus.ml.LLMIntentClassifier"
    llm:
      type: "cohere"
```

上記の構成では、[LLMIntentClassifier](./llm-intent.md) OpenAI ではなく [Cohere](https://cohere.ai/) LLM プロバイダーを使用する必要があります。

次の LLM プロバイダーがサポートされています。

#### オープンAI

既定の LLM プロバイダー。`OPENAI_API_KEY`環境変数を設定する必要があります。モデルカムはオプションパラメータとして設定してください

```yaml
llm:
  type: "openai"
  model_name: "text-davinci-003"
  temperature: 0.7
```

#### コヒレ

cohere のサポートをインストールする必要があります (たとえば、`pip install cohere` を使用して)。さらに、`COHERE_API_KEY`環境変数を設定する必要があります。

```yaml
llm:
  type: "cohere"
  model: "gptd-instruct-tft"
  temperature: 0.7
```

#### Vertex AI

Vertex AI を使用するには、次の `pip install google-cloud-aiplatform` Vertex AI の認証情報は、 [Google 認証のドキュメント](https://googleapis.dev/python/google-auth/latest/reference/google.auth.html#module-google.auth)を参照してください。

```yaml
llm:
  type: "vertexai"
  model_name: "text-bison"
  temperature: 0.7
```

#### ハギングフェイスハブ

Hugging Face Hub LLM は、Hugging Face のモデルを使用します。追加のパッケージをインストールする必要があります: `pip install huggingface_hub`。環境変数`HUGGINGFACEHUB_API_TOKEN`は、有効な API トークンに設定する必要があります。

```yaml
llm:
  type: "huggingface_hub"
  repo_id: "gpt2"
  task: "text-generation"
```

#### ラマCPP

llama-cpp 言語モデルを使用するには、必要な Python ライブラリをインストールする必要があります `pip install llama-cpp-python` を使用します。Llama モデルへのパスを指定する必要があります。詳細については、[llama-cpp プロジェクト](https://github.com/abetlen/llama-cpp-python)をご覧ください。

```yaml
llm:
  type: "llamacpp"
  model_path: "/path/to/model.bin"
  temperature: 0.7
```

#### その他のLLMプロバイダー

別の LLM プロバイダーを使用する場合は、[このマッピング](https://github.com/hwchase17/langchain/blob/ecee4d6e9268d71322bbf31fd16c228be304d45d/langchain/llms/__init__.py#L110)に対応する `llm.type` プロパティでプロバイダーの名前を指定できます。

### 埋め込みプロバイダーの構成

埋め込みプロバイダーは、各コンポーネントの`埋め込みプロパティ`を使用して構成できます。`embeddings.type` プロパティは、使用する埋め込みプロバイダーを指定します。

```yaml
pipeline:
  - name: "rasa_plus.ml.LLMIntentClassifier"
    embeddings:
      type: "cohere"
```

上記の構成では、[LLMIntentClassifier](./llm-intent.md) OpenAI ではなく [Cohere](https://cohere.ai/) 埋め込みプロバイダーを使用する必要があります。

> [!note]  
> 埋め込みが必要なコンポーネントは一部のコンポーネントのみ すべてのコンポーネントが埋め込みを使用するわけではありません。たとえば、[LLMResponseRephraser](./llm-nlg.md) コンポーネントは埋め込みを使用しません。これらのコンポーネントでは、`embeddings` プロパティは必要ありません。

次の埋め込みプロバイダーがサポートされています。

#### オープンAI

デフォルトの埋め込み。`OPENAI_API_KEY`環境変数を設定する必要があります。モデルカムはオプションパラメータとして設定してください

```yaml
embeddings:
  type: "openai"
  model: "text-embedding-ada-002"
```

#### コヒレ

[Cohere](https://cohere.ai/)からの埋め込み。cohere用のpythonパッケージをインストールする必要があります(例:`uing pip install cohere`)。ザ `COHERE_API_KEY`環境変数を設定する必要があります。モデルはオプションのパラメーターとして構成できます。

```yaml
embeddings:
  type: "cohere"
  model: "embed-english-v2.0"
```

#### スパサイ

Spacy 埋め込みプロバイダーは、`en_core_web_sm`モデルを使用して生成します。 埋め込み。モデルは個別にインストールする必要があります。 `python -m spacy download en_core_web_sm` .

```yaml
embeddings:
  type: "spacy"
```

#### Vertex AI

Vertex AI を使用するには、次の `pip install google-cloud-aiplatform` Vertex AI の認証情報は、 [Google 認証のドキュメント](https://googleapis.dev/python/google-auth/latest/reference/google.auth.html#module-google.auth)を参照してください。

```yaml
embeddings:
  type: "vertexai"
  model_name: "textembedding-gecko"
```

#### ハグフェイスインストラクション

Hugging Face Instruct 埋め込みプロバイダーは文トランスフォーマーを使用し、追加のパッケージをインストールする必要があります。 `pip install sentence_transformers InstructorEmbedding`

```yaml
embeddings:
  type: "huggingface_instruct"
  model_name: "hkunlp/instructor-large"
```

#### ハギングフェイスハブ

Hugging Face Hub埋め込みプロバイダーは、Hugging Faceのモデルを使用します。追加のパッケージをインストールする必要があります: `pip install huggingface_hub`。環境変数`HUGGINGFACEHUB_API_TOKEN`は、有効な API トークンに設定する必要があります。

```yaml
embeddings:
  type: "huggingface_hub"
  repo_id: "sentence-transformers/all-mpnet-base-v2"
  task: "feature-extraction"
```

#### ラマCPP

llama-cpp 埋め込みを使用するには、必要な Python ライブラリをインストールする必要があります `pip install llama-cpp-python` を使用します。Llama モデルへのパスを指定する必要があります。詳細については、[llama-cpp プロジェクト](https://github.com/abetlen/llama-cpp-python)をご覧ください。

```yaml
embeddings:
  type: "llamacpp"
  model_path: "/path/to/model.bin"
```