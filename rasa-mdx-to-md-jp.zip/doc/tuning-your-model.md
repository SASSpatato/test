---
id: tuning-your-model
sidebar_label: Tuning Your NLU Model
title: Tuning Your NLU Model
abstract: Rasa will provide you with a suggested NLU config on initialization of the project, but as your project grows, it's likely that you will need to adjust your config to suit your training data.
---

## パイプラインの選び方

Rasa では、受信メッセージは一連のコンポーネントによって処理されます。これらのコンポーネントは、`config.yml`で定義されたいわゆる処理`パイプライン`で次々に実行されます。NLU パイプラインを選択すると、モデルをカスタマイズし、データセットで微調整できます。

開始するには、[[./model-configuration.md#推奨される構成|推奨される構成]] 機能では、既定のパイプラインを選択します。`config.yml` ファイルにボットの`言語`を指定し、`パイプライン` キーを除外するか空のままにするだけです。

```yaml-rasa
language: fr  # your 2-letter language code

pipeline:
# intentionally left empty
```

### 賢明な開始パイプライン

ゼロから始める場合は、事前トレーニング済みの単語埋め込みから始めると役立つことがよくあります。事前トレーニングされた単語埋め込みは、ある種の言語知識をすでにエンコードしているため、役立ちます。たとえば、トレーニングデータに「リンゴを買いたい」のような文があり、Rasa に「梨を買う」の意図を予測するように求められた場合、モデルは「リンゴ」と「梨」という単語が非常に似ていることをすでに認識しています。これは、十分なトレーニングデータがない場合に特に便利です。

[spaCy でサポートされている言語](https://spacy.io/usage/models#languages)の 1 つを使い始める場合は、次のパイプラインをお勧めします。

これは [[./components.md#spacyfeaturizer|Spacyfeaturizer]]は、事前トレーニングされた単語埋め込みを提供します([[./components.md#言語モデル|言語モデル]])。

パイプライン内で事前トレーニング済みの単語埋め込みを使用しない場合、特定の言語にバインドされず、よりドメイン固有になるようにモデルをトレーニングできます。

お使いの言語に単語の埋め込みがない場合、またはドメイン固有の用語がある場合は、次のパイプラインを使用することをお勧めします。

このパイプラインでは、 [[./components.md#countvectorsfeaturizer|CountVectorsFeaturizer]] を使用して、指定したトレーニング データのみでトレーニングします。このパイプラインは、単語がスペースで区切られている任意の言語を処理できます。これがあなたの言語に当てはまらない場合は、[[./components.md#トークナイザー|WhitespaceTokenizerの代替案]]を確認してください。

> [!note] 
> パイプラインでカスタムコンポーネントを使用する場合は、[カスタム NLU コンポーネント](./components.md)を参照してください。

### コンポーネントのライフサイクル

各コンポーネントは入力を処理したり、出力を作成したりします。コンポーネントの順序は、`コンポーネントがconfig.yml`にリストされている順序によって決まります。コンポーネントの出力は、パイプライン内のその後の他のコンポーネントで使用できます。一部のコンポーネントは、パイプライン内の他のコンポーネントで使用される情報のみを生成します。他のコンポーネントは、処理の完了後に返される`出力`属性を生成します。

たとえば、文の場合 `"I am looking for Chinese food"` 、出力は次のようになります。

```json
{
    "text": "I am looking for Chinese food",
    "entities": [
        {
            "start": 8,
            "end": 15,
            "value": "chinese",
            "entity": "cuisine",
            "extractor": "DIETClassifier",
            "confidence": 0.864
        }
    ],
    "intent": {"confidence": 0.6485910906220309, "name": "restaurant_search"},
    "intent_ranking": [
        {"confidence": 0.6485910906220309, "name": "restaurant_search"},
        {"confidence": 0.1416153159565678, "name": "affirm"}
    ]
}
```

これは、次のパイプライン内のさまざまなコンポーネントの結果の組み合わせとして作成されます。

```yaml-rasa
pipeline:
  - name: WhitespaceTokenizer
  - name: RegexFeaturizer
  - name: LexicalSyntacticFeaturizer
  - name: CountVectorsFeaturizer
  - name: CountVectorsFeaturizer
    analyzer: "char_wb"
    min_ngram: 1
    max_ngram: 4
  - name: DIETClassifier
  - name: EntitySynonymMapper
  - name: ResponseSelector
```

たとえば、ここでの`エンティティ`属性は、`DIETClassifier`コンポーネントによって作成されます。

すべてのコンポーネントは、`Component`基本クラスからいくつかのメソッドを実装できます。パイプラインでは、これらの異なるメソッドが特定の順序で呼び出されます。次のパイプラインを`config.yml`に追加したと仮定します。

```yaml-rasa
pipeline:
  - name: "Component A"
  - name: "Component B"
  - name: "Last Component"
```

次の図は、このパイプラインのトレーニング中の呼び出し順序を示しています。

<Image src="./component-lifecycle-img.png" caption="Component Lifecycle" alt="The component lifecycle during training. Components are processed in the order they're listed in the configuration file. All components are created and initialized in order before they are trained in order and then persisted in order." />

`create` 関数を使用して最初のコンポーネントが作成される前に、いわゆる`コンテキスト`が作成されます (これは Python の辞書にすぎません)。このコンテキストは、コンポーネント間で情報を渡すために使用されます。たとえば、1 つのコンポーネントはトレーニング データの特徴ベクトルを計算し、それをコンテキスト内に保存し、別のコンポーネントはコンテキストからこれらの特徴ベクトルを取得してインテント分類を行うことができます。

最初は、コンテキストにすべての構成値が入力されます。画像の矢印は呼び出し順序を示し、渡されたコンテキストのパスを視覚化します。すべてのコンポーネントがトレーニングされて永続化された後、最終的なコンテキスト ディクショナリを使用してモデルのメタデータが永続化されます。

### マルチインテント分類の実行

マルチインテント分類を使用して、複数のインテントを予測したり (`例: check_balances+transfer_money`)、階層的なインテント構造をモデル化したりできます (例: `フィードバック + ポジティブ`は`雑談`よりも`フィードバック + ネガティブ`に似ています)。

マルチインテント分類を行うには、パイプラインで [DIETClassifier](./components.md#dietclassifier) を使用する必要があります。また、使用しているトークナイザーでこれらのフラグを定義する必要があります。

*   `intent_tokenization_flag`: 意図ラベルがトークン化されるように、`True` に設定します。
    
*   `intent_split_symbol`: インテントラベルを分割する区切り文字文字列に設定します。この場合 `+`、デフォルトは `_` です。
    

構成例を次に示します。

```yaml-rasa
language: "en"

pipeline:
- name: "WhitespaceTokenizer"
  intent_tokenization_flag: True
  intent_split_symbol: "+"
- name: "CountVectorsFeaturizer"
- name: "DIETClassifier"
```

#### マルチインテントを使用する場合

金融サービスボットがあり、インテント`check_balances`と`transfer_money`の例があるとします。

```yaml-rasa
nlu:
- intent: check_balances
  examples: |
    - How much money do I have?
    - what's my account balance?

- intent: transfer_money
  examples: |
    - I want to transfer money to my savings account
    - transfer money
```

ただし、ボットは、両方の意図を組み合わせた次のような受信メッセージを受信します。

私はどれくらいのお金を持っていますか?貯蓄に振り替えたい。

これらの例が十分に表示されている場合は、新しいインテント マルチインテント `check_balances+transfer_money`を作成し、受信した例を追加できます。

```yaml-rasa
nlu:
- intent: check_balances+transfer_money
  examples: |
    - How much money do I have? I want to transfer some to savings.
    - What's the balance on my account? I need to transfer some so I want to know how much I have
```

> [!note] 
> モデルは、トレーニングデータで例が明示的に示されていないインテントの組み合わせを予測しません。考えられるすべてのインテントの組み合わせを考慮すると、インテントの数が爆発的に増加するため、実際のユーザーから十分な例が入ってきたインテントの組み合わせのみを追加する必要があります。

#### 対話管理にマルチインテントを使用する方法

マルチインテント分類は、マルチインテント*後の*アクション予測の下流タスクを支援することを目的としています。対話トレーニングデータでマルチインテントを使用するには、次の 2 つの補完的な方法があります。

1.  マルチインテントの通常のストーリーまたはルールを追加します。たとえば、個々のインテントごとに次の 2 つのルールがあるとします。

```yaml-rasa
rules:
- rule: check account balance
  steps:
  - intent: check_balances
  - action: action_check_balances
- rule: transfer money
  steps:
  - intent: transfer_money
  - action: action_transfer_money
```

両方のインテントに対処するための一連のアクションを指定するマルチインテントに別のルールを追加できます。

```
rules:
- rule: check balances and transfer money
  steps:
  - intent: check_balances+transfer_money
  - action: action_check_balances
  - action: action_transfer_money
```

2.  機械学習ポリシーを、単一インテント ストーリーからマルチインテント シナリオに一般化できるようにします。

マルチインテントを使用する場合、インテントはマルチホットエンコーディングを使用する機械学習ポリシーで特徴付けられます。つまり、`check_balances+transfer_money` の特徴付けは、個々の意図の特徴付けと重複します。機械学習ポリシー [[./policies.md#TEDポリシー|TEDポリシー]] は、マルチインテントがどのストーリーにも明示的に現れなくても、マルチインテントに基づいて予測を行うことができます。ただし、通常は個々のインテントの 1 つだけが存在するかのように動作するため、マルチインテントのケースを扱う特定のストーリーまたはルールを記述することをお勧めします。

### パイプラインの比較

Rasaは、データに対する複数のパイプラインのパフォーマンスを直接比較するツールを提供します。参照([[./testing-your-assistant.md#NLU パイプラインの比較|詳細については、NLU パイプラインの比較]]) を参照してください。

## 適切なコンポーネントの選択

エンティティ抽出、インテント分類、応答選択、前処理などのコンポーネントがあります。スペルチェックを実行したり、センチメント分析を実行したりするなど、独自のコンポーネントを追加する場合は、「[カスタム NLU コンポーネント」](./components.md)を参照してください。

パイプラインは通常、次の 3 つの主要部分で構成されます。

### トークン化

[WhitespaceTokenizer](./components.md#whitespacetokenizer) を使用して、空白トークン化された (つまり、単語がスペースで区切られている) 言語を処理できます。言語が空白トークン化されていない場合は、別のトークナイザーを使用する必要があります。さまざまな[トークナイザー](./components.md)をサポートしていますが、独自の[カスタムトークナイザー](./components.md)を作成することもできます。

> [!note] 
> パイプラインのさらに下にある一部のコンポーネントでは、特定のトークナイザーが必要になる場合があります。これらの要件は、個々のコンポーネントの `requires` パラメーターで確認できます。パイプライン内で必要なコンポーネントが欠落している場合、エラーがスローされます。

### 特徴付け

事前トレーニング済みの単語埋め込みを提供するコンポーネントを使用するかどうかを決定する必要があります。トレーニング データの量が少ない場合は、事前トレーニング済みの単語埋め込みから始めることをお勧めします。大量のデータがあり、最も関連性の高い単語がデータに含まれることを確認し、単語の埋め込みが行われるようにしたら、トレーニング データから単語の意味を直接学習する教師あり埋め込みにより、モデルをドメインにより固有にすることができます。お使いの言語の事前トレーニング済みモデルが見つからない場合は、教師あり埋め込みを使用する必要があります。

#### 事前トレーニング済み埋め込み

パイプラインで事前トレーニング済みの単語埋め込みを使用する利点は、"リンゴを買いたい" などのトレーニング例があり、Rasa に "get pears" の意図を予測するように求められた場合、モデルは "apples" と "pears" という単語が非常に似ていることを既に認識していることです。これは、十分なトレーニングデータがない場合に特に便利です。事前トレーニング済みの単語埋め込みを提供するいくつかのコンポーネントをサポートしています。

1.  [MitieFeaturizer (ミティエフィーチャライザー)](./components.md#mitiefeaturizer)
    
2.  [SpacyFeaturizer](./components.md#spacyfeaturizer)
    
3.  [ConveRTフェチュライザー](./components.md#convertfeaturizer)
    
4.  [LanguageModelFeaturizer ](./components.md#languagemodelfeaturizer)
    

トレーニングデータが英語の場合は、[ConveRTFeaturizer](./components.md#convertfeaturizer) を使用することをお勧めします。[ConveRTFeaturizer](./components.md#convertfeaturizer) の利点は、ユーザー メッセージの各単語を個別に処理するのではなく、文全体のコンテキスト ベクトル表現を作成することです。たとえば、「車を予約できますか?」のようなトレーニングの例があり、Rasa が「自分の場所から配車が必要です」の意図を予測するように求められた場合、両方の例のコンテキスト ベクトル表現はすでに非常に類似しているため、両方に分類された意図は同じである可能性が高くなります。これは、十分なトレーニングデータがない場合にも役立ちます。

[ConveRTFeaturizer](./components.md#convertfeaturizer)の代替手段は、BERT、GPT-2などの事前トレーニング済みの言語モデルを使用して、完全な文の同様のコンテキストベクトル表現を抽出する[LanguageModelFeaturizer](./components.md#languagemodelfeaturizer)です。見る [LanguageModelFeaturizer](./components.md#languagemodelfeaturizer) サポートされている言語モデルの完全な一覧を参照してください。

トレーニングデータが英語でない場合は、トレーニングデータに固有の言語で事前トレーニングされた言語モデルの別のバリアントを使用することもできます。たとえば、BERT モデルには中国語 (`bert-base-chinese`) と日本語 (`bert-base-japanese`) のバリアントがあります。これらの言語モデルのさまざまなバリアントの完全なリストは、[Transformersライブラリの公式ドキュメント](https://huggingface.co/models?library=tf&sort=downloads)で入手できます。

[SpacynLP](./components.md#spacyfeaturizer) は、さまざまな言語で単語埋め込みも提供しているため、トレーニング データの言語に応じて、これを別の代替手段として使用できます。

#### 教師あり埋め込み

パイプライン内で事前トレーニング済みの単語埋め込みを使用しない場合、特定の言語にバインドされず、よりドメイン固有になるようにモデルをトレーニングできます。たとえば、一般的な英語では、「バランス」という言葉は「対称性」と密接に関連していますが、「現金」という言葉とは大きく異なります。銀行の領域では、「残高」と「現金」は密接に関連しており、モデルでそれを捉える必要があります。次のような [sparse 特徴子](./components.md#featurizers)のカテゴリの特性化器のみを使用する必要があります。 [CountVectorsFeaturizer](./components.md#countvectorsfeaturizer)、[RegexFeaturizer](./components.md#regexfeaturizer)、または [LexicalSyntacticFeaturizer](./components.md#lexicalsyntacticfeaturizer) (事前トレーニング済みの単語埋め込みを使用しない場合)。

### インテント分類/応答セレクター

データによっては、インテント分類、エンティティ認識、または応答の選択のみを実行することができます。または、これらのタスクを複数組み合わせることもできます。タスクごとに複数のコンポーネントをサポートしています。インテント分類とエンティティ認識には [DIETClassifier](./components.mdx#dietclassifier) を使用し、応答の選択には [ResponseSelector](./components.mdx#responseselector) を使用することをお勧めします。

既定では、これらのコンポーネントはすべて、パイプラインで生成された使用可能なすべての機能を使用します。ただし、特定のコンポーネントで使用される機能を制限することが理にかなっている場合があります。たとえば、[ResponseSelector](./components.mdx#responseselector) は、 [RegexFeaturizer](./components.mdx#regexfeaturizer) または [LexicalSyntacticFeaturizer](./components.mdx#lexicalsyntacticfeaturizer) が使用されます。これを実現するには、次の操作を行います。オプション `alias` を使用して、パイプライン内のすべてのフィーチャライザーにエイリアスを設定します。既定では、エイリアスは完全な Featurizer クラス名 (`RegexFeaturizer` など) に設定されます。その後、たとえば、オプション `featurizer` を使用して [ResponseSelector](./components.md#応答セレクター) で、どの特徴子を使用する必要がある機能かを指定できます。オプション [`特徴付け]` を設定しない場合、使用可能なすべての機能が使用されます。

次に、`DIETClassifier` が使用可能なすべての特徴を使用し、`ResponseSelector` が `ConveRTFeaturizer` と `CountVectorsFeaturizer` の特徴のみを使用している構成ファイルの例を示します。

### エンティティ抽出

エンティティ抽出には、必要な情報のユーザー メッセージを解析することが含まれます。Rasaは、カスタムエンティティのエンティティ抽出ツールと、日付や場所などの事前トレーニング済みエンティティを提供します。利用可能な抽出器とその最適な用途の概要は次のとおりです。

| コンポーネント | 必要 | Model | 筆記 |
| --- | --- | --- | --- |
| DIETClassifier | 該当なし | トランスフォーマーの上の条件付きランダム フィールド | カスタムエンティティのトレーニングに適しています |
| CRFEntityExtractor | sklearn-crfsuite | 条件付きランダムフィールド | カスタムエンティティのトレーニングに適しています |
| SpacyEntityExtractor | スパサイ | 平均パーセプトロン | 事前トレーニング済みエンティティを提供します。 |
| DucklingEntityExtractor | アヒルの子を走らせる | コンテキストフリーの文法 | 事前トレーニング済みエンティティを提供します。 |
| MitieEntityExtractor | MITIE | 構造化SVM | カスタムエンティティのトレーニングに適しています |
| EntitySynonymMapper | 既存のエンティティ | 該当なし | 既知の同義語をマップする |

## パフォーマンスの向上

### クラスの不均衡の処理

分類アルゴリズムは、クラスの不均衡が大きい場合、たとえば、一部のインテントのトレーニング データが多く、他のインテントのトレーニング データが非常に少ない場合、うまく機能しないことがよくあります。この問題を軽減するには、`バランスの取れた`バッチ処理戦略を使用できます。 このアルゴリズムにより、すべてのクラスがすべてのバッチで、または少なくとも 後続のバッチをできるだけ多く実行し、一部のクラスが他のクラスよりも頻度が高いという事実を模倣します。 バランスバッチ処理が既定で使用されます。オフにして従来のバッチ処理戦略を使用するには、次のものが含まれます。 `batch_strategy: 設定`ファイル内のシーケンス。

```yaml-rasa
language: "en"

pipeline:
# - ... other components
- name: "DIETClassifier"
  batch_strategy: sequence
```

### 診断データへのアクセス

モデルの動作をより深く理解するために、予測プロセスの中間結果にアクセスできます。これを行うには、[メッセージ](./reference/rasa/shared/nlu/training_data/message.md#message-objects)の`diagnostic_data`フィールドにアクセスする必要があります [Prediction](./reference/rasa/core/policies/policy.md#policyprediction-objects)オブジェクトには、アテンションの重みと推論計算のその他の中間結果に関する情報が含まれています。この情報は、[RasaLit](https://github.com/RasaHQ/rasalit) などのデバッグと微調整に使用できます。

[[./command-line-interface.md#rasa train|train a model]] を取得した後、次のように処理されたメッセージが与えられた場合、DIET の診断データにアクセスできます。

```python
nlu_diagnostic_data = message.as_dict()[DIAGNOSTIC_DATA]

for component_name, diagnostic_data in nlu_diagnostic_data.items():
    attention_weights = diagnostic_data["attention_weights"]
    print(f"attention_weights for {component_name}:")
    print(attention_weights)

    text_transformed = diagnostic_data["text_transformed"]
    print(f"ntext_transformed for {component_name}:")
    print(text_transformed)
```

また、次のように TED の診断データにアクセスできます。

```python
prediction = policy.predict_action_probabilities(
    GREET_RULE, domain, RegexInterpreter()
)
print(f"{prediction.diagnostic_data.get('attention_weights')}")
```

## Tensorflow の設定

TensorFlow では、ランタイム環境でオプションを構成できます。 [TF Config サブモジュール](https://www.tensorflow.org/api_docs/python/tf/config)。Rasa は、これらの構成オプションのより小さなサブセットをサポートし、`tf.config` サブモジュールを適切に呼び出します。この小さなサブセットは、開発者が Rasa で頻繁に使用する構成で構成されます。すべての構成オプションは、後続のセクションに示すように、環境変数を使用して指定されます。

### 決定論的演算

GPU を使用していて、パイプラインに 1 つ以上のスパース特徴付け器がある場合、および/または `TEDPolicy`、`UnexpecTEDIntentPolicy`、`DIETClassifier`、または `ResponseSelector` のいずれかを使用している場合、環境変数 `TF_DETERMINISTIC_OPS=1` の場合、基礎となる tensorflow 演算の決定論的な GPU 実装`tf.sparse.sparse_dense_matmul`ないため、 `tf.nn.sparse_softmax_cross_entropy_with_logits` 、および`tf.math.unsorted_segment`操作。詳細については[こちら](https://github.com/tensorflow/community/blob/master/rfcs/20210119-determinism.md)を参照してください

上記の理由から、モデルは、複数の実行にわたってGPUでトレーニングした場合に、まったく同じパフォーマンスが得られることも保証されていません。これは、標準のホールドアウトテストセットで評価しながら、同じトレーニングデータに対して同じ構成とランダムシードを適切に設定してトレーニングを複数回実行する状況にも当てはまります。内部実験では、さまざまなデータセットのホールドアウトテストセットでトレーニングおよび評価された場合、モデルのパフォーマンスに次のような変動があることが示されています(実験は各データセットで5回実行されました)。

```
+-----------------------+------------+------------------+------------------+-------------------+
| Task,                 | Number of  | Average standard | Minimum standard | Maximum standard  |
| Metric (Range)        | datasets   | deviation        | deviation        | deviation         |
+-----------------------+------------+------------------+------------------+-------------------+
| Intent Classification | 11         | 0.0042           | 2.4e-5           | 0.0176            |
| Macro F1 (0-1)        |            |                  |                  |                   |
+-----------------------+------------+------------------+------------------+-------------------+
| Entity Recognition    | 7          | 0.0019           | 0.0007           | 0.0044            |
| Macro F1 (0-1)        |            |                  |                  |                   |
+-----------------------+------------+------------------+------------------+-------------------+
| Response Selection    | 2          | 0.0098           | 0.0003           | 0.0231            |
| Macro F1 (0-1)        |            |                  |                  |                   |
+-----------------------+------------+------------------+------------------+-------------------+
| Action Selection      | 5          | 0.0025           | 0.0010           | 0.0053            |
| Macro F1 (0-1)        |            |                  |                  |                   |
+-----------------------+------------+------------------+------------------+-------------------+
| Conversation Success  | 5          | 0.0077           | 0.0052           | 0.0103            |
| Accuracy (0-1)        |            |                  |                  |                   |
+-----------------------+------------+------------------+------------------+-------------------+
```

上記の実験は、Nvidia Tesla P4 GPU で実行されました。データセットで評価するときにも、モデルのパフォーマンスに同様の変動が予想されます。テストしたさまざまなパイプライン構成で、パイプラインでスパース特徴付け器を使用すると、変動がより顕著になります。ここでは、[フィーチャライザー](./components.md#featurizers)の "タイプ" を確認することで、どのフィーチャライザーがまばらであるかを確認できます。

上記のタスクでのモデルのパフォーマンスは、CPU でトレーニングされた場合、複数の実行にわたって再現可能であり、これらのいずれも変更されていません。

1.  トレーニングデータ
2.  テストデータ
3.  構成パイプライン
4.  Random Seed を構成のコンポーネントに挿入します。

### CPUパフォーマンスの最適化

> [!note] 
> これらのオプションは、上級 TensorFlow ユーザーであり、パイプラインでの機械学習コンポーネントの実装を理解している場合にのみ構成することをお勧めします。これらのオプションは、Tensorflow の内部で操作がどのように実行されるかに影響します。デフォルト値のままにしておくと問題ありません。

NLU コンポーネントまたはコアポリシーが使用する TensorFlow 操作に応じて、これらのオプションを調整することでマルチコア CPU 並列処理を活用できます。

#### 1 つの操作の並列化

1 つの操作の実行を並列化するために使用できるスレッドの最大数を指定する環境変数として設定 `TF_INTRA_OP_PARALLELISM_THREADS` します。たとえば、`tf.matmul()` や `tf.reduce_sum` などの操作は、並行して実行されている複数のスレッドで実行できます。この変数のデフォルト値は `0` で、TensorFlow は CPU コアごとに 1 つのスレッドを割り当てます。

#### 複数の操作の並列化

複数の**ノンブロッキング**操作の実行を並列化するために使用できるスレッドの最大数を指定する環境変数として設定 `TF_INTER_OP_PARALLELISM_THREADS` します。これらには、TensorFlow グラフでそれらの間に有向パスを持たない操作が含まれます。つまり、一方の演算の計算は、もう一方の演算の計算には影響しません。この変数のデフォルト値は `0` で、TensorFlow は CPU コアごとに 1 つのスレッドを割り当てます。

これら 2 つのオプションの違いの詳細については、こちらを参照してください [stackoverflow スレッド](https://stackoverflow.com/questions/41233635/meaning-of-inter-op-parallelism-threads-and-intra-op-parallelism-threads/41233901#41233901)を使用します。

### GPU パフォーマンスの最適化

#### GPU メモリの増加の制限

TensorFlow は、デフォルトで、実行中のプロセスで使用可能なすべての GPU メモリをブロックします。これは、複数の TensorFlow プロセスを実行していて、それらにメモリを分散したい場合に制限される可能性があります。Rasaが使用可能なすべてのGPUメモリをブロックしないようにするには、環境変数`TF_FORCE_GPU_ALLOW_GROWTH`を`True`に設定します。

#### 使用可能な絶対 GPU メモリの制限

Rasa プロセスで使用できる GPU メモリの絶対量を制限することができます。

たとえば、2 つの表示可能な GPU (`GPU:0` と `GPU:1`) があり、最初の GPU から 1024 MB、2 番目の GPU から 2048 MB を割り当てるとします。これを行うには、環境変数 `TF_GPU_MEMORY_ALLOC` を`「0:1024, 1:2048」`に設定します。