---
id: forms
sidebar_label: Forms
title: Forms
description: Follow a rule-based process of information gathering using forms in open source bot framework Rasa.
abstract: One of the most common conversation patterns is to collect a few pieces of information from a user in order to do something (book a restaurant, call an API, search a database, etc.). This is also called **slot filling**.
---

## 使い

Rasa でフォームを使用するには、[[./policies.md#ルールポリシー|ルールポリシー]]がポリシー設定に追加されます。例えば：

```yaml-rasa
policies:
- name: RulePolicy
```

### フォームの定義

[ドメイン](./domain.md)の`フォーム`セクションに追加して、フォームを定義します。 フォームの名前は、 フォーム実行を処理するための[ストーリー](./stories.md)または[ルール](./rules.md)。必須の`required_slots`キーにスロット名のリストを指定する必要があります。

次のフォーム`の例は`、スロットを埋めrestaurant_form `料理`とスロット`num_people`。

```yaml-rasa
entities:
- cuisine
- number
slots:
  cuisine:
    type: text
    mappings:
    - type: from_entity
      entity: cuisine
  num_people:
    type: any
    mappings:
    - type: from_entity
      entity: number
forms:
  restaurant_form:
    required_slots:
        - cuisine
        - num_people
```

フォーム全体に対して無視するインテントのリストを `ignored_intents`鍵。`ignored_intents` の下にリストされているインテントは、 各スロット・マッピングの`not_intent`キー。

たとえば、インテントが `chitchat` のときにフォームの必要なスロットを埋めたくない場合は、次のものを定義する必要があります (フォーム名の後、`ignored_intents` キーワードの下に)。

```yaml-rasa
entities:
- cuisine
- number
slots:
  cuisine:
    type: text
    mappings:
    - type: from_entity
      entity: cuisine
  num_people:
    type: any
    mappings:
    - type: from_entity
      entity: number
forms:
  restaurant_form:
    ignored_intents: 
    - chitchat
    required_slots:
        - cuisine
        - num_people
```

フォームアクションが初めて呼び出されると、フォームがアクティブ化され、次に必要なスロット値の入力を求められます。これは、前者が見つからない場合は `utter_ask_<slot_name>` という `utter_ask_<form_name>_<slot_name>` [応答](./responses.md)を探すことによって行われます。これらの応答は、必要なスロットごとにドメイン ファイルで定義してください。

### フォームの有効化

フォームをアクティブ化するには、アシスタントがフォームを実行するタイミングを説明する[ストーリー](./stories.md)または[ルール](./rules.md)を追加する必要があります。特定のインテントがフォームをトリガーする場合は、たとえば次のルールを使用できます。

```yaml-rasa
rules:
- rule: Activate form
  steps:
  - intent: request_restaurant
  - action: restaurant_form
  - active_loop: restaurant_form
```

> [!note] 
> `active_loop: restaurant_form` ステップは、フォームの実行後にフォームをアクティブ化する必要があることを示します`restaurant_form`。

### フォームの非アクティブ化

フォームは、必要なスロットがすべて埋まると自動的に非アクティブ化されます。フォームの末尾のアシスタントの動作をルールまたはストーリーで記述できます。該当するストーリーまたはルールを追加しない場合、アシスタントはフォームの完了後に次のユーザー メッセージを自動的にリッスンします。次の例では、フォームに必要なスロットがすべて埋められるとすぐに発話`utter_submit your_form utter_slots_values`を実行します。

```yaml-rasa
rules:
- rule: Submit form
  condition:
  # Condition that form is active.
  - active_loop: restaurant_form
  steps:
  # Form is deactivated
  - action: restaurant_form
  - active_loop: null
  - slot_was_set:
    - requested_slot: null
  # The actions we want to run when the form is submitted.
  - action: utter_submit
  - action: utter_slots_values
```

ユーザーは、フォームを早期に中断したい場合があります。[[./forms.md#ストーリーを書く / 不幸なフォームパスのルール|ストーリーを書く/不幸なフォームパスのルール]]について、このケースのストーリーやルールの書き方について。

### スロットマッピング

> [!warning] 3.0 での変更 
> 3.0 では、ドメインの `slots` セクションで [[./domain.md#スロットマッピング|スロットマッピング]] が定義されています。この変更により、同じスロットマッピングを複数のフォームで再利用できるようになり、不要な重複が排除されます。[[./migration-guide.md#スロットマッピング|migration guide]] に従ってアシスタントを更新してください。
> 
> Note specifically the role of [[./domain.md#マッピング条件|マッピング条件]] と [[./domain.md#独自の`from_entity`マッピングマッチング|unique entity mapping]] 制約を使用します。

### ストーリーを書く / 不幸なフォームパスのルール

ユーザーは、あなたが要求した情報で常に応答するとは限りません。通常、ユーザーは質問をしたり、おしゃべりをしたり、気が変わったり、そうでなければ幸せな道から外れたりします。

フォームがアクティブな間、ユーザーの入力が要求されたスロットを埋めない場合、フォームアクションの実行は拒否され、フォームは自動的に`ActionExecutionRejection`を発生させます。フォームが `ActionExecutionRejection` を発生させる特定のシナリオは次のとおりです。

*   スロットが要求されましたが、ユーザーが最後のメッセージでスロットを埋めておらず、[[forms.md#フォーム入力の検証|Validating slots]] または [[forms.md#カスタムスロットマッピング|extracting slots]] のカスタムアクションを定義していませんでした。
*   スロットが要求されましたが、[[forms.md#フォーム入力の検証|Validating slots]] または [[forms.md#カスタムスロットマッピング|extracting slots]] のカスタムアクションで `SlotSet` イベントが返されませんでした。

フォームの実行を意図的に拒否するには、カスタム検証またはスロットマッピングの一部として `ActionExecutionRejected` イベントを返すこともできます。

フォームの実行が拒否される可能性がある状況に対処するために、予想される中断を含むルールまたはストーリーを記述できます。たとえば、ユーザーがボットとおしゃべりすることを期待している場合は、これを処理するルールを追加できます。

```yaml-rasa
rules:
- rule: Example of an unhappy path
  condition:
  # Condition that form is active.
  - active_loop: restaurant_form
  steps:
  # This unhappy path handles the case of an intent `chitchat`.
  - intent: chitchat
  - action: utter_chitchat
  # Return to form after handling the `chitchat` intent
  - action: restaurant_form
  - active_loop: restaurant_form
```

状況によっては、ユーザーがフォーム アクションの途中で気が変わり、最初の要求を続行しないことに決めることがあります。このような場合、アシスタントは要求されたスロットの要求を停止する必要があります。

このような状況は、フォームを非アクティブ化し、要求されたスロットをリセットするデフォルトのアクション`action_deactivate_loop`を使用して適切に処理できます。そのような会話の例は次のようになります。

```yaml-rasa
stories:
- story: User interrupts the form and doesn't want to continue
  steps:
  - intent: request_restaurant
  - action: restaurant_form
  - active_loop: restaurant_form
  - intent: stop
  - action: utter_ask_continue
  - intent: stop
  - action: action_deactivate_loop
  - active_loop: null
```

これらのルールやストーリーは、[[./writing-stories.md#対話型学習の使用|インタラクティブ・ラーニング]]を使用して構築することを**強く**お勧めします。これらのルールやストーリーを手書きで書くと、重要なことを見逃してしまう可能性があります。

## 高度な使用法

フォームは、[[./actions.md#カスタムアクション|カスタムアクション]]。

### フォーム入力の検証

ユーザー入力からスロット値を抽出した後、抽出されたスロットを検証できます。デフォルトでは、Rasaはスロットを要求した後にスロットがいっぱいになったかどうかのみ検証します。

[[./actions.md#カスタムアクション|カスタムアクション]]`validate_<form_name>` 抽出されたスロットを検証します。このアクションを`アクション`に追加してください セクションに追加します。

```yaml-rasa
actions:
- validate_restaurant_form
```

フォームが実行されると、ユーザーがターンするたびにカスタムアクションが実行され、最後に入力されたスロットが検証されます。

このカスタム アクションは、`FormValidationAction` クラスを拡張して、抽出されたスロットの検証プロセスを簡略化できます。この場合、抽出されたスロットごとに `validate_<slot_name>` という名前の関数を記述する必要があります。

次の例は、`cuisine` という名前のスロットが有効であることを検証するカスタムアクションの実装を示しています。

```python
from typing import Text, List, Any, Dict

from rasa_sdk import Tracker, FormValidationAction
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.types import DomainDict


class ValidateRestaurantForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_restaurant_form"

    @staticmethod
    def cuisine_db() -> List[Text]:
        """Database of supported cuisines"""

        return ["caribbean", "chinese", "french"]

    def validate_cuisine(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: DomainDict,
    ) -> Dict[Text, Any]:
        """Validate cuisine value."""

        if slot_value.lower() in self.cuisine_db():
            # validation succeeded, set the value of the "cuisine" slot to value
            return {"cuisine": slot_value}
        else:
            # validation failed, set this slot to None so that the
            # user will be asked for the slot again
            return {"cuisine": None}
```

また、`Action` クラスを拡張し、抽出されたスロットを `tracker.slots_to_validate` で取得して、検証プロセスを完全にカスタマイズすることもできます。

### カスタムスロットマッピング

> [!warning] 3.0 で変更 
> `FormValidationAction` の`required_slots`メソッドに提供される `slots_mapped_in_domain` 引数が `domain_slots` 引数に置き換えられましたので、カスタムアクションを新しい引数名に更新してください。

定義済みの [[./domain.md#スロットマッピング|スロットマッピング]] がいずれもユースケースに適合しない場合は、[[./actions.md#カスタムアクション|カスタムアクション]] `validate_<form_name>` を使用して独自の抽出コードを記述します。Rasa は、フォームの実行時にこのアクションをトリガーします。

Rasa SDK を使用している場合は、提供されている `FormValidationAction` です。`FormValidationAction` を使用する場合、カスタムスロットを抽出するには、次の 3 つの手順が必要です。

1.  カスタム方法でマッピングする必要があるすべてのスロットに対してメソッド`extract_<slot_name>`を定義します。カスタム マッピングを使用して `domain.yml` ファイルで定義されている各**スロットには、**`extract_<slot_name>` メソッドの独自の独立した実装が必要です。
2.  ドメイン ファイルで、フォームの`required_slots`に必要なすべてのスロットを、定義済みマッピングとカスタムマッピングの両方で一覧表示します。

さらに、動的に要求されたスロットを追加する `required_slots` メソッドをオーバーライドできます: 詳細については、[[./forms.md#動的フォームの動作|動的フォーム動作]] セクションを参照してください。

> [!note] 
> ドメインファイルの`スロット`セクションにカスタムマッピングを使用してスロットを追加し、`FormValidationAction` を拡張するカスタムアクションによってフォームのコンテキスト内でのみ検証する場合は、このスロットのマッピングが`カスタム`タイプであり、スロット名がフォームの`required_slots`に含まれていることを確認してください。

次の例は、スロットを抽出するフォームの実装を示しています 事前定義されたマッピングを使用するスロットに加えて、カスタムの方法で`outdoor_seating`します。このメソッドは、最後のユーザーメッセージにキーワード `outdoor` が存在したかどうかに基づいてスロット`outdoor_seating extract_outdoor_seating`を設定します。

```python
from typing import Dict, Text, List, Optional, Any

from rasa_sdk import Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import FormValidationAction


class ValidateRestaurantForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_restaurant_form"

    async def extract_outdoor_seating(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> Dict[Text, Any]:
        text_of_last_user_message = tracker.latest_message.get("text")
        sit_outside = "outdoor" in text_of_last_user_message

        return {"outdoor_seating": sit_outside}
```

デフォルトでは、`FormValidationAction` は自動的に [[forms.md#requested_slotスロット|`requested_slot`]] を、`required_slots`で指定された最初のスロットに指定しますが、これは満たされていません。

### 動的フォームの動作

デフォルトでは、Rasaはドメインファイル内のフォームにリストされているスロットから次の空のスロットを要求します。[[forms.md#カスタムスロットマッピング|カスタムスロットマッピング]] と `FormValidationAction` を使用すると、`required_slots` メソッドによって返される最初の空のスロットを要求します。`required_slots`のすべてのスロットが埋まると、フォームは無効になります。

フォームの必要なスロットを動的に更新できます。これは、たとえば、前のスロットの埋め方に基づいて追加のスロットを埋める必要がある場合や、スロットが要求される順序を変更する場合などに役立ちます。

Rasa SDK を使用している場合は、動的な動作に合わせて `FormValidationAction` を使用し、オーバーライド`required_slots`することを強くお勧めします。[[forms.md#カスタムスロットマッピング|カスタムスロットマッピング]]で説明されているように、定義済みマッピングを使用しないすべてのスロットに対してメソッド`extract_<slot name>`を実装する必要があります。以下の例では、ユーザーが外に座りたいと言った場合に備えて、日陰に座るか太陽の下に座るかを尋ねます。

```python
from typing import Text, List, Optional

from rasa_sdk.forms import FormValidationAction

class ValidateRestaurantForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_restaurant_form"

    async def required_slots(
        self,
        domain_slots: List[Text],
        dispatcher: "CollectingDispatcher",
        tracker: "Tracker",
        domain: "DomainDict",
    ) -> List[Text]:
        additional_slots = ["outdoor_seating"]
        if tracker.slots.get("outdoor_seating") is True:
            # If the user wants to sit outside, ask
            # if they want to sit in the shade or in the sun.
            additional_slots.append("shade_or_sun")

        return additional_slots + domain_slots
```

逆に、特定の条件下でドメインファイルで定義されているフォームの`required_slots`からスロットを削除する場合は、`domain_slots`を新しい変数にコピーし、直接変更するのではなく、その新しい変数に変更を適用する必要があります `domain_slots`。`domain_slots`を直接変更すると、予期しない動作が発生する可能性があります。例えば：

```python
from typing import Text, List, Optional

from rasa_sdk.forms import FormValidationAction

class ValidateBookingForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_booking_form"

    async def required_slots(
        self,
        domain_slots: List[Text],
        dispatcher: "CollectingDispatcher",
        tracker: "Tracker",
        domain: "DomainDict",
    ) -> List[Text]:
        updated_slots = domain_slots.copy()
        if tracker.slots.get("existing_customer") is True:
            # If the user is an existing customer,
            # do not request the `email_address` slot
            updated_slots.remove("email_address")

        return updated_slots
```

### requested_slotスロット

スロット`requested_slot`は、タイプ [[domain.md#テキストスロット|`text`]]です。会話中は`requested_slot`の値は無視されます。この動作を変更する場合は、`requested_slot`をカテゴリ スロットとしてドメイン ファイルに追加する必要があります。 `influence_conversation` `true` に設定されます。現在ユーザーから要求されているスロットに応じて、不満なパスを別の方法で処理する場合は、これを行うことをお勧めします。たとえば、ユーザーがボットの質問の 1 つに別の質問で応答した場合、*たとえば、なぜそれを知る必要があるのか?*この`説明`の意図に対する反応は、物語のどこにいるかによって異なります。レストランの場合、あなたのストーリーは次のようになります。

```yaml-rasa
stories:
- story: explain cuisine slot
  steps:
  - intent: request_restaurant
  - action: restaurant_form
  - active_loop: restaurant
  - slot_was_set:
    - requested_slot: cuisine
  - intent: explain
  - action: utter_explain_cuisine
  - action: restaurant_form
  - active_loop: null

- story: explain num_people slot
  steps:
  - intent: request_restaurant
  - action: restaurant_form
  - active_loop: restaurant
  - slot_was_set:
    - requested_slot: cuisine
  - slot_was_set:
    - requested_slot: num_people
  - intent: explain
  - action: utter_explain_num_people
  - action: restaurant_form
  - active_loop: null
```

繰り返しになりますが、これらのストーリーを構築するには、[[./writing-stories.md#対話型学習の使用|interactive learning]]を使用することを**強く**お勧めします。

### カスタムアクションを使用した次のスロットの要求

フォームは、ユーザーが次にどのスロットを埋める必要があるかを決定するとすぐに、アクション `utter_ask_<form_name>_<slot_name>` または`utter_ask_<slot_name>`を実行します ユーザーに必要な情報の提供を求めるため。通常の発話が カスタムアクション `action_ask_<form_name>_<slot_name>` や `action_ask_<slot_name>` 次のスロットを要求します。

```python
from typing import Dict, Text, List

from rasa_sdk import Tracker
from rasa_sdk.events import EventType
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk import Action


class AskForSlotAction(Action):
    def name(self) -> Text:
        return "action_ask_cuisine"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        dispatcher.utter_message(text="What cuisine?")
        return []
```

スロットに複数の要求オプションがある場合、Rasa は次の順序で優先順位を付けます。

1.  `action_ask_<form_name>_<slot_name>`
2.  `utter_ask_<form_name>_<slot_name>`
3.  `action_ask_<slot_name>`
4.  `utter_ask_<slot_name>`