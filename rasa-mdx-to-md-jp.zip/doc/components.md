---
id: components
sidebar_label: Pipeline Components
title: Components
abstract: Components make up your NLU pipeline and work sequentially to process user input
  into structured output. There are components for entity extraction, for intent classification, response selection,
  pre-processing, and more.
---

## 言語モデル

次のコンポーネントは、パイプラインで事前トレーニング済みの単語ベクトルを使用する場合に必要な事前トレーニング済みモデルを読み込みます。

### MitieNLP

*   **短い**
    
    MITIE初期化子
    
*   **出力**
    
    何もない
    
*   **必要**
    
    何もない
    
*   **形容**
    
    MITIE構造体を初期化します。すべての MITIE コンポーネントはこれに依存しているため、これは MITIE コンポーネントを使用するすべてのパイプラインの先頭に配置する必要があります。
    
*   **構成**
    
    MITIE ライブラリには言語モデルファイルが必要であり、設定で指定**する必要があります**。
    
    ```yaml-rasa
    pipeline:
    - name: "MitieNLP"
      # language model to load
      model: "data/total_word_feature_extractor.dat"
    ```
    
    そのファイルの入手元の詳細については、[[installing-rasa-open-source#MITIEの依存関係|installing MITIE]]にアクセスしてください。
    
    MITIE を使用して、言語コーパスから独自の単語ベクトルを事前トレーニングすることもできます。そのためには、次の手順を実行します。
    
    1.  クリーンな言語コーパス (ウィキペディアのダンプが機能します) をテキスト ファイルのセットとして取得します。
        
    2.  コーパスで[MITIE Wordrep Tool](https://github.com/mit-nlp/MITIE/tree/master/tools/wordrep)をビルドして実行します。これには、データセットとワークステーションによっては、数時間または数日かかる場合があります。wordrepを実行するには128GBのRAMのようなものが必要です–はい、それはたくさんあります:スワップを拡張してみてください。
        
    3.  新しい `total_word_feature_extractor.dat` パスを`モデル`パラメータとして設定し、 [設定](./model-configuration.md)ファイル。
        
    
    MITIEワードベクトルをトレーニングする方法の完全な例については、 Rasa NLUは、中国語版ウィキペディアのダンプからMITIEモデルを作成するブログ投稿である[Rasa NLUを構築し](http://www.crownpku.com/2017/07/27/%E7%94%A8Rasa_NLU%E6%9E%84%E5%BB%BA%E8%87%AA%E5%B7%B1%E7%9A%84%E4%B8%AD%E6%96%87NLU%E7%B3%BB%E7%BB%9F.html)ました。
    

### SpacyNLP

*   **短い**
    
    spaCy 言語初期化子
    
*   **出力**
    
    何もない
    
*   **必要**
    
    何もない
    
*   **形容**
    
    spaCy 構造体を初期化します。すべての spaCy コンポーネントはこれに依存しているため、これは spaCy コンポーネントを使用するすべてのパイプラインの先頭に配置する必要があります。
    
*   **構成**
    
    使用する言語モデルを指定する必要があります。名前は `spacy.load(name)` に渡されます。利用可能なモデルの詳細については、[spaCy のドキュメント](https://spacy.io/usage/models)を参照してください。
    
    ```yaml-rasa
    pipeline:
    - name: "SpacyNLP"
      # language model to load
      model: "en_core_web_md"
    
      # when retrieving word vectors, this will decide if the casing
      # of the word is relevant. E.g. `hello` and `Hello` will
      # retrieve the same vector, if set to `False`. For some
      # applications and models it makes sense to differentiate
      # between these two words, therefore setting this to `True`.
      case_sensitive: False
    ```
    
    spaCy モデルのダウンロード方法の詳細については、[[installing-rasa-open-source#spaCyの依存関係|installing SpaCy]] にアクセスしてください。
    
    SpaCy の事前トレーニング済み言語モデルに加えて、このコンポーネントを使用して、自分でトレーニングした spaCy モデルをアタッチすることもできます。
    

## トークナイザー

トークナイザーはテキストをトークンに分割します。複数のインテントを予測したり、階層的なインテント構造をモデル化したりするために、インテントを複数のラベルに分割する場合は、任意のトークナイザーで次のフラグを使用します。

*   `intent_tokenization_flag`は、インテントラベルをトークン化するかどうかを示します。意図ラベルがトークン化されるように、`これを True` に設定します。
    
*   `intent_split_symbol`、インテントラベルを分割する区切り文字文字列を設定し、デフォルトはアンダースコア(`_`)です。
    

### ホワイトスペーストークナイザー

*   **短い**
    
    空白を区切り文字として使用するトークナイザー
    
*   **出力**
    
    ユーザーメッセージ、応答(存在する場合)、およびインテント(指定されている場合)の`トークン`
    
*   **必要**
    
    何もない
    
*   **形容**
    
    空白で区切られたすべての文字シーケンスのトークンを作成します。
    
    `a-zA-Z0-9_#@&` にない文字は、次の条件のいずれかを満たす場合、空白で分割する前に空白に置き換えられます。
    
    *   文字は空白の後に続きます: `" !word"` → `"word"`
    *   文字の前には空白があります`: "word! " →` `"word"`
    *   文字は文字列の先頭にあります: `"!word"` → `"word"`
    *   文字列の末尾にある文字は、`"word!"` → `"word" です。`
    
    次の点に注意してください。
    
    *   `「wo!rd」` → `「wo!rd」`
    
    さらに、文字が数字の間にない場合、空白で分割する前に空白に置き換えられます。 `a-zA-Z0-9_#@&.~:/?[]()!$*+,;=-`
    
    *   `"twenty{one"` → `"twenty"`, `"one"` ("{"' は数字の間にはありません)
    *   `"20{1"` → `"20{1"` ("{"' は数字の間に*あります*)
    
    次の点に注意してください。
    
    *   `「name@example.com」``→「name@example.com」`
    *   `「10,000.1」`→`「10,000.1」`
    *   `「1 - 2」`→`「1」、「``2」`
*   **構成**
    
    ```yaml-rasa
    pipeline:
    - name: "WhitespaceTokenizer"
      # Flag to check whether to split intents
      "intent_tokenization_flag": False
      # Symbol on which intent should be split
      "intent_split_symbol": "_"
      # Regular expression to detect tokens
      "token_pattern": None
    ```
    

### Jiebaトークナイザー

*   **短い**
    
    中国語に Jieba を使用したトークナイザー
    
*   **出力**
    
    ユーザーメッセージ、応答(存在する場合)、およびインテント(指定されている場合)の`トークン`
    
*   **必要**
    
    何もない
    
*   **形容**
    
    中国語専用の Jieba トークナイザーを使用してトークンを作成します。中国語でのみ機能します。
    

> [!NOTE]
> 注: `JiebaTokenizer` を使用するには、`pip3 install jieba を使用して Jieba` をインストールする必要があります。

*   **構成**
    
    ユーザーのカスタム辞書ファイルは、`dictionary_path`を介してファイルのディレクトリパスを指定することで自動ロードできます。`dictionary_path`が `None` (デフォルト) の場合、ユーザー辞書は使用されません。
    
    ```yaml-rasa
    pipeline:
    - name: "JiebaTokenizer"
      dictionary_path: "path/to/custom/dictionary/dir"
      # Flag to check whether to split intents
      "intent_tokenization_flag": False
      # Symbol on which intent should be split
      "intent_split_symbol": "_"
      # Regular expression to detect tokens
      "token_pattern": None
    ```
    

### MitieTokenizer (ミティエトークナイザー)

*   **短い**
    
    MITIEを使用したトークナイザー
    
*   **出力**
    
    ユーザーメッセージ、応答(存在する場合)、およびインテント(指定されている場合)の`トークン`
    
*   **必要**
    
    [ミティエNLP](./components.md#ミティエNLP)
    
*   **形容**
    
    MITIEトークナイザーを使用してトークンを作成します。
    
*   **構成**
    
    ```yaml-rasa
    pipeline:
    - name: "MitieTokenizer"
      # Flag to check whether to split intents
      "intent_tokenization_flag": False
      # Symbol on which intent should be split
      "intent_split_symbol": "_"
      # Regular expression to detect tokens
      "token_pattern": None
    ```
    

### スペーシートークナイザー

*   **短い**
    
    spaCyを使用したトークナイザー
    
*   **出力**
    
    ユーザーメッセージ、応答(存在する場合)、およびインテント(指定されている場合)の`トークン`
    
*   **必要**
    
    [スペーシーNLP](./components.md#スペーシーNLP)
    
*   **形容**
    
    spaCy トークナイザーを使用してトークンを作成します。
    
*   **構成**
    
    ```yaml-rasa
    pipeline:
    - name: "SpacyTokenizer"
      # Flag to check whether to split intents
      "intent_tokenization_flag": False
      # Symbol on which intent should be split
      "intent_split_symbol": "_"
      # Regular expression to detect tokens
      "token_pattern": None
    ```
    

## フィーチャライザー

テキスト特徴付け器は、スパース特徴付け器と高密度特徴付け器の 2 つの異なるカテゴリに分類されます。スパース特徴付け器は、欠損値 (ゼロなど) が多い特徴ベクトルを返す特徴付け器です。これらの特徴ベクトルは通常、多くのメモリを消費するため、スパース特徴として保存します。スパース特徴は、ゼロ以外の値とベクトル内のそれらの位置のみを格納します。したがって、多くのメモリを節約し、より大きなデータセットでトレーニングすることができます。

すべての特徴付け器は、シーケンス特徴と文の特徴という 2 種類の特徴を返すことができます。シーケンス特徴は、サイズ `(number-of-tokens x feature-dimension)` の行列です。行列には、シーケンス内のすべてのトークンの特徴ベクトルが含まれています。これにより、シーケンスモデルをトレーニングできます。文の特徴は、サイズ `(1 x 特徴次元)` の行列で表されます。これには、完全な発話の特徴ベクトルが含まれています。文の特徴は、任意の単語バッグモデルで使用できます。したがって、対応する分類子は、使用する特徴の種類を決定できます。注: シーケンス特徴と文の特徴の`次元`は、同じである必要はありません。

### MitieFeaturizer (ミティエフィーチャライザー)

*   **短い**
    
    MITIE フィーチャライザーを使用して、ユーザー メッセージと応答 (指定されている場合) のベクトル表現を作成します。
    
*   **出力**
    
    ユーザーメッセージと応答の`dense_features`
    
*   **必要**
    
    [ミティエNLP](./components.md#ミティエNLP)
    
*   **種類**
    
    高密度フィーチャライザー
    
*   **形容**
    
    MITIE フィーチャライザーを使用して、エンティティ抽出、インテント分類、応答分類の特徴を作成します。
    
    > [!note] `MitieIntentClassifier`コンポーネントでは使用されないことに注意してください。ただし、パイプラインの後半で`dense_features`を使用する任意のコンポーネントで使用できます。
    
*   **構成**
    
    文ベクトル、つまり完全な発話のベクトルは、平均または最大プーリングの2つの異なる方法で計算できます。プーリング方法は、オプション `pooling` を使用して、構成ファイルで指定できます。デフォルトのプーリング方式は `mean` に設定されています。
    
    ```yaml-rasa
    pipeline:
    - name: "MitieFeaturizer"
      # Specify what pooling operation should be used to calculate the vector of
      # the complete utterance. Available options: 'mean' and 'max'.
      "pooling": "mean"
    ```
    

### SpacyFeaturizer

*   **短い**
    
    spaCy 特徴付け器を使用して、ユーザー メッセージと応答 (指定されている場合) のベクトル表現を作成します。
    
*   **出力**
    
    ユーザーメッセージと応答の`dense_features`
    
*   **必要**
    
    [スペーシーNLP](./components.md#スペーシーNLP)
    
*   **種類**
    
    高密度フィーチャライザー
    
*   **形容**
    
    spaCy 特徴付け器を使用して、エンティティ抽出、意図分類、応答分類の特徴を作成します。
    
*   **構成**
    
    文ベクトル、つまり完全な発話のベクトルは、平均または最大プーリングの2つの異なる方法で計算できます。プーリング方法は、オプション `pooling` を使用して、構成ファイルで指定できます。デフォルトのプーリング方式は `mean` に設定されています。
    
    ```yaml-rasa
    pipeline:
    - name: "SpacyFeaturizer"
      # Specify what pooling operation should be used to calculate the vector of
      # the complete utterance. Available options: 'mean' and 'max'.
      "pooling": "mean"
    ```
    

### ConveRTフェチュライザー

*   **短い**
    
    ユーザーメッセージと応答(指定されている場合)のベクトル表現を作成します。 [ConveRT](https://github.com/PolyAI-LDN/polyai-models) モデル。
    
*   **出力**
    
    ユーザーメッセージと応答の`dense_features`
    
*   **種類**
    
    高密度フィーチャライザー
    
*   **形容**
    
    エンティティ抽出、インテント分類、応答選択のための機能を作成します。[デフォルトのシグネチャ](https://github.com/PolyAI-LDN/polyai-models#tfhub-signatures)を使用して、入力テキストのベクトル表現を計算します。
    
    > [!note] 注: `ConveRT` モデルは会話の英語コーパスでのみトレーニングされるため、このフィーチャライザーは、トレーニング データが英語の場合にのみ使用する必要があります。
    
    > [!note] 注: このコンポーネントは現在、M1 / M2アーキテクチャを使用しているMacOSでは実行できないことに注意してください。この制限の詳細については、[[環境設定#M1 / M2 (Apple Silicon) の制限事項|こちら]] を参照してください。
    
*   **構成**
    
    ```yaml-rasa
    pipeline:
    - name: "ConveRTFeaturizer"
    # Remote URL/Local directory of model files(Required)
    "model_url": None
    ```
    
    > [!注意] 注意 ConveRT モデルのパブリック URL が最近オフラインになったため、パラメーター `model_url` をコミュニティ/セルフホスト URL またはモデル ファイルを含むローカル ディレクトリへのパスに設定することが必須になりました。
    

### LanguageModelFeaturizer

*   **短い**
    
    事前トレーニング済みの言語モデルを使用して、ユーザーメッセージと応答(指定されている場合)のベクトル表現を作成します。
    
*   **出力**
    
    ユーザーメッセージと応答の`dense_features`
    
*   **種類**
    
    高密度フィーチャライザー
    
*   **形容**
    
    エンティティ抽出、インテント分類、応答選択のための機能を作成します。事前トレーニング済みの言語モデルを使用して、入力テキストのベクトル表現を計算します。
    
    > [!note] 注: トレーニング データと同じ言語コーパスで事前トレーニングされた言語モデルを使用していることを確認してください。
    
*   **構成**
    
    このコンポーネントの前に[トークナイザー](./components.md#トークナイザー)コンポーネントを含めます。
    
    読み込む言語モデルは、パラメーター `model_name` を使用して指定する必要があります。以下の表を参照してください。 現在サポートされている言語モデル。ロードする重みは、追加のパラメータで指定できます `model_weights`。空のままにすると、表にリストされている既定のモデルの重みが使用されます。
    
    ```
    +----------------+--------------+-------------------------+
    | Language Model | Parameter    | Default value for       |
    |                | "model_name" | "model_weights"         |
    +----------------+--------------+-------------------------+
    | BERT           | bert         | rasa/LaBSE              |
    +----------------+--------------+-------------------------+
    | GPT            | gpt          | openai-gpt              |
    +----------------+--------------+-------------------------+
    | GPT-2          | gpt2         | gpt2                    |
    +----------------+--------------+-------------------------+
    | XLNet          | xlnet        | xlnet-base-cased        |
    +----------------+--------------+-------------------------+
    | DistilBERT     | distilbert   | distilbert-base-uncased |
    +----------------+--------------+-------------------------+
    | RoBERTa        | roberta      | roberta-base            |
    +----------------+--------------+-------------------------+
    | camemBERT      | camembert    | camembert-base          |
    +----------------+--------------+-------------------------+
    ```
    
    デフォルトの事前トレーニング済みモデルの重みとは別に、 [HuggingFace モデル](https://huggingface.co/models)は、次の条件が満たされている場合に限ります (上記のファイルは、モデル Web サイトの「ファイルとバージョン」セクションにあります)。
    
    *   モデルアーキテクチャは、サポートされている言語モデルの 1 つです (`config.json` の`model_type`がテーブルの列 `model_name` にリストされていることを確認してください)
        
    *   モデルには事前トレーニング済みの Tensorflow 重みがあります (ファイル `tf_model.h5` が存在することを確認してください)
        
    *   モデルはデフォルトのトークナイザーを使用します (`config.json`カスタム `tokenizer_class`設定を含めることはできません)
        
    
    > [!note] 注: `bert` アーキテクチャのデフォルトとしてロードされる `LaBSE` 重みは、112 の言語でトレーニングされた多言語モデルを提供します ([チュートリアル](https://www.youtube.com/watch?v=7tAWk_Coj-s)と元の[論文](https://arxiv.org/pdf/2007.01852.pdf)を参照)。これをベースラインとして使用し、他の重み/アーキテクチャでこのコンポーネントを最適化する前にボットをエンドツーエンドでテストすることを強くお勧めします。
    
    次の構成は、[言語](https://huggingface.co/rasa/LaBSE/tree/main)モデル BERT を `rasa/LaBSE` の重みで読み込みます。
    
    ```yaml-rasa
    pipeline:
      - name: LanguageModelFeaturizer
        # Name of the language model to use
        model_name: "bert"
        # Pre-Trained weights to be loaded
        model_weights: "rasa/LaBSE"
    
        # An optional path to a directory from which
        # to load pre-trained model weights.
        # If the requested model is not found in the
        # directory, it will be downloaded and
        # cached in this directory for future use.
        # The default value of `cache_dir` can be
        # set using the environment variable
        # `TRANSFORMERS_CACHE`, as per the
        # Transformers library.
        cache_dir: null
    ```
    

### RegexFeaturizer

*   **短い**
    
    正規表現を使用してユーザーメッセージのベクトル表現を作成します。
    
*   **出力**
    
    ユーザーメッセージとトークンの`sparse_features``。パターン`
    
*   **必要**
    
    `tokens`
    
*   **種類**
    
    スパース特徴付け器
    
*   **形容**
    
    エンティティ抽出とインテント分類の機能を作成します。トレーニング中に、`RegexFeaturizer` はトレーニング データ形式で定義された正規表現のリストを作成します。正規表現ごとに、この式がユーザーメッセージで見つかったかどうかをマークする機能が設定されます。すべての特徴は、分類を簡素化するために、後でインテント分類器/エンティティ抽出器に供給されます(分類器がトレーニングフェーズで学習したと仮定すると、このセット特徴量は特定のインテント/エンティティを示します)。エンティティ抽出の正規表現機能は、現在、[CRFEntityExtractor](./components.md#crfentityextractor) と [ダイエットクラシファイア](./components.md#ダイエットクラシファイア)成分!
    
*   **構成**
    
    `case_sensitive: False` オプションを追加して、特徴付けライザーの大文字と小文字を区別しないようにします (既定値は `case_sensitive: 本当です`。
    
    単語の区切りに空白を使用しない中国語などの言語を正しく処理するには、ユーザーは `use_word_boundaries: False` オプションを追加する必要があります (既定値は `use_word_boundaries: True`) です。
    
    ```yaml-rasa
    pipeline:
    - name: "RegexFeaturizer"
      # Text will be processed with case sensitive as default
      "case_sensitive": True
      # use match word boundaries for lookup table
      "use_word_boundaries": True
    ```
    
    **増分トレーニングの構成**
    
    [[command-line-interface#段階的なトレーニング|段階的なトレーニング]] 中に`sparse_features`が固定サイズになるようにするには、将来トレーニング データに追加される可能性のある追加のパターンを考慮してコンポーネントを構成する必要があります。これを行うには、`number_additional_patterns` パラメータを呼び出します。
    
    ```yaml-rasa
    pipeline:
    - name: RegexFeaturizer
      number_additional_patterns: 10
    ```
    
    ユーザーが設定していない場合、コンポーネントはトレーニングデータに現在存在するパターン数の 2 倍(ルックアップテーブルや正規表現パターンを含む)を`number_additional_patterns`のデフォルト値として使用します。この数は、増分トレーニング中に新しいパターンの追加スロットが頻繁に不足しないように、最低 10 に保たれます。コンポーネントに追加のパターン スロットがなくなると、新しいパターンは削除され、特徴付け中に考慮されません。この時点で、新しいモデルを最初から再トレーニングすることをお勧めします。
    

### CountVectorsFeaturizer

*   **短い**
    
    ユーザー メッセージ、インテント、および応答の単語の表現を作成します。
    
*   **出力**
    
    ユーザー メッセージ、インテント、応答の`sparse_features`
    
*   **必要**
    
    `tokens`
    
*   **種類**
    
    スパース特徴付け器
    
*   **形容**
    
    インテント分類と応答選択のための機能を作成します。 を使用して、ユーザーメッセージ、意図、応答の単語の袋状表現を作成します。 [sklearnのCountVectorizer](https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.CountVectorizer.html)。数字のみで構成されるすべてのトークン (たとえば、123 と 99 は a123d ではない) は、同じ特徴量に割り当てられます。
    
*   **構成**
    
    [sklearnのCountVectorizer](https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.CountVectorizer.html)ドキュメントを参照してください 設定パラメータの詳細については、を参照してください。
    
    この特徴付け器は、`アナライザー`構成パラメーターを使用して、単語または文字の n-gram を使用するように構成できます。既定では、`アナライザー`は`単語`に設定されているため、単語トークン数が機能として使用されます。文字 n-gram を使用する場合は、`analyzer` を `char` または `char_wb` に設定します。n-gramの下限と上限は、パラメータ`min_ngram`と`max_ngram`を使用して構成できます。デフォルトでは、両方とも `1` に設定されています。既定では、特徴付け器は、単語が使用可能な場合は、単語の代わりに単語の補題を直接受け取ります。単語の補題は、現在 [SpacyTokenizer](./components.md#SpacyFeaturizer) によってのみ設定されます。この動作を無効にするには、`use_lemma`を `False` に設定します。
    
    > [!note] note オプション `char_wb` は、単語境界内のテキストからのみ文字 n-gram を作成します。単語の端にある n-gram にはスペースが埋め込まれています。このオプションを使用して、[サブワード セマンティック ハッシュ](https://arxiv.org/abs/1810.07150)を作成できます。
    
    > [!note] 注: 文字 n-gram の場合は、`min_ngram` パラメータと `max_ngram` パラメータを増やすことを忘れないでください。そうしないと、語彙には 1 文字しか含まれません。
    
    語彙外 (OOV) 単語の処理:
    
    > [!note] 注: `アナライザー`が `word` の場合にのみ有効になります。
    
    トレーニングは限られた語彙データで実行されるため、予測中にアルゴリズムが未知の単語(トレーニング中に見られなかった単語)に遭遇しないことを保証することはできません。未知の単語の処理方法をアルゴリズムに教えるために、トレーニング データ内の一部の単語を一般的な単語`OOV_token`に置き換えることができます。この場合、予測中は、すべての未知の単語がこの一般的な単語`OOV_token`として扱われます。
    
    たとえば、トレーニングデータに、異なる`数の`メッセージと、いくつかの追加の一般的な単語を含む、`範囲外`の別のインテントを作成できますOOV_token。その後、アルゴリズムは、未知の単語を含むメッセージをこのインテントの範囲`外`として分類する可能性があります。
    
    `OOV_token`または単語のリストを`OOV_words`設定できます。
    
    *   `OOV_token`、目に見えない単語のキーワードを設定します。トレーニングデータに一部のメッセージで単語として`OOV_token`が含まれている場合、予測中にトレーニング中に表示されなかった単語は提供された`OOV_token`に置き換えられます。`OOV_token=None` (既定の動作) の場合、トレーニング中に表示されなかった単語は、予測時間中に無視されます。
        
    *   `OOV_words`トレーニング中に`OOV_token`として扱われる単語のリストを設定します。Out-Of-Vocabulary として扱う単語のリストがわかっている場合は、トレーニング データで手動で変更したり、カスタム プリプロセッサを使用したりする代わりに、`OOV_words` に設定できます。
        
    
    > [!note] 注 この特徴付け器は、単語**を数えること**によって単語のバッグ表現を作成するため、文内の`OOV_token`の数が重要になる場合があります。
    
    > [!note] 注 `OOV_words` はオプションであり、トレーニング データには手動またはカスタムの追加プリプロセッサによって`入力OOV_token`を含めることができます。未確認の単語は、このトークンがトレーニング データに存在するか、`OOV_words` リストが提供されている**場合にのみ、**`OOV_token`に置き換えられます。
    
    ユーザーメッセージとインテントの間で語彙を共有する場合は、オプションを設定する必要があります `True` に`use_shared_vocab`します。その場合、インテント内のトークンとユーザーメッセージの間に共通のボキャブラリセットが構築されます。
    
    ```yaml-rasa
    pipeline:
    - name: "CountVectorsFeaturizer"
      # Analyzer to use, either 'word', 'char', or 'char_wb'
      "analyzer": "word"
      # Set the lower and upper boundaries for the n-grams
      "min_ngram": 1
      "max_ngram": 1
      # Set the out-of-vocabulary token
      "OOV_token": "_oov_"
      # Whether to use a shared vocab
      "use_shared_vocab": False
    ```
    
    **増分トレーニングの構成**
    
    [[command-line-interface#段階的なトレーニング|段階的なトレーニング]] 中に`sparse_features`のサイズが固定されるようにするには、将来新しいトレーニング例の一部として追加される可能性のある追加のボキャブラリートークンを考慮してコンポーネントを構成する必要があります。これを行うには、ベースモデルを最初からトレーニングしながら`additional_vocabulary_size`パラメーターを設定します。
    
    ```yaml-rasa
    pipeline:
    - name: CountVectorsFeaturizer
      additional_vocabulary_size:
        text: 1000
        response: 1000
        action_text: 1000
    ```
    
    上記の例のように、それぞれに追加のボキャブラリーサイズを定義できます。 `テキスト` (ユーザーメッセージ)、`応答` (`ResponseSelector` で使用されるボット応答)、および `action_text` (`ResponseSelector` によって使用されないボット応答)。共有ボキャブラリー (`use_shared_vocab=True`) を作成する場合は、`text` 属性の値を定義するだけで済みます。属性のいずれかがユーザーによって構成されていない場合、コンポーネントは現在のボキャブラリー サイズの半分を属性の`additional_vocabulary_size`のデフォルト値として取ります。この数は、増分トレーニング中に追加の語彙スロットが頻繁に不足しないように、最低 1000 に保たれます。コンポーネントに追加のボキャブラリ スロットがなくなると、新しいボキャブラリ トークンは削除され、特徴付け中に考慮されません。この時点で、新しいモデルを最初から再トレーニングすることをお勧めします。
    
    上記の構成パラメーターは、モデルをデータに適合させるために構成する必要があるパラメーターです。ただし、適応できる追加のパラメーターが存在します。
    
    より多くの設定可能なパラメータ
    
```
+---------------------------+-------------------------+--------------------------------------------------------------+
| Parameter                 | Default Value           | Description                                                  |
+===========================+=========================+==============================================================+
| use_shared_vocab          | False                   | If set to 'True' a common vocabulary is used for labels      |
|                           |                         | and user message.                                            |
+---------------------------+-------------------------+--------------------------------------------------------------+
| analyzer                  | word                    | Whether the features should be made of word n-gram or        |
|                           |                         | character n-grams. Option 'char_wb' creates character        |
|                           |                         | n-grams only from text inside word boundaries;               |
|                           |                         | n-grams at the edges of words are padded with space.         |
|                           |                         | Valid values: 'word', 'char', 'char_wb'.                     |
+---------------------------+-------------------------+--------------------------------------------------------------+
| strip_accents             | None                    | Remove accents during the pre-processing step.               |
|                           |                         | Valid values: 'ascii', 'unicode', 'None'.                    |
+---------------------------+-------------------------+--------------------------------------------------------------+
| stop_words                | None                    | A list of stop words to use.                                 |
|                           |                         | Valid values: 'english' (uses an internal list of            |
|                           |                         | English stop words), a list of custom stop words, or         |
|                           |                         | 'None'.                                                      |
+---------------------------+-------------------------+--------------------------------------------------------------+
| min_df                    | 1                       | When building the vocabulary ignore terms that have a        |
|                           |                         | document frequency strictly lower than the given threshold.  |
+---------------------------+-------------------------+--------------------------------------------------------------+
| max_df                    | 1                       | When building the vocabulary ignore terms that have a        |
|                           |                         | document frequency strictly higher than the given threshold  |
|                           |                         | (corpus-specific stop words).                                |
+---------------------------+-------------------------+--------------------------------------------------------------+
| min_ngram                 | 1                       | The lower boundary of the range of n-values for different    |
|                           |                         | word n-grams or char n-grams to be extracted.                |
+---------------------------+-------------------------+--------------------------------------------------------------+
| max_ngram                 | 1                       | The upper boundary of the range of n-values for different    |
|                           |                         | word n-grams or char n-grams to be extracted.                |
+---------------------------+-------------------------+--------------------------------------------------------------+
| max_features              | None                    | If not 'None', build a vocabulary that only consider the top |
|                           |                         | max_features ordered by term frequency across the corpus.    |
+---------------------------+-------------------------+--------------------------------------------------------------+
| lowercase                 | True                    | Convert all characters to lowercase before tokenizing.       |
+---------------------------+-------------------------+--------------------------------------------------------------+
| OOV_token                 | None                    | Keyword for unseen words.                                    |
+---------------------------+-------------------------+--------------------------------------------------------------+
| OOV_words                 | []                      | List of words to be treated as 'OOV_token' during training.  |
+---------------------------+-------------------------+--------------------------------------------------------------+
| alias                     | CountVectorFeaturizer   | Alias name of featurizer.                                    |
+---------------------------+-------------------------+--------------------------------------------------------------+
| use_lemma                 | True                    | Use the lemma of words for featurization.                    |
+---------------------------+-------------------------+--------------------------------------------------------------+
| additional_vocabulary_size| text: 1000              | Size of additional vocabulary to account for incremental     |
|                           | response: 1000          | training while training a model from scratch                 |
|                           | action_text: 1000       |                                                              |
+---------------------------+-------------------------+--------------------------------------------------------------+
```



### LexicalSyntacticFeaturizer
*   **短い**

エンティティ抽出をサポートするために、ユーザー メッセージの字句機能と構文機能を作成します。

*   **出力**

ユーザーメッセージの`sparse_features`

*   **必要**

`tokens`

*   **種類**

スパース特徴付け器

*   **形容**

エンティティ抽出の特徴を作成します。ユーザーメッセージ内のすべてのトークンをスライディングウィンドウで移動し、構成に従って機能を作成します(以下を参照)。既定の設定が存在するため、設定を指定する必要はありません。

*   **構成**

特徴付け器が抽出する字句機能と構文機能の種類を構成できます。次の機能を使用できます。


```

============== ========================================================================================== フィーチャー名 説明 ============== ========================================================================================== BOS トークンが文の先頭にあるかどうかをチェックします。EOS トークンが文の最後にあるかどうかをチェックします。low トークンが小文字であるかどうかをチェックします。upper トークンが大文字であるかどうかをチェックします。title トークンが大文字で始まり、残りの文字はすべて小文字であるかどうかをチェックします。digit トークンに数字のみが含まれているかどうかをチェックします。prefix5 トークンの最初の 5 文字を取ります。prefix2 トークンの最初の 2 文字を取ります。suffix5 トークンの最後の 5 文字を取ります。suffix3 トークンの最後の 3 文字を取ります。suffix2 トークンの最後の 2 文字を取ります。suffix1 トークンの最後の文字を取ります。pos トークンの Part-of-Speech タグを取得します (`SpacyTokenizer` が必要)。pos2 トークンの品詞タグの最初の 2 文字を取ります (`SpacyTokenizer` が必要)。============== ==========================================================================================

````

フィーチャライザーがスライディング ウィンドウを使用してユーザー メッセージ内のトークン上を移動するときに、スライディング ウィンドウ内の前のトークン、現在のトークン、および次のトークンの機能を定義できます。特徴量を [before, token, after] 配列として定義します。前のトークン、現在のトークン、および後のトークンの機能を定義する場合、機能構成は次のようになります。

```yaml-rasa
pipeline:
- name: LexicalSyntacticFeaturizer
  "features": [
    ["low", "title", "upper"],
    ["BOS", "EOS", "low", "upper", "title", "digit"],
    ["low", "title", "upper"],
  ]
````

この構成は、既定の構成でもあります。

> [!note] 
> 注: `pos` または `pos2` を利用する場合は、`パイプラインに SpacyTokenizer` を追加する必要があります。

## インテント分類子

インテント分類子は、ドメイン ファイルで定義されているインテントの 1 つを受信ユーザー メッセージに割り当てます。

### MitieIntentClassifier

*   **短い**
    
    MITIE インテント分類子 ( [(テキスト カテゴライザー](https://github.com/mit-nlp/MITIE/blob/master/examples/python/text_categorizer_pure_model.py))
    
*   **出力**
    
    `intent`
    
*   **必要**
    
    ユーザーメッセージと[ミティエNLP](./components.md#ミティエNLP)の`トークン`
    
*   **出力例**
    
    ```json
    {
        "intent": {"name": "greet", "confidence": 0.98343}
    }
    ```
    
*   **形容**
    
    この分類子は、MITIE を使用してインテント分類を実行します。基礎となる分類子は、スパース線形カーネルを持つマルチクラス線形SVMを使用しています( `train_text_categorizer_classifier` [MITIEトレーナーコード](https://github.com/mit-nlp/MITIE/blob/master/mitielib/src/text_categorizer_trainer.cpp))。
    

> [!note] 注 この分類子は、特徴量を独自に抽出するため、特徴付け器に依存しません。

*   **構成**
    
    ```yaml-rasa
    pipeline:
    - name: "MitieIntentClassifier"
    ```
    

### LogisticRegressionClassifier (ロジスティック回帰分類子)

*   **短い**
    
    [scikit-learn 実装](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html)を使用したロジスティック回帰意図分類器。
    
*   **出力**
    
    `意図`と`intent_ranking`
    
*   **必要**
    
    `sparse_features`か`dense_features`のいずれかが存在する必要があります。
    
*   **出力例**
    

```json
{
    "intent": {"name": "greet", "confidence": 0.780},
    "intent_ranking": [
        {
            "confidence": 0.780,
            "name": "greet"
        },
        {
            "confidence": 0.140,
            "name": "goodbye"
        },
        {
            "confidence": 0.080,
            "name": "restaurant_search"
        }
    ]
}
```

*   **形容**
    
    この分類子は、scikit-learnのロジスティック回帰実装を使用して、インテント分類を実行します。スパースな特徴のみを使用できますが、存在する高密度の特徴も取得します。一般に、DIETはより高い精度の結果をもたらすはずですが、この分類器はより高速にトレーニングする必要があり、軽量のベンチマークとして使用できます。この実装では、scikit-learnの基本設定を使用しますが、「`バランス」`設定を想定する`class_weight`パラメータを除きます。
    
*   **構成**
    

すべてのデフォルトを含む設定例を以下に示します。

```yaml
pipeline:
- name: LogisticRegressionClassifier
  max_iter: 100
  solver: lbfgs
  tol: 0.0001
  random_state: 42
  ranking_length: 10
```

設定パラメータについては、以下で簡単に説明します。

*   `max_iter`: ソルバーが収束するまでにかかる最大反復回数。
*   `solver`: 使用するソルバー。非常に小さなデータセットの場合は、`liblinear`を検討できます。
*   `tol`: オプティマイザの停止基準の許容誤差。
*   `random_state`: トレーニング前にデータをシャッフルするために使用されます。
*   `ranking_length`: レポートする上位のインテントの数。すべてのインテントを報告するには 0 に設定します

パラメーターの詳細については、[scikit-learn のドキュメント ページ](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html)を参照してください。

### SklearnIntentClassifier

*   **短い**
    
    Sklearnインテント分類器
    
*   **出力**
    
    `意図`と`intent_ranking`
    
*   **必要**
    
    ユーザーメッセージの`dense_features`
    
*   **出力例**
    
    ```json
    {
        "intent": {"name": "greet", "confidence": 0.7800},
        "intent_ranking": [
            {
                "confidence": 0.7800,
                "name": "greet"
            },
            {
                "confidence": 0.1400,
                "name": "goodbye"
            },
            {
                "confidence": 0.0800,
                "name": "restaurant_search"
            }
        ]
    }
    ```
    
*   **形容**
    
    sklearn インテント分類器は、グリッド検索を使用して最適化される線形 SVM をトレーニングします。また、「勝てなかった」レーベルのランキングも提供します。`SklearnIntentClassifier` の前に、密な パイプラインのフィーチャライザー。この高密度特徴付け器は、分類に使用される特徴を作成します。 アルゴリズム自体の詳細については、 [グリッド検索CV](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GridSearchCV.html) ドキュメンテーション。
    
*   **構成**
    
    SVM のトレーニング中に、ハイパーパラメータ検索が実行され、最適なパラメータセットが見つかります。構成では、試行されるパラメーターを指定できます。
    
    ```yaml-rasa
    pipeline:
    - name: "SklearnIntentClassifier"
      # Specifies the list of regularization values to
      # cross-validate over for C-SVM.
      # This is used with the ``kernel`` hyperparameter in GridSearchCV.
      C: [1, 2, 5, 10, 20, 100]
      # Specifies the kernel to use with C-SVM.
      # This is used with the ``C`` hyperparameter in GridSearchCV.
      kernels: ["linear"]
      # Gamma parameter of the C-SVM.
      "gamma": [0.1]
      # We try to find a good number of cross folds to use during
      # intent training, this specifies the max number of folds.
      "max_cross_validation_folds": 5
      # Scoring function used for evaluating the hyper parameters.
      # This can be a name or a function.
      "scoring_function": "f1_weighted"
    ```
    

### キーワードインテント分類子

*   **短い**
    
    小規模で短期的なプロジェクトを対象としたシンプルなキーワードマッチングインテント分類器。
    
*   **出力**
    
    `intent`
    
*   **必要**
    
    何もない
    
*   **出力例**
    
    ```json
    {
        "intent": {"name": "greet", "confidence": 1.0}
    }
    ```
    
*   **形容**
    
    この分類子は、メッセージでキーワードを検索することで機能します。この照合ではデフォルトで大文字と小文字が区別され、ユーザー・メッセージ内のキーワード・ストリングの完全一致のみが検索されます。インテントのキーワードは、NLU トレーニングデータ内のそのインテントの例です。これは、例全体のキーワードであり、例内の個々の単語ではないことを意味します。
    

> [!note] 注: この分類子は、小規模なプロジェクトまたは開始プロジェクトのみを対象としています。NLU トレーニング データが少ない場合は、[モデルのチューニングで](./tuning-your-model.md)推奨されるパイプラインを確認できます。

*   **構成**
    
    ```yaml-rasa
    pipeline:
    - name: "KeywordIntentClassifier"
      case_sensitive: True
    ```
    

### DIETClassifier

*   **短い**
    
    インテント分類とエンティティ抽出に使用されるデュアルインテントエンティティトランスフォーマー(DIET)
    
*   **出力**
    
    `エンティティ`、`インテント`、`intent_ranking`
    
*   **必要**
    
    ユーザーメッセージとオプションでインテントの`dense_features`や`sparse_features`
    
*   **出力例**
    
    ```json
    {
        "intent": {"name": "greet", "confidence": 0.7800},
        "intent_ranking": [
            {
                "confidence": 0.7800,
                "name": "greet"
            },
            {
                "confidence": 0.1400,
                "name": "goodbye"
            },
            {
                "confidence": 0.0800,
                "name": "restaurant_search"
            }
        ],
        "entities": [{
            "end": 53,
            "entity": "time",
            "start": 48,
            "value": "2017-04-10T00:00:00.000+02:00",
            "confidence": 1.0,
            "extractor": "DIETClassifier"
        }]
    }
    ```
    
*   **形容**
    
    DIET (Dual Intent and Entity Transformer) は、インテント分類とエンティティ認識のためのマルチタスクアーキテクチャです。アーキテクチャは、両方のタスクで共有されるトランスフォーマーに基づいています。エンティティ ラベルのシーケンスは、トークンの入力シーケンスに対応するトランスフォーマー出力シーケンスの上にある条件付きランダム フィールド (CRF) タグ付けレイヤーを介して予測されます。インテントラベルの場合、完全な発話とインテントラベルのトランスフォーマー出力は、単一のセマンティックベクトル空間に埋め込まれます。ドット積損失を使用して、ターゲットラベルとの類似性を最大化し、ネガティブサンプルとの類似性を最小化します。
    
    DIET は、事前トレーニング済みの単語埋め込みや事前トレーニング済みの言語モデルを提供しませんが、次の場合にこれらの機能を使用できます。 これらはパイプラインに追加されます。モデルについて詳しく知りたい場合は、 YouTubeの[アルゴリズムホワイトボード](https://www.youtube.com/playlist?list=PL75e0qA87dlG-za8eLI6t0_Pbxafk-cxb)シリーズでは、モデルアーキテクチャを詳しく説明しています。
    
    > [!note] 注: 予測時間中にメッセージにトレーニング中に見られなかった単語**のみ**が含まれ、Out-Of-Vocabulary プリプロセッサが使用されていない場合、空のインテント `None` が信頼度 `0.0` で予測されます。これは、`単語`アナライザーを特徴付け器として [CountVectorsFeaturizer](./components.md#countvectorsfeaturizer) のみ使用する場合に発生する可能性があります。`char_wb` アナライザーを使用する場合は、常に信頼度値 `> 0.0` の意図を取得する必要があります。
    
*   **構成**
    
    インテント分類のみに `DIETClassifier` を使用する場合は、`entity_recognition` を `False` に設定します。エンティティ認識のみを行う場合は、`intent_classification` を `False` に設定します。デフォルトでは、`DIETClassifier`は両方を行い、`つまりentity_recognition`と`intent_classification`は `本当です`。
    
    モデルを適応させるために、いくつかのハイパーパラメータを定義できます。モデルを適応させる場合は、まず次のパラメーターを変更します。
    
    *   `epochs`: このパラメータは、アルゴリズムがトレーニングデータを表示する回数を設定します (デフォルト: `300`)。1 `エポック`は、すべてのトレーニング例の 1 つのフォワードパスと 1 つのバックワードパスに相当します。モデルが適切に学習するには、より多くのエポックが必要な場合があります。エポックが増してもパフォーマンスに影響を与えない場合があります。エポック数が少ないほど、モデルのトレーニングが速くなります。
        
    *   `hidden_layers_sizes`: このパラメーターを使用すると、ユーザーメッセージとインテントのフィードフォワードレイヤーの数とその出力ディメンションを定義できます(デフォルト:`テキスト:[]、ラベル:[]`)。リスト内のすべてのエントリは、フィードフォワード層に対応します。たとえば、`テキスト [256, 128]` を設定すると、トランスフォーマーの前に 2 つのフィードフォワード レイヤーが追加されます。入力トークンのベクトル(ユーザーメッセージから来る)は、これらのレイヤーに渡されます。最初のレイヤーの出力寸法は 256 で、2 番目のレイヤーの出力寸法は 128 になります。空のリストが使用されている場合(デフォルトの動作)、フィードフォワードレイヤーは追加されません。正の整数値のみを使用してください。通常、2の累乗数が使用されます。また、リスト内の値は減少するのが通常行われています:次の値は前の値より小さいか等しいです。
        
    *   `embedding_dimension`: このパラメータは、モデル内で使用される埋め込みレイヤーの出力寸法を定義します(デフォルト: `20`)。モデルアーキテクチャ内で複数の埋め込みレイヤーを使用しています。たとえば、完全な発話とインテントのベクトルは、比較されて損失が計算される前に埋め込みレイヤーに渡されます。
        
    *   `number_of_transformer_layers`: このパラメータは、使用するトランスフォーマー レイヤーの数を設定します (既定値: `2`)。トランスフォーマー レイヤーの数は、モデルに使用するトランスフォーマー ブロックに対応します。
        
    *   `transformer_size`: このパラメータは、トランスのユニット数を設定します(デフォルト:`256`)。トランスフォーマーから出てくるベクトルは、指定された`transformer_size`を持ちます。`transformer_size`は`number_of_attention_heads`パラメータの倍数である必要があり、それ以外の場合はエラーでトレーニングが終了します。
        
    *   `connection_density`: このパラメータは、モデル内のすべてのフィードフォワード層(デフォルト:`0.2`)に対してゼロ以外の値に設定されたカーネル重みの割合を定義します。値は 0 から 1 の間である必要があります。`connection_density` 1に設定すると、カーネルの重みは0に設定されず、レイヤーは標準のフィードフォワードレイヤーとして機能します。あなたはすべきではありません `connection_density` を 0 に設定すると、すべてのカーネルの重みが 0 になり、モデルが学習できなくなります。
        
    *   `constrain_similarities`: このパラメータを `True` に設定すると、すべての類似性項にシグモイド クロス エントロピー損失が適用されます。これは、入力ラベルと負のラベルの類似性をより小さな値に保つのに役立ちます。これは、モデルを実際のテストセットに一般化するのに役立つはずです。
        
    *   `model_confidence`: このパラメーターを使用すると、ユーザーは推論中に信頼度を計算する方法を構成できます。入力として受け取ることができる値は `softmax`[1](#user-content-fn-1) の 1 つだけです。`softmax`では、信頼度は`[0, 1]`の範囲です。計算された類似性は、`softmax`活性化関数で正規化されます。
        
    
    上記の構成パラメーターは、モデルをデータに適合させるために構成する必要があるパラメーターです。ただし、適応できる追加のパラメーターが存在します。
    
    より多くの設定可能なパラメータ
    

```
+---------------------------------+------------------+--------------------------------------------------------------+
| Parameter                       | Default Value    | Description                                                  |
+=================================+==================+==============================================================+
| hidden_layers_sizes             | text: []         | Hidden layer sizes for layers before the embedding layers    |
|                                 | label: []        | for user messages and labels. The number of hidden layers is |
|                                 |                  | equal to the length of the corresponding list.               |
+---------------------------------+------------------+--------------------------------------------------------------+
| share_hidden_layers             | False            | Whether to share the hidden layer weights between user       |
|                                 |                  | messages and labels.                                         |
+---------------------------------+------------------+--------------------------------------------------------------+
| transformer_size                | 256              | Number of units in transformer.                              |
+---------------------------------+------------------+--------------------------------------------------------------+
| number_of_transformer_layers    | 2                | Number of transformer layers.                                |
+---------------------------------+------------------+--------------------------------------------------------------+
| number_of_attention_heads       | 4                | Number of attention heads in transformer.                    |
+---------------------------------+------------------+--------------------------------------------------------------+
| use_key_relative_attention      | False            | If 'True' use key relative embeddings in attention.          |
+---------------------------------+------------------+--------------------------------------------------------------+
| use_value_relative_attention    | False            | If 'True' use value relative embeddings in attention.        |
+---------------------------------+------------------+--------------------------------------------------------------+
| max_relative_position           | None             | Maximum position for relative embeddings.                    |
+---------------------------------+------------------+--------------------------------------------------------------+
| unidirectional_encoder          | False            | Use a unidirectional or bidirectional encoder.               |
+---------------------------------+------------------+--------------------------------------------------------------+
| batch_size                      | [64, 256]        | Initial and final value for batch sizes.                     |
|                                 |                  | Batch size will be linearly increased for each epoch.        |
|                                 |                  | If constant `batch_size` is required, pass an int, e.g. `8`. |
+---------------------------------+------------------+--------------------------------------------------------------+
| batch_strategy                  | "balanced"       | Strategy used when creating batches.                         |
|                                 |                  | Can be either 'sequence' or 'balanced'.                      |
+---------------------------------+------------------+--------------------------------------------------------------+
| epochs                          | 300              | Number of epochs to train.                                   |
+---------------------------------+------------------+--------------------------------------------------------------+
| random_seed                     | None             | Set random seed to any 'int' to get reproducible results.    |
+---------------------------------+------------------+--------------------------------------------------------------+
| learning_rate                   | 0.001            | Initial learning rate for the optimizer.                     |
+---------------------------------+------------------+--------------------------------------------------------------+
| embedding_dimension             | 20               | Dimension size of embedding vectors.                         |
+---------------------------------+------------------+--------------------------------------------------------------+
| dense_dimension                 | text: 128        | Dense dimension for sparse features to use.                  |
|                                 | label: 20        |                                                              |
+---------------------------------+------------------+--------------------------------------------------------------+
| concat_dimension                | text: 128        | Concat dimension for sequence and sentence features.         |
|                                 | label: 20        |                                                              |
+---------------------------------+------------------+--------------------------------------------------------------+
| number_of_negative_examples     | 20               | The number of incorrect labels. The algorithm will minimize  |
|                                 |                  | their similarity to the user input during training.          |
+---------------------------------+------------------+--------------------------------------------------------------+
| similarity_type                 | "auto"           | Type of similarity measure to use, either 'auto' or 'cosine' |
|                                 |                  | or 'inner'.                                                  |
+---------------------------------+------------------+--------------------------------------------------------------+
| loss_type                       | "cross_entropy"  | The type of the loss function, either 'cross_entropy'        |
|                                 |                  | or 'margin'. If type 'margin' is specified,                  |
|                                 |                  | "model_confidence=cosine" will be used which is deprecated   |
|                                 |                  | as of 2.3.4. See footnote (1).                               |
+---------------------------------+------------------+--------------------------------------------------------------+
| ranking_length                  | 10               | Number of top intents to report. Set to 0 to report all      |
|                                 |                  | intents.                                                     |
+---------------------------------+------------------+--------------------------------------------------------------+
| renormalize_confidences         | False            | Normalize the reported top intents. Applicable only with loss|
|                                 |                  | type 'cross_entropy' and 'softmax' confidences.              |
+---------------------------------+------------------+--------------------------------------------------------------+
| maximum_positive_similarity     | 0.8              | Indicates how similar the algorithm should try to make       |
|                                 |                  | embedding vectors for correct labels.                        |
|                                 |                  | Should be 0.0 < ... < 1.0 for 'cosine' similarity type.      |
+---------------------------------+------------------+--------------------------------------------------------------+
| maximum_negative_similarity     | -0.4             | Maximum negative similarity for incorrect labels.            |
|                                 |                  | Should be -1.0 < ... < 1.0 for 'cosine' similarity type.     |
+---------------------------------+------------------+--------------------------------------------------------------+
| use_maximum_negative_similarity | True             | If 'True' the algorithm only minimizes maximum similarity    |
|                                 |                  | over incorrect intent labels, used only if 'loss_type' is    |
|                                 |                  | set to 'margin'.                                             |
+---------------------------------+------------------+--------------------------------------------------------------+
| scale_loss                      | False            | Scale loss inverse proportionally to confidence of correct   |
|                                 |                  | prediction.                                                  |
+---------------------------------+------------------+--------------------------------------------------------------+
| regularization_constant         | 0.002            | The scale of regularization.                                 |
+---------------------------------+------------------+--------------------------------------------------------------+
| negative_margin_scale           | 0.8              | The scale of how important it is to minimize the maximum     |
|                                 |                  | similarity between embeddings of different labels.           |
+---------------------------------+------------------+--------------------------------------------------------------+
| connection_density              | 0.2              | Connection density of the weights in dense layers.           |
|                                 |                  | Value should be between 0 and 1.                             |
+---------------------------------+------------------+--------------------------------------------------------------+
| drop_rate                       | 0.2              | Dropout rate for encoder. Value should be between 0 and 1.   |
|                                 |                  | The higher the value the higher the regularization effect.   |
+---------------------------------+------------------+--------------------------------------------------------------+
| drop_rate_attention             | 0.0              | Dropout rate for attention. Value should be between 0 and 1. |
|                                 |                  | The higher the value the higher the regularization effect.   |
+---------------------------------+------------------+--------------------------------------------------------------+
| use_sparse_input_dropout        | True             | If 'True' apply dropout to sparse input tensors.             |
+---------------------------------+------------------+--------------------------------------------------------------+
| use_dense_input_dropout         | True             | If 'True' apply dropout to dense input tensors.              |
+---------------------------------+------------------+--------------------------------------------------------------+
| evaluate_every_number_of_epochs | 20               | How often to calculate validation accuracy.                  |
|                                 |                  | Set to '-1' to evaluate just once at the end of training.    |
+---------------------------------+------------------+--------------------------------------------------------------+
| evaluate_on_number_of_examples  | 0                | How many examples to use for hold out validation set.        |
|                                 |                  | Large values may hurt performance, e.g. model accuracy.      |
+---------------------------------+------------------+--------------------------------------------------------------+
| intent_classification           | True             | If 'True' intent classification is trained and intents are   |
|                                 |                  | predicted.                                                   |
+---------------------------------+------------------+--------------------------------------------------------------+
| entity_recognition              | True             | If 'True' entity recognition is trained and entities are     |
|                                 |                  | extracted.                                                   |
+---------------------------------+------------------+--------------------------------------------------------------+
| use_masked_language_model       | False            | If 'True' random tokens of the input message will be masked  |
|                                 |                  | and the model has to predict those tokens. It acts like a    |
|                                 |                  | regularizer and should help to learn a better contextual     |
|                                 |                  | representation of the input.                                 |
+---------------------------------+------------------+--------------------------------------------------------------+
| tensorboard_log_directory       | None             | If you want to use tensorboard to visualize training         |
|                                 |                  | metrics, set this option to a valid output directory. You    |
|                                 |                  | can view the training metrics after training in tensorboard  |
|                                 |                  | via 'tensorboard --logdir <path-to-given-directory>'.        |
+---------------------------------+------------------+--------------------------------------------------------------+
| tensorboard_log_level           | "epoch"          | Define when training metrics for tensorboard should be       |
|                                 |                  | logged. Either after every epoch ('epoch') or for every      |
|                                 |                  | training step ('batch').                                 |
+---------------------------------+------------------+--------------------------------------------------------------+
| featurizers                     | []               | List of featurizer names (alias names). Only features        |
|                                 |                  | coming from the listed names are used. If list is empty      |
|                                 |                  | all available features are used.                             |
+---------------------------------+------------------+--------------------------------------------------------------+
| checkpoint_model                | False            | Save the best performing model during training. Models are   |
|                                 |                  | stored to the location specified by `--out`. Only the one    |
|                                 |                  | best model will be saved.                                    |
|                                 |                  | Requires `evaluate_on_number_of_examples > 0` and            |
|                                 |                  | `evaluate_every_number_of_epochs > 0`                        |
+---------------------------------+------------------+--------------------------------------------------------------+
| split_entities_by_comma         | True             | Splits a list of extracted entities by comma to treat each   |
|                                 |                  | one of them as a single entity. Can either be `True`/`False` |
|                                 |                  | globally, or set per entity type, such as:                   |
|                                 |                  | ```                                                          |
|                                 |                  | ...                                                          |
|                                 |                  | - name: DIETClassifier                                       |
|                                 |                  |   split_entities_by_comma:                                   |
|                                 |                  |     address: True                                            |
|                                 |                  |     ...                                                      |
|                                 |                  | ...                                                          |
|                                 |                  | ```                                                          |
+---------------------------------+------------------+--------------------------------------------------------------+
| constrain_similarities          | False            | If `True`, applies sigmoid on all similarity terms and adds  |
|                                 |                  | it to the loss function to ensure that similarity values are |
|                                 |                  | approximately bounded. Used only if `loss_type=cross_entropy`|
+---------------------------------+------------------+--------------------------------------------------------------+
| model_confidence                | "softmax"        | Affects how model's confidence for each intent               |
|                                 |                  | is computed. Currently, only one value is supported:         |
|                                 |                  | 1. `softmax` - Similarities between input and intent         |
|                                 |                  | embeddings are post-processed with a softmax function,       |
|                                 |                  | as a result of which confidence for all intents sum up to 1. |
|                                 |                  | This parameter does not affect the confidence for entity     |
|                                 |                  | prediction.                                                  |
+---------------------------------+------------------+--------------------------------------------------------------+
```

  >[!note] note
  >Parameter `maximum_negative_similarity` is set to a negative value to mimic the original starspace algorithm in the case `maximum_negative_similarity = maximum_positive_similarity` and `use_maximum_negative_similarity = False`. See [starspace paper](https://arxiv.org/abs/1709.03856) for details.
### フォールバック分類子

*   **短い**

NLU インテント分類スコアがあいまいな場合`nlu_fallback`インテントを使用してメッセージを分類します。信頼度は、`フォールバックしきい値`と同じに設定されます。

*   **出力**

`エンティティ`、`インテント`、`intent_ranking`

*   **必要**

`インテント`と、以前のインテント分類子からの`intent_ranking`出力

* **Output-Example**

  ```json

      {
          "intent": {"name": "nlu_fallback", "confidence": 0.7183846840434321},
          "intent_ranking": [
              {
                  "confidence": 0.7183846840434321,
                  "name": "nlu_fallback"
              },
              {
                  "confidence": 0.28161531595656784,
                  "name": "restaurant_search"
              }
          ],
          "entities": [{
              "end": 53,
              "entity": "time",
              "start": 48,
              "value": "2017-04-10T00:00:00.000+02:00",
              "confidence": 1.0,
              "extractor": "DIETClassifier"
          }]
      }
  ```

*   **形容**
    
    `FallbackClassifier` は、インテント `nlu_fallback` でユーザー メッセージを分類します。 前のインテント分類子が `しきい値`以上の信頼度でインテントを分類できる `FallbackClassifier` の。また、フォールバックの意図を予測することもできます。 上位 2 つのインテントの信頼度スコアが `ambiguity_threshold`。
    
    `FallbackClassifier` を使用して、 NLU 予測が不確実なメッセージを処理するフォー[ルバック アクション](./fallback-handoff.md#fallbacks)。

  ```yaml-rasa
  rules:

  - rule: Ask the user to rephrase in case of low NLU confidence
    steps:
    - intent: nlu_fallback
    - action: utter_please_rephrase
  ```
*   **構成**
    
    `FallbackClassifier` は、`nlu_fallback` の予測のみを追加します。 他のインテントが信頼度以上で予測されなかった場合のインテント `しきい値`よりも。
    
    *   `threshold`: このパラメータは、`nlu_fallback`インテントを予測するためのしきい値を設定します。前のインテント分類子によって予測されたインテントに、`しきい値`以上の信頼度レベルがない場合、`FallbackClassifier` は信頼度 `1.0` で`nlu_fallback`インテントの予測を追加します。
    *   `ambiguity_threshold`: `ambiguity_threshold`を設定すると、 `FallbackClassifier` は、最もランク付けされた 2 つのインテントの信頼度スコアの差が`ambiguity_threshold`よりも小さい場合に、`nlu_fallback`インテントも予測します。


## エンティティ抽出器

エンティティ抽出器は、ユーザーメッセージから個人名や場所などのエンティティを抽出します。

>[!note] note
>複数のエンティティ抽出器を使用する場合は、各抽出器がエンティティ型の排他的なセットを対象とすることをお勧めします。たとえば、日付と時刻を抽出するには [Duckling](components.md#ducklingentityextractor) を使用し、人名を抽出するには [[#DIETClassifier]] を使用します。そうしないと、複数の抽出器が同じエンティティ型を対象としている場合、エンティティが複数回抽出される可能性が非常に高いです。
> 
> たとえば、[MitieEntityExtractor](components.md#mitieentityextractor)、[[#DIETClassifier]]、[CRFEntityExtractor](components.md#crfentityextractor) などの 2 つ以上の汎用抽出ツールを使用する場合、トレーニング データ内のエンティティ型は、それらすべてによって検出され、抽出されます。エンティティ型で入力する[スロット](domain.md#スロット)が`テキスト`型の場合、パイプライン内の最後の抽出器が勝ちます。スロットが`リスト`タイプの場合、重複を含むすべての結果がリストに追加されます。
> 
> 抽出が異なるエンティティタイプに焦点を当てている場合でも、重複/重複抽出の別のあまり明白ではないケースが発生する可能性があります。フードデリバリーボットと `I would like to order the Monday special` 次のようなユーザーメッセージを想像してみてください。仮に、時間抽出器のパフォーマンスがあまり良くない場合、ここで`月曜日`を注文の時間として抽出し、他の抽出器が`月曜日の特別`日を食事として抽出する可能性があります。この種の重複するエンティティに苦労している場合は、抽出器を改善するためにトレーニング データを追加することが理にかなっている場合があります。それでも不十分な場合は、独自のロジックに従ってエンティティ抽出の競合を解決する[[#Custom コンポーネント]]を追加できます


### MitieEntityExtractor


*   **短い**

MITIE エンティティ抽出 ([MITIE NER トレーナー](https://github.com/mit-nlp/MITIE/blob/master/mitielib/src/ner_trainer.cpp)を使用)

*   **出力**

`entities`

*   **必要**

[MitieNLP](./components.md#mitienlp) と`トークン`



* **Output-Example**

```json
{
    "entities": [{
        "value": "New York City",
        "start": 20,
        "end": 33,
        "confidence": null,
        "entity": "city",
        "extractor": "MitieEntityExtractor"
    }]
}
````

*   **形容**
    
    `MitieEntityExtractor` は、MITIE エンティティ抽出を使用して、メッセージ内のエンティティを検索します。基礎となる分類器は、スパース線形カーネルとカスタム機能を備えたマルチクラス線形SVMを使用しています。MITIE コンポーネントは、エンティティの信頼度値を提供しません。
    
    > [!note] 注: このエンティティ抽出器は、特徴量を独自に抽出するため、特徴付け器に依存しません。
    
*   **構成**
    
    ```yaml-rasa
    pipeline:
    - name: "MitieEntityExtractor"
    ```
    

### SpacyEntityExtractor

*   **短い**
    
    spaCy エンティティ抽出
    
*   **出力**
    
    `entities`
    
*   **必要**
    
    [スペーシーNLP](./components.md#スペーシーNLP)
    
*   **出力例**
    
    ```json
    {
        "entities": [{
            "value": "New York City",
            "start": 20,
            "end": 33,
            "confidence": null,
            "entity": "city",
            "extractor": "SpacyEntityExtractor"
        }]
    }
    ```
    
*   **形容**
    
    このコンポーネントは、spaCy を使用して、メッセージのエンティティを予測します。spaCyは、統計的BILOU遷移モデルを使用します。現時点では、このコンポーネントは spaCy 組み込みエンティティ抽出モデルのみを使用でき、再トレーニングすることはできません。この抽出器は信頼度スコアを提供しません。
    
    この[インタラクティブなデモ](https://explosion.ai/demos/displacy-ent)では、spaCyのエンティティ抽出モデルをテストできます。一部の spaCy モデルでは、大文字と小文字が非常に区別されることに注意してください。
    

> [!note] 注: `SpacyEntityExtractor` エクストラクタは`信頼レベル`を提供せず、常に `null` を返します。

*   **構成**
    
    spaCyコンポーネントが抽出するディメンション(エンティティタイプ)を構成します。利用可能なディメンションの完全なリストは、[spaCyのドキュメント](https://spacy.io/api/annotation#section-named-entities)に記載されています。dimensionsオプションを指定しないままにすると、使用可能なすべてのディメンションが抽出されます。
    
    ```yaml-rasa
    pipeline:
    - name: "SpacyEntityExtractor"
      # dimensions to extract
      dimensions: ["PERSON", "LOC", "ORG", "PRODUCT"]
    ```
    

### CRFEntityExtractor

*   **短い**
    
    条件付きランダム フィールド (CRF) エンティティ抽出
    
*   **出力**
    
    `entities`
    
*   **必要**
    
    `トークン`と`dense_features` (オプション)
    
*   **出力例**
    
    ```json
    {
        "entities": [{
            "value": "New York City",
            "start": 20,
            "end": 33,
            "entity": "city",
            "confidence": 0.874,
            "extractor": "CRFEntityExtractor"
        }]
    }
    ```
    
*   **形容**
    
    このコンポーネントは、名前付きエンティティ認識を行うための条件付きランダム フィールド (CRF) を実装します。CRFは、時間ステップが単語であり、状態がエンティティクラスである無向マルコフ連鎖と考えることができます。単語の特徴(大文字と小文字、POSタグ付けなど)は、隣接するエンティティタグ間の遷移と同様に、特定のエンティティクラスに確率を与えます:次に、最も可能性の高いタグのセットが計算されて返されます。
    
    事前トレーニング済みの単語埋め込みなどのカスタム機能を `CRFEntityExtractor` に渡す場合は、`CRFEntityExtractor` の前にパイプラインに高密度特徴付け器を追加し、その後 `CRFEntityExtractor` を使用して、機能構成に `"text_dense_feature"` を追加することで、高密度機能を利用します。 `CRFEntityExtractor`は、追加の密な特徴を自動的に検出し、密な特徴が`len(tokens)`の反復可能であるかどうかをチェックします(各エントリはベクトルです)。チェックに失敗した場合に警告が表示されます。ただし、`CRFEntityExtractor` は、追加のカスタム機能なしでトレーニングを継続します。密な特徴が存在する場合、`CRFEntityExtractor`は密な特徴を`sklearn_crfsuite`に渡します トレーニングに使用します。
    
*   **構成**
    
    `CRFEntityExtractor` には、使用する既定の機能のリストがあります。ただし、デフォルト設定を上書きすることはできます。次の機能を使用できます。
    
    ```
    ===================  ==========================================================================================
    Feature Name         Description
    ===================  ==========================================================================================
    low                  word identity - use the lower-cased token as a feature.
    upper                Checks if the token is upper case.
    title                Checks if the token starts with an uppercase character and all remaining characters are
                         lowercased.
    digit                Checks if the token contains just digits.
    prefix5              Take the first five characters of the token.
    prefix2              Take the first two characters of the token.
    suffix5              Take the last five characters of the token.
    suffix3              Take the last three characters of the token.
    suffix2              Take the last two characters of the token.
    suffix1              Take the last character of the token.
    pos                  Take the Part-of-Speech tag of the token (``SpacyTokenizer`` required).
    pos2                 Take the first two characters of the Part-of-Speech tag of the token
                         (``SpacyTokenizer`` required).
    pattern              Take the patterns defined by ``RegexFeaturizer``.
    bias                 Add an additional "bias" feature to the list of features.
    text_dense_features  Adds additional features from a dense featurizer.
    ===================  ==========================================================================================
    ```
    
    フィーチャライザーがスライディング ウィンドウを使用してユーザー メッセージ内のトークン上を移動するときに、スライディング ウィンドウ内の前のトークン、現在のトークン、および次のトークンの機能を定義できます。特徴量を [before, token, after] 配列として定義します。
    
    さらに、BILOU タグ付けスキーマを使用するかどうかを決定するためのフラグを設定することもできます。
    
    *   `BILOU_flag` BILOU タグ付けを使用するかどうかを決定します。既定値は `True`。
    
    ```yaml-rasa
    pipeline:
    - name: "CRFEntityExtractor"
      # BILOU_flag determines whether to use BILOU tagging or not.
      "BILOU_flag": True
      # features to extract in the sliding window
      "features": [
        ["low", "title", "upper"],
        [
          "bias",
          "low",
          "prefix5",
          "prefix2",
          "suffix5",
          "suffix3",
          "suffix2",
          "upper",
          "title",
          "digit",
          "pattern",
          "text_dense_features"
        ],
        ["low", "title", "upper"],
      ]
      # The maximum number of iterations for optimization algorithms.
      "max_iterations": 50
      # weight of the L1 regularization
      "L1_c": 0.1
      # weight of the L2 regularization
      "L2_c": 0.1
      # Name of dense featurizers to use.
      # If list is empty all available dense features are used.
      "featurizers": []
      # Indicated whether a list of extracted entities should be split into individual entities for a given entity type
      "split_entities_by_comma":
          address: False
          email: True
    ```
    
    > [!note] 注 POS 機能 (`pos` または `pos2`) を使用する場合は、パイプラインに `SpacyTokenizer` が必要です。
    
    > [!note] 注 `パターン機能を使用する場合`は、パイプラインに `RegexFeaturizer` が必要です。
    
    > [!note] 注 `text_dense_features`機能を使用する場合は、パイプラインに高密度の特徴付け器 (`LanguageModelFeaturizer` など) が必要です。
    

### DucklingEntityExtractor

*   **短い**
    
    アヒルの子では、日付、金額、距離などの一般的なエンティティをさまざまな言語で抽出できます。
    
*   **出力**
    
    `entities`
    
*   **必要**
    
    何もない
    
*   **出力例**
    
    ```json
    {
        "entities": [{
            "end": 53,
            "entity": "time",
            "start": 48,
            "value": "2017-04-10T00:00:00.000+02:00",
            "confidence": 1.0,
            "extractor": "DucklingEntityExtractor"
        }]
    }
    ```
    
*   **形容**
    
    このコンポーネントを使用するには、アヒルの子サーバーを実行する必要があります。最も簡単な オプションは、 `docker run -p 8000:8000 rasa/duckling` .
    
    または、[duckling をマシンに直接インストール](https://github.com/facebook/duckling#quickstart)してサーバーを起動することもできます。
    
    アヒルの子は、日付、数字、距離、その他の構造化されたエンティティを認識し、それらを正規化することができます。duckling は、ランキングを提供せずに、できるだけ多くのエンティティ タイプを抽出しようとすることに注意してください。たとえば、アヒルの子コンポーネントのディメンションとして`数値`と`時間`の両方を指定すると、コンポーネントは数値として `10 と 10` の 2 つのエンティティを抽出します。 テキストから`10分`後の時間として、`10分で`着きます。このような状況では、アプリケーションはどのエンティティ型が正しいものかを決定する必要があります。抽出器はルールベースのシステムであるため、常に信頼度として 1.0 を返します。
    
    サポートされている言語のリストは、 [Duckling GitHub リポジトリ](https://github.com/facebook/duckling/tree/master/Duckling/Dimensions)。
    
*   **構成**
    
    アヒルの子コンポーネントが抽出するディメンション、つまりエンティティタイプを設定します。使用可能なディメンションの完全なリストは、[duckling プロジェクトの readme](https://github.com/facebook/duckling) にあります。dimensionsオプションを指定しないままにすると、使用可能なすべてのディメンションが抽出されます。
    
    ```yaml-rasa
    pipeline:
    - name: "DucklingEntityExtractor"
      # url of the running duckling server
      url: "http://localhost:8000"
      # dimensions to extract
      dimensions: ["time", "number", "amount-of-money", "distance"]
      # allows you to configure the locale, by default the language is
      # used
      locale: "de_DE"
      # if not set the default timezone of Duckling is going to be used
      # needed to calculate dates from relative expressions like "tomorrow"
      timezone: "Europe/Berlin"
      # Timeout for receiving response from http url of the running duckling server
      # if not set the default timeout of duckling http url is set to 3 seconds.
      timeout : 3
    ```
    

### ダイエットクラシファイア

*   **短い**
    
    インテント分類とエンティティ抽出に使用されるデュアルインテントエンティティトランスフォーマー(DIET)
    
*   **形容**
    
    [ミティエNLP](./components.md#ミティエNLP) の詳細な説明は、インテント分類子のセクションにあります。
    

### RegexEntityExtractor

*   **短い**
    
    トレーニングデータで定義されているルックアップテーブルや正規表現を使用してエンティティを抽出します
    
*   **出力**
    
    `entities`
    
*   **必要**
    
    何もない
    
*   **形容**
    
    このコンポーネントは、トレーニングデータで定義された [[nlu-training-data#ルックアップテーブル|ルックアップテーブル]] と [[nlu-training-data#Regular Expressions for Entity Extraction|regex]] を使用してエンティティを抽出します。コンポーネントは、ユーザーメッセージにルックアップテーブルの1つのエントリが含まれているか、正規表現の1つと一致するかをチェックします。一致するものが見つかった場合、値はエンティティとして抽出されます。
    
    このコンポーネントは、トレーニングデータで定義されているエンティティの 1 つと等しい名前を持つ正規表現特徴のみを使用します。エンティティごとに少なくとも 1 つの例に注釈を付けてください。
    
    > [!note] 注: この抽出器を [MitieEntityExtractor](components.md#mitieentityextractor)、[CRFEntityExtractor](components.md#crfentityextractor)、または [DIETClassifier](components.md#dietclassifier) と組み合わせて使用すると、エンティティが複数抽出される可能性があります。特に、多くのトレーニング文に、正規表現も定義したエンティティ型のエンティティアノテーションがある場合はなおさらです。複数の抽出の詳細については、[[#Entity Extractors]] の先頭にある大きな情報ボックスを参照してください。
    > 
    > この RegexEntityExtractor と前述の別の統計抽出ツールの両方が必要と思われる場合は、次の 2 つのオプションのいずれかを検討することをお勧めします。
    > 
    > オプション 1 は、抽出器の種類ごとに排他的エンティティ型がある場合に推奨されます。抽出器が互いに干渉しないようにするには、各regex / lookupエンティティ型に1つの例文のみに注釈を付け、それ以上は注釈を付けません。
    > 
    > オプション 2 は、正規表現の一致を統計抽出器の追加シグナルとして使用したいが、個別のエンティティ型がない場合に便利です。この場合、1) パイプライン内の抽出器の前に [RegexFeaturizer](components.md#regexfeaturizer) を追加し、2) トレーニング データ内のすべてのエンティティ例に注釈を付け、3) パイプラインから RegexEntityExtractor を削除します。このようにして、統計抽出器は正規表現の一致の存在に関する追加のシグナルを受信し、これらの一致に依存するタイミングと依存しないタイミングを統計的に判断できるようになります。
    
*   **構成**
    
    エンティティ抽出器の大文字と小文字を区別するには、`case_sensitive: True` オプションを追加して、デフォルトは `case_sensitive: False`です。
    
    単語の区切りに空白を使用しない中国語などの言語を正しく処理するには、ユーザーは `use_word_boundaries: False` オプションを追加する必要があります (既定値は `use_word_boundaries: True`) です。
    
    ```yaml-rasa
        pipeline:
        - name: RegexEntityExtractor
          # text will be processed with case insensitive as default
          case_sensitive: False
          # use lookup tables to extract entities
          use_lookup_tables: True
          # use regexes to extract entities
          use_regexes: True
          # use match word boundaries for lookup table
          use_word_boundaries: True
    ```
    

### EntitySynonymMapper (エンティティーシノニムマッパー)

*   **短い**
    
    同義エンティティ値を同じ値にマップします。
    
*   **出力**
    
    以前のエンティティ抽出コンポーネントが検出した既存のエンティティを変更します。
    
*   **必要**
    
    エンティティ抽出器からの抽出[器](./components.md)
    
*   **形容**
    
    トレーニング データに定義されたシノニムが含まれている場合、このコンポーネントは、検出されたエンティティ値が同じ値にマップされるようにします。たとえば、トレーニングデータに次の例が含まれているとします。
    
    ```json
    [
        {
          "text": "I moved to New York City",
          "intent": "inform_relocation",
          "entities": [{
            "value": "nyc",
            "start": 11,
            "end": 24,
            "entity": "city",
          }]
        },
        {
          "text": "I got a new flat in NYC.",
          "intent": "inform_relocation",
          "entities": [{
            "value": "nyc",
            "start": 20,
            "end": 23,
            "entity": "city",
          }]
        }
    ]
    ```
    
    このコンポーネントを使用すると、`エンティティ New York City` と `NYC` を `nyc` にマッピングできます。エンティティ抽出は、メッセージに `NYC` が含まれている場合でも `nyc` を返します。このコンポーネントは、既存のエンティティを変更すると、このエンティティのプロセッサリストに自身を追加します。
    
*   **構成**
    
    ```yaml-rasa
    pipeline:
    - name: "EntitySynonymMapper"
    ```
    
    > [!note] 注 `EntitySynonymMapper` を NLU パイプラインの一部として使用する場合は、構成ファイル内のエンティティ抽出器の下に配置する必要があります。
    
    ## インテント分類子とエンティティ抽出器の組み合わせ
    
    ### ダイエットクラシファイア
    
    *   **短い**
        
        インテント分類とエンティティ抽出に使用されるデュアルインテントエンティティトランスフォーマー(DIET)
        
    *   **出力**
        
        `エンティティ`、`インテント`、`intent_ranking`
        
    *   **必要**
        
        ユーザーメッセージとオプションでインテントの`dense_features`や`sparse_features`
        
    *   **出力例**
        
        ```json
        {
            "intent": {"name": "greet", "confidence": 0.7800},
            "intent_ranking": [
                {
                    "confidence": 0.7800,
                    "name": "greet"
                },
                {
                    "confidence": 0.1400,
                    "name": "goodbye"
                },
                {
                    "confidence": 0.0800,
                    "name": "restaurant_search"
                }
            ],
            "entities": [{
                "end": 53,
                "entity": "time",
                "start": 48,
                "value": "2017-04-10T00:00:00.000+02:00",
                "confidence": 1.0,
                "extractor": "DIETClassifier"
            }]
        }
        ```
        
    *   **形容**
        
        DIET (Dual Intent and Entity Transformer) は、インテント分類とエンティティ認識のためのマルチタスクアーキテクチャです。アーキテクチャは、両方のタスクで共有されるトランスフォーマーに基づいています。エンティティ ラベルのシーケンスは、トークンの入力シーケンスに対応するトランスフォーマー出力シーケンスの上にある条件付きランダム フィールド (CRF) タグ付けレイヤーを介して予測されます。インテントラベルの場合、完全な発話とインテントラベルのトランスフォーマー出力は、単一のセマンティックベクトル空間に埋め込まれます。ドット積損失を使用して、ターゲットラベルとの類似性を最大化し、ネガティブサンプルとの類似性を最小化します。
        
        モデルについて詳しく知りたい場合は、 YouTubeの[アルゴリズムホワイトボード](https://www.youtube.com/playlist?list=PL75e0qA87dlG-za8eLI6t0_Pbxafk-cxb)シリーズでは、モデルアーキテクチャを詳しく説明しています。
        
        > [!note] 注: 予測時間中にメッセージにトレーニング中に見られなかった単語**のみ**が含まれ、Out-Of-Vocabulary プリプロセッサが使用されていない場合、空のインテント `None` が信頼度 `0.0` で予測されます。これは、`単語`アナライザーを特徴付け器として [CountVectorsFeaturizer](./components.md#countvectorsfeaturizer) のみ使用する場合に発生する可能性があります。`char_wb` アナライザーを使用する場合は、常に信頼度値 `> 0.0` の意図を取得する必要があります。
        
    *   **構成**
        
        インテント分類のみに `DIETClassifier` を使用する場合は、`entity_recognition` を `False` に設定します。エンティティ認識のみを行う場合は、`intent_classification` を `False` に設定します。デフォルトでは、`DIETClassifier`は両方を行い、`つまりentity_recognition`と`intent_classification`は `本当です`。
        
        モデルを適応させるために、いくつかのハイパーパラメータを定義できます。モデルを適応させる場合は、まず次のパラメーターを変更します。
        
        *   `epochs`: このパラメータは、アルゴリズムがトレーニングデータを表示する回数を設定します (デフォルト: `300`)。1 `エポック`は、すべてのトレーニング例の 1 つのフォワードパスと 1 つのバックワードパスに相当します。モデルが適切に学習するには、より多くのエポックが必要な場合があります。エポックが増してもパフォーマンスに影響を与えない場合があります。エポック数が少ないほど、モデルのトレーニングが速くなります。
            
        *   `hidden_layers_sizes`: このパラメーターを使用すると、ユーザーメッセージとインテントのフィードフォワードレイヤーの数とその出力ディメンションを定義できます(デフォルト:`テキスト:[]、ラベル:[]`)。リスト内のすべてのエントリは、フィードフォワード層に対応します。たとえば、`テキスト [256, 128]` を設定すると、トランスフォーマーの前に 2 つのフィードフォワード レイヤーが追加されます。入力トークンのベクトル(ユーザーメッセージから来る)は、これらのレイヤーに渡されます。最初のレイヤーの出力寸法は 256 で、2 番目のレイヤーの出力寸法は 128 になります。空のリストが使用されている場合(デフォルトの動作)、フィードフォワードレイヤーは追加されません。正の整数値のみを使用してください。通常、2の累乗数が使用されます。また、リスト内の値は減少するのが通常行われています:次の値は前の値より小さいか等しいです。
            
        *   `embedding_dimension`: このパラメータは、モデル内で使用される埋め込みレイヤーの出力寸法を定義します(デフォルト: `20`)。モデルアーキテクチャ内で複数の埋め込みレイヤーを使用しています。たとえば、完全な発話とインテントのベクトルは、比較されて損失が計算される前に埋め込みレイヤーに渡されます。
            
        *   `number_of_transformer_layers`: このパラメータは、使用するトランスフォーマー レイヤーの数を設定します (既定値: `2`)。トランスフォーマー レイヤーの数は、モデルに使用するトランスフォーマー ブロックに対応します。
            
        *   `transformer_size`: このパラメータは、トランスのユニット数を設定します(デフォルト:`256`)。トランスフォーマーから出てくるベクトルは、指定された`transformer_size`を持ちます。`transformer_size`は`number_of_attention_heads`パラメータの倍数である必要があり、それ以外の場合はエラーでトレーニングが終了します。
            
        *   `connection_density`: このパラメータは、モデル内のすべてのフィードフォワード層(デフォルト:`0.2`)に対してゼロ以外の値に設定されたカーネル重みの割合を定義します。値は 0 から 1 の間である必要があります。`connection_density` 1に設定すると、カーネルの重みは0に設定されず、レイヤーは標準のフィードフォワードレイヤーとして機能します。あなたはすべきではありません `connection_density` を 0 に設定すると、すべてのカーネルの重みが 0 になり、モデルが学習できなくなります。
            
        *   `BILOU_flag`: このパラメータは、BILOU タグ付けを使用するかどうかを決定します。デフォルトは `True`。
            
    
    上記の構成パラメーターは、モデルをデータに適合させるために構成する必要があるパラメーターです。ただし、適応できる追加のパラメーターが存在します。
    
    より多くの設定可能なパラメータ
    
    ```
    +---------------------------------+------------------+--------------------------------------------------------------+
    | Parameter                       | Default Value    | Description                                                  |
    +=================================+==================+==============================================================+
    | hidden_layers_sizes             | text: []         | Hidden layer sizes for layers before the embedding layers    |
    |                                 | label: []        | for user messages and labels. The number of hidden layers is |
    |                                 |                  | equal to the length of the corresponding.                    |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | share_hidden_layers             | False            | Whether to share the hidden layer weights between user       |
    |                                 |                  | messages and labels.                                         |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | transformer_size                | 256              | Number of units in transformer.                              |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | number_of_transformer_layers    | 2                | Number of transformer layers.                                |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | number_of_attention_heads       | 4                | Number of attention heads in transformer.                    |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | use_key_relative_attention      | False            | If 'True' use key relative embeddings in attention.          |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | use_value_relative_attention    | False            | If 'True' use value relative embeddings in attention.        |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | max_relative_position           | None             | Maximum position for relative embeddings.                    |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | unidirectional_encoder          | False            | Use a unidirectional or bidirectional encoder.               |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | batch_size                      | [64, 256]        | Initial and final value for batch sizes.                     |
    |                                 |                  | Batch size will be linearly increased for each epoch.        |
    |                                 |                  | If constant `batch_size` is required, pass an int, e.g. `8`. |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | batch_strategy                  | "balanced"       | Strategy used when creating batches.                         |
    |                                 |                  | Can be either 'sequence' or 'balanced'.                      |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | epochs                          | 300              | Number of epochs to train.                                   |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | random_seed                     | None             | Set random seed to any 'int' to get reproducible results.    |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | learning_rate                   | 0.001            | Initial learning rate for the optimizer.                     |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | embedding_dimension             | 20               | Dimension size of embedding vectors.                         |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | dense_dimension                 | text: 128        | Dense dimension for sparse features to use if no dense       |
    |                                 | label: 20        | features are present.                                        |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | concat_dimension                | text: 128        | Concat dimension for sequence and sentence features.         |
    |                                 | label: 20        |                                                              |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | number_of_negative_examples     | 20               | The number of incorrect labels. The algorithm will minimize  |
    |                                 |                  | their similarity to the user input during training.          |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | similarity_type                 | "auto"           | Type of similarity measure to use, either 'auto' or 'cosine' |
    |                                 |                  | or 'inner'.                                                  |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | loss_type                       | "cross_entropy"  | The type of the loss function, either 'cross_entropy'        |
    |                                 |                  | or 'margin'. Type 'margin' is only compatible with           |
    |                                 |                  | "model_confidence=cosine",                                   |
    |                                 |                  | which is deprecated (see changelog for 2.3.4).               |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | ranking_length                  | 10               | Number of top intents  to report. Set to 0 to report all     |
    |                                 |                  | intents.                                                     |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | renormalize_confidences         | False            | Normalize the reported top intents. Applicable only with loss|
    |                                 |                  | type 'cross_entropy' and 'softmax' confidences.              |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | maximum_positive_similarity     | 0.8              | Indicates how similar the algorithm should try to make       |
    |                                 |                  | embedding vectors for correct labels.                        |
    |                                 |                  | Should be 0.0 < ... < 1.0 for 'cosine' similarity type.      |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | maximum_negative_similarity     | -0.4             | Maximum negative similarity for incorrect labels.            |
    |                                 |                  | Should be -1.0 < ... < 1.0 for 'cosine' similarity type.     |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | use_maximum_negative_similarity | True             | If 'True' the algorithm only minimizes maximum similarity    |
    |                                 |                  | over incorrect intent labels, used only if 'loss_type' is    |
    |                                 |                  | set to 'margin'.                                             |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | scale_loss                      | False            | Scale loss inverse proportionally to confidence of correct   |
    |                                 |                  | prediction.                                                  |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | regularization_constant         | 0.002            | The scale of regularization.                                 |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | negative_margin_scale           | 0.8              | The scale of how important it is to minimize the maximum     |
    |                                 |                  | similarity between embeddings of different labels.           |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | connection_density              | 0.2              | Connection density of the weights in dense layers.           |
    |                                 |                  | Value should be between 0 and 1.                             |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | drop_rate                       | 0.2              | Dropout rate for encoder. Value should be between 0 and 1.   |
    |                                 |                  | The higher the value the higher the regularization effect.   |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | drop_rate_attention             | 0.0              | Dropout rate for attention. Value should be between 0 and 1. |
    |                                 |                  | The higher the value the higher the regularization effect.   |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | use_sparse_input_dropout        | True             | If 'True' apply dropout to sparse input tensors.             |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | use_dense_input_dropout         | True             | If 'True' apply dropout to dense input tensors.              |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | evaluate_every_number_of_epochs | 20               | How often to calculate validation accuracy.                  |
    |                                 |                  | Set to '-1' to evaluate just once at the end of training.    |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | evaluate_on_number_of_examples  | 0                | How many examples to use for hold out validation set.        |
    |                                 |                  | Large values may hurt performance, e.g. model accuracy.      |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | intent_classification           | True             | If 'True' intent classification is trained and intents are   |
    |                                 |                  | predicted.                                                   |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | entity_recognition              | True             | If 'True' entity recognition is trained and entities are     |
    |                                 |                  | extracted.                                                   |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | use_masked_language_model       | False            | If 'True' random tokens of the input message will be masked  |
    |                                 |                  | and the model has to predict those tokens. It acts like a    |
    |                                 |                  | regularizer and should help to learn a better contextual     |
    |                                 |                  | representation of the input.                                 |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | BILOU_flag                      | True             | If 'True', additional BILOU tags are added to entity labels. |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | tensorboard_log_directory       | None             | If you want to use tensorboard to visualize training         |
    |                                 |                  | metrics, set this option to a valid output directory. You    |
    |                                 |                  | can view the training metrics after training in tensorboard  |
    |                                 |                  | via 'tensorboard --logdir <path-to-given-directory>'.        |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | tensorboard_log_level           | "epoch"          | Define when training metrics for tensorboard should be       |
    |                                 |                  | logged. Either after every epoch ('epoch') or for every      |
    |                                 |                  | training step ('batch').                                 |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | featurizers                     | []               | List of featurizer names (alias names). Only features        |
    |                                 |                  | coming from the listed names are used. If list is empty      |
    |                                 |                  | all available features are used.                             |
    +---------------------------------+------------------+--------------------------------------------------------------+
    | checkpoint_model                | False            | Save the best performing model during training. Models are   |
    |                                 |                  | stored to the location specified by `--out`. Only the one    |
    |                                 |                  | best model will be saved.                                    |
    |                                 |                  | Requires `evaluate_on_number_of_examples > 0` and            |
    |                                 |                  | `evaluate_every_number_of_epochs > 0`                        |
    +---------------------------------+------------------+--------------------------------------------------------------+
    ```
    
    > [!note] 注: パラメータ `maximum_negative_similarity` は、 と `use_maximum_negative_similarity = False` の場合 `maximum_negative_similarity = maximum_positive_similarity` の元の宇宙アルゴリズムを模倣するために負の値に設定されています。詳細については、スタースペースの論文を参照してください。
    

## セレクター

セレクターは、一連の候補応答からボットの応答を予測します。

### 応答セレクター

*   **短い**
    
    応答セレクター
    
*   **出力**
    
    応答セレクターの検索意図としてのキーと、予測応答、信頼度、および検索意図の下の応答キーを含む値を持つ辞書
    
*   **必要**
    
    ユーザーメッセージと応答の`dense_features`や`sparse_features`
    
*   **出力例**
    
    NLU から解析された出力には、`response_selector` という名前のプロパティがあります。 各応答セレクターコンポーネントの出力が含まれます。各応答セレクターは、 その応答セレクターの`retrieval_intent`パラメーターによって識別され、次の 2 つのプロパティを格納します。
    
    *   `response`: 対応する取得インテント、予測の信頼度、および関連する応答の下で予測された応答キー。
        
    *   `ranking`: 上位 10 個の候補応答キーの信頼度を使用したランキング。
        
    
    結果の例:
    
    ```json
    {
        "response_selector": {
          "faq": {
            "response": {
              "id": 1388783286124361986,
              "confidence": 0.7,
              "intent_response_key": "chitchat/ask_weather",
              "responses": [
                {
                  "text": "It's sunny in Berlin today",
                  "image": "https://i.imgur.com/nGF1K8f.jpg"
                },
                {
                  "text": "I think it's about to rain."
                }
              ],
              "utter_action": "utter_chitchat/ask_weather"
             },
            "ranking": [
              {
                "id": 1388783286124361986,
                "confidence": 0.7,
                "intent_response_key": "chitchat/ask_weather"
              },
              {
                "id": 1388783286124361986,
                "confidence": 0.3,
                "intent_response_key": "chitchat/ask_name"
              }
            ]
          }
        }
    }
    ```
    
    特定の応答セレクターの`retrieval_intent`パラメーターがデフォルト値のままの場合、対応する応答セレクターは、返される出力で`デフォルト`として識別されます。
    
    ```json
    {
        "response_selector": {
          "default": {
            "response": {
              "id": 1388783286124361986,
              "confidence": 0.7,
              "intent_response_key": "chitchat/ask_weather",
              "responses": [
                {
                  "text": "It's sunny in Berlin today",
                  "image": "https://i.imgur.com/nGF1K8f.jpg"
                },
                {
                  "text": "I think it's about to rain."
                }
              ],
              "utter_action": "utter_chitchat/ask_weather"
             },
            "ranking": [
              {
                "id": 1388783286124361986,
                "confidence": 0.7,
                "intent_response_key": "chitchat/ask_weather"
              },
              {
                "id": 1388783286124361986,
                "confidence": 0.3,
                "intent_response_key": "chitchat/ask_name"
              }
            ]
          }
        }
    }
    ```
    
*   **形容**
    
    レスポンスセレクターコンポーネントを使用して、レスポンス取得モデルを構築し、一連の候補レスポンスからボットレスポンスを直接予測できます。このモデルの予測は、ダイアログマネージャーが予測された応答を発するために使用されます。ユーザー入力と応答ラベルを同じ空間に埋め込み、[ミティエNLP](./components.md#ミティエNLP)とまったく同じニューラルネットワークアーキテクチャと最適化に従います。
    
    このコンポーネントを使用するには、トレーニングデータに[[glossary.md#[取得インテント](./chitchat-faqs.md)|取得インテント]]が含まれている必要があります。これらを定義するには、[[training-data-format#トレーニング例|NLU トレーニング例に関するドキュメント]] と [[responses#応答の定義|getrieval intents の応答発話の定義に関するドキュメント]] を確認してください。
    
    > [!note] 注: 予測時間中にメッセージにトレーニング中に見られなかった単語**のみ**が含まれ、Out-Of-Vocabulary プリプロセッサが使用されていない場合、空の応答 `None` が信頼度 `0.0` で予測されます。これは、`単語`アナライザーを特徴付け器として [CountVectorsFeaturizer](./components.md#countvectorsfeaturizer) のみ使用する場合に発生する可能性があります。`char_wb` アナライザーを使用する場合は、常に信頼度値 `> 0.0` の応答が返されます。
    
*   **構成**
    
    このアルゴリズムには、[ダイエットクラシファイア](./components.md#ダイエットクラシファイア) が使用するほぼすべてのハイパーパラメータが含まれています。モデルを適応させる場合は、まず次のパラメーターを変更します。
    
    *   `epochs`: このパラメータは、アルゴリズムがトレーニングデータを表示する回数を設定します (デフォルト: `300`)。1 `エポック`は、すべてのトレーニング例の 1 つのフォワードパスと 1 つのバックワードパスに相当します。モデルが適切に学習するには、より多くのエポックが必要な場合があります。エポックが増してもパフォーマンスに影響を与えない場合があります。エポック数が少ないほど、モデルのトレーニングが速くなります。
        
    *   `hidden_layers_sizes`: このパラメータを使用すると、フィードフォワードレイヤーの数と、ユーザーメッセージとインテントの出力ディメンションを定義できます(デフォルト: `text: [256, 128], label: [256, 128]` )。リスト内のすべてのエントリは、フィードフォワード層に対応します。たとえば、`テキスト [256, 128]` を設定すると、トランスフォーマーの前に 2 つのフィードフォワード レイヤーが追加されます。入力トークンのベクトル(ユーザーメッセージから来る)は、これらのレイヤーに渡されます。最初のレイヤーの出力寸法は 256 で、2 番目のレイヤーの出力寸法は 128 になります。空のリストが使用されている場合(デフォルトの動作)、フィードフォワードレイヤーは追加されません。正の整数値のみを使用してください。通常、2の累乗数が使用されます。また、リスト内の値は減少するのが通常行われています:次の値は前の値より小さいか等しいです。
        
    *   `embedding_dimension`: このパラメータは、モデル内で使用される埋め込みレイヤーの出力寸法を定義します(デフォルト: `20`)。モデルアーキテクチャ内で複数の埋め込みレイヤーを使用しています。たとえば、完全な発話とインテントのベクトルは、比較されて損失が計算される前に埋め込みレイヤーに渡されます。
        
    *   `number_of_transformer_layers`: このパラメータは、使用するトランスフォーマー レイヤーの数を設定します (既定値: `0`)。トランスフォーマー レイヤーの数は、モデルに使用するトランスフォーマー ブロックに対応します。
        
    *   `transformer_size`: このパラメータは、トランスフォーマーのユニット数を設定します(デフォルト: `なし`)。トランスフォーマーから出てくるベクトルは、指定された`transformer_size`を持ちます。`transformer_size`は`number_of_attention_heads`パラメータの倍数である必要があり、それ以外の場合はエラーでトレーニングが終了します。
        
    *   `connection_density`: このパラメータは、モデル内のすべてのフィードフォワード層(デフォルト:`0.2`)に対してゼロ以外の値に設定されたカーネル重みの割合を定義します。値は 0 から 1 の間である必要があります。`connection_density` 1に設定すると、カーネルの重みは0に設定されず、レイヤーは標準のフィードフォワードレイヤーとして機能します。あなたはすべきではありません `connection_density` を 0 に設定すると、すべてのカーネルの重みが 0 になり、モデルが学習できなくなります。
        
    *   `constrain_similarities`: このパラメータを `True` に設定すると、すべての類似性項にシグモイド クロス エントロピー損失が適用されます。これは、入力ラベルと負のラベルの類似性をより小さな値に保つのに役立ちます。これは、モデルを実際のテストセットに一般化するのに役立つはずです。
        
    *   `model_confidence`: このパラメーターを使用すると、ユーザーは推論中に信頼度を計算する方法を構成できます。入力として受け取ることができる値は `softmax` 1 つだけです。`softmax`では、信頼度は`[0, 1]`の範囲です。計算された類似性は、`softmax`活性化関数で正規化されます。
        
    
    このコンポーネントは、特定の取得インテントの応答セレクターをトレーニングするように構成することもできます。パラメーター `retrieval_intent` は、この応答セレクター モデルがトレーニングされる検索インテントの名前を設定します。デフォルトは `None` で、モデルはすべての検索インテントに対してトレーニングされます。
    
    デフォルトの構成では、コンポーネントは、応答キー(`FAQ/ask_name`など)を含む取得インテントをトレーニングのラベルとして使用します。または、`use_text_as_labelを` `True` に切り替えることで、応答のテキストをトレーニングラベルとして使用するように構成することもできます。このモードでは、コンポーネントは、トレーニングにテキスト属性を持つ最初の使用可能な応答を使用します。何も見つからない場合は、検索インテントと応答キーを組み合わせてラベルとして使用するようにフォールバックします。
    
    > [!note] note アシスタントで `ResponseSelector` コンポーネントを使用する方法の例については、[responseselectorbot](https://github.com/RasaHQ/rasa/tree/main/examples/responseselectorbot) を確認してください。さらに、`ResponseSelector` を使用した [FAQ の処理](./chitchat-faqs.md)に関するこのチュートリアルも役に立ちます。
    
    上記の構成パラメーターは、モデルをデータに適合させるために構成する必要があるパラメーターです。ただし、適応できる追加のパラメーターが存在します。
    
    より多くの設定可能なパラメータ
    
    ```text
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | Parameter                       | Default Value     | Description                                                  |
    +=================================+===================+==============================================================+
    | hidden_layers_sizes             | text: [256, 128]  | Hidden layer sizes for layers before the embedding layers    |
    |                                 | label: [256, 128] | for user messages and labels. The number of hidden layers is |
    |                                 |                   | equal to the length of the corresponding list. We recommend  |
    |                                 |                   | disabling the hidden layers (by providing empty lists) when  |
    |                                 |                   | the transformer is enabled.                                  |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | share_hidden_layers             | False             | Whether to share the hidden layer weights between user       |
    |                                 |                   | messages and labels.                                         |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | transformer_size                | None              | Number of units in the transformer. When a positive value is |
    |                                 |                   | provided for `number_of_transformer_layers`, the default size|
    |                                 |                   | becomes `256`.                                               |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | number_of_transformer_layers    | 0                 | Number of transformer layers; positive values enable the     |
    |                                 |                   | transformer.                                                 |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | number_of_attention_heads       | 4                 | Number of attention heads in transformer.                    |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | use_key_relative_attention      | False             | If 'True' use key relative embeddings in attention.          |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | use_value_relative_attention    | False             | If 'True' use value relative embeddings in attention.        |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | max_relative_position           | None              | Maximum position for relative embeddings.                    |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | unidirectional_encoder          | False             | Use a unidirectional or bidirectional encoder.               |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | batch_size                      | [64, 256]         | Initial and final value for batch sizes.                     |
    |                                 |                   | Batch size will be linearly increased for each epoch.        |
    |                                 |                   | If constant `batch_size` is required, pass an int, e.g. `8`. |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | batch_strategy                  | "balanced"        | Strategy used when creating batches.                         |
    |                                 |                   | Can be either 'sequence' or 'balanced'.                      |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | epochs                          | 300               | Number of epochs to train.                                   |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | random_seed                     | None              | Set random seed to any 'int' to get reproducible results.    |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | learning_rate                   | 0.001             | Initial learning rate for the optimizer.                     |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | embedding_dimension             | 20                | Dimension size of embedding vectors.                         |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | dense_dimension                 | text: 512         | Dense dimension for sparse features to use if no dense       |
    |                                 | label: 512        | features are present.                                        |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | concat_dimension                | text: 512         | Concat dimension for sequence and sentence features.         |
    |                                 | label: 512        |                                                              |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | number_of_negative_examples     | 20                | The number of incorrect labels. The algorithm will minimize  |
    |                                 |                   | their similarity to the user input during training.          |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | similarity_type                 | "auto"            | Type of similarity measure to use, either 'auto' or 'cosine' |
    |                                 |                   | or 'inner'.                                                  |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | loss_type                       | "cross_entropy"   | The type of the loss function, either 'cross_entropy'        |
    |                                 |                   | or 'margin'. Type 'margin' is only compatible with           |
    |                                 |                   | "model_confidence=cosine",                                   |
    |                                 |                   | which is deprecated (see changelog for 2.3.4).               |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | ranking_length                  | 10                | Number of top responses to report. Set to 0 to report all    |
    |                                 |                   | responses.                                                   |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | renormalize_confidences         | False             | Normalize the top responses. Applicable only with loss type  |
    |                                 |                   | 'cross_entropy' and 'softmax' confidences.                   |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | maximum_positive_similarity     | 0.8               | Indicates how similar the algorithm should try to make       |
    |                                 |                   | embedding vectors for correct labels.                        |
    |                                 |                   | Should be 0.0 < ... < 1.0 for 'cosine' similarity type.      |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | maximum_negative_similarity     | -0.4              | Maximum negative similarity for incorrect labels.            |
    |                                 |                   | Should be -1.0 < ... < 1.0 for 'cosine' similarity type.     |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | use_maximum_negative_similarity | True              | If 'True' the algorithm only minimizes maximum similarity    |
    |                                 |                   | over incorrect intent labels, used only if 'loss_type' is    |
    |                                 |                   | set to 'margin'.                                             |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | scale_loss                      | True              | Scale loss inverse proportionally to confidence of correct   |
    |                                 |                   | prediction.                                                  |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | regularization_constant         | 0.002             | The scale of regularization.                                 |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | negative_margin_scale           | 0.8               | The scale of how important is to minimize the maximum        |
    |                                 |                   | similarity between embeddings of different labels.           |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | connection_density              | 0.2               | Connection density of the weights in dense layers.           |
    |                                 |                   | Value should be between 0 and 1.                             |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | drop_rate                       | 0.2               | Dropout rate for encoder. Value should be between 0 and 1.   |
    |                                 |                   | The higher the value the higher the regularization effect.   |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | drop_rate_attention             | 0.0               | Dropout rate for attention. Value should be between 0 and 1. |
    |                                 |                   | The higher the value the higher the regularization effect.   |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | use_sparse_input_dropout        | False             | If 'True' apply dropout to sparse input tensors.             |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | use_dense_input_dropout         | False             | If 'True' apply dropout to dense input tensors.              |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | evaluate_every_number_of_epochs | 20                | How often to calculate validation accuracy.                  |
    |                                 |                   | Set to '-1' to evaluate just once at the end of training.    |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | evaluate_on_number_of_examples  | 0                 | How many examples to use for hold out validation set.        |
    |                                 |                   | Large values may hurt performance, e.g. model accuracy.      |
    |                                 |                   | Set to 0 for no validation.                                  |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | use_masked_language_model       | False             | If 'True' random tokens of the input message will be masked  |
    |                                 |                   | and the model should predict those tokens.                   |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | retrieval_intent                | None              | Name of the intent for which this response selector model is |
    |                                 |                   | trained.                                                     |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | use_text_as_label               | False             | Whether to use the actual text of the response as the label  |
    |                                 |                   | for training the response selector. Otherwise, it uses the   |
    |                                 |                   | response key as the label.                                   |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | tensorboard_log_directory       | None              | If you want to use tensorboard to visualize training         |
    |                                 |                   | metrics, set this option to a valid output directory. You    |
    |                                 |                   | can view the training metrics after training in tensorboard  |
    |                                 |                   | via 'tensorboard --logdir <path-to-given-directory>'.        |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | tensorboard_log_level           | "epoch"           | Define when training metrics for tensorboard should be       |
    |                                 |                   | logged. Either after every epoch ("epoch") or for every      |
    |                                 |                   | training step ("batch").                                     |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | featurizers                     | []                | List of featurizer names (alias names). Only features        |
    |                                 |                   | coming from the listed names are used. If list is empty      |
    |                                 |                   | all available features are used.                             |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | checkpoint_model                | False             | Save the best performing model during training. Models are   |
    |                                 |                   | stored to the location specified by `--out`. Only the one    |
    |                                 |                   | best model will be saved.                                    |
    |                                 |                   | Requires `evaluate_on_number_of_examples > 0` and            |
    |                                 |                   | `evaluate_every_number_of_epochs > 0`                        |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | constrain_similarities          | False             | If `True`, applies sigmoid on all similarity terms and adds  |
    |                                 |                   | it to the loss function to ensure that similarity values are |
    |                                 |                   | approximately bounded. Used only if `loss_type=cross_entropy`|
    +---------------------------------+-------------------+--------------------------------------------------------------+
    | model_confidence                | "softmax"         | Affects how model's confidence for each response label       |
    |                                 |                   | is computed. Currently, only one value is supported:         |
    |                                 |                   | 1. `softmax` - Similarities between input and response label |
    |                                 |                   | embeddings are post-processed with a softmax function,       |
    |                                 |                   | as a result of which confidence for all labels sum up to 1.  |
    +---------------------------------+-------------------+--------------------------------------------------------------+
    ```
    
    > [!note] 注: パラメータ `maximum_negative_similarity` は、 と `use_maximum_negative_similarity = False` の場合 `maximum_negative_similarity = maximum_positive_similarity` の元の宇宙アルゴリズムを模倣するために負の値に設定されています。詳細については、スタースペースの論文を参照してください。
    

## カスタムコンポーネント

> [!info]
> 3.0 の新機能Rasa 3.0 では、NLU コンポーネントとポリシーの実装が統合されました。これには、以前のバージョンの Rasa Open Source 用に作成されたカスタムコンポーネントを変更する必要があります。移行のステップバイステップガイドについては、[[migration-guide#カスタムポリシーとカスタムコンポーネント|移行ガイド]]を参照してください。

カスタムコンポーネントを作成して、NLU が現在提供していない特定のタスク (センチメント分析など) を実行できます。

モジュールパスを追加することで、パイプラインにカスタムコンポーネントを追加できます。したがって、`センチメント`というモジュールがある場合 `SentimentAnalyzer` クラスを含む:

```yaml-rasa
pipeline:
- name: "sentiment.SentimentAnalyzer"
```

カスタムコンポーネントの完全なガイドについては、[カスタムグラフコンポーネントに関するガイド](custom-graph-components.md)を参照してください。また、[[tuning-your-model#コンポーネントライフサイクル|コンポーネントライフサイクル]]です。


---

1.  `model_confidence: cosine`は 2.3.4 で非推奨になり ([[changelog#[2.3.4] - 2021-02-26|change]] を参照)、設定で指定することはできませんが、`loss_type: margin` が指定されている場合は、設定に関係なく `model_confidence: cosine` が使用されます。[↩](#user-content-fnref-1)