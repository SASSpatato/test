---
id: testing-your-assistant
sidebar_label: Testing Your Assistant
title: Testing Your Assistant
abstract: Rasa lets you validate and test dialogues end-to-end by running through
  test stories. In addition, you can
  also test the dialogue management and the message processing (NLU)
  separately.
---

## データとストーリーの検証

データ検証では、ドメイン、NLU データ、またはストーリー データに間違いや重大な不整合がないことを確認します。データを検証するには、CI に次のコマンドを実行させます。

```bash
rasa data validate
```

`config.yml` ファイル内の 1 つ以上のポリシーに`max_history`値を渡す場合は、それらの最小値を

```bash
rasa data validate --max-history <max_history>
```

データ検証でエラーが発生する場合、モデルのトレーニングも失敗したり、パフォーマンスが低下したりする可能性があるため、 モデルをトレーニングする前に、このチェックを実行することを常にお勧めします。に `--fail-on-warnings` フラグを使用すると、このステップは、より軽微な問題を示す警告で失敗します。

> [!note] 
> 注: `rasa data validate` を実行しても、[ルール](./rules.md)がストーリーと整合性があるかどうかはテスト**されません**。ただし、トレーニング中、`RulePolicy` はルールとストーリー間の競合をチェックします。そのような対立は訓練を中止します。

バリデーターと利用可能なすべてのオプションの詳細については、[[./command-line-interface.md#RASAデータ検証|`rasa data validate`のドキュメント]]を参照してください。

## テストストーリーの作成

テスト・ストーリーでトレーニング済みモデルをテストすることは、特定の状況でアシスタントがどのように動作するかを確信するための最良の方法です。変更されたストーリー形式で記述されたテストストーリーを使用すると、会話全体を提供し、特定のユーザー入力が与えられた場合にモデルが期待どおりに動作することをテストできます。これは、ユーザーの会話からより複雑なストーリーを導入し始める場合に特に重要です。

テスト ストーリーはトレーニング データのストーリーに似ていますが、ユーザー メッセージも含まれます。

以下にいくつかの例を示します。

**基本：**

```
stories:
- story: A basic story test
  steps:
  - user: |
      hello
    intent: greet
  - action: utter_ask_howcanhelp
  - user: |
     show me [chinese]{"entity": "cuisine"} restaurants
    intent: inform
  - action: utter_ask_location
  - user: |
      in [Paris]{"entity": "location"}
    intent: inform
  - action: utter_ask_price
```

**ボタンペイロード:**

```
stories:
- story: A test where a user clicks on a button with payload
  steps:
  - user: |
      hello
    intent: greet
  - action: utter_ask_howcanhelp
  - user: /inform{{"cuisine":"chinese"}}
    intent: inform
  - action: utter_ask_location
  - user: /inform{{"location":"Paris"}}
    intent: inform
  - action: utter_ask_price
```

**カスタムアクション:**

```
stories:
- story: A test where a custom action returns events
  steps:
  - user: |
      hey
    intent: greet
  - action: my_custom_action
  - slot_was_set:
    - my_slot: "value added by custom action"
  - action: utter_ask_age
  - user: |
      thanks
    intent: thankyou
  - action: utter_no_worries
```

**ハッピーパスを形成する:**

```
stories:
- story: A test story with a form
  steps:
  - user: |
      hi
    intent: greet
  - action: utter_greet
  - user: |
      im looking for a restaurant
    intent: request_restaurant
  - action: restaurant_form
  - active_loop: restaurant_form
  - user: |
      [afghan](cuisine) food
    intent: inform
  - action: restaurant_form
  - active_loop: null
  - action: utter_slots_values
  - user: |
      thanks
    intent: thankyou
  - action: utter_no_worries
```

**不幸な道を形作る:**

```
stories:
- story: A test story with unexpected input during a form
  steps:
  - user: |
      hi
    intent: greet
  - action: utter_greet
  - user: |
      im looking for a restaurant
    intent: request_restaurant
  - action: restaurant_form
  - active_loop: restaurant_form
  - user: |
      How's the weather?
    intent: chitchat
  - action: utter_chitchat
  - action: restaurant_form
  - active_loop: null
  - action: utter_slots_values
  - user: |
      thanks
    intent: thankyou
  - action: utter_no_worries
```

```
stories:
- story: A basic test story with multiple entities for a single token
  steps:
  - user: |
      hello
    intent: greet
  - action: utter_ask_howcanhelp
  - user: |
     show me [chinese]{"entity": "cuisine"} restaurants
    intent: inform
  - action: utter_ask_location
  - user: |
      in [Paris][{"entity": "location"}, {"entity": "city"}]
    intent: inform
  - action: utter_ask_price
```

デフォルトでは、このコマンドは名前が `test_` で始まるすべてのファイルのストーリーに対してテストを実行します。特定のテスト ストーリー ファイルまたはディレクトリに `--stories` 引数を指定することもできます。アシスタントをテストするには、以下を実行します。

```bash
rasa test
```

会話テストは、組み込むテストケースと同じくらい徹底的で正確であるため、アシスタントを改善するにつれて、一連のテストストーリーを増やし続ける必要があります。従うべき経験則は、テストストーリーが実際の会話の真の分布を代表するものになるようにすることです。

その他の設定オプションについては、[[./command-line-interface.md#rasa test|`rasa test`]] に関する CLI ドキュメントを参照してください。

> [!info] カスタムアクションのテスト
>  [カスタムアクション](./custom-actions.md)は、テストストーリーの一部として実行されません。カスタムアクションで会話にイベントを追加する場合は、テストストーリーに反映する必要があります(テストストーリーに`slot_was_set`イベントを追加するなど)。
> カスタムアクションのコードをテストするには、単体テストを記述する必要があります これらのテストを [CI/CD パイプライン](./setting-up-ci-cd.md)に含めます。

## NLU モデルの評価

ストーリーのテストに加えて、自然言語理解 (NLU) モデルを個別にテストすることもできます。アシスタントが現実世界にデプロイされると、トレーニング データでは見られなかったメッセージが処理されます。これをシミュレートするには、常にテスト用にデータの一部を取っておく必要があります。次のいずれかを実行できます。

1.  [[#ホールドアウトテストセットの使用]] NLUデータをシャッフルして分割します
    
2.  [[#クロス検証の使用]]は、複数のトレーニング/テスト分割を自動的に作成します
    

### ホールドアウトテストセットの使用

train-test set アプローチを使用する場合は、古くなりやすい静的 NLU テストセットを使用するのではなく、モデルを評価するたびに `rasa data split` を使用して [[./command-line-interface.md#RASAデータ分割| shuffle and split your data]] を使用するのが最善です。

NLU データは、以下を使用してトレーニング セットとテスト セットに分割できます。

```bash
rasa data split nlu
```

次に、トレーニング済みの NLU モデルが生成したテスト セットのデータをどの程度うまく予測するかを確認できます。

```bash
rasa test nlu
    --nlu train_test_split/test_data.yml
```

### クロス検証の使用

NLU トレーニングデータに大幅な変更を加えた場合 (インテントを 2 つのインテントに分割したり、多くのトレーニング例を追加したりするなど)、クロス検証を使用して完全な NLU 評価を実行する必要があります。クロス検証では、複数のトレーニング/テスト分割が自動的に作成され、各トレーニング/テスト分割の評価結果が平均化されます。つまり、すべてのデータがクロス検証中に評価されるため、クロス検証はNLUモデルを自動的にテストする最も徹底的な方法になります。

NLU テストをクロス検証モードで実行するには、次のコマンドを実行します。

```bash
rasa test nlu
    --nlu data/nlu
    --cross-validation
```

`-f/--folds` フラグを使用して使用するテスト/トレーニング分割の数を指定できます。

```bash
rasa test nlu
    --nlu data/nlu
    --cross-validation
    --folds 5
```

クロスバリデーション中は、NLUモデルがフォールドごとにトレーニングされるため、大規模なデータセットと多数のフォールドを使用したクロスバリデーションには時間がかかる可能性があることに注意してください。小さなデータセットでは、フォールドの数が多いと、各テスト分割で使用できるインテントあたりの例が少なすぎる可能性があります。

一方、フォールドの数を少なく指定すると、データははるかに大きなチャンクに分割され、フォールドごとにトレーニングするデータが比例して少なくなります。

データセットのサイズについて、両方の考慮事項のバランスをとるフォールドの数を選択します。

> [!tip] ハイパーパラメータの調整 
> モデルをさらに改善するには、こちらをご覧ください。 [ハイパーパラメータのチューニングに関するチュートリアル](https://blog.rasa.com/rasa-nlu-in-depth-part-3-hyperparameters/)。

### NLU パイプラインの比較

トレーニング データを最大限に活用するには、さまざまなパイプラインとさまざまな量のトレーニング データでモデルをトレーニングおよび評価する必要があります。

これを行うには、複数の構成ファイルを`rasa test`コマンドに渡します。

```bash
rasa test nlu --nlu data/nlu.yml
   --config config_1.yml config_2.yml
```

これにより、いくつかの手順が実行されます。

1.  `データ/nlu.yml`からグローバルに 80% のトレーニング/20% のテスト分割を作成します。
2.  グローバル トレイン分割から一定の割合のデータを除外します。
3.  残りのトレーニングデータで各構成のモデルをトレーニングします。
4.  グローバル テスト分割で各モデルを評価します。

ステップ 2 では、トレーニングデータの異なる割合で上記のプロセスを繰り返し、トレーニングデータの量を増やした場合に各パイプラインがどのように動作するかを把握します。トレーニングは完全に決定論的ではないため、指定された構成ごとにプロセス全体が 3 回繰り返されます。

平均値と標準偏差が [f1スコア](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.f1_score.html) すべての配管がプロットされます。 f1 スコア グラフは、すべてのトレーニング/テスト セット、トレーニング済みモデル、分類、エラー レポートとともに、`nlu_comparison_results` というフォルダーに保存されます。

f1 スコア グラフを調べると、NLU モデルに十分なデータがあるかどうかを理解するのに役立ちます。すべてのトレーニングデータを使用しても f1-score がまだ改善していることがグラフで示されている場合は、データが増えるとさらに改善される可能性があります。ただし、すべてのトレーニング データを使用したときに f1 スコアが頭打ちになった場合、データを追加しても役に立たない可能性があります。

実行数または除外率を変更する場合は、次のことができます。

```bash
rasa test nlu --nlu data/nlu.yml
  --config config_1.yml config_2.yml
  --runs 4 --percentages 0 25 50 70 90
```

### 出力の解釈

#### インテント分類子

`rasa テスト`スクリプトは、インテント分類モデルのレポート (`intent_report.json`)、混同行列 (`intent_confusion_matrix.png`)、および信頼度ヒストグラム (`intent_histogram.png`) を生成します。

このレポートには、各インテントの[精度](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.precision_score.html)、[再現率](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.recall_score.html)、[f1 スコア](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.f1_score.html)が記録され、全体的な平均も表示されます。これらのレポートは、`--report` 引数を使用して JSON ファイルとして保存できます。

混同行列は、どのインテントが他のインテントと間違われているかを示します。誤って予測されたサンプルはログに記録され、デバッグを容易にするために `errors.json` というファイルに保存されます。

![image](/static/img/intent_confusion_matrix_example.png)

ヒストグラムを使用すると、すべての予測の信頼度を視覚化でき、正しい予測と間違った予測がそれぞれ青と赤のバーで表示されます。トレーニングデータの品質を向上させると、青いヒストグラムバーがプロットの上に移動し、赤いヒストグラムバーがプロットの下に移動します。また、赤いヒストグラムバー自体の数を減らすのにも役立ちます。

![image](/static/img/intent_histogram_example.png)

#### 応答セレクター

`RASA テスト`は、インテント分類子を評価するのと同じ方法で応答セレクターを評価し、レポート ( `response_selection_report.json` )、混同行列 ( `response_selection_confusion_matrix.png` )、信頼度ヒストグラム ( `response_selection_histogram.png` )、およびエラー ( `response_selection_errors.json` ) を生成します。パイプラインに複数の応答セレクターが含まれている場合、それらは 1 つのレポートで評価されます。

このレポートは、[[glossary.md#[取得インテント](./chitchat-faqs.md)|取得インテント]]を呼び出し、全体的な平均を提供します。これらのレポートは、`--report` 引数を使用して JSON ファイルとして保存できます。

#### エンティティ抽出

`RASA テスト`は、トレーニング可能なエンティティ抽出器が認識するようにトレーニングされている各エンティティタイプの再現率、精度、および F1 スコアを報告します。

`DIETClassifier`や`CRFEntityExtractor`などのトレーニング可能なエンティティ抽出器のみが`rasaテスト`によって評価されます。`DucklingHTTPExtractor` などの事前トレーニング済み抽出器は評価されません。

パイプラインに複数のエンティティ抽出器がある場合、またはいくつかのカスタム抽出器を使用している場合は、複数のエンティティが同じトークンに関連付けられている可能性があります。この場合、テストファイルで次のようなリスト表記を使用できます。

```yaml
stories:
- story: A basic test story with multiple entities for a single token
  steps:
    - user: |
        I like [ice cream][{"entity": "food"}, {"entity": "desert"}]
      intent: inform
    # ...
```

> [!caution] エンティティの注釈が正しくない 
> エンティティのいずれかに誤った注釈が付けられている場合、評価が失敗する可能性があります。一般的な問題の 1 つは、エンティティがトークン内で停止または開始できないことです。たとえば、 `[Brian](name)'s house`のような``名前`エンティティの例がある場合、これはトークナイザーが`Brian'sを`複数のトークンに分割している場合にのみ有効です。

#### エンティティスコアリング

エンティティ抽出を評価するために、単純なタグベースのアプローチを適用します。[[nlu-training-data.md#BILOUエンティティのタグ付け|BILOU タグ]] とまったく同じですが、トークンごとにエンティティ型タグのみがタグ付けされます。「near Alexanderplatz」のようなロケーションエンティティの場合、BILOUベースの`B-LOC L-LOC`ではなく`LOC LOC`というラベルが想定されます。

私たちのアプローチは、部分的な抽出に報酬を与え、エンティティの分割にペナルティを与えないため、評価に関してはより寛大です。たとえば、前述のエンティティ「near Alexanderplatz」と「Alexanderplatz」を抽出するシステムが与えられた場合、私たちのアプローチは「Alexanderplatz」の抽出に報酬を与え、見逃した単語「near」にペナルティを与えます。

ただし、BILOUベースのアプローチでは、Alexanderplatzが単一のトークンエンティティ(`U-LOC`)ではなくエンティティ(`L-LOC`)の最後のトークンとしてラベル付けされることが予想されるため、これは完全な失敗としてラベル付けされます。また、「near」と「Alexanderplatz」を分割して抽出すると、アプローチでは満点が得られ、BILOUベースのアプローチではゼロ点になることに注意してください。

「今夜アレクサンダー広場の近く」というフレーズの 2 つの採点メカニズムの比較は次のとおりです。

| extracted                                           | Simple tags (score) | BILOU tags (score)     |
| --------------------------------------------------- | ------------------- | ---------------------- |
| `[near Alexanderplatz](loc) [tonight](time)`        | loc loc time (3)    | B-loc L-loc U-time (3) |
| `[near](loc) [Alexanderplatz](loc) [tonight](time)` | loc loc time (3)    | U-loc U-loc U-time (1) |
| `near [Alexanderplatz](loc) [tonight](time)`        | O   loc time (2)    | O     U-loc U-time (1) |
| `[near](loc) Alexanderplatz [tonight](time)`        | loc O   time (2)    | U-loc O     U-time (1) |
| `[near Alexanderplatz tonight](loc)`                | loc loc loc  (2)    | B-loc I-loc L-loc  (1) |


## 対話モデルの評価

テストスクリプトを使用して、一連のテストストーリーでトレーニング済みの対話モデルを評価できます。

```bash
rasa test core --stories test_stories.yml --out results
```

これにより、失敗したストーリーが `results/failed_test_stories.yml` に出力されます。アクションの少なくとも 1 つが誤って予測された場合、ストーリーは失敗します。

テストスクリプトは、混同行列を `結果/story_confmat.pdf`。ドメイン内の各アクションについて、混同行列には、アクションが正しく予測された頻度と、代わりに誤ったアクションが予測された頻度が表示されます。

### 生成された警告の解釈

テストスクリプトは、 `results/stories_with_warnings.yml` という警告ファイルも生成します。このファイルには、[`action_unlikely_intent`](./default-actions.md#action_unlikely_intent) どの会話ターンでも予測されたが、原作のすべての行動は正しく予測された。 ただし、テスト ストーリーに元々`action_unlikely_intent`が含まれていた場合 (たとえば[、ルールが`action_unlikely_intent`後に会話パスをトリガーするように設計されている](./default-actions.md#カスタマイズ)ことを確認するために)、ポリシーのアンサンブルがトリガーできなかった場合、対応するストーリーは失敗したストーリー `results/failed_test_stories.yml` として終了します。

ストーリーは、`action_unlikely_intent`の予測の重大度によって分類されます。この重大度は、[[./policies.md#UnexpecTED インテント ポリシー|`UnexpecTEDIntentPolicy`]] 自体を予測時に実行します。重大度が高いほど、意図の可能性は低くなるため、その特定の会話パスを確認することがより重要になります。

その`action_unlikely_intent`は `UnexpecTEDIntentPolicy` は、内部で機械学習ベースのモデルを採用しているため、誤った警告も発生する可能性があります。これらのストーリーの会話パスがトレーニング ストーリーに既に存在する場合は、このような警告を無視することを選択できます。

### ポリシー構成の比較

対話モデルの設定を選択したり、特定のポリシーのハイパーパラメータを選択したりするには、対話モデルがこれまでに見たことのない会話にどの程度一般化されるかを測定する必要があります。特にプロジェクトの開始時に、ボットをトレーニングするための実際の会話があまりない場合は、テストセットとして使用する会話を除外したくないかもしれません。

Rasaには、ポリシー設定の選択と微調整に役立つスクリプトがいくつか用意されています。満足したら、完全なデータセットで最終構成をトレーニングできます。

これを行うには、まず、さまざまな構成のモデルをトレーニングする必要があります。比較するポリシーを含む 2 つ (またはそれ以上) の構成ファイルを作成し、それらをトレーニング スクリプトに提供してモデルをトレーニングします。

```bash
rasa train core -c config_1.yml config_2.yml 
  --out comparison_models --runs 3 --percentages 0 5 25 50 70 95
```

[[./testing-your-assistant.md#NLU パイプラインの比較|NLU モデルが評価されました]] の場合、上記のコマンドは、複数の構成と異なる量のトレーニング データで対話モデルをトレーニングします。提供された各構成ファイルについて、Rasa はトレーニング ストーリーの 0、5、25、50、70、および 95% をトレーニング データから除外して対話モデルをトレーニングします。一貫した結果を確保するために、これを 3 回繰り返します。

このスクリプトが終了したら、複数のモデルをテスト スクリプトに渡して、トレーニングしたばかりのモデルを比較できます。

```bash
rasa test core -m comparison_models --stories stories_folder
  --out comparison_results --evaluate-model-directory
```

これにより、`stories_folder` のストーリーの各モデルが評価されます (トレーニングセットまたはテストセットのいずれかです)といくつかのグラフをプロットします を使用して、どのポリシーが最もパフォーマンスが高いかを示します。以前の train コマンド以降 各モデルをトレーニングするためにある程度のトレーニングデータを除外し、 上記のテストコマンドは、モデルがホールドアウトされたストーリーをどの程度うまく予測しているかを測定できます。 1 つのポリシーを比較するには、それぞれ 1 つのポリシーのみを含む構成ファイルを作成します。

> [!note] 
> このトレーニングプロセスには時間がかかる場合があるため、中断できないバックグラウンドのどこかで実行することをお勧めします。

### アクションコードのテスト

アクションコードのテストに使用されるアプローチは、その実装方法によって異なります。たとえば、外部 API に接続する場合は、それらの API が一般的な入力に期待どおりに応答するように統合テストを作成する必要があります。アクションコードをテストする場合でも、これらのテストを CI パイプラインに含めて、変更を加えるたびに実行できるようにする必要があります。

ご質問や問題がございましたら、専用の フォー[ラムのテストセクション](https://forum.rasa.com/tags/testing)!

## エンドツーエンドのテスト

> [!warning] Rasa PROのみ

> [!info] 3.5 の新機能
> エンドツーエンドのテストを使用して、ダイアログ管理やカスタムアクションなど、アシスタント全体をテストできるようになりました。

エンドツーエンドのテストは、拡張された包括的な CLI ベースのテストツールであり、事前設定されたさまざまなコンテキストで会話シナリオをテストし、[カスタムアクション](./action-server/actions.md)を実行し、[応答](./responses.md)テキストまたは名前を検証し、[スロット](./domain.md#スロット)が埋まったときにアサートすることができます。

エンドツーエンドのテストは、NLUまたは対話モデルのみのテストに限定されず、効果的な受け入れテストまたは統合テストを設計できます。エンドツーエンドのテストの主な機能は次のとおりです。

*   [アクションサーバー](./action-server/running-action-server.md)との統合: テストでカスタムアクションを実行できます。前提条件は、アクションサーバーをバックグラウンドで起動することです。
*   テストパラメータ化(例:異なるユーザープロファイルやその他の外部要因):異なるプレフィルドスロットを持つ複数のテストフィクスチャを定義し、テストで再利用できます。
*   応答テキストまたは名前の検証: ボットの応答テキスト (スロット値と [[./responses.md#条件付き応答の変動|条件付き応答バリエーション]] を含む) または`完全な`名前が期待どおりであることをアサートできます。
*   ボットがスロット値を期待どおりに設定することをアサートします。

### テストケースの書き方

テストケースを記述するには、プロジェクトの`テスト`ディレクトリ内にYAMLファイルを作成する必要があります。ファイルの名前は`e2e_test_cases.yml`にする必要があります。`テスト`ディレクトリ内にサブディレクトリを作成し、そこにテストケースのYAMLファイルを配置することもできます。これらのファイルは Rasa Pro によって自動的に検出され、実行されますが、`rasa test e2e` コマンドの位置引数としてサブディレクトリへのパスを指定する必要があります。

各入力ファイルには、`必要なtest_cases`キーが含まれている必要があります。このキーの値は、テスト ケースのリストです。各テストケースには、`test_case`キーに付けられた名前と`、ステップ`キーに指定されたテストステップのリストが含まれている必要があります。ステップは、次のいずれかになります。

*   `user`: ユーザーメッセージ
*   `ボット`: ボットの応答
*   `utter`: ドメイン発話
*   `slot_was_set`: スロット名と設定された値

個々のテストケースコンテキストを設定するために事前に入力されたスロットが必要な場合は、オプションの`フィクスチャトップ`レベルキーを追加することもできます。`フィクスチャ` キーはフィクスチャ名のリスト (一意である必要があります) であり、各フィクスチャ名はスロット キーと値のペアのリストにマッピングされます。テスト・ケースの 1 つに事前入力されたスロットが必要な場合は、テスト・ケースのオプションの`フィクスチャ`・キーにフィクスチャ名を追加することで、フィクスチャ名をテスト・ケース定義に追加できます。スロットのキーと値のペアは、テストケースが実行される前に設定されます。

次の例は、フィクスチャを含むテスト・ケース・ファイルと、使用可能なすべてのステップを使用する 2 つのテスト・ケースを示しています。

```yaml
fixtures:
 - premium:  # name of the fixture must be provided and be unique
   - membership_type: premium  # every fixture can contain multiple slot key-value pairs
   - logged_in: True
 - standard:
   - logged_in: True
   - membership_type: standard

test_cases:
 - test_case: "test_premium_booking"
   fixtures:
    - premium  # re-use the name of the fixture provided in fixtures section
   steps:
    - user: "Hi!"
    - bot: "Welcome back! How can I help you?"
    - user: "I want to book a trip."
    - utter: utter_ask_location
    - user: "I would like to travel to Lisbon."
    - slot_was_set:
      - location: "Lisbon"
    - utter: utter_ask_date
    - user: "I would like to travel on 22nd of June."
    - slot_was_set:
      - travel_date: "2023-06-22"
    - bot: "Great! I will book your trip to Lisbon on 22nd of June."
    - bot: "You saved 20% by being a premium member."

 - test_case: "test_anonymous_booking"
   steps:
    - user: "Hi!"
    - bot: "Hey! How can I help you?"
    - user: "I want to book a trip."
    - utter: utter_ask_location
    - user: "I would like to travel to Paris."
    - slot_was_set:
      - location: "Paris"
    - utter: utter_ask_date
    - user: "I would like to travel on 2nd of April."
    - slot_was_set:
      - travel_date: "2023-04-02"
    - bot: "Great! I will book your trip to Paris on 2nd of April."
    - bot: "You can also choose to save 20% by becoming a premium member."
```

> [!note] 
> テストケースで複数の連続した`slot_was_set`ステップを使用する場合、これらのステップを定義する順序は、ダイアログでスロットが埋められる順序と一致する必要があります。

### テストの実行方法

エンドツーエンドのテストをローカルまたはCIパイプラインで実行するには、[[./command-line-interface.md#RASAテストE2E|`rasa test e2e` コマンド]] このコマンドは、以下の引数を取ります。

*   テストケースファイルまたはテストケースを含むディレクトリへのパスの位置引数: `rasa test e2e <path>` 指定しない場合、デフォルトのパスは `tests/e2e_test_cases.yml` です。
*   トレーニング済みモデルの省略可能な引数: `--model <path>`
*   [[./model-storage.md#クラウドからモデルを読み込む|remote storage]] からトレーニング済みモデルを取得するためのオプションの引数: `--remote-storage <remote-storage-location>`
*   `endpoints.yml` ファイルのオプション引数: `--endpoints <path>`
*   最初の失敗時にテスト実行を停止するためのオプションの引数: `rasa test e2e --fail-fast`
*   テスト結果を`e2e_results.yml`ファイルにエクスポートするためのオプションの引数: `rasa test e2e -o`

#### カスタムアクションのテスト

テストケースにカスタムアクションが含まれている場合は、最初にアクションサーバーを起動します。

```bash
rasa run actions && rasa test e2e
```

### 出力の解釈方法

デフォルトでは、結果は常に`標準出力`に出力され、コマンドは終了コード `0` (すべてのテストに合格した場合) または `1` (テストが失敗した場合) で終了します。

出力スタイルは`pytest`に触発されています。

*   失敗したテストケースはスタックされ、それぞれが `git diff` と同様のスタイルで識別された不一致の違いを強調します: 予期されるメッセージの前には `+` プレフィックスが付き、実際のメッセージの前には `-` プレフィックスが付きます。
*   短いテストの概要には、失敗したすべてのテストケース名とファイルの場所のリストが新しい行に含まれています。

コマンドで `-o` フラグが指定されている場合、結果は `tests/e2e_results.yml` ファイルにも書き込まれ、このファイルには次のキーを持つテスト結果のリストが含まれます。

*   `name`: テストケースの名前
*   `pass_status`: テストケースのステータス (`True` または `False`)
*   `expected_steps`: 予想されるテスト手順
*   `差異`: 予想されるテストステップと実際のテストステップの違いのリスト