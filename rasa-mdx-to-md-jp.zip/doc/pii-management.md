---
id: pii-management
sidebar_label: PII Management
title: PII Management
hide_table_of_contents: false
---

> [!warning] Rasa Proのみ

> [!warning] 3.6 の新機能 
> Kafka イベントブローカーを介してストリーミングされるログおよびイベント内の個人を特定できる情報 (PII) データを匿名化できるようになりました。PII データの匿名化を有効にする方法については、読み続けてください。

アシスタントが収集した機密性の高い顧客データの管理は、規制を遵守し、データを分析に利用できるようにしながらデータを安全に管理するための重要な要件です。Rasa Pro 3.6 では、Kafka イベントブローカーを介してストリーミングされるログおよびイベント内の PII データを匿名化する機能が導入されています。

トラッカーストアは、匿名化されていない会話データを引き続き保存することに注意してください。これは、否認防止の目的で原始的なデータの信頼できる情報源を保持するために必要です。[Vault シークレットマネージャー](./secrets-managers.md)を使用してトラッカーストアを保護し、ローテーション認証情報で信頼できる情報源を保護する方法を学びます。

さらに、トラッカーストアデータは推論時にアシスタントの対話管理において重要な役割を果たすため、転送中のデータを匿名化すると、アシスタントの対話管理アクションの予測に望ましくない結果をもたらす可能性があります。

## アーキテクチャの概要

Rasa イベントの匿名化は、対話管理アクションの予測と実行の最後に匿名化パイプラインを介して実行されます。匿名化パイプラインによって行われる処理はバックグラウンド・タスクとしてスケジュールされ、アシスタントの応答時間には影響しないことに注意してください。

匿名化の手順は次のとおりです。

1.  Rasa エージェントは、各ユーザー・メッセージ処理中に匿名化パイプラインを呼び出します。
2.  匿名化パイプラインは、新しいイベントに適用される一連の匿名化ルールを実行します。
3.  パイプラインは、`endpoints.yml` の匿名化ルールリストにマッピングされた Kafka トピックに匿名化されたイベントを公開します。
4.  トラッカーストアは、匿名化されていない元のイベントを保存します。

### サポートされている Rasa イベント

匿名化される Rasa イベントには、次のものがあります。

*   `user`
*   `bot`
*   `slot`
*   `entities`

### サポートされている PII エンティティタイプ

匿名化パイプラインでは、エンティティ認識エンジンと匿名化ツールの両方として [Microsoft Presidio](https://microsoft.github.io/presidio/text_anonymization/) が使用されます。Presidio は、幅広いエンティティ型と匿名化方法をサポートするオープンソース ライブラリです。

匿名化ルールで[、すぐにサポートされている Presidio エンティティ タイプ](https://microsoft.github.io/presidio/supported_entities/)を指定できます。現在、Rasa Pro匿名化パイプラインにカスタムエンティティタイプを追加することはできません。

## 匿名化ルールの書き方

`endpoints.yml`で匿名化ルールを記述して、どの Presidio エンティティを匿名化するかを明示的に宣言できるようになりました。匿名化パイプラインは、`endpoints.yml` ファイルの`匿名化`セクションを使用して構成できます。このセクションには、次の例に示す構造が必要です。

```yaml
anonymization:
  metadata:
    language: en
    model_name: en_core_web_lg
    model_provider: spacy
  rule_lists:
    - id: rules_1
      rules:
        - entity: PERSON
          substitution: text
          value: John Doe
        - entity: LOCATION
          substitution: faker
        - entity: CREDIT_CARD
          substitution: faker
        - entity: IBAN_CODE
          substitution: faker
    - id: rules_2
      rules:
        - entity: CREDIT_CARD
          substitution: mask
        - entity: IBAN_CODE
          substitution: mask
```

### メタデータセクションに入力する方法

メタデータセクションには、`言語`、`model_name`、`model_provider`のフィールドが含まれています。

`言語`フィールドは、匿名化するテキストの言語コードを指定します。匿名化パイプラインごとに指定できる言語は 1 つだけであるため、この機能は現在、エンド ユーザーによる言語切り替えを処理できないことに注意してください。

`model_name` フィールドと `model_provider` フィールドは、匿名化に使用する Presidio モデルの名前とプロバイダーを指定します。使用可能なモデル・プロバイダーは、`spacy`、`stanza`、および `transformers` です。

`spacy` を使用する場合は、`en_core_web_lg` や `es_core_news_lg` などの利用可能な大型モデルを使用することを強くお勧めします。これは、より正確なエンティティ認識を保証するためです。

> [!caution] 
> 大規模なモデルを使用する場合は、Rasa Pro 環境にモデルをロードするのに十分なメモリーがあることを確認する必要があります。

`トランスフォーマー` モデル プロバイダーの使用を選択した場合は、`model_name` フィールドに 2 つのモデル名 (HuggingFace モデル名と spaCy モデル名) を指定する必要があります。例えば：

```yaml
anonymization:
  metadata:
    language: en
    model_name:
       spacy: en_core_web_lg
       transformers: dslim/bert-base-NER
    model_provider: transformers
```

#### 言語モデルのインストール方法

宣言したモデルを Rasa Pro 環境の `model_name` フィールドにインストールする必要があります。例えば、`model_name: en_core_web_lg` を宣言する場合は、Rasa Pro 環境に spaCy `en_core_web_lg` モデルをインストールする必要があります。spaCy および stanza モデルのモデルのインストール手順は、[Presidio の公式ドキュメント](https://microsoft.github.io/presidio/analyzer/nlp_engines/spacy_stanza/)で行うことができます。

`トランスフォーマー`・モデル・プロバイダーの場合、Rasa Pro 環境の `model_name` フィールドで宣言した*両方の*モデルをインストールする必要があります。たとえば、`endpoints.yml` `transformers: dslim/bert-base-NER` で宣言する場合は、Rasa Pro 環境に `dslim/bert-base-NER` モデルをインストールする必要があります。`HuggingFace`のモデルダウンロード手順は、[Presidio公式ドキュメント](https://microsoft.github.io/presidio/analyzer/nlp_engines/transformers/)にあります。

> [!note] 
> すべての言語に事前学習済みの言語モデルがあるわけではありません。事前トレーニング済みの言語モデルが使用できない言語を使用する場合は、独自の [spaCy](https://spacy.io/usage/training)、[スタンザ](https://stanfordnlp.github.io/stanza/training.html)、または [huggingface](https://huggingface.co/docs/transformers/training) モデルをトレーニングし、Rasa Pro 環境にインストールする必要があります。

### rule_listsセクションに入力する方法

`rule_lists`セクションには、匿名化ルールのリストのリストが含まれています。各ルール・リストには、string 型の一意の `ID` と`ルール`のリストが必要です。各ルールには、`エンティティ` フィールドと`置換`フィールドが必要です。`エンティティ` フィールドは、匿名化する Presidio エンティティ タイプを指定し、大文字にする必要があります。現在、正規表現はエンティティの識別にはサポートされていないことに注意してください。

`置換`フィールドは、使用する匿名化方法を指定します。現在、次の匿名化方法がサポートされています: `テキスト`、`マスク`、`フェイカー`:

*   `テキスト`匿名化メソッドは、元のエンティティ値を`値`フィールドで指定された値に置き換えます。次の例では、`PERSON` エンティティ値を `John Doe` に置き換えます。

```yaml
anonymization:
  metadata:
    language: en
    model_name: en_core_web_lg
    model_provider: spacy
  rule_lists:
    - id: rules_1
      rules:
        - entity: PERSON
          substitution: text
          value: John Doe
```

*   `マスク`匿名化メソッドは、文字 '*' を使用して、元のエンティティ値を同じ長さのマスクに置き換えます。たとえば、元のエンティティ値が `John Doe` の場合、匿名化された値は になります。

```yaml
anonymization:
  metadata:
    language: en
    model_name: en_core_web_lg
    model_provider: spacy
  rule_lists:
    - id: rules_1
      rules:
        - entity: PERSON
          substitution: mask
```

*   `faker` 匿名化方式は、元のエンティティ値を [Faker](https://faker.readthedocs.io/en/stable/) ライブラリによって生成された偽の値に置き換えます。たとえば、元のエンティティ値が `John Doe` の場合、匿名化された値は Faker ライブラリによって生成された偽の名前に置き換えられます。

```yaml
anonymization:
  metadata:
    language: en
    model_name: en_core_web_lg
    model_provider: spacy
  rule_lists:
    - id: rules_1
      rules:
        - entity: PERSON
          substitution: faker
```

置換方法が指定されていない場合、デフォルトの置換方法は`マスク`です。

`value` フィールドは、`テキスト`匿名化メソッドでのみ必要です。匿名化された値として使用するテキストを指定します。`value` フィールドが指定されていない場合、匿名化される元のエンティティ値は、角かっこで囲まれたエンティティ タイプ名に置き換えられます。たとえば、`値`フィールドが `PERSON` エンティティ タイプに指定されていない場合、匿名化された値は `<PERSON>` になります。

`フェイカー`匿名化方式では、[フェイカー](https://faker.readthedocs.io/en/stable/) ライブラリを使用して偽のデータを生成します。デフォルトでは、`フェイカー`匿名化メソッドは、ローカライズされたPresidioエンティティタイプが使用されない限り、英語で偽のデータを生成します。たとえば、`ES_NIF`エンティティタイプに`偽物`置換方法を使用すると、生成される偽データはスペイン語NIFの形式と一致します。

`偽造者`置換メソッドは、次のPresidioエンティティタイプをサポートしていません。

*   `暗号`、`NRP`、`MEDICAL_LICENSE`
*   `US_BANK_NUMBER`、`US_DRIVER_LICENSE`
*   `UK_NHS`
*   `IT_FISCAL_CODE`、`IT_DRIVER_LICENSE`、`IT_PASSPORT`、`IT_IDENTITY_CARD`
*   `SG_NRIC_FIN`
*   `AU_ABN`、`AU_ACN`、`AU_TFN`、`AU_MEDICARE`

上記のエンティティのいずれかが`フェイカー`置換方法と一緒に使用される場合、匿名化パイプラインはデフォルトで`マスク`置換方法になります。

## Kafka イベントブローカー設定を更新する方法

匿名化パイプラインは Kafka を使用して、匿名化ルール・リストにマップされている Kafka トピックに匿名化されたイベントを公開します。Kafka イベントブローカーは、`endpoints.yml`ファイルで設定できます。Kafka イベントブローカーには、以下の構造を持つ必要がある `anonymization_topics` セクションが含まれている必要があります。

```yaml
event_broker:
  type: kafka
  partition_by_sender: True
  security_protocol: PLAINTEXT
  url: localhost
  anonymization_topics:
    - name: topic_1
      anonymization_rules: rules_1
    - name: topic_2
      anonymization_rules: rules_2
  client_id: kafka-python-rasa
```

`anonymization_topics` セクションには、匿名化されたイベントが公開される Kafka トピックのリストが含まれています。各 Kafka トピックには`、名前`フィールドと`anonymization_rules`フィールドが必要です。`name` フィールドは、Kafka トピックの名前を指定します。`anonymization_rules` フィールドは、Kafka トピックに使用される匿名化ルールリストの `ID` を指定します。

### Kafka を使用した Rasa X/Enterprise への匿名化されたイベントのストリーミング

Rasa X/Enterprise への匿名化されたイベントのストリーミングは、Rasa X/Enterprise バージョン `1.3.0` 以降でのみサポートされます。さらに、Kafka イベントブローカーを使用する必要があり、他のイベントブローカータイプはサポートされていません。

`anonymization_topics` セクションに `rasa_x_consumer: true` キーと値のペアを追加することで、Kafka 経由で匿名化されたイベントを Rasa X/Enterprise にストリーミングできます。

```yaml
event_broker:
  type: kafka
  partition_by_sender: True
  url: localhost
  anonymization_topics:
    - name: topic_1
      anonymization_rules: rules_1
      rasa_x_consumer: true
    - name: topic_2
      anonymization_rules: rules_2
```

複数の Kafka 匿名化トピックに`rasa_x_consumer`キーと値のペアが含まれている場合、匿名化されたイベントは、`rasa_x_consumer` キーと値のペアを含む`anonymization_topics`リストの最初のトピックにマッピングされた Kafka トピックにストリーミングされます。

`rasa_x_consumer`キーと値のペアはオプションであることに注意してください。指定しない場合、匿名化されたイベントは Kafka トピックに公開されますが、Rasa X/Enterprise にはストリーミングされません。

## ログ内の PII の匿名化を有効にする方法

ログ内の PII の匿名化を有効にするには、`endpoints.yml` ファイルの`ロガー`セクションに入力します。`ロガー`セクションは、次の構造を持つ必要があります。

```yaml
logger:
  formatter:
    anonymization_rules: rules_1
```

`anonymization_rules` フィールドは、ログに使用する匿名化ルール リストの `ID` を指定します。

> [!caution] 
> 本番環境では、ログ レベルの INFO を使用して実行することを強くお勧めします。ログ・レベル DEBUG で実行すると、処理遅延によりアシスタントの応答待ち時間が長くなります。

Kafka イベントブローカーを使用して `rasa シェル`をデバッグモードで実行すると、イベントの公開に関連するログがボットメッセージ**の後に**コンソールに出力される可能性があることに注意してください。この動作は、イベントの匿名化と公開がバックグラウンドタスクとして非同期的に行われるため、アシスタントがボットの応答をすでに予測して実行した後に完了するため、予期されます。