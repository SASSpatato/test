---
sidebar_label: Tracing
title: Tracing
description: Resolve performance issues faster and identify bottlenecks
  through OpenTelemetry-based tracing
---

## トレーシング

分散トレースは、分散システム (この場合は Rasa アシスタント) を通過する要求を追跡し、要求に関するデータを**トレース バックエンド**に送信し、トレース バックエンドはすべてのトレース データを収集して検査できるようにします。トレース データは、単一のサービスのコンポーネント (Rasa 自体) と、アクション サーバーなどの異なる分散サービス間の要求のフローを理解するのに役立ちます。

### サポートされているトレースバックエンド/コレクター

Rasa Pro でリクエストをトレースするには、 [Jaeger](https://www.jaegertracing.io/) をバックエンドとして使用するか、[OTEL コレクタ (OpenTelemetry Collector)](https://opentelemetry.io/docs/collector/) を使用します。を使用してトレースを収集し、選択したバックエンドに送信します。手順については、[[#Configuring a Tracing Backend or Collector]] を参照してください。

### 有効化/無効化

トレースは、Rasa Proで自動的に有効になります [[#トレースバックエンドまたはコレクタの設定|サポートされているトレースバックエンドの構成]]トレースを有効にするためにそれ以上のアクションは必要ありません。

エンドポイントファイルで `tracing:` 設定キーを空のままにすることで、トレースを無効にできます。

### ラサチャンネル

[W3C トレース コンテキスト仕様](https://www.w3.org/TR/trace-context/)を使用して要求とともに送信されるトレース コンテキスト REST チャネル経由で Rasa Pro でトレースを続行するために使用されます。

### アクションサーバー

Rasa Pro からのトレース・コンテキストは、[W3C トレース・コンテキスト仕様](https://www.w3.org/TR/trace-context/)を使用してカスタム・アクション・サーバーへの要求とともに送信され、カスタム・アクション・サーバーを介して要求のトレースを続行するために使用されます。

トレースは、カスタム アクションを受信する Webhook をインストルメント化することによって、アクション サーバーで継続されます。トレース コンテキストの一部としてキャプチャされた属性については、「[[#アクションサーバー属性]] 」を参照してください。

Rasa Proのトレースコンテキストの一部として使用できる属性の詳細については、[[#トレースされたイベント]]を参照してください。

## トレースバックエンドまたはコレクタの設定

トレースバックエンドまたはコレクターを構成するには、エンドポイント、`つまりendpoints.yml`ファイル、またはデプロイのHelm値の関連セクションにト`レース`エントリを追加します。

### ジャガー

Jaeger トレースバックエンドを設定するには、`タイプ`を `jaeger` として指定します。

```yaml
tracing:
  type: jaeger
  host: localhost
  port: 6831
  service_name: rasa
  sync_export: ~
```

### OTEL コレクター

コレクターは、ベンダーに依存しない方法でトレースを収集し、さまざまなバックエンドに転送するコンポーネントです。たとえば、OpenTelemetry Collector (OTEL) は、複数の異なるコンポーネントやインストルメンテーション ライブラリからトレースを収集し、jaeger などの複数の異なるバックエンドにエクスポートできます。

OTEL コレクタを設定するには、`タイプ`を `otlp` として指定します。

```yaml
tracing:
  type: otlp
  endpoint: my-otlp-host:4318
  insecure: false
  service_name: rasa
  root_certificates: ./tests/unit/tracing/fixtures/ca.pem
```

## トレースされたイベント

追跡可能な Rasa サービス・エリアは、以下のために必要なアクションを対象としています。

*   **モデルのトレーニング**(つまり、各[グラフコンポーネント](https://rasa.com/docs/rasa/custom-graph-components#graph-components)のトレーニング)
*   **メッセージを処理する**

### モデルトレーニング

トレースは、Rasa [`GraphTrainer`](https://rasa.com/docs/rasa/reference/rasa/engine/training/graph_trainer/#graphtrainer-objects) クラスと [`GraphNode`](https://rasa.com/docs/rasa/reference/rasa/engine/graph/#graphnode-objects) クラスをインストルメント化することで、モデル トレーニングに対して有効になります。

#### `グラフトレーナー` 属性

`GraphTrainer` のトレーニング中に、次の属性を検査できます。

*   モデル構成の`training_type`:
    *   `"NLU"`
    *   `"CORE"`
    *   `"BOTH"`
    *   `"END-TO-END"`
*   モデル構成の`言語`
*   `config.yml`ファイルで使用される`recipe_name`
*   `output_filename`: パッケージ化されたモデルが保存される場所
*   `is_finetuning`: ブール引数 (True の場合、`増`分トレーニングが有効になります)

#### `グラフノード` 属性

次の属性は、すべてのグラフノードのトレーニング中(およびメッセージ処理中の予測中)にキャプチャされます。

*   `node_name`
*   `component_class`
*   `fn_name`:呼び出されるコンポーネントクラスのメソッド

### メッセージ処理

次の Rasa クラスは、メッセージ処理中にトレースを有効にするためにインストゥルメント化されています。

*   [`Agent`](https://rasa.com/docs/rasa/reference/rasa/core/agent/#agent-objects)
*   [`MessageProcessor`](https://rasa.com/docs/rasa/reference/rasa/core/processor/#messageprocessor-objects)
*   [`TrackerStore`](https://rasa.com/docs/rasa/tracker-stores)
*   [`LockStore`](https://rasa.com/docs/rasa/lock-stores)

つまり、これらの操作が追跡可能になりました。

*   メッセージの受信
*   メッセージの解析
*   次のアクションの予測
*   アクションの実行
*   トラッカーの取得と保存
*   会話をロックする
*   イベントブローカーへの公開
*   アクション・サーバーへのトレース・コンテキストの受け渡し

#### `エージェント` 属性

メッセージを処理する`エージェント`・インスタンスをトレースすると、次の属性がキャプチャーされます。

*   `input_channel`: チャネルコネクタの名前
*   `sender_id`: 会話 ID
*   `model_id`: モデルの一意の識別子
*   `model_name`:モデル名

#### `メッセージプロセッサ` 属性

トレース中に次の `MessageProcessor` 属性が抽出されます。

*   `number_of_events`:トラッカー内のイベント数
*   `action_name`: 予測および実行されたアクションの名前
*   `sender_id`: `DialogueStateTracker` オブジェクトの会話 ID
*   `message_id`: 一意のメッセージ ID

後者の 3 つの属性は、カスタム アクション サーバーに対して行われた要求に渡されるトレース コンテキストにも挿入されます。

#### `TrackerStore` と `LockStore` の属性

監視可能な `TrackerStore` 属性と `LockStore` 属性には、次のものが含まれます。

*   `number_of_streamed_events`: ストリーミングする新しいイベントの数
*   `broker_class`: 新しいイベントが公開される`イベント・ブローカ`
*   `lock_store_class`: メッセージがアクティブに処理されている間に会話をロックするために使用されるロックストアの名前

## アクション サーバーでのトレース

API リクエストは、カスタムアクションを受信する Webhook をインストルメント化することで、アクションサーバーを通過するときにトレースされます。

### アクションサーバー属性

次の属性は、トレース コンテキストの一部としてキャプチャされます。

*   `http.method`: リクエストを行うために使用される HTTP メソッド
*   `http.route`: リクエストのエンドポイント
*   `next_action`: 次に実行するアクションの名前
*   `version`: 使用される RASA バージョン
*   `sender_id`: メッセージの送信元の ID
*   `message_id`: 一意のメッセージ ID

また、[スパンを作成する](https://opentelemetry.io/docs/instrumentation/python/manual/#creating-spans)ことで、カスタムアクションコードに沿ってリクエストのトレースを続行することもできます を使用して、任意のオブジェクトの実行を追跡します。

アクション・サーバーでのトレースの有効化と無効化も、説明されている [[#有効化/無効化|above]] と同じ方法で行います。[[#トレースバックエンドまたはコレクタの設定/Collectors|above]] にリストされているのと同じトレース・バックエンド/コレクターも、アクション・サーバーでサポートされています。詳細な手順については、[[#トレースバックエンドまたはコレクタの設定]] を参照してください。