---
sidebar_label: Load Testing Guidelines
title: Load Testing Guidelines
description: |
  Information about how best to scale up your bot to support parallel user activity
  and how you can use tracing to help debug issues.
---

## 概要

負荷とユーザーの増加を処理するシステムの能力に関するメトリックを収集するために、Rasa アシスタントが特定のマシン構成で処理できる最大同時ユーザー数を評価するテストを実行しました。各テストケースでは、毎秒 1000 人のユーザーの[生成速度](https://docs.locust.io/en/1.5.0/configuration.html#all-available-configuration-options)を使用して、ピーク時の同時実行時に次の数の同時ユーザーを生成しました。テストでは、Rasa [HTTP-API](https://rasa.com/docs/rasa/pages/http-api) と [Locust](https://locust.io/) オープンソースのロードテストツールを使用しました。

| ユーザー | CPU | 記憶 |
| --- | --- | --- |
| 最大50,000 | 6vCPU | 16ギガバイト |
| 最大80,000 | 6vCPU、CPU使用率がほぼ90% | 16ギガバイト |

### スケールアップ中のボット関連の問題のデバッグ

多数の同時ユーザーアクティビティを処理する Rasa [HTTP-API](https://rasa.com/docs/rasa/pages/http-api) 機能をテストするために、Rasa Pro [トレース](./tracing.md)機能とトレースバックエンドまたは Jaeger などのコレクターを使用して、テスト対象のボットのトレースを収集しました。

> [!note] 
> 私たちのチームは現在、追加のパフォーマンス関連のテストを実行しています。さらに詳しい情報は、進行するにつれてここに追加されます。