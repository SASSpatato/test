---
id: example-queries
sidebar_label: Example queries
title: Example queries
description:
---

このセクションは、アシスタントの会話の分析を開始するのに役立ちます。この例では、SQL 照会とメタベースの視覚化の例を使用します。

会話のその他のメトリックとカテゴリについては、「\[\[getting-started-with-analytics#メトリックの種類|メトリックの種類\]\]を参照してください。

## 月間セッション数

アシスタントの一般的な高レベルの使用状況メトリックは、月あたりのセッション数です。SQL 照会としては次のようになります。

```sql
SELECT
  date_trunc('month', "public"."rasa_session"."timestamp") AS "first_seen",
  count(*) AS "count"
FROM "public"."rasa_session"
GROUP BY 1
ORDER BY 1 ASC
```

![Number of sessions per month visualized in Metabase.](/static/img/analytics/graph-number-sessions-month.png )

Metabaseで視覚化された月あたりのセッション数。

## チャネルあたりのセッション数

アシスタントを複数のチャネルに接続している場合は、チャネルごとのセッション数 (たとえば週あたり) を確認すると便利です。このメトリックに必要なクエリは次のとおりです。

```sql
SELECT
  "public"."rasa_sender"."channel" AS "channel",
  "public"."rasa_sender"."first_seen" AS "timestamp",
  count(distinct "public"."rasa_sender"."sender_key") AS "count"
FROM "public"."rasa_sender"
GROUP BY 1, 2
ORDER BY 1 ASC, 2 ASC
```

![Number of sessions per channel visualized in Metabase.](/static/img/analytics/graph-number-sessions-channel.png )

Metabase で視覚化されたチャネルごとのセッション数。

## 上位 N のインテント

アシスタントを改善するために、ユーザーが表現するさまざまなインテントを調べることができます。以下のクエリは、そのトピックについて適切な視点を持つのに役立つ上位 5 つのインテントを選択します。

```sql
SELECT
  "public"."rasa_user_message"."intent" AS "intent",
  count(*) AS "count"
FROM "public"."rasa_user_message"
GROUP BY 1
ORDER BY 2 DESC, 1 ASC
LIMIT 5
```

![Top 5 intents visualized in Metabase.](/static/img/analytics/graph-top-5-intents.png )

Metabase で視覚化された上位 5 つのインテント。

さらに、時間の経過に伴うインテント分布を調べることができます。

```sql
SELECT
  "public"."rasa_user_message"."intent" AS "intent",
  date_trunc('month', "public"."rasa_user_message"."timestamp") AS "timestamp",
  count(*) AS "count" FROM "public"."rasa_user_message"
GROUP BY 1, 2
ORDER BY 1 ASC, 2 ASC
```

![Intent distribution over time visualized in Metabase.](/static/img/analytics/graph-intent-distribution.png )

メタベースで視覚化された時間の経過に伴うインテント分布。

## エスカレーション率

エスカレーション率または人間の引き継ぎ率は、アシスタントが人間のエージェントに渡す会話の数の尺度です。このメトリックは、会話中に何が起こるかをよりよく理解するのに役立ちます。`handoff_to_support`という名前のインテントがあるとします。このサンプルクエリを使用して、時間の経過に伴うエスカレーション率を取得します。

```sql
WITH "sessions" AS (
    SELECT
        "public"."rasa_user_message"."session_id" AS "session_id",
        date_trunc('month', "public"."rasa_user_message"."timestamp") AS "timestamp",
        (
          CASE "public"."rasa_user_message"."intent"
            WHEN 'handoff_to_support'
            THEN 1 ELSE 0
          END
        ) AS "has_handoff_to_support"
    FROM "public"."rasa_user_message"
),
"sessions_with_handoff" AS (
    SELECT
      "session_id",
      "timestamp",
      SUM("has_handoff_to_support") AS "has_handoff_to_support"
    FROM "sessions"
    GROUP BY 1, 2
)
SELECT
  "timestamp",
  SUM("has_handoff_to_support") / count(*) AS "escalation_rate"
FROM "sessions_with_handoff"
GROUP BY 1 ASC
ORDER BY 1 ASC
```

![Escalation rate visualized in Metabase.](/static/img/analytics/graph-escalation-rate.png )

エスカレーション率をメタベースで視覚化。

## 放棄率

放棄率はさまざまなカスタム方法で定義できますが、ここでは、ボットが特定のメッセージ (`utter_ask_name` など) を発した後、ユーザー メッセージなしで終了するセッションとして定義します。特定のインテント セットの後にユーザー メッセージなしで終了するセッションを検出するようにメトリックを調整できます。SQL クエリは次のようになります。

```sql
WITH "sessions" AS (
    SELECT
        DISTINCT ON ("public"."rasa_event"."session_id") "public"."rasa_event"."session_id",
        "public"."rasa_event"."timestamp" AS "timestamp",
        (
            CASE
                WHEN "public"."rasa_bot_message"."template_name" = 'utter_ask_name'
                THEN 1 ELSE 0
            END
        ) AS "is_abandonned"
    FROM "public"."rasa_event"
    INNER JOIN "public"."rasa_bot_message"
      ON "public"."rasa_event"."id" = "public"."rasa_bot_message"."event_id"
    WHERE "public"."rasa_event"."event_type" = 'bot'
    ORDER BY 1, 2 DESC
)
SELECT
  date_trunc('month', "timestamp") AS "timestamp",
  SUM("is_abandonned")::float / count(*) AS "abandonment_rate"
FROM "sessions"
GROUP BY 1
ORDER BY 1 ASC
```

![Abandonment rate visualized in Metabase.](/static/img/analytics/graph-abandonment-rate.png )

メタベースで可視化した放棄率。