---
id: getting-started-with-analytics
sidebar_label: Getting started
title: Getting started with Analytics
description:
abstract: Visualise and process Rasa assistant metrics in the
  tooling of choice.
---

Analytics Data Pipelineは、選択したツール(BIツール、データウェアハウス)でRasaアシスタントのメトリックを視覚化して処理するのに役立ちます。本番アシスタントとその会話の視覚化と分析により、ROIを評価し、時間の経過とともにアシスタントのパフォーマンスを向上させることができます。

   ![Rasa Pro Analytics - Sessions per channel](/static/img/analytics/graph-number-sessions-channel.png ) ![Rasa Pro Analytics - Escalation rate](/static/img/analytics/graph-escalation-rate.png ) ![Rasa Pro Analytics - Intents distribution over time](/static/img/analytics/graph-intent-distribution.png ) ![Rasa Pro Analytics - Top intents](/static/img/analytics/graph-top-5-intents.png )

Rasa アシスタントの成功を測定し、戦略的投資を行うことは、より良いビジネス成果につながります。また、エンドユーザーのニーズを理解し、より良いサービスを提供するのにも役立ちます。

![An overview of the components of Rasa Pro.](/static/img/rasa-pro-analytics-overview.png )

Rasa Pro は、Kafka を使用して本番アシスタントに接続します。パイプラインは、Docker コンテナが正常にデプロイされ、データウェアハウスと Kafka インスタンスに接続されるとすぐに分析を計算します。

## メトリックの種類

アシスタントから収集されるメトリックは、大まかに次のように分類できます。

*   ユーザー分析: アシスタントのユーザーは誰で、アシスタントについてどのように感じていますか?例: 人口統計、チャネル、感情分析
*   使用状況分析: アシスタントの全体的な健全性はどうで、どのような種類のトラフィックがアシスタントに流入していますか?例: セッションの合計数、セッションあたりの時間、エラー、エラー率
*   会話分析: 会話中に何が起こったか?例: 送信されたメッセージの数、放棄の深さ、ユーザーによって導入されたトピックの数、上位 N の意図
*   ビジネス分析: ビジネス目標に関してアシスタントのパフォーマンスはどうですか?例: LoB ごとのアシスタントの ROI、アシスタントとエージェントの時間比較、封じ込め率

このバージョンの Analytics パイプラインでは、次の指標の測定が可能です

| メトリック | カテゴリ | 意味 |
| --- | --- | --- |
| 会話数 | 使用状況分析 | 会話の合計数 |
| ユーザー数 | 使用状況分析 | ユーザーの合計数 |
| セッション数 | 使用状況分析 | アシスタントへの総トラフィック |
| 使用チャンネル | 使用状況分析 | チャネル別のセッション |
| ユーザーセッション数 | ユーザー分析 | ユーザーセッションの合計数またはユーザーあたりの平均セッション数 |
| 上位 N のインテント | 会話分析 | すべてのユーザーの上位の意図 |
| 平均応答時間 | 会話分析 | アシスタントの平均応答時間 |
| 封じ込め率 | ビジネス分析 | アシスタントによって純粋に処理された会話の割合(人間のエージェントに渡されない) |
| 放棄率 | ビジネス分析 | 放棄された会話の割合 |
| エスカレーション率 | ビジネス分析 | 会話が人間のエージェントにエスカレーションされた割合 |

これらのメトリクスを抽出する方法の例については、「[クエリの例](./example-queries.md)」を参照してください。

## 前提 条件

*   Rasa Pro をセットアップするには、Kafka の本番環境デプロイが必要です。[Amazon Managed Streaming for Apache Kafka](https://aws.amazon.com/msk/) を使用することをお勧めします。
    
*   データレイクの本番デプロイメントは、データパイプラインに接続する必要があります。Rasa Proは、次のデータレイクを直接サポートします。
    
    *   [PostgreSQL](https://aws.amazon.com/rds/postgresql/) ( **推奨**されます。すべてのPostgreSQL >= 11.0がサポートされています)
    *   [Amazon Redshift](https://aws.amazon.com/redshift/)
    
    事実上、他のすべてのデータレイクは、PostgreSQL のデプロイと同期するように構成できます。PostgreSQL デプロイをいずれかの [BigQuery](#ビッグクエリ) に接続する方法については、その他の手順をご覧ください。 または [[#2. データウェアハウスを接続する|データウェアハウスの接続ステップ]]。
    
    メンテナンス作業を最小限に抑えるために、データレイクのマネージドデプロイをお勧めします。
    

## 1. アシスタントを接続する

アシスタントを Rasa Pro Services に接続するには、アシスタントをイベントブローカーに接続する必要があります。アシスタントはすべてのイベントをイベントブローカーにストリーミングし、Rasa Pro Services によって消費されます。

アシスタントの構成は、[[deploy-rasa-pro-services#インストールと構成|インストールと構成]] の最初のステップです。アシスタントを Analytics パイプラインに接続するために追加の構成は必要ありません。アシスタントがデプロイされると、Analytics パイプラインはアシスタントからデータを受信し、次のステップで構成されるデータウェアハウスに永続化します。

## 2. データウェアハウスを接続する

変換された会話データを AWS の 2 つの異なるデータウェアハウスタイプにストリーミングするように分析パイプラインを設定することを選択できます。

*   [PostgreSQL](#postgresql)
*   [赤方偏移](#赤方偏移)

さらに、PostgreSQL のデプロイと同期して構成されている場合、すべてのデータ ウェアハウスがサポートされます [[#PostgreSQL から Redshift へのストリーミング]]。

PostgreSQLデプロイを以下と同期するための簡単な手順が含まれています。

*   [ビッグクエリ](#ビッグクエリ)
*   [snowflake](#snowflake)

### PostgreSQL

Amazon Relational Database Service (RDS) を使用して、PostgreSQL データベースを実行する環境である PostgreSQL DB インスタンスを作成できます。

まず、記載されている手順に従って Amazon RDS を設定する必要があります [ここで](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_SettingUp.html)。次に、PostgreSQL DB インスタンスを作成します。次のいずれかの命令セットに従うことができます。

*   [**PostgreSQL DB インスタンスの作成」**セクション](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_GettingStarted.CreatingConnecting.PostgreSQL.html#CHAP_GettingStarted.Creating.PostgreSQL)に記載されている AWS *Easy 作成*手順
*   AWS [*Standard の作成*手順](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_CreateDBInstance.html)

[[#1. アシスタントを接続する|アシスタントの接続]]で指定されたDBAPI形式でDB URLを構築するには、データベースの資格情報を入力する必要があります。PostgreSQL DBインスタンスの作成プロセス中にデータベース認証オプションを選択した後、データベースのユーザー名とパスワードを取得する必要があります。

*   データベース資格情報のみを使用するパスワード**認証** (その場合は、マスターユーザー名のユーザー名を入力し、マスターパスワードを生成する必要があります)。
*   [**パスワードと IAM DB 認証**](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/UsingWithRDS.IAMDBAuth.html) を使用して、データベースユーザーの認証にIAMユーザーおよびロールを使用します。
*   [**パスワードと Kerberos 認証**](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/postgresql-kerberos.html)

最後に、Analytics パイプライン Docker コンテナを実行するときに、[[deploy-rasa-pro-services#Docker コンテナー構成 (リファレンス)|environment variable `RASA_ANALYTICS_DB_URL`]] を PostgreSQL Amazon RDS DB インスタンスの URL に設定します。

### 赤方偏移

代わりに、データレイクの選択として Amazon Redshift を設定する場合は、[**PostgreSQL ステップ**](#postgresql)で作成された Amazon RDS DB インスタンス内の PostgreSQL ソースデータベースからデータをストリーミングすることを選択できます Redshift ターゲットに、または Amazon Redshift に [[#Direct connection|direct connect]] に。

#### PostgreSQL から Redshift へのストリーミング

前提[条件](https://docs.aws.amazon.com/dms/latest/userguide/CHAP_Target.Redshift.html#CHAP_Target.Redshift.Prerequisites)を満たしている場合 Amazon Redshift データベースをターゲットとして使用するには、次の 2 つのステップを実装する必要があります。

1.  次の[手順](https://docs.aws.amazon.com/dms/latest/userguide/CHAP_Source.PostgreSQL.html)に従って、AWS Database Migration Service (DMS) の PostgreSQL ソースを設定します
2.  手順に従って AWS DMS の Redshift ターゲットを設定します [ここ](https://docs.aws.amazon.com/dms/latest/userguide/CHAP_Target.Redshift.html)。

#### Direct connection

Redshift との直接接続を有効にするには、[Amazon Redshift クラスター](https://docs.aws.amazon.com/redshift/latest/mgmt/working-with-clusters.html)の作成に関する次のリソースに従ってください。その前に、履歴データを Redshift に直接ストリーミングするよりも、PostgreSQL RDS インスタンスに直接ストリーミングするよりもはるかに時間がかかる可能性があることを考慮する必要があります。

`RASA_ANALYTICS_DB_URL`を Redshift クラスター DB URL に更新し、次の形式に従う必要があります。

```
redshift://<USER>:<PASSWORD>@<AWS URL>:5439/<DB NAME>
```

例えば：

```
redshift://awsuser:4324312adfaGQ@analytics.cp1yucixmagz.us-east-1.redshift.amazonaws.com:5439/analytics
```

> [!caution] 
> Redshift の書き込みパフォーマンスに関する注意パフォーマンスを考慮すると、Redshift への直接接続を選択しないことを強くお勧めします。Redshift は分析に最適なデータレイクですが、データを直接ストリーミングするために必要な書き込みパフォーマンスが欠けています。

### ビッグクエリ

PostgreSQL から BigQuery にデータをストリーミングするには、[Datastream for BigQuery](https://cloud.google.com/datastream/docs) を使用します。Datastream for BigQuery は、[CloudSQL](https://cloud.google.com/sql/docs/postgres) を含むいくつかの [PostgreSQL デプロイ タイプ](https://cloud.google.com/datastream/docs/configure-your-source-postgresql-database#overview)をサポートしています。

開始する前に、Datastream の[前提条件](https://cloud.google.com/datastream/docs/before-you-begin)と、追加の Datastream ネットワーク接続[要件](https://cloud.google.com/datastream/docs/quickstart-replication-to-bigquery#requirements)を確認してください。

Datastream を使用して PostgreSQL CloudSQL から BigQuery にデータをレプリケートする方法については[、このクイックスタート ガイド](https://cloud.google.com/datastream/docs/quickstart-replication-to-bigquery)に厳密に従ってください。

または、次のデータストリーム設定ガイドを詳しく調べることもできます。

*   [ソースPostgreSQLデータベースを構成する](https://cloud.google.com/datastream/docs/configure-your-source-postgresql-database)
*   オプション: [顧客管理の暗号化キー](https://cloud.google.com/datastream/docs/use-cmek)を使用する
*   [PostgreSQL データベースの接続プロファイル](https://cloud.google.com/datastream/docs/create-connection-profiles#cp4postgresdb)を作成する
*   [ストリーム](https://cloud.google.com/datastream/docs/create-a-stream)を作成する

### snowflake

PostgreSQL デプロイは、手動で同期することも、自動化された[パートナー ソリューション](https://docs.snowflake.com/en/user-guide/ecosystem-etl.html)を介して同期することもできます。

手動同期の手順には、次の手順が含まれます。

*   `COPY INTO`[コマンド](https://docs.snowflake.com/en/sql-reference/sql/copy-into-location.html)を使用して、PostgreSQLからファイルにデータを抽出します。また、抽出する前に、Snowflake[データ読み込みのベストプラクティス](https://docs.snowflake.com/en/user-guide/data-load-considerations.html)を調べる必要があります。
*   抽出されたデータファイルを、AWS S3、Google Cloud Storage、Microsoft Azure などの内部または外部の場所にステージングします。
*   `COPY INTO`[コマンド](https://docs.snowflake.com/en/sql-reference/sql/copy-into-table.html)を使用して、ステージングされたファイルをSnowflakeテーブルにコピーします。Snowflakeへの[バルクデータロード](https://docs.snowflake.com/en/user-guide/data-load-bulk.html)を使用するか、[Snowpipe](https://docs.snowflake.com/en/user-guide/data-load-snowpipe.html)を使用して継続的にロードするかを決定できます。または、[このプラグイン](https://cdap.atlassian.net/wiki/spaces/DOCS/pages/694157985/Cloud+Storage+to+Snowflake+Action)を利用して、既存のSnowflakeテーブルにデータをロードすることもできます。

## 3. 過去の会話を取り込む (オプション)

Analytics が Kafka インスタンスに接続されると、Kafka トピックの以前のすべてのイベントが消費され、データベースに取り込まれます。Kafka には、トピックのイベントに対する保持ポリシーがあり、[デフォルトは 7 日間です](https://docs.confluent.io/platform/current/installation/configuration/topic-configs.html#topicconfigs_retention.ms)。

Rasa トピックに設定された保持ポリシーよりも古い会話のイベントを処理する場合は、過去の会話からイベントを手動で取り込むことができます。

過去の会話からデータを手動で取り込むには、トラッカーストアへの接続が必要です。トラッカーストアには、過去の会話と Kafka クラスターへの接続が含まれています。`rasa export` コマンドを使用して、トラッカーストアに保存されているイベントを Kafka にエクスポートします。

```shell
rasa export --endpoints endpoints.yml
```

本番トラッカーストアから読み取り、イベントブローカーとしてKafkaに書き込むようにエクスポートを設定します。

```yaml-rasa
  tracker_store:
      type: SQL
      dialect: "postgresql"
      url: "localhost"
      db: "tracker"
      username: postgres
      password: password

  event_broker:
      type: kafka
      topic: rasa-events
      url: localhost:29092
      partition_by_sender: true
```

> [!note] 
> 過去のイベントを手動で取り込むことを複数回実行すると、イベントが重複します。現在、Analytics には重複排除は実装されていません。取り込まれたすべてのイベントは、以前に処理された場合でもデータベースに保存されます。

## 4. BIソリューションを接続する

ビジネスインテリジェンスプラットフォームとデータウェアハウスの接続方法は、プラットフォームごとに異なります。Metabase と Tableau の手順例を示しますが、AWS、Redshift、PostgreSQL をサポートする任意の BI プラットフォームを使用できます。

### 例: メタベース

Metabase は、無料のオープンソース ビジネス インテリジェンス プラットフォームです。データをクエリして視覚化するためのシンプルなインターフェイスを提供します。メタベースは、PostgreSQL または Redshift データベースに接続できます。

*   [Metabase を PostgreSQL に接続する](https://www.metabase.com/data_sources/postgresql)
*   [Metabase を Redshift に接続する](https://www.metabase.com/data_sources/amazon-redshift)

### 例: Tableau

Tableau はビジネス インテリジェンス プラットフォームです。ビジネス インテリジェンス ダッシュボードを構築するための柔軟なインターフェイスを提供します。Tableau は、PostgreSQL または Redshift データベースに接続できます。

*   [Tableau を PostgreSQL に接続する](https://help.tableau.com/current/pro/desktop/en-us/examples_postgresql.htm)
*   [Tableau と Redshift の接続](https://help.tableau.com/current/pro/desktop/en-us/examples_amazonredshift.htm)