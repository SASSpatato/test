---
id: telemetry
sidebar_label: Rasa Telemetry
title: Rasa Telemetry
abstract: |
  Rasa uses telemetry to report anonymous usage information. This information
  is essential to help improve Rasa for all users.
---

Rasaに取り組んでいるチームにとって、製品がどのように使用されているかを理解することが重要です。これにより、研究活動と機能開発に適切な優先順位を付けることができます。

Rasa を初めて実行すると、テレメトリレポートについて通知されます。

## オプトアウトする方法

テレメトリレポートは、次のコマンドを実行することでいつでもオプトアウトできます。

```bash
rasa telemetry disable
```

または、環境変数として `RASA_TELEMETRY_ENABLED=false` を定義します。レポートを再度有効にする場合は、次のコマンドを実行します。

```bash
rasa telemetry enable
```

## テレメトリレポートを使用する理由

匿名**の**テレメトリデータにより、使用状況に基づいて研究活動と機能開発に優先順位を付けることができます。高品質な製品を確保できるように、使用状況や信頼性に関する集計情報を収集したいと考えています。

では、報告されたテレメトリ データをどのように使用すればよいでしょうか?データの使用目的の例をいくつか示します。

*   どの言語、パイプライン、ポリシーが使用されているかを知ることができます。これにより、ユーザーに最も大きな影響を与えるテキストと対話を処理するプロジェクトに研究努力を向けることができます。
*   データセットのサイズと一般的な構造(インテントの数など)を知ることができます。これにより、さまざまなタイプのデータセットでソフトウェアをより適切にテストし、フレームワークのパフォーマンスを最適化できます。
*   アシスタントの構築中に発生するエラーの種類(初期化、トレーニングなど)について、より詳細に取得できます。これにより、フレームワークの品質が向上し、より一般的でイライラする問題の解決に時間を集中できるようになります。

## 機密データはどうですか?

機密データがマシンから離れることはありません。私たち：

*   個人を特定できる情報を報告**しない**
*   トレーニング データを報告**しない**
*   アシスタントが送受信したメッセージを報告**しない**

> [!note]  報告された内容を検査する 
> train コマンドの実行など、環境変数 `RASA_TELEMETRY_DEBUG=true` を定義することで、報告されるすべてのテレメトリ情報を表示できます。
> 
> ```bash
> RASA_TELEMETRY_DEBUG=true rasa train
> ```
> 
> `RASA_TELEMETRY_DEBUG`を設定すると、情報はどのサーバーにも送信されず、代わりに json ダンプとしてコマンドラインに記録され、検査できます。

## 何を報告しますか?

Rasaは、集計された使用状況の詳細、コマンド呼び出し、パフォーマンス測定、およびエラーを報告します。テレメトリ データを使用して、使用パターンをよりよく理解します。報告されたデータは、将来の機能を設計し、現在の作業に優先順位を付ける方法をより適切に決定することを直接可能にします。

具体的には、すべてのテレメトリイベントについて次の情報を収集します。

*   報告されたイベントの種類 (*例: トレーニング開始)*
*   Rasa マシン ID: これは UUID で生成され、グローバル Rasa 設定の `~/.config/rasa/global.yml` に保存され、`metrics_id`として送信されます。
*   現在の作業ディレクトリの一方向ハッシュまたはgit remoteのハッシュ
*   一般的な OS レベルの情報 (オペレーティング・システム、CPU の数、GPU の数、およびコマンドが CI 内で実行されているかどうか)
*   現在の Rasa および Python バージョン
*   コマンドが Docker コンテナー内で実行されているかどうか
*   ライセンスのハッシュ(Rasa Proを使用している場合)

実行後に Rasa に報告されたデータを示すレポートの例を次に示します `ラサトレイン`:

```json
{
  "userId": "38d23c36c9be443281196080fcdd707d",
  "event": "Training Started",
  "properties": {
    "language": "en",
    "num_intent_examples": 68,
    "num_entity_examples": 0,
    "num_actions": 17,
    "num_templates": 6,
    "num_conditional_response_variations": 5,
    "num_slot_mappings": 10,
    "num_custom_slot_mappings": 2,
    "num_conditional_slot_mappings": 3,
    "num_slots": 0,
    "num_forms": 0,
    "num_intents": 6,
    "num_entities": 0,
    "num_story_steps": 5,
    "num_lookup_tables": 0,
    "num_synonyms": 0,
    "num_regexes": 0,
    "metrics_id": "38d23c36c9be443281196080fcdd707d"
  },
  "context": {
    "os": {
      "name": "Darwin",
      "version": "19.4.0"
    },
    "ci": false,
    "project": "a0a7178e6e5f9e6484c5cfa3ea4497ffc0c96d0ad3f3ad8e9399a1edd88e3cf4",
    "python": "3.7.5",
    "rasa_open_source": "2.0.0",
    "cpu": 16,
    "docker": false,
    "license_hash": "t1a7170e6e5f9e6484c5cfa3ea4497ffc0c96a0ad3f3ad8e9399adadd88e3cf5"
  }
}
```

データセットから**個々のユーザーを特定することはできません**。匿名化されており、ユーザーを追跡することはできません。