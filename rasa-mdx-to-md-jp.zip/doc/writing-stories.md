---
id: writing-stories
sidebar_label: Writing Conversation Data
title: Writing Conversation Data
abstract: Conversation data includes the stories and rules that make up
  the training data for your Rasa assistant's dialogue management
  model. Well-written conversation data allows your assistant to reliably
  follow conversation paths you've laid out and generalize to
  unexpected paths.
---

## ストーリーのデザイン

ストーリーをデザインする際には、ハッピーパスとハッピーパスの2つのグループを考慮する必要がある会話型インタラクションがあります。ハッピーパスは、ユーザーが期待どおりに会話フローに従い、プロンプトが表示されたら常に必要な情報を提供するタイミングを表します。ただし、ユーザーは質問、おしゃべり、またはその他の質問で幸せな道から逸脱することがよくあります。私たちはこれを不幸な道と呼びます。

ボットが不満なパスを適切に処理することは重要ですが、特定のユーザーがどのようなパスをたどるかを予測することも不可能です。多くの場合、開発者は、不幸なパスを設計するときに、起こりうるすべての分岐パスを考慮しようとします。ステートマシンで考えられるすべての状態(その多くは決して到達しない)を計画するには、多くの追加作業が必要であり、トレーニング時間が大幅に増加します。

代わりに、[会話主導の開発](./conversation-driven-development.md)をお勧めします 不幸な道を設計するときのアプローチ。 会話駆動型開発では、ボットをできるだけ早くテスト ユーザーと共有し、ユーザーが幸せなパスからどのように逸脱しているかを正確に知る実際の会話データを収集することを促進します。このデータから、ユーザーが何であるかを達成するためのストーリーを作成できます 彼らを幸せな道に導く方法を考え始めることを要求し、考え始めます。

## ストーリーを書くタイミングとルール

[ルールは](./rules.md)、常に同じパスをたどる必要がある会話の一部を処理するためにダイアログ マネージャーが使用するトレーニング データの一種です。

ルールは、以下を実装する場合に役立ちます。

*   [ワンターンの対話:](./chitchat-faqs.md) 一部のメッセージは、応答するためにコンテキストを必要としません。ルールは、インテントを応答にマッピングする簡単な方法であり、これらのメッセージに対する固定回答を指定します。
    
*   [フォールバック動作](./fallback-handoff.md): [[components#FallbackClassifier|FallbackClassifier]] を使用すると、特定のフォールバック動作で信頼度の低いユーザー メッセージに応答するルールを記述できます。
    
*   [フォーム](./forms.md): フォームの有効化と送信はどちらも、多くの場合、固定されたパスをたどります。フォーム中に[予期しない入力](./unexpected-input.md)を処理するルールを記述することもできます。
    

ルールは目に見えない会話に一般化されないため、シングルターンの会話スニペット用にルールを予約し、ストーリーを使用してマルチターンの会話をトレーニングする必要があります。

ボットが「greet」という意図を持つユーザーメッセージに対して固定応答「utter_greet」を返すルールの例は次のとおりです。

```yaml-rasa
rules:
- rule: Greeting Rule
  steps:
  - intent: greet
  - action: utter_greet
```

複数ターンの相互作用の場合は、次のようにストーリーを定義する必要があります。

```yaml-rasa
stories:
 - story: Greeting and ask user how they're doing
   steps:
   - intent: greet
   - action: utter_greet
   - action: utter_ask_how_doing
   - intent: doing_great
   - action: utter_happy
```

## 会話フローの管理

ストーリーズ内の会話フローを管理するためのヒントをいくつか紹介します。

### 会話に影響を与えるためにスロットを使用する場合

スロットはボットのメモリとして機能します。スロットを定義するときに、[[domain.md#スロット|slots]] が会話に影響を与えるかどうかを定義できます。プロパティ`influence_conversation`が `false` に設定されたスロットは、情報のみを格納できます。プロパティ `influence_conversation` が `true` に設定されているスロットは、そこに格納されている情報に基づいてダイアログ フローに影響を与える可能性があります。

スロットは、[[domain#スロットマッピング|slot-mappings]]に基づいて、すべてのユーザーメッセージの後に設定できます。また、ユーザーメッセージに応答して実行される[カスタムアクション](./actions.md)によって設定することもできます。会話に影響を与えるすべてのスロットは、ストーリーやルールに追加する必要があります。たとえば、カスタムアクションによって設定されたブールスロットを使用して、次のストーリーを使用して、その値に基づいてダイアログフローを制御できます。

```yaml-rasa
stories:
- story: Welcome message, premium user
  steps:
   - intent: greet
   - action: action_check_profile
   - slot_was_set:
     - premium_account: true
   - action: utter_welcome_premium

- story: Welcome message, basic user
  steps:
   - intent: greet
   - action: action_check_profile
   - slot_was_set:
     - premium_account: false
   - action: utter_welcome_basic
   - action: utter_ask_upgrade
```

スロットが会話フローに影響を与えたくない場合は、スロットのプロパティ `influence_conversation` を `false` に設定する必要があります。会話に影響を与えないスロットの`slot_was_set`イベントをストーリーに含める必要はありません。

### 分岐ロジックの実装

ストーリーを作成するとき、次のアクションは、カスタム アクションの 1 つで返される値に依存することがあります。このような場合は、スロットを返すことと、ボットが次に行うことに影響を与えるカスタム アクション コードを直接使用することとの間で適切なバランスを見つけることが重要です。

ボットの応答を決定するためにのみ値を使用する場合は、ストーリーで特徴付けされたスロットを使用するのではなく、カスタム アクション内に決定ロジックを埋め込むことを検討してください。これにより、全体的な複雑さが軽減され、ストーリーの管理が容易になります。

たとえば、次のストーリーを変換できます。

```yaml-rasa
stories:
- story: It's raining now
  steps:
  - intent: check_for_rain
  - action: action_check_for_rain
  - slot_was_set:
    - raining: true
  - action: utter_is_raining
  - action: utter_bring_umbrella

- story: It isn't raining now
  steps:
  - intent: check_for_rain
  - action: action_check_for_rain
  - slot_was_set:
    - raining: false
  - action: utter_not_raining
  - action: utter_no_umbrella_needed
```

1つのストーリーに:

```yaml-rasa
stories:
- story: check for rain
  steps:
  - intent: check_for_rain
  - action: action_check_for_rain
```

をカスタムアクションコードに置き換えます。

```python
def run(self, dispatcher, tracker, domain):
	is_raining = check_rain()
	if is_raining:
		dispatcher.utter_message(template="utter_is_raining")
		dispatcher.utter_message(template="utter_bring_umbrella")
	else:
		dispatcher.utter_message(template="utter_not_raining")
		dispatcher.utter_message(template="utter_no_umbrella_needed")
	return []
```

この値を使用して今後のアクション フローに影響を与える場合は、ストーリーを決定するために特徴付けされたスロットを返します。たとえば、新規ユーザーに関する情報を収集するが、リピーターは収集しない場合、ストーリーは次のようになります。

```yaml-rasa
stories:
- story: greet new user
  steps:
  - intent: greet
  - action: check_user_status
  - slot_was_set:
    - new_user: true
  - action: utter_greet
  - action: new_user_form
  - active_loop: new_user_form
  - active_loop: null

- story: greet returning user
  steps:
  - intent: greet
  - action: check_user_status
  - slot_was_set:
    - new_user: false
  - action: utter_greet
  - action: utter_how_can_help
```

### OR ステートメントとチェックポイントの使用

[[./stories.md#OR ステートメント|OR ステートメント]]と[[./stories.md#チェックポイント|checkpoints]]は、書かなければならないストーリーの数を減らすのに役立ちます。ただし、注意して使用する必要があります。OR ステートメントやチェックポイントを使いすぎるとトレーニングが遅くなり、チェックポイントが多すぎるとストーリーが理解しにくくなる可能性があります。

#### OR ステートメント

異なるインテントまたはスロットイベントがボットによって同じ方法で処理されるストーリーでは、新しいストーリーを作成する代わりに OR ステートメントを使用できます。

たとえば、次の 2 つのストーリーをマージできます。

```yaml-rasa
stories:
- story: newsletter signup
  steps:
  - intent: signup_newsletter
  - action: utter_ask_confirm_signup
  - intent: affirm
  - action: action_signup_newsletter

- story: newsletter signup, confirm via thanks
  steps:
  - intent: signup_newsletter
  - action: utter_ask_confirm_signup
  - intent: thanks
  - action: action_signup_newsletter
```

OR ステートメントを含む 1 つのストーリーに:

```yaml-rasa
stories:
- story: newsletter signup with OR
  steps:
  - intent: signup_newsletter
  - action: utter_ask_confirm_signup
  - or:
    - intent: affirm
    - intent: thanks
  - action: action_signup_newsletter
```

トレーニング時に、このストーリーは2つのオリジナルストーリーに分かれます。

> [!注意] データの再構築を検討する 
> ストーリーで OR ステートメントを頻繁に使用していることに気付いた場合は、インテントを再構築して粒度を下げ、ユーザー メッセージをより広範にキャプチャすることを検討してください。

#### チェックポイント

チェックポイントは、ストーリーを頻繁に繰り返される個別のブロックにモジュール化するのに役立ちます。たとえば、ボットが各会話フローの最後にユーザー フィードバックを求める場合は、チェックポイントを使用して、各ストーリーの最後にフィードバック インタラクションを含める必要がなくなります。

```yaml-rasa
stories:
- story: beginning of conversation
  steps:
  - intent: greet
  - action: utter_greet
  - intent: goodbye
  - action: utter_goodbye
  - checkpoint: ask_feedback

- story: user provides feedback
  steps:
  - checkpoint: ask_feedback
  - action: utter_ask_feedback
  - intent: inform
  - action: utter_thank_you
  - action: utter_anything_else

- story: user doesn't have feedback
  steps:
  - checkpoint: ask_feedback
  - action: utter_ask_feedback
  - intent: deny
  - action: utter_no_problem
  - action: utter_anything_else
```

> [!warning] 使いすぎないでください
> チェックポイントは、さまざまなストーリーで会話の特定のセクションを再利用しやすくすることを目的としています。既存のチェックポイント内でチェックポイントを使用すると、トレーニング時間が大幅に長くなり、ストーリーが理解しにくくなるため、強くお勧めしません。

### ストーリーに論理区切りを作成する

会話フローを設計するとき、最初から最後まで完全な会話のやり取りを捉えた長いストーリーの例を作成したくなることがよくあります。多くの場合、これにより、分岐パスを考慮するために必要なトレーニング ストーリーの数が増えます。代わりに、長いストーリーをサブタスクを処理する小さな会話ブロックに分割することを検討してください。

紛失したクレジットカードを処理するためのハッピーパスストーリーは、次のようになります。

```yaml-rasa
stories:
- story: Customer loses a credit card, reviews transactions, and gets a new card
  steps:
  - intent: card_lost
  - action: check_transactions
  - slot_was_set:
    - reviewed_transactions: ["starbucks"]
  - action: utter_ask_fraudulent_transactions
  - intent: inform
  - action: action_update_transactions
  - intent: affirm
  - action: utter_confirm_transaction_dispute
  - action: utter_replace_card
  - action: mailing_address_form
  - active_loop: mailing_address
  - active_loop: null
  - action: utter_sent_replacement
  - action: utter_anything_else
  - intent: affirm
  - action: utter_help
```

クレジット カードの紛失の処理には、不正取引の支出履歴の確認、再発行カードの郵送先住所の確認、および追加のリクエストでユーザーにフォローアップするという一連のサブタスクが含まれます。この会話アークでは、ボットがユーザー入力を求め、考慮する必要がある分岐パスを作成する場所がいくつかあります。

たとえば、「utter_ask_fraudulent_transactions」というプロンプトが表示された場合、ユーザーは「拒否」インテントで応答することがあります。ユーザーは、ボットが他に支援できるものがあるかどうかを尋ねられたときに、"拒否" の意図で応答することを選択することもできます。

この長い物語をいくつかの小さな物語に次のように分けることができます。

```yaml-rasa
stories:
- story: Customer loses a credit card
  steps:
  - intent: card_lost
  - action: utter_card_locked
  - action: spending_history_form
  - active_loop: spending_history_form
  - active_loop: null
  - slot_was_set:
    - reviewed_transactions: ["starbucks"]
  - action: utter_ask_fraudulent_transactions

- story: Customer reviews transactions and gets a new card
  steps:
  - action: utter_ask_fraudulent_transactions
  - intent: inform
  - action: action_update_transactions
  - slot_was_set:
    - reviewed_transactions: ["target", "starbucks"]
  - intent: affirm
  - action: utter_confirm_transaction_dispute
  - action: utter_replace_card
  - action: mailing_address_form
  - active_loop: mailing_address
  - active_loop: null
  - action: utter_sent_replacement
  - action: utter_anything_else

- story: Customer has something else they need help with
  steps:
  - action: utter_anything_else
  - intent: affirm
  - action: utter_help
```

## コンテキスト切り替えの処理

多くの場合、ユーザーはあなたが要求した情報で応答せず、代わりに逸脱します 無関係な質問を抱えた幸せな道から。使用 [CDD](./conversation-driven-development.md) ユーザーがどのような不幸な道をたどっているかを理解するために、コンテキストの切り替えを処理するためのストーリーを作成できます。

### コンテキスト切り替えのルールの使用

シングルターンの間投詞など、場合によっては、[ストーリー](./stories.md)ではなく[ルール](./rules.md)を使用してコンテキスト切り替えを処理できます。

次の会話シナリオを考えてみましょう。

こんにちは、クレジットカードの請求書を支払いたいですできる!これらのクレジット口座のどれに支払いを行いますか?

- クレジットアカウントA

- クレジット口座B

クレジット口座Bいくら支払いたいですか?アカウント残高はいくらですか?当座預金残高は 1532.00 ドルですいくら支払いたいですか?最低残高を支払いたい

この例では、ユーザーはクレジット カードの請求書の支払いの途中で、アカウント残高を尋ねてから、クレジット カード支払いフォームに戻されます。アカウント残高を要求すると、コンテキストに関係なく常に同じ応答が得られるため、既存のフロー内で自動的にトリガーされるルールを作成できます。

```yaml-rasa
rules:
- rule: Check my account balance
  steps:
  - intent: check_account_balance
  - action: action_get_account_balance
```

既定では、フォームは引き続きアクティブなままであり、追加のトレーニング ストーリーを作成することなく、必要な情報の再入力を求められます。

### コンテキスト切り替えのためのストーリーの使用

ユーザーの間投詞が複数の会話ターンを必要とする場合に、コンテキストの切り替えを処理するために追加のストーリーを作成する必要があります。2 つの異なる会話フローがあり、ユーザーがフローを切り替えられるようにする場合は、切り替えの方法とコンテキストの維持方法を指定するストーリーを作成する必要があります。

たとえば、ユーザーの質問時にコンテキストを切り替え、その質問の完了後に元のフローに戻る場合は、次のようにします。

こんにちは、クレジットカードの請求書を支払いたいですできる!これらのクレジット口座のどれに支払いを行いますか?

- クレジットアカウントA

- クレジット口座B

クレジット口座Bいくら支払いたいですか?実は移籍したい大丈夫！誰に送金したいですか?Katy Parrow に 500 ドルを送金したいケイティ・パロウに500ドルを送金することに成功しました。今すぐクレジットカードの請求書を支払いますか?

このコンテキスト切り替えの対話を説明するストーリーを作成する必要があります。

```yaml-rasa
stories:
- story: Context switch from credit card payment to money transfer
  steps:
  - intent: pay_credit_card
  - action: credit_card_payment_form
  - active_loop: credit_card_payment_form
  - intent: transfer_money                         # - user requests a money transfer
  - active_loop: null                              # - deactivate the credit card form
  - action: transfer_money_form                    # - switch to the money transfer form
  - active_loop: transfer_money_form
  - active_loop: null
  - action: utter_continue_credit_card_payment     # - once the money transfer is completed,
                                                   #   ask the user to return to the
                                                   #   credit card payment form
```

## 会話データファイルの管理

トレーニング データは、単一のファイルとして、または複数のファイルを含むディレクトリとして Rasa に提供できます。ストーリーやルールを作成するときは、通常、表現される会話の種類に基づいて個別のファイルを作成することをお勧めします。

たとえば、雑談を処理するためのファイル`chitchat.yml`と、FAQ 用の`faqs.yml`ファイルを作成できます。[rasa-demoボット](https://github.com/RasaHQ/rasa-demo)を参照してください 複雑なアシスタントでのストーリーファイル管理の例。

## 対話型学習の使用

対話型学習により、ボットと対話してフィードバックを提供することで、ストーリーを簡単に書くことができます。これは、ボットが何ができるかを調べるための強力な方法であり、ボットが犯した間違いを修正する最も簡単な方法です。機械学習ベースの対話の利点の 1 つは、ボットがまだ何かを行う方法を知らないときに、ボットに教えるだけで済むことです。

Rasaでは、[[./command-line-interface.md#RASAインタラクティブ|`rasa interactive`]]を参照してください。

### コマンドライン対話学習

CLI コマンド `rasa interactive` は、コマンド行で対話式学習を開始します。 ボットにカスタム アクションがある場合は、次の操作も行ってください。 [アクションサーバーを](./action-server/running-action-server.md)別のターミナルウィンドウで実行します。

インタラクティブモードでは、ボットが続行する前に、すべての意図とアクションの予測を確認するよう求められます。次に例を示します。

```text
? Next user input:  hello

? Is the NLU classification for 'hello' with intent 'hello' correct?  Yes

------
Chat History

 #    Bot                        You
────────────────────────────────────────────
 1    action_listen
────────────────────────────────────────────
 2                                    hello
                         intent: hello 1.00
------

? The bot wants to run 'utter_greet', correct?  (Y/n)

```

会話の各ステップで会話履歴とスロット値を確認できます。

||y||予測を承認するために、ボットは続行します。||n||の場合、続行する前に予測を修正する機会が与えられます。

```text
? What is the next action of the bot?  (Use arrow keys)
 » <create new action>
   1.00 utter_greet
   0.00 ...
   0.00 action_back
   0.00 action_deactivate_loop
   0.00 action_default_ask_affirmation
   0.00 action_default_ask_rephrase
   0.00 action_default_fallback
   0.00 action_listen
   0.00 action_restart
   0.00 action_session_start
   0.00 action_two_stage_fallback
   0.00 utter_cheer_up
   0.00 utter_did_that_help
   0.00 utter_goodbye
   0.00 utter_happy
   0.00 utter_iamabot
```

いつでも、||Ctrl-C||をクリックしてメニューにアクセスし、さらにストーリーを作成し、これまでに作成したストーリーからデータをエクスポートできます。

```text
? Do you want to stop?  (Use arrow keys)
 » Continue
   Undo Last
   Fork
   Start Fresh
   Export & Quit
```