---
id: chitchat-faqs
sidebar_label: Chitchat and FAQs
title: Chitchat and FAQs
abstract: FAQ assistants are the simplest assistants to build and typically the first kind of assistant anyone builds. This page is a guide to the concepts and training data you need to handle non-contextual questions like FAQs and chitchat.
---

[FAQ](./glossary.md#FAQ) と[[./glossary.md#[お喋り](./chitchat-faqs.md)|お喋り]]は、会話アシスタントが固定されたメッセージ セットで応答する 2 つのケースであり、会話で以前に何が起こったかに関係なく、アシスタントは常に同じ方法で応答する必要があります。たとえば、次の会話では、会話のどの時点でもすべての質問をすることができ、回答はユーザーが以前に発言した内容とは無関係です。

あなたの名前は何ですか私の名前はサラです!アシスタントはどの言語で構築できますか?Rasaを使って、好きな言語でアシスタントを作ることができます!Rasa X/Enterpriseとは?Rasa X/Enterprise は、実際の会話から学習し、アシスタントを改善するためのツールです。

## FAQとおしゃべりのための応答セレクターの使用に関するステップバイステップガイド

FAQやおしゃべりを処理するには、ルールベースの対話管理ポリシー([[./policies.md#ルールポリシー|RulePolicy]]) と、質問に対する適切な応答を返す簡単な方法 ([応答セレクター](./components.md#応答セレクター)) を呼び出します。

### 1. 設定の更新

FAQやおしゃべりでは、同じ種類の質問がされるたびにアシスタントが常に同じ方法で応答するようにする必要があります。[ルールを使用すると](rules.md)、まさにそれを行うことができます。ルールを使用するには、[[./policies.md#Rule Policy|RulePolicy]] を設定ファイル内のポリシーに追加します。

```yaml-rasa
policies:
# other policies
- name: RulePolicy
```

次に、NLU パイプラインの ResponseSelector を構成ファイルに含めます。ResponseSelector が機能するには特徴付けと意図分類子が必要なため、パイプライン内の次のコンポーネントの後に来る必要があります。

```yaml-rasa
pipeline:
  - name: WhitespaceTokenizer
  - name: RegexFeaturizer
  - name: LexicalSyntacticFeaturizer
  - name: CountVectorsFeaturizer
  - name: CountVectorsFeaturizer
    analyzer: char_wb
    min_ngram: 1
    max_ngram: 4
  - name: DIETClassifier
    epochs: 100
  - name: EntitySynonymMapper
  - name: ResponseSelector
    epochs: 100
```

デフォルトでは、ResponseSelector はすべての取得インテントに対して 1 つの取得モデルを構築します。FAQとチャットの応答を個別に取得するには、複数のResponseSelectorコンポーネントを使用し、`retrieval_intent`キーを指定します。

```yaml-rasa
pipeline:
# Other components
- name: ResponseSelector
  epochs: 100
  retrieval_intent: faq
- name: ResponseSelector
  epochs: 100
  retrieval_intent: chitchat
```

### 2. 検索インテントとResponseSelectorの定義

20 の異なる FAQ がある例を考えてみましょう。各質問は個別のインテントとして表されますが、すべての FAQ インテントはダイアログで同じ方法で処理されます。FAQ インテントごとに、アシスタントは、尋ねられた質問に応じて適切な応答**を取得し**ます。

20 個のルールを記述する代わりに、1 つのアクション (`たとえば utter_faq`) を使用して、すべての FAQ を 1 つのルールで処理し、`faq などの 1` つの [[glossary.md#[取得インテント](./chitchat-faqs.md)|取得インテント]] の下にグループ化することができます。

1 つのアクションは、[応答セレクター](./components.md#応答セレクター) の出力を使用して、ユーザーが尋ねた特定の FAQ に対して正しい応答を返します。

### 3. ルールの作成

取得インテントごとに 1 つのルールのみを記述する必要があります。その取得インテントの下にグループ化されたすべてのインテントは、同じ方法で処理されます。アクション名は`utter_`で始まり、取得インテントの名前で終わります。FAQやおしゃべりに応答するためのルールを記述します。

```yaml-rasa
rules:
  - rule: respond to FAQs
    steps:
    - intent: faq
    - action: utter_faq
  - rule: respond to chitchat
    steps:
    - intent: chitchat
    - action: utter_chitchat
```

アクション`utter_faq`と`utter_chitchat`は、ResponseSelector の予測を使用して実際の応答メッセージを返します。

### 4. NLUトレーニングデータの更新

ResponseSelector の NLU トレーニング例は、通常のトレーニング例と同じように見えますが、名前がグループ化されている取得インテントを参照する必要がある点が異なります。

```yaml-rasa
nlu:
  - intent: chitchat/ask_name
    examples: |
      - What is your name?
      - May I know your name?
      - What do people call you?
      - Do you have a name for yourself?
  - intent: chitchat/ask_weather
    examples: |
      - What's the weather like today?
      - Does it look sunny outside today?
      - Oh, do you mind checking the weather for me please?
      - I like sunny days in Berlin.
```

追加した`チャット`インテントを含めるようにドメインファイルを更新してください。

```yaml-rasa
intents:
# other intents
- chitchat
```

### 5. 応答の定義

ResponseSelector の応答は、取得インテントと同じ命名規則に従います。これに加えて、通常のボット[応答](domain.md#応答)のすべての特性を持つことができます。上記のおしゃべりの意図については、私たちの回答は次のようになります。

```yaml-rasa
responses:
  utter_chitchat/ask_name:
  - image: "https://i.imgur.com/zTvA58i.jpeg"
    text: Hello, my name is Retrieval Bot.
  - text: I am called Retrieval Bot!
  utter_chitchat/ask_weather:
  - text: Oh, it does look sunny right now in Berlin.
    image: "https://i.imgur.com/vwv7aHN.png"
  - text: I am not sure of the whole week but I can see the sun is out today.
```

## 概要

次の手順が完了したら、ボットをトレーニングして試すことができます。

- [ ] ポリシーに RulePolicy を追加し、config.yml のパイプラインに ResponseSelector を追加します
- [ ] FAQ/おしゃべりに応答するためのルールを少なくとも1つ追加する
- [ ] FAQ/おしゃべりインテントの例を追加する
- [ ] FAQ/チャットの意図に対する回答を追加する
- [ ] ドメイン内の意図を更新する

これで、アシスタントは、アシスタントが別のタスクでユーザーを支援しているときにこれらの間投詞が発生した場合でも、FAQ やおしゃべりに正しく一貫して応答できるはずです。