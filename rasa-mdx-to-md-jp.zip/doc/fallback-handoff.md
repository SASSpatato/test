---
id: fallback-handoff
sidebar_label: Fallback and Human Handoff
title: Fallback and Human Handoff
abstract: This is a guide on how to handle various failures of your assistant.
---

ボットを完璧に設計したとしても、ユーザーは必然的にあなたが予期していなかったことをアシスタントに言うでしょう。このような場合、アシスタントは失敗するため、正常に失敗することが重要です。

## 範囲外メッセージの処理

ユーザーの不満を避けるために、ユーザーが尋ねる可能性があることがわかっているが、ユーザー目標をまだ実装していない質問を処理できます。

### 1. 範囲外のインテントの作成

NLU トレーニングデータで`out_of_scope`インテントを定義し、既知の範囲外のリクエストをトレーニング例として追加する必要があります。

```yaml-rasa
nlu:
- intent: out_of_scope
  examples: |
    - I want to order food
    - What is 2 + 2?
    - Who's the US President?
```

すべての意図と同様に、例の大部分を調達する必要があります [実際の会話から](conversation-driven-development.md)会話駆動型開発による実際の会話から学習します。

### 2. 応答メッセージの定義

ドメイン ファイルで範囲外の応答を定義する必要があります。発話`utter_out_of_scope`を既定の応答として使用すると、次のようになります。

```yaml-rasa
responses:
  utter_out_of_scope:
  - text: Sorry, I can't handle that request.
```

### 3. 範囲外ルールの作成

最後に、範囲外のリクエストで何が起こるかについてのルールを記述する必要があります。

```yaml-rasa
rules:
- rule: out-of-scope
  steps:
  - intent: out_of_scope
  - action: utter_out_of_scope
```

### 特定の範囲外メッセージの処理

ユーザーが将来ユーザーの目標にしたい特定のことを尋ねているのを観察した場合は、これらを別のインテントとして処理して、メッセージを理解したが、まだ解決策がないことをユーザーに知らせることができます。たとえば、ユーザーが「Rasaの仕事に応募したい」と尋ねた場合、「あなたが仕事を探していることは理解していますが、そのスキルをまだ処理できないのではないかと思います」と返信できます。

`out_of_scope`インテントの例と同様に、トレーニング例を使用して新しいインテントを作成し、応答メッセージを定義し、ルールを作成する必要があります。

## フォールバック

Rasa は未表示のメッセージに一般化しますが、一部のメッセージは分類の信頼度が低い場合があります。フォールバックを使用すると、これらの信頼度の低いメッセージが適切に処理され、アシスタントはデフォルト・メッセージで応答するか、ユーザー入力のあいまいさを解消するかを選択できます。

### NLU フォールバック

NLU の信頼度が低い受信メッセージを処理するには、 [FallbackClassifier](./components.md#フォールバック分類子) です。この設定を使用すると、他のすべてのインテント予測が設定された信頼度しきい値を下回ったときに、インテント`nlu_fallback`が予測されます。その後、`nlu_fallback`が予測されたときにボットが何をすべきかについてのルールを記述できます。

#### 1. 設定の更新

FallbackClassifier を使用するには、NLU パイプラインに追加します。

```yaml-rasa
pipeline:
# other components
- name: FallbackClassifier
  threshold: 0.7
```

#### 2. 応答メッセージの定義

応答を追加して、メッセージが信頼度の低い状態で分類されたときにボットが送信するメッセージを定義します。

```yaml-rasa
responses:
  utter_please_rephrase:
  - text: I'm sorry, I didn't quite understand that. Could you rephrase?
```

#### 3. NLU フォールバックルールの作成

次の[ルール](./rules.md)は、信頼度の低いメッセージを送信するときに、ユーザーに言い換えるように求めます。

```yaml-rasa
rules:
- rule: Ask the user to rephrase whenever they send a message with low NLU confidence
  steps:
  - intent: nlu_fallback
  - action: utter_please_rephrase
```

### 低いアクションの信頼度への対応

ユーザーが予期しないメッセージを送信する可能性があるため、その行動が未知の会話パスに導かれる可能性があります。Rasa's machine learning policies such as the [[./policies.md#TED Policy|TED ポリシー]] は、これらの未知のパスを処理するように最適化されています。

機械学習ポリシーが次のアクションを高い信頼度で予測できない場合に対処するには、[[./policies.md#ルールポリシー|Rule Policy]] を使用して、[設定](./policies.md)可能なしきい値を超える信頼度で次のアクション予測がポリシーにない場合にデフォルト アクションを予測します。

以下のステップを使用して、アクションの信頼度が低い場合に実行されるアクションと、対応する信頼度のしきい値を構成できます。

#### 1. 設定の更新

config.yml のポリシーに RulePolicy を追加する必要があります。デフォルトでは、ルールポリシーには以下の設定が付属しています。

```yaml-rasa
policies:
- name: RulePolicy
  # Confidence threshold for the `core_fallback_action_name` to apply.
  # The action will apply if no other action was predicted with
  # a confidence >= core_fallback_threshold
  core_fallback_threshold: 0.4
  core_fallback_action_name: "action_default_fallback"
  enable_fallback_prediction: True
```

#### 2. デフォルトの応答メッセージの定義

アクションの信頼度がしきい値を下回ったときにボットが何を言うかを定義するには、応答`utter_default`を定義します。

```yaml-rasa
responses:
  utter_default:
  - text: Sorry I didn't get that. Can you rephrase?
```

アクションの信頼度がしきい値を下回ると、Rasa はアクションを実行します `action_default_fallback`。これにより、応答が`utter_default`送信され、フォールバックの原因となったユーザーメッセージの前の会話の状態に戻るため、将来のアクションの予測には影響しません。

#### 3. デフォルトアクションのカスタマイズ (オプション)

`action_default_fallback` は、Rasa のデフォルトアクションで、 ユーザーへの応答`utter_default`。独自のカスタムアクションを作成して、 フォールバック ([[./actions.md#カスタムアクション|カスタムアクションの詳細については、カスタムアクション]]を参照してください)。 次のスニペットは、 `action_default_fallback`が別のテンプレートをディスパッチします `utter_fallback_template`:

```python
from typing import Any, Text, Dict, List

from rasa_sdk import Action, Tracker
from rasa_sdk.events import UserUtteranceReverted
from rasa_sdk.executor import CollectingDispatcher

class ActionDefaultFallback(Action):
    """Executes the fallback action and goes back to the previous state
    of the dialogue"""

    def name(self) -> Text:
        return ACTION_DEFAULT_FALLBACK_NAME

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict[Text, Any]]:
        dispatcher.utter_message(template="my_custom_fallback_template")

        # Revert user message which led to fallback.
        return [UserUtteranceReverted()]
```

### 2 段階フォールバック

ボットがユーザーが何を望んでいるのかを理解する機会を与えるには、通常、明確な質問をすることでユーザーのメッセージの曖昧さを解消しようとします。2 段階フォールバックは、次の順序を使用して、複数の段階で低い NLU 信頼度を処理するように作成されています。

1.  ユーザーメッセージが信頼度が低い状態で分類される
    *   ユーザーは意図を確認するように求められます
2.  ユーザーが意図を確認または拒否する
    *   確認すれば、最初から高い信頼度で意図を分類したかのように会話が続く。それ以上のフォールバック手順は実行されません。
    *   拒否した場合、ユーザーはメッセージを言い換えるように求められます。
3.  ユーザーが意図を言い換える
    *   メッセージが信頼度の高い状態で分類されている場合、会話はユーザーが最初からこの意図を持っていたかのように続行されます。
    *   言い換えられたユーザーメッセージの信頼度がまだ低い場合は、ユーザーは意図を確認するように求められます。
4.  ユーザーが言い換えられた意図を確認または拒否する
    *   確認すると、ユーザーが最初からこの意図を持っていたかのように会話が続行されます。
    *   拒否すると、究極のフォールバックアクションがトリガーされます(たとえば、人間への引き継ぎ)。デフォルトの最終的なフォールバックアクションは、`action_default_fallback`を呼び出すことです。このアクションにより、ボットは`utter_default`を発話します 応答し、2 段階フォールバック中に発生したターンが発生しなかったかのように会話の状態をリセットします。

2 段階フォールバックは、次の手順を使用して有効にできます。

#### 1. 設定の更新

FallbackClassifier をパイプラインに追加し、[[./policies.md#ルールポリシー|Rule Policy]] をポリシー設定に追加します。

```yaml
recipe: default.v1
pipeline:
# other components
- name: FallbackClassifier
  threshold: 0.7

policies:
# other policies
- RulePolicy
```

#### 2. フォールバック応答の定義

ボットがユーザーにメッセージの言い換えを求める方法を定義するには、応答`utter_ask_rephrase`を定義します。

```yaml-rasa
responses:
  utter_ask_rephrase:
  - text: I'm sorry, I didn't quite understand that. Could you rephrase?
```

Rasaは、ユーザーがどの意図を意味したかを尋ね、ユーザーに言い換えるように求めるためのデフォルトの実装を提供します。これらのアクションの動作をカスタマイズするには、[デフォルト・アクション](default-actions.md)に関するドキュメントを参照してください。

#### 3. 2 段階フォールバックルールの定義

トレーニングデータに次の[ルール](./rules.md)を追加します。このルールにより、分類の信頼度が低いメッセージが受信されるたびに、2 段階フォールバックがアクティブになります。

```yaml-rasa
rules:
- rule: Implementation of the Two-Stage-Fallback
  steps:
  - intent: nlu_fallback
  - action: action_two_stage_fallback
  - active_loop: action_two_stage_fallback
```

### 4. 究極のフォールバックアクションの定義

ユーザーが言い換えたインテントを拒否したときのボットの応答を定義するには、応答`utter_default`を定義します。

```yaml-rasa
responses:
  utter_default:
  - text: I'm sorry, I can't help you.
```

または、より複雑な動作に合わせて`action_default_fallback`をカスタマイズするには、[[./actions.md#カスタムアクション|カスタムアクション]]。たとえば、ボットが人間を呼び出してユーザーとの対話を停止する場合:

```python
from typing import Any, Dict, List, Text

from rasa_sdk import Action, Tracker
from rasa_sdk.events import UserUtteranceReverted
from rasa_sdk.executor import CollectingDispatcher

class ActionDefaultFallback(Action):
    def name(self) -> Text:
        return "action_default_fallback"

    def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict[Text, Any]]:

        # tell the user they are being passed to a customer service agent
        dispatcher.utter_message(text="I am passing you to a human...")
        
        # assume there's a function to call customer service
        # pass the tracker so that the agent has a record of the conversation between the user
        # and the bot for context
        call_customer_service(tracker)
     
        # pause the tracker so that the bot stops responding to user input
        return [ConversationPaused(), UserUtteranceReverted()]
```

> [!warning]
> カスタムの最終フォールバックアクションによって返されるイベントカスタム`action_default_fallback`によって返されるイベントの1つとして`UserUtteranceReverted()`を含める必要があります。このイベントを含めないと、2 段階のフォールバック プロセス中に発生したすべてのイベントがトラッカーに含まれ、ボットのポリシー パイプラインからの後続のアクション予測が妨げられる可能性があります。2 段階のフォールバック プロセス中に発生したイベントは、ボットがルールまたは記憶されたストーリーを適用して次のアクションを正しく予測できるように、発生しなかったかのように扱うことをお勧めします。

## ヒューマンハンドオフ

フォールバックアクションの一環として、ボットを人間のエージェントに引き渡すことができます たとえば、Two-Stage-Fallback の最終アクションとして、またはユーザーが明示的に要求した場合 人間のために。人間による引き継ぎを実現する簡単な方法は、 [メッセージングまたは音声チャネル](messaging-and-voice-channels.md)を使用して、特定のボットまたはユーザーメッセージに基づいてどのホストをリッスンするかを切り替えます。

たとえば、2 段階フォールバックの最後のアクションとして、ボットはユーザーに「人間のアシスタントに転送しますか?」と尋ね、ユーザーが「はい」と答えた場合、ボットは「handoff_to_human」などの特定のペイロードを含むメッセージをチャネルに送信します。チャネルは、このメッセージを認識すると、Rasa サーバーのリッスンを停止し、その時点までのチャット会話のトランスクリプトを含むメッセージをヒューマン チャネルに送信します。

フロントエンドから人間に引き継ぐための実装は、使用しているチャネルによって異なります。[チャットルーム](https://github.com/scalableminds/chatroom)チャネルの適応を使用した実装例は、[Financial Demo](https://github.com/RasaHQ/financial-demo) と [Helpdesk-Assistant](https://github.com/RasaHQ/helpdesk-assistant) スターターパックで確認できます。

## 概要

アシスタントが障害を適切に処理できるようにするには、既知の範囲外メッセージを処理し、フォールバック動作の形式を追加する必要があります。人間による引き継ぎを追加する場合は、追加で追加するか、フォールバック設定の最終ステップとして追加できます。各メソッドに対して行う必要がある変更の概要は次のとおりです。

範囲外のインテントの場合:

- [ ] 範囲外のインテントごとにトレーニング例を NLU データに追加する
- [ ] 範囲外の応答またはアクションを定義する
- [ ] 範囲外のインテントごとにルールを定義する
- [ ] RulePolicy を config.yml に追加する

シングルステージ NLU フォールバックの場合:

- [ ] config.yml のパイプラインに FallbackClassifier を追加する
- [ ] フォールバック応答またはアクションを定義する
- [ ] nlu_fallbackインテントのルールを定義する
- [ ] RulePolicy を config.yml に追加する

低いコアの信頼度を処理する場合:

- [ ] config.yml でのコア フォールバックの RulePolicy の設定
- [ ] オプションで、構成するフォールバックアクションをカスタマイズします
- [ ] utter_default応答を定義する

2 段階フォールバックの場合:

- [ ] config.yml のパイプラインに FallbackClassifier を追加する
- [ ] action_two_stage_fallbackアクションをトリガーするnlu_fallbackインテントのルールを定義する
- [ ] ドメインで範囲外のインテントを定義する
- [ ] RulePolicy を config.yml に追加する

人間に引き継ぐ場合:

- [ ] ホストを切り替えるようにフロントエンドを構成する
- [ ] ハンドオフペイロードを送信するカスタムアクション(フォールバックアクションの場合があります)を記述します
- [ ] ハンドオフをトリガーするルールを追加する (フォールバックの一部でない場合)
- [ ] RulePolicy を config.yml に追加する