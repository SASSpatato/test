---
id: unexpected-input
sidebar_label: Handling Unexpected Input
title: Handling Unexpected Input
abstract: One thing you can count on when building a conversational assistant is that users
  will say unexpected things. This page is a guide on handling unexpected input.
---

予期しない入力は、定義した [[glossary.md#幸せ/不幸な道|happy path]] からの逸脱です。例えば：

*   ユーザーがサブスクリプションに関する会話の途中で立ち去り、戻ってきて「こんにちは!」と言います。
*   ボットが電子メール アドレスを尋ねると、ユーザーは「なぜそれを知る必要があるのですか?」と尋ねます。

このページは、ボットのドメイン内にまだ存在する予期しない入力を処理する方法に関するガイドです。処理しようとしている予期しない入力の種類に応じて、説明されているメソッドの一部またはすべてが適用できる場合があります。このガイドは、ユーザー入力のあいまいさを解消したり、範囲外の質問を処理したりすることではありません。このような場合は、[フォールバックとヒューマンハンドオフ](fallback-handoff.md)に関するガイドを参照してください。

## ユーザーの感嘆詞

予期しない入力には、一般的な間投詞と文脈による間投詞の 2 種類があります。一般的な間投詞は、会話のコンテキストに関係なく、常に同じ応答が得られるはずの中断です。インテントに対する応答を定義するルールが既にある場合は、それを中断として処理するために他に何もする必要はありません。[FAQとおしゃべり](./chitchat-faqs.md)は、一般的な一般的な間投詞です。文脈間投詞とは、その応答が会話の文脈に依存するものです。たとえば、ユーザーが「なぜそれが必要なのですか?」と尋ねた場合、答えはボットが何を求めたかによって異なります。

### 文脈の間投詞

文脈に応じた感嘆詞の処理は、[文脈に応じた会話](contextual-conversations.md)の処理と似ています 原則として。

文脈間投詞の一般的なケースの 1 つは、[フォーム](forms.md)のスロット入力中に、ユーザーが「なぜそれを知る必要があるのですか?」または「それを説明できますか?」と尋ねることです。応答はスロットごとに異なるはずです。例えば：

こんにちはこんにちは！私はレストラン検索アシスタントです!どうすればいいですか?レストランを探していますどんな料理?フランス語何人ですか?なぜそれを知る必要があるのでしょうか?レストランがあなたを収容できることを確認するために、あなたのパーティーに何人が参加しているかを知る必要があります。何人ですか?

`requested_slot`が会話に影響を与える必要があるため、スロットのプロパティ`influence_conversation`を設定する必要があります`requested_slot` true`に設定`し、カテゴリ型を割り当てます。

```yaml-rasa
slots:
  requested_slot:
    type: categorical
    values:
      - cuisine
      - num_people
      - outdoor_seating
      - preferences
      - feedback
    influence_conversation: true
    mappings:
    - type: custom
```

これは、対話モデルが予測を行うときにスロットの値に注意を払うことを意味します([[./domain.md#スロットと会話の動作|スロットがアシスタントの行動にどのように影響するか]]の詳細をご覧ください)。

次に、`requested_slot` の値に基づいて、感嘆詞に対する特定の応答のストーリーを書くことができます。

```yaml-rasa
stories:
- story: cuisine interjection
  steps:
  - intent: request_restaurant
  - action: restaurant_form
  - active_loop: restaurant_form
  - slot_was_set:
    - requested_slot: cuisine
  - intent: explain
  - action: utter_explain_cuisine
  - action: restaurant_form

- story: number of people interjection
  steps:
  - intent: request_restaurant
  - action: restaurant_form
  - active_loop: restaurant_form
  - slot_was_set:
    - requested_slot: num_people
  - intent: explain
  - action: utter_explain_num_people
  - action: restaurant_form
```

## 概要

予期しない入力を処理する方法は、応答がコンテキスト依存であるかどうかによって異なります。

一般的な間投詞の場合:

- [ ] シングルターンの相互作用のルールを定義する
- [ ] FAQやおしゃべりの中断にResponseSelectorを使用する

文脈に応じない感嘆詞の場合:

- [ ] requested_slotカテゴリスロットにする (フォーム用)
- [ ] 間投詞に対する文脈固有の応答のストーリーを、該当する場合はスロット値を使用して作成します