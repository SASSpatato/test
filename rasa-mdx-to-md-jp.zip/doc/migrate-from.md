---
id: migrate-from
sidebar_label: Migrate From (beta)
title: Migrate From Other Tools (beta)
---

開発者が他のツールから Rasa に切り替える理由は次のとおりです。

*   **高速**: ローカルで実行 - HTTP リクエストやサーバーのラウンド トリップは必要ありません
    
*   **カスタマイズ可能**:モデルを調整し、データセットの精度を高めます
    
*   **オープンソース**:ベンダーロックインのリスクなし - RasaはApache 2.0ライセンスの下にあり、商用プロジェクトで使用できます
    

さらに、当社のオープンソースツールを使用すると、開発者はコンテキストに応じたAIアシスタントを構築し、ルールの代わりに機械学習を使用して対話を管理できます([このブログ投稿](http://blog.rasa.com/a-new-approach-to-conversational-software/)でチェックしてください)。

以下から移行する方法について説明します。

*   [Googleダイアログフロー](./migrate-from/google-dialogflow-to-rasa.md)
    
*   [Wit.ai](./migrate-from/facebook-wit-ai-to-rasa.md)
    
*   [Microsoft LUIS](./migrate-from/microsoft-luis-to-rasa.md)
    
*   [IBMワトソン](./migrate-from/ibm-watson-to-rasa.md)