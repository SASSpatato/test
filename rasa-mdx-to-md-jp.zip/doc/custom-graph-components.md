---
id: custom-graph-components
sidebar_label: Custom Graph Components
title: Custom Graph Components
abstract: You can extend Rasa with custom NLU components and policies. This page provides a guide on how to develop your own custom graph components.
---

Rasaは、さまざまな[NLUコンポーネント](components.md)と[ポリシー](policies.md)をすぐに提供します。カスタムグラフコンポーネントを使用して、それらをカスタマイズしたり、独自のコンポーネントを最初から作成したりできます。

カスタムグラフコンポーネントをRasaで使用するには、次の要件を満たす必要があります。

*   [[#`GraphComponent` インターフェイス]]
*   使用されたモデル構成で[[#モデル構成へのグラフコンポーネントの登録|registered]]である必要があります
*   これは、[[#モデル構成でのカスタムコンポーネントの使用]]で使用する必要があります。
*   型アノテーションを使用する必要があります。Rasa は、型アノテーションを使用してモデル構成を検証します。[前方参照](https://www.python.org/dev/peps/pep-0484/#forward-references)は許可されません。Python 3.7を使用している場合は、前方参照を取り除くために使用できます [`from __future__ import annotations`](https://www.python.org/dev/peps/pep-0563/#enabling-the-future-behavior-in-python-3-7) 。

## グラフコンポーネント

Rasaは、渡された[モデル構成](model-configuration.md)を使用して、[有向非巡回グラフ](https://en.wikipedia.org/wiki/Directed_acyclic_graph)を構築します。このグラフは、モデル構成内の項目間の依存関係と、それらの間のデータフローについて説明します。これには、次の 2 つの大きな利点があります。

*   Rasa は計算グラフを使用して、モデルの実行を最適化できます。この例としては、トレーニング ステップの効率的なキャッシュや、独立したステップの並行実行などがあります。
*   Rasaは、さまざまなモデルアーキテクチャを柔軟に表現できます。グラフが非巡回的なままである限り、Rasaは理論的には、基盤となるソフトウェアアーキテクチャを使用されているモデルアーキテクチャに結び付けることなく、モデル構成に基づいて任意のグラフコンポーネントに任意のデータを渡すことができます。

モデル構成を計算グラフに変換する場合 [ポリシー](policies.md)と [NLU コンポーネント](components.md)は、このグラフ内のノードになります。モデル構成ではポリシーと NLU コンポーネントの間に区別がありますが、グラフ内に配置すると区別が抽象化されます。この時点で、ポリシーと NLU コンポーネントは抽象グラフ *コンポーネント*になります。実際には、これは [[custom-graph-components.md#`GraphComponent` インターフェイス|`GraphComponent` ]] インターフェイス: ポリシーと NLU コンポーネントの両方が、Rasa のグラフと互換性があり、実行可能になるには、このインターフェイスから継承する必要があります。

![Visualization of the Rasa Graph Architecture](/static/img/graph_architecture.png)

## はじめ

開始する前に、カスタムを実装するかどうかを決定する必要があります [NLU コンポーネント](components.md)または[ポリシー](policies.md)。カスタムポリシーを実装する場合は、`GraphComponent`インターフェイスをすでに実装している既存の `rasa.core.policies.policy.Policy` クラスを拡張することをお勧めします。

```python
from rasa.core.policies.policy import Policy
from rasa.engine.recipes.default_recipe import DefaultV1Recipe

# TODO: Correctly register your graph component
@DefaultV1Recipe.register(
    [DefaultV1Recipe.ComponentType.POLICY_WITHOUT_END_TO_END_SUPPORT], is_trainable=True
)
class MyPolicy(Policy):
    ...
```

カスタム NLU コンポーネントを実装する場合は、次のスケルトンから始めます。

次のセクションを読んで、上記の例で `TODO`を解決する方法と、カスタムコンポーネントに実装する必要がある他のメソッドを確認してください。

> [!NOTE] 
> カスタムトークナイザーカスタムトークナイザーを作成する場合は、クラスを `rasa.nlu.tokenizers.tokenizer.Tokenizer` 拡張する必要があります。`train` メソッドと `process` メソッドはすでに実装されているため、`tokenize` メソッドを上書きするだけで済みます。

## `GraphComponent` インターフェイス

カスタム NLU コンポーネントまたはポリシーを Rasa で実行するには、`GraphComponent` インターフェイスを実装する必要があります。

### `create`

`create` メソッドは、トレーニング中にグラフコンポーネントをインスタンス化するために使用され、オーバーライドする必要があります。Rasa は、メソッドを呼び出すときに次のパラメーターを渡します。

*   `config`: これは、モデル構成ファイル内のグラフコンポーネントに提供される構成とマージされたコンポーネントのデフォルト構成です。
*   `model_storage`: これを使用して、グラフコンポーネントを永続化してロードできます。その使用法の詳細については、[[#モデルの永続性]] セクションを参照してください。
*   `resource`: `model_storage`内のコンポーネントの一意の識別子。その使用法の詳細については、[[#モデルの永続性]] セクションを参照してください。
*   `execution_context`: これにより、現在の 実行モード:
    *   `model_id`: 推論中に使用されるモデルの一意の識別子。このパラメーターは、トレーニング中に `None` です。
    *   `should_add_diagnostic_data`: `True` の場合、実際の予測に加えて、グラフ コンポーネントの予測に追加の診断メタデータを追加する必要があります。
    *   `is_finetuning`: `True`の場合、グラフコンポーネントは[[command-line-interface.md#段階的なトレーニング|finetuning]]を使用してトレーニングできます。
    *   `graph_schema`: `graph_schema`は、アシスタントをトレーニングしたり、アシスタントを使用して予測を行ったりするために使用される計算グラフを記述します。
    *   `node_name`: `node_name`は、呼び出されたグラフコンポーネントによって満たされるグラフスキーマ内のステップの一意の識別子です

### `load`

`load` メソッドは、推論中にグラフコンポーネントをインスタンス化するために使用されます。このメソッドの既定の実装では、`create` メソッドが呼び出されます。グラフコンポーネント [[#段階的なトレーニング|トレーニングの一部としてデータを永続化]] の場合は、これをオーバーライドすることをお勧めします。個々のパラメータの説明については、[[#`create`]]を参照してください。

### `get_default_config`

このメソッドは`、`グラフ コンポーネントの既定の設定get_default_config返します。デフォルトの実装は、グラフコンポーネントに構成がないことを意味する空の辞書を返します。Rasaは、実行時に設定ファイルで指定されたデフォルト設定を更新します。

### `supported_languages`

このメソッドは、グラフコンポーネントがサポートする[言語](https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes)を指定する`supported_languages`です。Rasa は、モデル構成ファイルの`言語`キーを使用して、グラフ コンポーネントが指定された言語での使用に有効であることを検証します。グラフコンポーネントが `None` を返す場合 (これはデフォルトの実装です)、グラフコンポーネントが`not_supported_languages`の一部ではないすべての言語をサポートしていることを示します。

例：

*   `[]`: グラフコンポーネントはどの言語もサポートしていません
*   `なし`: `not_supported_languages`で定義されている言語を想定して、すべての言語がサポートされます
*   `["en"]`:グラフコンポーネントは英会話でのみ使用できます。

### `not_supported_languages`

このメソッドは、グラフコンポーネントがサポートしていない[言語](https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes)を指定する`not_supported_languages`です。Rasa は、モデル構成ファイルの`言語`キーを使用して、グラフコンポーネントが指定された言語での使用に有効であることを検証します。グラフコンポーネントが `None` を返す場合 (これはデフォルトの実装です)、`supported_languages`で指定されたすべての言語をサポートしていることを示します。

例：

*   `なし`または `[]`: `supported_languages`で指定されたすべての言語がサポートされています。
*   `["en"]`: グラフコンポーネントは、英語以外のどの言語でも使用できます。

### `required_packages`

`required_packages`メソッドは、このグラフコンポーネントを使用するためにインストールする必要がある追加のPythonパッケージを示します。Rasaは、実行時に必要なライブラリが見つからない場合、実行中にエラーを発生させます。デフォルトでは、このメソッドは空のリストを返しますが、これはグラフコンポーネントに追加の依存関係がないことを意味します。

例：

*   `[]`: このグラフコンポーネントを使用するために追加のパッケージは必要ありません
*   `["spacy"]`: このグラフコンポーネントを使用するには、Python パッケージ `spacy` をインストールする必要があります。

## モデルの永続性

一部のグラフコンポーネントでは、トレーニング中にデータを永続化する必要がありますが、推論時にグラフコンポーネントで使用できるようにする必要があります。典型的なユースケースは、モデルの重みの保存です。Rasa は、以下のスニペットに示すように、この目的のためにグラフコンポーネント`の作成メソッドと``ロード`メソッドに`model_storage`パラメータと`リソース`パラメータを提供します。この`model_storage`は、すべてのグラフコンポーネントからのデータへのアクセスを提供します。この`リソース`を使用すると、モデルストレージ内のグラフコンポーネントの場所を一意に識別できます。

```python
from __future__ import annotations

from typing import Any, Dict, Text

from rasa.engine.graph import GraphComponent, ExecutionContext
from rasa.engine.storage.resource import Resource
from rasa.engine.storage.storage import ModelStorage

class MyComponent(GraphComponent):
    @classmethod
    def create(
        cls,
        config: Dict[Text, Any],
        model_storage: ModelStorage,
        resource: Resource,
        execution_context: ExecutionContext,
    ) -> MyComponent:
        ...

    @classmethod
    def load(
        cls,
        config: Dict[Text, Any],
        model_storage: ModelStorage,
        resource: Resource,
        execution_context: ExecutionContext,
        **kwargs: Any
    ) -> MyComponent:
        ...
```

### モデル・ストレージへの書き込み

以下のスニペットは、グラフコンポーネントのデータをモデルストレージに書き込む方法を示しています。トレーニング後にグラフコンポーネントを永続化するには、`トレーニング`メソッドが`model_storage`と`リソース`の値にアクセスする必要があります。したがって、初期化時に `model_storage` と `resource` の値を格納する必要があります。

グラフコンポーネントのトレーニングメソッドは、Rasa がトレーニング間でトレーニング結果をキャッシュできるように、`リソース`の値を返す必要があります。コンテキストマネージャーは `self._model_storage.write_to(self._resource)` 、グラフコンポーネントに必要なデータを永続化できるディレクトリへのパスを提供します。

```python
from __future__ import annotations
import json
from typing import Optional, Dict, Any, Text

from rasa.engine.graph import GraphComponent, ExecutionContext
from rasa.engine.storage.resource import Resource
from rasa.engine.storage.storage import ModelStorage
from rasa.shared.nlu.training_data.training_data import TrainingData

class MyComponent(GraphComponent):

    def __init__(
        self,
        model_storage: ModelStorage,
        resource: Resource,
        training_artifact: Optional[Dict],
    ) -> None:
        # Store both `model_storage` and `resource` as object attributes to be able
        # to utilize them at the end of the training
        self._model_storage = model_storage
        self._resource = resource

    @classmethod
    def create(
        cls,
        config: Dict[Text, Any],
        model_storage: ModelStorage,
        resource: Resource,
        execution_context: ExecutionContext,
    ) -> MyComponent:
        return cls(model_storage, resource, training_artifact=None)

    def train(self, training_data: TrainingData) -> Resource:
        # Train your graph component
        ...

        # Persist your graph component
        with self._model_storage.write_to(self._resource) as directory_path:
            with open(directory_path / "artifact.json", "w") as file:
                json.dump({"my": "training artifact"}, file)

        # Return resource to make sure the training artifacts
        # can be cached.
        return self._resource

```

### モデルストレージからの読み取り

Rasa は、グラフ コンポーネントの `load` メソッドを呼び出して、推論のためにインスタンス化します。コンテキストマネージャー `self._model_storage.read_from(resource)` を使用して、グラフコンポーネントのデータが永続化されたディレクトリへのパスを取得できます。提供されたパスを使用して、永続化されたデータをロードし、それを使用してグラフコンポーネントを初期化できます。`model_storage`は、指定された`リソース`に対して永続化されたデータが見つからない場合に `ValueError` をスローすることに注意してください。

```python
from __future__ import annotations
import json
from typing import Optional, Dict, Any, Text

from rasa.engine.graph import GraphComponent, ExecutionContext
from rasa.engine.storage.resource import Resource
from rasa.engine.storage.storage import ModelStorage

class MyComponent(GraphComponent):

    def __init__(
        self,
        model_storage: ModelStorage,
        resource: Resource,
        training_artifact: Optional[Dict],
    ) -> None:
        self._model_storage = model_storage
        self._resource = resource

    @classmethod
    def load(
        cls,
        config: Dict[Text, Any],
        model_storage: ModelStorage,
        resource: Resource,
        execution_context: ExecutionContext,
        **kwargs: Any,
    ) -> MyComponent:
        try:
            with model_storage.read_from(resource) as directory_path:
                with open(directory_path / "artifact.json", "r") as file:
                    training_artifact = json.load(file)
                    return cls(
                        model_storage, resource, training_artifact=training_artifact
                    )
        except ValueError:
            # This allows you to handle the case if there was no
            # persisted data for your component
            ...
```

## モデル構成へのグラフコンポーネントの登録

グラフコンポーネントをRasaで使用できるようにするには、グラフコンポーネントをレシピに登録する必要がある場合があります。Rasaはレシピを使用して、モデル構成の内容を実行可能ファイル[[custom-graph-components.md#グラフコンポーネント|graphs]]に変換します。現在、Rasa は `default.v1` と実験的な `graph.v1` レシピをサポートしています。`default.v1` レシピの場合は、`DefaultV1Recipe.register` を使用してグラフコンポーネントを登録する必要があります。 デコレータ：

Rasa は、`レジスタ`デコレータで提供される情報と、設定ファイル内のグラフコンポーネントの位置を使用して、必要なデータを含むグラフコンポーネントの実行をスケジュールします。`DefaultV1Recipe.register` デコレータでは、次の詳細を指定できます。

*   `component_types`: これは、グラフコンポーネントがアシスタント内で果たす目的を指定します。複数のタイプを指定することができます(たとえば、グラフコンポーネントがインテント分類子とエンティティ抽出器の両方である場合)。
    
    *   `ComponentType.MODEL_LOADER`: [[components.md#言語モデル|言語モデル]] のコンポーネント タイプ。このタイプのグラフコンポーネントは、他のグラフコンポーネントの`トレーニング`、`process_training_data`、`およびプロセス`メソッドに事前トレーニング済みモデルを提供します `model_from=<model loader name>` 。このグラフコンポーネントは、トレーニングと推論中に実行されます。Rasaは、グラフコンポーネントの`provide`メソッドを使用して、依存するグラフコンポーネントに提供する必要があるモデルを取得します。
        
    *   `ComponentType.MESSAGE_TOKENIZER` : コンポーネントタイプ [トークナイザー](components.md#トークナイザー)。このグラフコンポーネントは、トレーニングと推論中に実行されます。Rasaは、次の場合、グラフコンポーネントの`train`メソッドを使用します。 `is_trainable=True` が指定されています。Rasa は トレーニングデータの例と`プロセスを`トークン化するための`process_training_data` 推論中にメッセージをトークン化します。
        
    *   `ComponentType.MESSAGE_FEATURIZER` : コンポーネントタイプ [フィーチャライザー](components.md#フィーチャライザー)。このグラフコンポーネントは、トレーニングと推論中に実行されます。Rasaは、次の場合、グラフコンポーネントの`train`メソッドを使用します。 `is_trainable=True` が指定されています。Rasa は トレーニング データの例と`プロセスを`特徴付ける`ためのprocess_training_data` 推論中にメッセージを特徴付けます。
        
    *   `ComponentType.INTENT_CLASSIFIER` : コンポーネントタイプ [インテント分類子](components.md#インテント分類子).このグラフコンポーネントは、`is_trainable=True` の場合にのみトレーニング中に実行されます。グラフコンポーネントは、推論中に常に実行されます。Rasaは、次の場合、グラフコンポーネントの`train`メソッドを使用します。 `is_trainable=True` が指定されています。Rasa は、グラフ コンポーネントの`プロセス` メソッドを使用して、推論中にメッセージの意図を分類します。
        
    *   `ComponentType.ENTITY_EXTRACTOR` : [[components.md#エンティティ抽出器|entity extractors]] のコンポーネントタイプ。このグラフコンポーネントは、`is_trainable=True` の場合にのみトレーニング中に実行されます。グラフコンポーネントは、推論中に常に実行されます。Rasaは、次の場合、グラフコンポーネントの`train`メソッドを使用します。 `is_trainable=True` が指定されています。Rasa は、グラフ コンポーネントの`プロセス` メソッドを使用して、推論中にエンティティを抽出します。
        
    *   `ComponentType.POLICY_WITHOUT_END_TO_END_SUPPORT` : コンポーネントタイプ 追加のエンドツーエンド機能を必要としない[ポリシー](policies.md) (詳細については、[[stories.md#エンドツーエンドのトレーニング|エンドツーエンドのトレーニング]] を参照してください)。このグラフコンポーネントは、`is_trainable=True` の場合にのみトレーニング中に実行されます。グラフコンポーネントは、推論中に常に実行されます。Rasaは、次の場合、グラフコンポーネントの`train`メソッドを使用します。 `is_trainable=True` が指定されています。Rasa は、グラフコンポーネントの`predict_action_probabilities`を使用して、会話内で実行する必要がある次のアクションの予測を行います。
        
    *   `ComponentType.POLICY_WITH_END_TO_END_SUPPORT` : コンポーネントタイプ 追加のエンドツーエンド機能を必要とする[ポリシー](policies.md) (詳細については、[[stories.md#エンドツーエンドのトレーニング|エンドツーエンドのトレーニング]] を参照してください)。エンドツーエンドの特徴は、グラフコンポーネントの`トレイン`に渡され、 `predict_action_probabilities`事前`計算`パラメータとして。このグラフコンポーネントは、`is_trainable=True` の場合にのみトレーニング中に実行されます。グラフコンポーネントは、推論中に常に実行されます。Rasaは、次の場合、グラフコンポーネントの`train`メソッドを使用します。 `is_trainable=True` が指定されています。Rasa は、グラフ コンポーネントの`predict_action_probabilities`を使用して、会話内で実行する必要がある次のアクションを予測します。
        
*   `is_trainable`: グラフコンポーネントが他の依存グラフコンポーネントのトレーニングデータを処理する前、または予測を行う前に、グラフコンポーネント自体をトレーニングする必要があるかどうかを指定します
    
*   `model_from`: 事前トレーニング済みの [[components.md#言語モデル|言語モデル]] をグラフ コンポーネントの`トレーニング`、`process_training_data`、`およびプロセス` メソッドに提供する必要があるかどうかを指定します。これらのメソッドは、言語モデルを受け取るためにパラメータ`モデル`をサポートする必要があります。このモデルを提供するグラフコンポーネントがモデル構成の一部であることを確認する必要があることに注意してください。この一般的なユースケースは、[Spacy](components.md#SpacyNLP) 言語モデルを他の NLU コンポーネントに公開する場合です。
    

## モデル構成でのカスタムコンポーネントの使用

カスタムグラフコンポーネントは、[モデル構成](model-configuration.md)内で他の NLU コンポーネントやポリシーと同様に使用できます。唯一の変更点は、クラス名のみではなく、完全なモジュール名を指定する必要があることです。完全なモジュール名は、指定された [PYTHONPATH](https://docs.python.org/3/using/cmdline.html#envvar-PYTHONPATH) に対するモジュールの場所によって異なります。 デフォルトでは、Rasa は CLI を実行するディレクトリを `PYTHONPATH`です。たとえば、`/Users/<user>/my-rasa-project`からCLIを実行する場合 モジュール `MyComponent` が にある `/Users/<user>/my-rasa-project/custom_components/my_component.py` 場合、モジュール パスは `custom_components.my_component.MyComponent` です。`名前`エントリを除くすべては、`構成`としてコンポーネントに渡されます。

```yaml-rasa
recipe: default.v1
language: en
pipeline:
# other NLU components
- name: your.custom.NLUComponent
  setting_a: 0.01
  setting_b: string_value

policies:
# other dialogue policies
- name: your.custom.Policy
```

## 実装のヒント

### メッセージメタデータ

[[./training-data-format.md#トレーニング例|トレーニングデータ内のインテント例のメタデータを定義する]] を使用すると、NLU コンポーネントは処理中にインテントメタデータとインテントサンプルメタデータの両方にアクセスできます。

```python
# in your component class

    def process(self, message: Message, **kwargs: Any) -> None:
        metadata = message.get("metadata")
        print(metadata.get("intent"))
        print(metadata.get("example"))
```

### スパースおよび高密度メッセージ機能

カスタム メッセージ フィーチャライザーを作成する場合は、シーケンス機能と文機能の 2 つの異なる種類の機能を返すことができます。シーケンス特徴は、サイズ `(number-of-tokens x feature-dimension)` の行列、つまり、行列にはシーケンス内のすべてのトークンの特徴ベクトルが含まれています。文の特徴は、サイズ `(1 x 特徴次元)` の行列で表されます。

## カスタムコンポーネントの例

### 高密度メッセージ特徴付け

高密度[メッセージ特徴付け器](components.md#フィーチャライザー)の例を次に示します 事前トレーニング済みモデルを使用します。

### スパース メッセージ フィーチャライザー

高密度[メッセージ特徴付け器](components.md#フィーチャライザー)の例を次に示します 新しいモデルをトレーニングします。

### NLU メタ学習者

> [!info]
> 高度なユースケースNLUメタ学習者は、高度なユースケースです。次のセクションは、前の分類子の出力に基づいてパラメーターを学習するコンポーネントがある場合にのみ関連します。パラメーターまたはロジックを手動で設定したコンポーネントの場合は、`is_trainable=False` を使用してコンポーネントを作成でき、上記の分類子を気にする必要はありません。

NLU メタ学習器は、他のトレーニング済みインテント分類器またはエンティティ抽出器の予測を使用し、その結果を改善しようとするインテント分類器またはエンティティ抽出器です。メタ学習器の例としては、前の 2 つのインテント分類器の出力を平均化するコンポーネントや、トレーニング例に対するインテント分類器の信頼度に応じてしきい値を設定するフォールバック分類器があります。

概念的には、トレーニング可能なフォールバック分類子を構築するには、まずそのフォールバック分類子をカスタムコンポーネントとして作成する必要があります。

次に、分類子の出力を下流の別のコンポーネントで使用する必要があるため、特徴付け器でもあるカスタム意図分類子を作成する必要があります。カスタム インテント分類子コンポーネントの場合、`process_training_data` メソッドを指定して、その予測をメッセージ データに追加する方法も定義する必要があります。インテントの真のラベルを上書きしないようにしてください。この目的のために DIET をサブクラス化する方法を示すテンプレートを次に示します。