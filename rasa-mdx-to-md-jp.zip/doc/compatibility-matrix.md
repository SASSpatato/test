---
id: compatibility-matrix
sidebar_label: Compatibility Matrix
title: Compatibility Matrix
description: |
  Information about compatibility between Rasa Pro Services and Rasa Plus.
---

[導入](./deploy/deploy-rasa-pro-services.md)するRasa Pro Servicesのバージョンを選択する際には、以下の表を参照して、Rasa Plusのインストールと互換性のあるバージョンを確認してください。

Rasa Pro Services のバージョンは、同じメジャー バージョン番号を共有することを除いて、Rasa Plus バージョンとは独立しています。

| Rasa Proサービス | ラサプラス |
| --- | --- |
| 3.0.x | 3.3.x、3.4.x、3.5.x |
| 3.1.x | 3.6.x |