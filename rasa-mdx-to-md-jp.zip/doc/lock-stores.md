---
id: lock-stores
sidebar_label: Lock Stores
title: Lock Stores
description: Messages that are being processed lock Rasa for a given conversation ID to ensure that multiple incoming messages for that conversation do not interfere with each other. Rasa provides multiple implementations to maintain conversation locks.
---

Rasa はチケットロックメカニズムを使用して、特定の会話 ID の受信メッセージが正しい順序で処理されるようにし、メッセージがアクティブに処理されている間は会話をロックします。つまり、複数の Rasa サーバーをレプリケートされたサービスとして並行して実行でき、クライアントは、特定の会話 ID のメッセージを送信するときに必ずしも同じノードにアドレスを指定する必要はありません。

## InMemoryLockStore (既定値)

*   **形容**
    
    `InMemoryLockStore` は、既定のロック ストアです。1 つのプロセス内で会話ロックが維持されます。
    

> [!注] このロックストアは、複数の Rasa サーバが並列に実行されている場合は使用しないでください。

*   **構成**
    
    `InMemoryTrackerStore` を使用するには、構成は必要ありません。
    

## ConcurrentRedisLockStore

> [!warning] Rasa Proのみ

`ConcurrentRedisLockStore` は、Redis を永続層として使用する新しいロックストアであり、複数の Rasa サーバーレプリカで安全に使用できます。このロックストアに切り替える方法については、[[#移行ガイド]]を参照してください。

### 形容

`ConcurrentRedisLockStore` は、発行された[チケット](https://rasa.com/docs/rasa/reference/rasa/core/lock/#ticket-objects)と最後に発行されたチケット番号のインスタンスの永続化レイヤーとして Redis を使用します。

チケット番号の初期化は 1 から始まりますが、`RedisLockStore` の初期化は 0 から始まります。チケットの有効期限が切れた場合、チケット番号は今後のチケットに再割り当てされません。その結果、チケット番号はチケットインスタンスに固有です。チケット番号は、永続化された最後に発行されたチケット番号の Redis アトミック トランザクション INCR を使用してインクリメントされます。

`ConcurrentRedisLockStore` は、任意の時点で 1 つの Rasa インスタンスのみが会話を処理できるようにします。したがって、この `LockStore の Redis` 実装は、異なる Rasa サーバーによって同じ会話に対して並行して受信したメッセージを処理できます。これは、レプリケートされた Rasa サーバーのセットを実行するために推奨されるロックストアです。

### 構成

RedisでRasaをセットアップするには、次の手順が必要です。

1.  Redis インスタンスを起動する
    
2.  必要な構成を`endpoints.yml`に追加する
    

```yaml-rasa
lock_store:
    type: rasa_plus.components.concurrent_lock_store.ConcurrentRedisLockStore
    host: <host of the redis instance, e.g. localhost>
    port: <port of your redis instance, usually 6379>
    password: <password used for authentication>
    db: <number of your database within redis, e.g. 0>
    key_prefix: <alphanumeric value to prepend to lock store keys>
```

3.  Redis バックエンドを使用して Rasa Core サーバーを起動するには、`--endpoints` フラグ、例:
    
    ```bash
    rasa run -m models --endpoints endpoints.yml
    ```
    

### パラメーター

*   `url` (デフォルト: `localhost`): redis インスタンスの URL
*   `port` (デフォルト: `6379`): redis が実行されているポート
*   `db` (デフォルト: `1`): redis データベースの数
*   `key_prefix` (デフォルト: `なし`): ロックストアキーの先頭に付けるプレフィックス。英数字である必要があります
*   `password` (デフォルト: `None`): 認証に使用されるパスワード (`None` は認証なしに等しい)
*   `use_ssl` (デフォルト: `False`): 通信が暗号化されているかどうか-`socket_timeout` (デフォルト: `10`): Redis が応答しない場合にエラーが発生するまでの秒単位の時間

### 移行ガイド

`RedisLockStore` から `ConcurrentRedisLockStore` に切り替えるには、`ConcurrentRedisLockStore` クラスへの完全なモジュール パスを `endpoints.yml` の`型`として指定します。

```yaml-rasa
lock_store:
    type: rasa_plus.components.concurrent_lock_store.ConcurrentRedisLockStore
    host: <host of the redis instance, e.g. localhost>
    port: <port of your redis instance, usually 6379>
    password: <password used for authentication>
    db: <number of your database within redis, e.g. 0>
    key_prefix: <alphanumeric value to prepend to lock store keys>
```

redis ロックストア設定の `url` フィールドを、redis インスタンスのホスト名を含むフィールド`ホスト`に置き換える必要があります。

`ConcurrentRedisLockStore` に切り替えるときに、データベースの移行は必要ありません。`RedisLockStore` を使用するときに以前と同じ Redis インスタンスとデータベース番号を使用できます。同じRedisデータベース番号を使用している場合は、既存のキーをすべて削除することができます。これらの以前のキーと値の項目は、`ConcurrentRedisLockStore` では不要になり、データベースをクリアできます。

`RedisLockStore` はシリアル化された [TicketLock](https://rasa.com/docs/rasa/reference/rasa/core/lock/#ticketlock-objects) インスタンスを保持し、`ConcurrentRedisLockStore` は代わりに個々の [`Ticket`](https://rasa.com/docs/rasa/reference/rasa/core/lock/#ticket-objects) インスタンスと最後に発行されたチケット番号を格納するため、`RedisLockStore` と `ConcurrentRedisLockStore` を使用する場合に格納されるキーと値の項目に重複はありません。`ConcurrentRedisLockStore` は、永続化された `Ticket` インスタンスから `TicketLock` を再作成し、同じメッセージ交換 ID の同時メッセージを処理できるようにします。

## RedisLockストア

*   **形容**
    
    `RedisLockStore` は、Redis を永続化レイヤーとして使用して会話ロックを維持します。これは、レプリケートされた Rasa サーバーのセットを実行するために推奨されるロックストアです。
    
*   **構成**
    
    RedisでRasaをセットアップするには、次の手順が必要です。
    
    1.  Redis インスタンスを起動する
        
    2.  必要な構成を`endpoints.yml`に追加する
        

```
     lock_store:
    type: "redis"
    url: <url of the redis instance, e.g. localhost>
    port: <port of your redis instance, usually 6379>
    password: <password used for authentication>
    db: <number of your database within redis, e.g. 0>
    key_prefix: <alphanumeric value to prepend to lock store keys>
```

3.  Redis バックエンドを使用して Rasa Core サーバーを起動するには、`次のように --endpoints` フラグを追加します。

```
     rasa run -m models --endpoints endpoints.yml
```

*   **パラメーター**
    
    *   `url` (デフォルト: `localhost`): redis インスタンスの URL
        
    *   `port` (デフォルト: `6379`): redis が実行されているポート
        
    *   `db` (デフォルト: `1`): redis データベースの数
        
    *   `key_prefix` (デフォルト: `なし`): ロックストアキーの先頭に付けるプレフィックス。英数字である必要があります
        
    *   `username` (デフォルト: `None`): 認証に使用されるユーザー名
        
    *   `password` (デフォルト: `None`): 認証に使用されるパスワード (`None` は認証なしに相当します)
        
    *   `use_ssl`(デフォルト:`False`):通信が暗号化されているかどうか
        
    *   `ssl_keyfile` (デフォルト: `なし`): ssl 秘密鍵へのパス
        
    *   `ssl_certfile` (デフォルト: `なし`): ssl 証明書へのパス
        
    *   `ssl_ca_certs` (デフォルト: `なし`): PEM 形式の連結された CA 証明書のファイルへのパス
        
    *   `socket_timeout` (デフォルト: `10`): Redis が応答しない場合にエラーが発生するまでの時間 (秒単位)
        

## カスタムロックストア

すぐに使えないロックストアが必要な場合は、独自のロックストアを実装できます。これは、基本クラス `LockStore` を拡張することによって行われます。

カスタム ロック ストア クラスでは、次のメソッドも実装する必要があります。

*   `get_lock`:ストレージから`conversation_id`のロックを取得します。は`テキストパラメータconversation_id`必要で、`TicketLock` インスタンスを返します。 [(ソースコード - 署名を参照)。](https://github.com/RasaHQ/rasa/blob/main/rasa/core/lock_store.py#L59)
*   `save_lock`: `ロック`オブジェクトをストレージにコミットします。requires `lock`パラメータは、`TicketLock`型で`None`を返します。 [(ソースコード - 署名を参照)。](https://github.com/RasaHQ/rasa/blob/main/rasa/core/lock_store.py#L67)
*   `delete_lock`: `ストレージからconversation_id`のロックを削除します。テキストパラメータ`conversation_id`必要で、`None`を返します。 [(ソースコード - 署名を参照)。](https://github.com/RasaHQ/rasa/blob/main/rasa/core/lock_store.py#L63)

### 構成

カスタムイベントブローカーへのモジュールパスと、必要なパラメータを`endpoints.yml`に配置します。

```yaml-rasa
lock_store:
  type: path.to.your.module.Class
  url: localhost
  a_parameter: a value
  another_parameter: another value
```