---
id: microsoft-luis-to-rasa
sidebar_label: Rasa as open source alternative to Microsoft LUIS - Migration Guide
title: Rasa as open source alternative to Microsoft LUIS - Migration Guide
description: Open source alternative to Microsoft LUIS for conversational bots and NLP
---

LUIS から Rasa へのアプリケーションの移行を開始しましょう。

## 手順 1: LUIS からトレーニング データをエクスポートする

[LUIS 会話アプリの](https://www.luis.ai/conversations/applications)一覧に移動し、エクスポートするアプリケーションを選択します。

![[luis_export.png]]

「エクスポート」> 「JSON としてエクスポート」を選択します。これにより、`.json`拡張子のファイルがダウンロードされ、Rasa に直接インポートできます。

## ステップ 2: Rasa プロジェクトを作成する

Rasa プロジェクトを作成するには、以下を実行します。

```bash
rasa init
```

これにより、`data` というディレクトリが作成されます。このディレクトリ内のファイルを削除し、json ファイルをこのディレクトリに移動します。

```bash
rm -r data/*
mv /path/to/file.json data/
```

## ステップ 3: NLU モデルをトレーニングする

LUIS データを使用してモデルをトレーニングするには、次を実行します。

```bash
rasa train nlu
```

## ステップ 4: NLU モデルをテストする

NLU モデルがいくつかのテスト メッセージをどのように解釈するかを見てみましょう。テスト セッションを開始するには、次のコマンドを実行します。

```bash
rasa shell nlu
```

これにより、入力を求められます。テストメッセージを入力し、「Enter」を押します。NLUモデルの出力が画面に出力されます。メッセージを入力し続け、好きなだけテストできます。「control + C」を押して終了します。

## ステップ 5: NLU モデルでサーバーを起動する

NLU モデルでサーバーを起動するには、次のコマンドを実行します。

```bash
rasa run
```

これにより、ポート 5005 でリッスンするサーバーが開始されます。

サーバーに要求を送信するには、以下を実行します。

```bash
curl 'localhost:5005/model/parse?emulation_mode=luis' -d '{"text": "hello"}'
The `emulation_mode` parameter tells Rasa that you want your json
response to have the same format as you would get from LUIS.
You can also leave it out to get the result in the usual Rasa format.

## Terminology:

The words `intent`, `entity`, `role`, and `utterance` have the same meaning in Rasa as they do
in LUIS.
LUIS's `patterns` feature is very similar to Rasa NLU's [regex features](./training-data-format.mdx#regular-expressions)
LUIS's `phrase lists` feature does not currently have an equivalent in Rasa NLU.

Join the [Rasa Community Forum](https://forum.rasa.com/) and let us know how your migration went!
```