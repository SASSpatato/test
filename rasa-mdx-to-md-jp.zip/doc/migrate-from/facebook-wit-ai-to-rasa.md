---
id: facebook-wit-ai-to-rasa
sidebar_label: "Rasa as open source alternative to Facebooku2019s Wit.ai - Migration
   Guide"
title: "Rasa as open source alternative to Facebooku2019s Wit.ai - Migration Guide"
description: Open source alternative to Facebook's Wit.ai for conversational bots and NLP
---

Wit.ai から Rasa へのアプリケーションの移行を開始するには:

## ステップ 1: トレーニング データを Wit.ai からエクスポートする

左側のナビゲーションバーの **管理**セクションにある **設定** 項目をクリックして、アプリの設定ページに移動します。**データのエクスポート** まで下にスクロールし、**データを使用して.zipをダウンロード** ボタンを押します。

これにより、拡張子`が.zip`のファイルがダウンロードされます。このファイルを解凍してフォルダーを作成します。ダウンロードから必要なファイルは、**utterances** ディレクトリにあります。

## ステップ 2: Rasa プロジェクトを作成する

Rasa プロジェクトを作成するには、以下を実行します。

```bash
rasa init
```

これにより、`data`というディレクトリが作成されます。このディレクトリ内のファイルを削除し、`発話ディレクトリ`の内容を`data`に移動します。

```bash
rm -rf data/
mv /path/to/utterances data/
```

## ステップ 3: NLU モデルをトレーニングする

Wit データを使用してモデルをトレーニングするには、次を実行します。

```bash
rasa train nlu
```

## ステップ 4: NLU モデルをテストする

NLU モデルがいくつかのテスト メッセージをどのように解釈するかを見てみましょう。テスト セッションを開始するには、次のコマンドを実行します。

```bash
rasa shell nlu
```

これにより、入力を求められます。テストメッセージを入力し、「Enter」を押します。NLUモデルの出力が画面に出力されます。メッセージを入力し続け、好きなだけテストできます。「control + C」を押して終了します。

## ステップ 5: NLU モデルでサーバーを起動する

NLU モデルでサーバーを起動するには、次のコマンドを実行します。

```bash
rasa run nlu
```

これにより、ポート 5005 でリッスンするサーバーが開始されます。

サーバーに要求を送信するには、以下を実行します。

```bash
curl 'localhost:5005/model/parse?emulation_mode=wit' -d '{"text": "hello"}'
The `emulation_mode` parameter tells Rasa that you want your json
response to have the same format as you would get from wit.ai.
You can also leave it out to get the result in the usual Rasa format.

Join the [Rasa Community Forum](https://forum.rasa.com/) and let us know how your migration went!
```