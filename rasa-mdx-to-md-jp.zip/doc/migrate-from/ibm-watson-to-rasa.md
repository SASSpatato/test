---
id: ibm-watson-to-rasa
sidebar_label: Rasa as open source alternative to IBM Watson - Migration Tips
title: Rasa as open source alternative to IBM Watson - Migration Tips
description: Open source alternative to IBM Watson for conversational bots and NLP
---

IBM Watson はまだサポートされていません。ただし、コミュニティー・メンバーのグループは、[エクスポートされた IBM Watson ワークスペース](https://developer.ibm.com/tutorials/learn-how-to-export-import-a-watson-assistant-workspace/)を使用する方法に取り組んでいます ラサで。それに興味がある場合は、[コミュニティフォーラム](https://forum.rasa.com/)をチェックしてください。