---
sidebar_label: Rasa as open source alternative to Google Dialogflow - Migration Guide
title: Rasa as open source alternative to Google Dialogflow - Migration Guide
description: Open source alternative to Google Dialogflow for conversational bots and NLP
---

Dialogflow から Rasa へのアプリケーションの移行を開始しましょう (より詳細なチュートリアルは[こちらにあります](http://blog.rasa.com/how-to-migrate-your-existing-google-dialogflow-assistant-to-rasa/))。

## ステップ 1: Dialogflow からデータをエクスポートする

歯車アイコンをクリックして、エージェントの設定に移動します。

![[dialogflow_export.png]]

「エクスポートとインポート」タブをクリックし、「ZIPとしてエクスポート」ボタンをクリックします。

![[dialogflow_export_2.png]]

これにより、拡張子`が.zip`のファイルがダウンロードされます。このファイルを解凍してフォルダーを作成します。

## ステップ 2: Rasa プロジェクトを作成する

Rasa プロジェクトを作成するには、以下を実行します。

```bash
rasa init
```

これにより、`data` というディレクトリが作成されます。このディレクトリ内のファイルを削除し、解凍したフォルダをこのディレクトリに移動します。

```bash
rm -r data/*
mv testagent data/
```

## ステップ 3: NLU モデルをトレーニングする

Dialogflow データを使用してモデルをトレーニングするには、次を実行します。

```bash
rasa train nlu
```

## ステップ 4: NLU モデルをテストする

NLU モデルがいくつかのテスト メッセージをどのように解釈するかを見てみましょう。テスト セッションを開始するには、次のコマンドを実行します。

```bash
rasa shell nlu
```

これにより、入力を求められます。テストメッセージを入力し、「Enter」を押します。NLUモデルの出力が画面に出力されます。メッセージを入力し続け、好きなだけテストできます。「control + C」を押して終了します。

## ステップ 5: NLU モデルでサーバーを起動する

NLU モデルでサーバーを起動するには、次のコマンドを実行します。

```bash
rasa run --enable-api
```

これにより、ポート 5005 でリッスンするサーバーが開始されます。

サーバーに要求を送信するには、以下を実行します。

```bash
curl 'localhost:5005/model/parse?emulation_mode=dialogflow' -d '{"text": "hello"}'
```

`emulation_mode` パラメーターは、JSON 応答を Dialogflow `sessions.detectIntent` エンドポイントから取得するのと同じ形式にすることを Rasa に指示します (形式については[、こちら](https://cloud.google.com/dialogflow/es/docs/reference/rest/v2/DetectIntentResponse)で説明します)。また、このパラメーターを省略して、通常の Rasa 形式で結果を取得することもできます。

## 用語：

`意図`、`エンティティ`、`発話`という単語は、Dialogflow と同様に Rasa でも同じ意味を持ちます。Dialogflow には、`フルフィルメント`と呼ばれる概念があります。Rasa では、これを [[actions#カスタムアクション|カスタムアクション]] と呼びます。

[Rasa コミュニティ フォーラム](https://forum.rasa.com/)に参加して、移行の様子をお知らせください。