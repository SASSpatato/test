---
id: nlu-training-data
sidebar_label: NLU Training Data
title: NLU Training Data
description: Read more about how to format training data with Rasa NLU for open source natural language processing.
abstract: NLU training data stores structured information about user messages.
---

NLU (自然言語理解) の目標は、ユーザー メッセージから構造化された情報を抽出することです。これには通常、ユーザーの[意図](glossary.md#intent)と メッセージに含まれる[[glossary.md#./training-data-format.md エンティティ 実体|エンティティ]]。[[#正規表現]] や [[#ルックアップテーブル]] などの追加情報をトレーニング データに追加して、モデルが意図とエンティティを正しく識別できるようにすることができます。

## トレーニング例

NLU トレーニング データは、意図ごとに分類されたユーザーの発話の例で構成されます。インテントを使いやすくするには、ユーザーがそのインテントで達成したいことに関連する名前を付け、小文字にし、スペースや特殊文字は避けてください。

> [!note] 
> `/` 記号は、応答テキスト識別子から [[glossary.md#[取得インテント](./chitchat-faqs.md)|取得インテント]] を区切るための区切り文字として予約されています。インテントの名前で使用しないように注意してください。


## エンティティ

[[glossary.md#./training-data-format.md エンティティ 実体|エンティティ]]、ユーザーメッセージ内の構造化された情報です。エンティティ抽出を機能させるには、ML モデルをトレーニングするためのトレーニング データを指定するか、[[#エンティティ抽出の正規表現]] を定義して、文字パターンに基づいて [`RegexEntityExtractor`](components.md#regexentityextractor) を使用してエンティティを抽出する必要があります。

抽出する必要があるエンティティを決定するときは、アシスタントがユーザーの目標のためにどのような情報を必要とするかを考えてください。ユーザーは、ユーザーの目標に必要のない追加の情報を提供する場合があります。これらをエンティティとして抽出する必要はありません。

トレーニングデータ内のエンティティに注釈を付ける方法の詳細については、[トレーニングデータ形式](./training-data-format.md)を参照してください。

## 類義 語

シノニムは、抽出されたエンティティを、大文字と小文字を区別しない方法で抽出されたリテラル テキスト以外の値にマップします。ユーザーが同じものを参照する方法が複数ある場合に、同義語を使用できます。エンティティを抽出するという最終目標を考え、そこからどの値を同等と見なすべきかを考えます。

ユーザーの残高を検索するために使用するエンティティ `アカウント`があるとします。考えられるアカウントタイプの1つは「クレジット」です。ユーザーは、自分の「クレジット」アカウントを「クレジットアカウント」および「クレジットカードアカウント」とも呼びます。

この場合、「クレジットカードアカウント」と「クレジットアカウント」を「クレジット」の同義語として定義できます。

```yaml-rasa
nlu:
- synonym: credit
  examples: |
    - credit card account
    - credit account
```

次に、これらのフレーズのいずれかがエンティティとして抽出されると`、価値クレジット`にマップされます。これらのフレーズの代替大文字と小文字 (`CREDIT、``credit ACCOUNT` など) もシノニムにマッピングされます。

> [!NOTE] トレーニング例を提供する シノニムマッピングは、エンティティが抽出**された後**にのみ行われます。つまり、トレーニング例には同義語の例 (`クレジット カード アカウント`と`クレジット アカウント`) を含めて、モデルがこれらをエンティティとして認識し、`クレジット`に置き換えることを学習する必要があります。

トレーニングデータにシノニムを含める方法の詳細については、[トレーニングデータ形式](./training-data-format.md)を参照してください。

## 正規表現

正規表現を使用すると、パイプライン内の [`RegexFeaturizer` コンポーネント](components.md#regexfeaturizer)と [`RegexEntityExtractor`](components.md#regexentityextractor) コンポーネントと組み合わせて、意図の分類とエンティティ抽出を改善できます。

### インテント分類の正規表現

正規表現を使用すると、パイプラインに `RegexFeaturizer` コンポーネントを含めることで、意図の分類を改善できます。`RegexFeaturizer` を使用する場合、正規表現はインテントを分類するためのルールとして機能しません。これは、インテント分類器がインテント分類のパターンを学習するために使用する機能のみを提供します。現在、すべてのインテント分類子は、利用可能な正規表現機能を利用しています。

この場合の正規表現の名前は、人間が判読できる記述です。正規表現が何に使用されるかを覚えるのに役立ち、対応するパターン機能のタイトルです。意図やエンティティ名と一致する必要はありません。「help」リクエストの正規表現は次のようになります。

```yaml-rasa
nlu:
- regex: help
  examples: |
    - bhelpb
```

一致する意図は、`挨拶`、`help_me`、`支援`などです。

正規表現は、できるだけ少ない単語に一致するように作成してください。たとえば、`help.*` の代わりに `bhelpb` を使用すると、後者はメッセージ全体に一致する可能性があるのに対し、最初のものは 1 つの単語のみに一致します。

> [!NOTE] 
> トレーニング例を提供する `RegexFeaturizer` はインテント分類子に機能を提供しますが、インテントを直接予測するわけではありません。インテント分類子が正規表現機能の使用方法を学習できるように、正規表現を含む十分な例を含めます。

### エンティティ抽出の正規表現

エンティティに決定論的な構造がある場合は、次の 2 つの方法のいずれかで正規表現を使用できます。

#### 特徴としての正規表現

正規表現を使用して、NLU パイプラインの [`RegexFeaturizer`](components.md#regexfeaturizer) コンポーネントの機能を作成できます。

`RegexFeaturizer` で正規表現を使用する場合、正規表現の名前は重要ではありません。`RegexFeaturizer` を使用する場合、正規表現は、モデルが意図/エンティティと正規表現に適合する入力の間の関連付けを学習するのに役立つ機能を提供します。

> [!NOTE] トレーニング例を提供する `RegexFeaturizer` はエンティティ抽出器に機能を提供しますが、エンティティを直接予測するわけではありません。エンティティ抽出器が正規表現機能の使用方法を学習できるように、正規表現を含む十分な例を含めます。

エンティティ抽出の正規表現機能は、現在、`CRFEntityExtractor` コンポーネントと `DIETClassifier` コンポーネントでのみサポートされています。その他のエンティティ抽出器 ( `MitieEntityExtractor` または `SpacyEntityExtractor` は、生成された特徴を使用しず、それらの存在によってこれらの抽出器のエンティティ認識は改善されません。

#### ルールベースのエンティティ抽出の正規表現

NLU パイプラインの [`RegexEntityExtractor`](components.md#regexentityextractor) コンポーネントを使用して、ルールベースのエンティティ抽出に正規表現を使用できます。

`RegexEntityExtractor` を使用する場合、正規表現の名前は抽出するエンティティの名前と一致する必要があります。たとえば、この正規表現と少なくとも 2 つの注釈付き例をトレーニング データに含めることで、10 桁から 12 桁の口座番号を抽出できます。

```yaml-rasa
nlu:
- regex: account_number
  examples: |
    - d{10,12}
- intent: inform
  examples: |
    - my account number is [1234567891](account_number)
    - This is my account number [1234567891](account_number)
```

ユーザーメッセージに10〜12桁のシーケンスが含まれている場合は常に、`account_number`エンティティとして抽出されます。`RegexEntityExtractor` では、エンティティの抽出方法を学習するためにトレーニング例は必要ありませんが、NLU モデルがトレーニング時にエンティティとして登録できるように、エンティティの注釈付き例が少なくとも 2 つ必要です。

## ルックアップテーブル

ルックアップテーブルは、大文字と小文字を区別しない正規表現パターンを生成するために使用される単語のリストです。これらは、パイプライン内の [`RegexFeaturizer`](components.md#regexfeaturizer) コンポーネントと [`RegexEntityExtractor`](components.md#regexentityextractor) コンポーネントを組み合わせて、 [[#正規表現]] が使用されるのと同じ方法で使用できます。

ルックアップ テーブルを使用すると、既知の可能な値のセットを持つエンティティを抽出できます。ルックアップ テーブルはできるだけ具体的にしてください。たとえば、国名を抽出するには、世界中のすべての国のルックアップ テーブルを追加できます。

```yaml-rasa
nlu:
- lookup: country
  examples: |
    - Afghanistan
    - Albania
    - ...
    - Zambia
    - Zimbabwe
```

`RegexFeaturizer` でルックアップ テーブルを使用する場合は、モデルが生成された正規表現を特徴として使用する方法を学習できるように、照合する意図またはエンティティの十分な例を提供します。`RegexEntityExtractor` でルックアップ テーブルを使用する場合は、NLU モデルがトレーニング時にエンティティとして登録できるように、エンティティの注釈付き例を少なくとも 2 つ指定します。

## エンティティ、ロール、およびグループ

単語をカスタムエンティティとして注釈を付けると、トレーニングデータで特定の概念を定義できます。たとえば、都市に注釈を付けることで都市を識別できます。

```
I want to fly from [Berlin]{"entity": "city"} to [San Francisco]{"entity": "city"} .
```

ただし、エンティティに詳細を追加したい場合があります。

たとえば、フライトを予約するアシスタントを作成するには、アシスタントは、上記の例の 2 つの都市のうち、どちらが出発都市で、どの都市が 目的地の都市。 `ベルリン`と`サンフランシスコ`はどちらも都市ですが、メッセージの中で異なる**役割を果たし**ています。異なるロールを区別するために、エンティティ ラベルに加えてロール ラベルを割り当てることができます。

```
- I want to fly from [Berlin]{"entity": "city", "role": "departure"} to [San Francisco]{"entity": "city", "role": "destination"}.
```

エンティティ ラベルの横に**グループ** ラベルを指定することで、異なるエンティティをグループ化することもできます。たとえば、グループラベルを使用して、さまざまな注文を定義できます。次の例では、グループラベルは、どのピザにどのトッピングを添え、各ピザのサイズにするかを指定します。

```
Give me a [small]{"entity": "size", "group": "1"} pizza with [mushrooms]{"entity": "topping", "group": "1"} and
a [large]{"entity": "size", "group": "2"} [pepperoni]{"entity": "topping", "group": "2"}
```

トレーニングデータでロールとグループを持つエンティティを定義する方法の詳細については、[[training-data-format.md#エンティティ|トレーニングデータ形式]]を参照してください。

抽出器によって返されるエンティティ オブジェクトには、検出されたロール/グループ ラベルが含まれます。

```json
{
  "text": "Book a flight from Berlin to SF",
  "intent": "book_flight",
  "entities": [
    {
      "start": 19,
      "end": 25,
      "value": "Berlin",
      "entity": "city",
      "role": "departure",
      "extractor": "DIETClassifier",
    },
    {
      "start": 29,
      "end": 31,
      "value": "San Francisco",
      "entity": "city",
      "role": "destination",
      "extractor": "DIETClassifier",
    }
  ]
}
```

> [!note] 
> エンティティの役割とグループは、現在、[DIETClassifier](./components.md#dietclassifier) と [CRFEntityExtractor](./components.md#crfentityextractor) によってのみサポートされています。

ロールとグループを持つエンティティを使用してモデルを適切にトレーニングするには、エンティティとロールまたはグループラベルのすべての組み合わせに十分なトレーニング例を必ず含めてください。モデルを一般化できるようにするには、トレーニング例にいくつかのバリエーションがあることを確認してください。たとえば、fly `FROM x TO y` だけでなく、`fly TO y FROM x` などの例を含める必要があります。

エンティティから特定のロール/グループを持つスロットを埋めるには、スロットの`from_entity`[スロットマッピング](./domain.md#スロットマッピング)を定義し、必要なロール/グループを指定する必要があります。例えば：

```yaml-rasa
entities:
   - city:
       roles:
       - departure
       - destination

slots:
  departure:
    type: any
    mappings:
    - type: from_entity
      entity: city
      role: departure
  destination:
    type: any
    mappings:
    - type: from_entity
      entity: city
      role: destination
```

### 対話の予測に影響を与えるエンティティの役割とグループ

役割またはグループごとに対話の予測に影響を与える場合は、目的の役割またはグループラベルを含むようにストーリーを変更する必要があります。また、[ドメイン ファイル](./domain.md#エンティティ)内のエンティティの対応するロールとグループを一覧表示する必要があります。

ユーザーの場所によって異なる文章を出力したいとします。たとえば、ユーザーがロンドンから到着したばかりの場合、ロンドンへの旅行はどうだったかを尋ねるとよいでしょう。ただし、ユーザーがマドリードに向かう途中の場合は、ユーザーのご滞在を祈りたいと思うかもしれません。これは、次の 2 つのストーリーで実現できます。

```yaml-rasa
stories:
- story: The user just arrived from another city.
  steps:
    - intent: greet
    - action: utter_greet
    - intent: inform_location
      entities:
        - city: London
          role: from
    - action: utter_ask_about_trip

- story: The user is going to another city.
  steps:
    - intent: greet
    - action: utter_greet
    - intent: inform_location
      entities:
        - city: Madrid
          role: to
    - action: utter_wish_pleasant_stay
```

## BILOUエンティティのタグ付け

[DIETClassifier](./components.md#dietclassifier) と [CRFEntityExtractor](./components.md#crfentityextractor) には、エンティティを処理するときに機械学習モデルが使用できるタグ付けスキーマを参照するオプション `BILOU_flag` があります。 `BILOU`は、Beginning、Inside、Last、Outside、Unit-lengthの略です。

たとえば、トレーニングの例

```
[Alex]{"entity": "person"} is going with [Marty A. Rick]{"entity": "person"} to [Los Angeles]{"entity": "location"}.
```

は、最初にトークンのリストに分割されます。次に、機械学習モデルは、オプション`BILOU_flag`の値に応じて、次に示すようにタグ付けスキーマを適用します。

| トークン | BILOU_flag = true | BILOU_flag = false |
| --- | --- | --- |
| アレックス | U-パーソン | 人 |
| です | O | O |
| ゆき | O | O |
| で | O | O |
| マーティ | Bパーソン | 人 |
| a | I-person | 人 |
| リック | L人 | 人 |
| 宛先 | O | O |
| ロス | Bロケーション | 場所 |
| アンヘレス | L位置 | 場所 |

BILOU タグ付けスキーマは、通常のタグ付けスキーマと比較してより豊富です。エンティティを予測する際の機械学習モデルのパフォーマンスを向上させるのに役立つ場合があります。

> [!注] 一貫性のないBILOUタグ
> オプション`BILOU_flag`が`True`に設定されている場合、モデルは一貫性のないBILOUタグ(`例:B人I-位置L人)`を予測する可能性があります。Rasa は、いくつかのヒューリスティックを使用して、矛盾した BILOU タグをクリーンアップします。たとえば、`B人 I-location L-person` は `B 人 I 人 L 人`に変更されます。