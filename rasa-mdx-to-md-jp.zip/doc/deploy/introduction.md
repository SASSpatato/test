---
id: introduction
sidebar_label: Introduction
title: Deploying a Rasa Assistant
description: How to deploy your Rasa Assistant with Kubernetes/Openshift
abstract: This section explains when and how to deploy an assistant built with Rasa.
  It will allow you to make your assistant available to users and set you up with a production-ready environment.
---

> [!note] 
> Docker、Kubernetes、Helmに馴染みがありませんか?[YouTubeチャンネル](https://www.youtube.com/channel/UCJ0V6493mLvqdiVwOKWBODQ)の「[Rasa Deploymentsを理解する](https://www.youtube.com/watch?v=aAs_RS0ueEw&list=PL75e0qA87dlHmfmu7oPPYA22fmc6GJ2aW)」をご覧ください。

## アシスタントを導入するタイミング

アシスタントをデプロイしてテストユーザーが使用できるようにする最適な時期は、最も重要なハッピーパスを処理できるようになったとき、または実行[可能な最小限のアシスタント](../glossary.md)と呼ばれるものです。その後、着信会話を使用して、アシスタントのさらなる開発を通知できます。

## 推奨される展開方法

[Rasa Helm Chart](https://github.com/RasaHQ/helm-charts/tree/main/charts/rasa) は、Kubernetes または Openshift クラスターにアシスタントをデプロイするための実稼働対応の方法です。詳細については、[デプロイ手順](./deploy-rasa.md)を参照してください。

### クラスターの要件

Rasa Helm チャートをインストールするには、既存の [Kubernetes クラスター](https://kubernetes.io/)または [OpenShift クラスター](https://www.openshift.com/)。まだお持ちでない場合は、次のようなクラウドプロバイダーからマネージドクラスターを入手できます。

*   [グーグルクラウド](https://cloud.google.com/kubernetes-engine)、
*   [デジタルオーシャン、](https://www.digitalocean.com/products/kubernetes/)
*   [Microsoft Azure](https://azure.microsoft.com/en-us/services/kubernetes-service/)、または
*   [アマゾン EKS](https://aws.amazon.com/eks/) です。

## 代替の展開方法

次のデプロイ方法は、運用環境のデプロイには適していませんが、開発とテストに役立ちます。

*   [[command-line-interface#rasa run|コマンドラインでローカルにアシスタントを実行する]]
    
*   [Docker コンテナーでのアシスタントの開発](../docker/building-in-docker.md)
    
*   [Docker Compose を使用したアシスタントのデプロイ](../docker/deploying-in-docker-compose.md)