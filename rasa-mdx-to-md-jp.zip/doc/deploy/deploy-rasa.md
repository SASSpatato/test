---
id: deploy-rasa
sidebar_label: "Deploy Rasa"
title: "Deploy Rasa"
description: Deploy a Rasa assistant on Kubernetes/Openshift using Helm
abstract: This page explains how to deploy Rasa Open Source and Rasa Plus using Helm.
---

> [!note]  
> Rasa Helm Chart はオープンソースであり、[helm-charts リポジトリ](https://github.com/rasahq/helm-charts)で入手できます。バグを発見した場合、または改善の提案がある場合は、このリポジトリで[問題を作成](https://github.com/RasaHQ/helm-charts/issues/new)してください。

## インストール要件

1.  Kubernetes または OpenShift コマンドラインインターフェイス (CLI) がインストールされていることを確認します。これは、次のコマンドを使用して確認できます。
    
    **Kubernetesの**
    
    ```bash
    kubectl version --short --client
    
    # The output should be similar to this
    # Client Version: v1.19.11
    ```
    
    **オープンシフト**
    
    ```bash
    oc version --client
    
    # The output should be similar to this
    # Client Version: 4.7.13
    ```
    
    このコマンドでエラーが発生した場合は、 [Kubernetes CLI](https://kubernetes.io/docs/tasks/tools/install-kubectl/) または [OpenShift CLI (英語)](https://docs.openshift.com/container-platform/4.7/cli_reference/openshift_cli/getting-started-cli.html#installing-openshift-cli) 使用しているクラスターによって異なります。
    
2.  Kubernetes / OpenShift CLI がクラスターに正しく接続されていることを確認します。これを行うには、次のコマンドを使用します。
    
    **Kubernetesの**
    
    ```bash
    kubectl version --short
    
    # The output should be similar to this
    # Client Version: v1.19.11
    # Server Version: v1.19.10
    ```
    
    **オープンシフト**
    
    ```bash
    oc version
    
    # The output should be similar to this
    # Client Version: 4.7.13
    # Kubernetes Version: v1.20.0+df9c838
    ```
    
    コマンドの実行時にエラーが発生した場合は、クラスターに接続されていません。クラスターに接続するコマンドを取得するには、クラスターの管理者またはクラウドプロバイダーのドキュメントを参照してください。
    
3.  [Helm CLI](https://helm.sh/docs/intro/install/) があることを確認する インストール。これを確認するには、次のコマンドを実行します。
    
    ```bash
    helm version --short
    
    # The output should be similar to this
    # v3.6.0+g7f2df64
    ```
    
    このコマンドでエラーが発生する場合は、 [ヘルムCLI](https://helm.sh/docs/intro/install/)です。
    
    Helm のバージョン `<3.5` を使用している場合は、Helm バージョンに更新してください。 `>=3.5`です。
    

## 取り付け

### 1. 名前空間の作成

Rasaを別の場所にインストールすることをお勧めします [Namespace](https://kubernetes.io/docs/concepts/overview/working-with-objects/namespaces/) 既存のクラスタ展開への干渉を回避します。新しい名前空間を作成するには 次のコマンドを実行します。

**Kubernetesの**

```bash
kubectl create namespace <your namespace>
```

**オープンシフト**

```bash
oc create namespace <your namespace>
```

### 2. 値ファイルの作成

Helm を使用したインストールのためのすべてのカスタム構成を含む `rasa-values.yml` という空のファイルを準備します。

使用可能なすべての値は、[Rasa Helm Chartリポジトリ](https://github.com/RasaHQ/helm-charts/tree/main/charts/rasa#values)にあります。

> [!note] 
> Rasa チャートのデフォルト構成では、Rasa サーバーがデプロイされ、モデルがダウンロードされ、ダウンロードされたモデルが提供されます。[Rasa Helm Chart リポジトリ](https://github.com/RasaHQ/helm-charts/tree/main/charts/rasa#quick-start)にアクセスして、その他の構成例を確認してください。

### 3. 初期モデルのロード

Rasaを初めてインストールするときは、まだモデルサーバーが使用できない場合や、デプロイメントをテストするための軽量モデルが必要な場合があります。この目的のために、トレーニングまたは初期モデルのダウンロードを選択できます。デフォルトでは、Rasa チャートは GitHub からサンプルモデルをダウンロードします。このオプションを使用するために、何も変更する必要はありません。

代わりに、定義した URL からダウンロードする既存のモデルを定義する場合は、次の構成に従って `rasa-values.yaml` を URL で更新します。

```yaml
applicationSettings:
  initialModel: "https://github.com/RasaHQ/rasa-x-demo/blob/master/models/model.tar.gz?raw=true"
```

> [!note]  
> 最初のモデル ダウンロードの URL はtar.gz ファイルを指す必要があり、認証を必要としないようにする必要があります。

初期モデルをトレーニングする場合は、 を `applicationSettings.trainInitialModel` `true` に設定します。`/app` ディレクトリにあるデータに基づいてモデルをトレーニングする init コンテナーを作成します。`/app` ディレクトリが空の場合は、新しいプロジェクトが作成されます。Git リポジトリからデータファイルをダウンロードし、初期モデルをトレーニングする方法を示す例は、Rasa Helm Charts の[例](https://github.com/RasaHQ/helm-charts/blob/main/examples/rasa/train-model-helmfile.yaml)にあります。

### 4. Rasa Assistant を導入する

次のコマンドを実行します。

```bash
kubectl version --short --client

# The output should be similar to this
# Client Version: v1.19.11
```

```bash
# Add the repository which contains the Rasa Helm Chart
helm repo add rasa https://helm.rasa.com

# Deploy Rasa
helm install 
    --namespace <your namespace> 
    --values rasa-values.yml 
    <release name> 
    rasa/rasa
```

**オープンソースの競争:** ヌル

**テイストプラス:**

Helm デプロイメントで Rasa Plus イメージを使用するには、イメージ名として `rasa` を `rasa-plus` に置き換える必要があります。また、env var と [[#ステップ 1 イメージ プル シークレット|specify a pull secret for the image]] でライセンスを渡す必要があります。

#### セキュリティパッチのリリース

Rasa Plus 3.4.0 以降、サポートされているバージョンの新しい Docker イメージを毎日 0800 UTC にリリースします。これらのイメージには OS セキュリティ パッチが適用されており、タグに生成日が `YYYYMMDD` 形式で含まれています。たとえば、2023 年 2 月 1 日に生成された 3.4.2 画像を使用するには、`タグ 3.4.2-20230201` を使用します。これらのイメージは、オプションで同じバージョンの Rasa Plus のドロップイン代替として使用できますが、その日付までのすべての OS セキュリティ更新プログラムが適用されます。

#### ステップ 1: イメージ プル シークレット

`rasa-plus` イメージにアクセスするには、プル シークレットを作成する必要があります。レジストリにアクセスするための JSON 資格情報ファイルが提供されている必要があります。ファイルの内容は次のようになります。

```json
{
  "type": "service_account",
  "project_id": "rasa-platform",
  "private_key_id": "somerandomcharacters",
  "private_key": "-----BEGIN PRIVATE KEY-----nnPBTu1lAJDLo136ZGTdMKi+/TuRqrIMg/..................................................................................................................................nsjAsuAH4Iz1XdfdenzGnyBZHn-----END PRIVATE KEY-----n",
  "client_email": "company@rasa-platform.iam.gserviceaccount.com",
  "client_id": "12345678910123",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://accounts.google.com/o/oauth2/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/company%40rasa-platform.iam.gserviceaccount.com"
}
```

クラスター環境に対応するコマンドを実行して、プルシークレットを作成します。

```bash
# kubernetes
kubectl --namespace <your namespace> 
    create secret docker-registry rasa-plus-pull-secret 
    --docker-server=https://europe-west3-docker.pkg.dev 
    --docker-email=company@rasa-platform.iam.gserviceaccount.com  # this value needs to be updated with correct client email
    --docker-username=_json_key 
    --docker-password="$(cat <your-json-registry-creds-file>.json)"
```

```bash
# openshift
oc --namespace <your namespace> 
    create secret docker-registry rasa-plus-pull-secret 
    --docker-server=https://europe-west3-docker.pkg.dev 
    --docker-email=company@rasa-platform.iam.gserviceaccount.com  # this value needs to be updated with correct client email
    --docker-username=_json_key 
    --docker-password="$(cat <your-json-registry-creds-file>.json)"
```

#### ステップ 2: ライセンスをシークレットに保存する

ステップ a: ライセンス文字列をファイルに保存します。

```sh
echo "<rasaplus-license-key-you-were-emailed>" > license.txt
```

手順 b: ライセンス キーを保持するシークレットを作成します。

```sh
kubectl -n <your-namespace> create secret generic rasapro-license --from-file=licensekey=./license.txt
```

ステップc:ディスク上のファイルを削除します。

```sh
/bin/rm license.txt
```

#### ステップ 3: `values.yml`を更新する

[Rasa Helm チャート](https://github.com/RasaHQ/helm-charts/tree/main/charts/rasa)の場合は、次のように更新します。

```yaml
registry: europe-west3-docker.pkg.dev/rasa-releases/rasa-plus/rasa-plus
command:
  - rasa
image:
  name: rasa-plus
  tag: 0.1.1
  pullSecrets:
    - name: rasa-plus-pull-secret
extraEnv:
  - name: RASA_PRO_LICENSE
    valueFrom:
      secretKeyRef:
        name: rasapro-license
        key: licensekey
```

[Rasa X/Enterprise Helm チャート](https://github.com/RasaHQ/rasa-x-helm)の場合は、次のように更新します。

```yaml
images:
  imagePullSecrets:
    - name: rasa-plus-pull-secret
rasa:
  command:
  - rasa
  name: europe-west3-docker.pkg.dev/rasa-releases/rasa-plus/rasa-plus
  tag: 0.1.1
  extraEnv:
    - name: RASA_PRO_LICENSE
      valueFrom:
        secretKeyRef:
          name: rasapro-license
          key: licensekey
```

> [!note]  
> **OpenShift のみ**: デプロイメントが失敗し、 `oc get イベント`が返された `1001 is not an allowed group spec.containers[0].securityContext.securityContext.runAsUser` 場合は、以下の値でインストールコマンドを再実行します。
> 
> ```yaml
> postgresql:
>  volumePermissions:
>    securityContext:
>      runAsUser: "auto"
>  securityContext:
>    enabled: false
>  shmVolume:
>    chmod:
>      enabled: false
> nginx:
>  image:
>    name: nginxinc/nginx-unprivileged
>    port: 8080
> ```
> 
> その後、デプロイの準備が整うまで待ちます。そのステータスを確認する場合は、Rasaのデプロイの準備が整うまで、次のコマンドがブロックされます。
> 
> **Kubernetes**
> 
> ```bash
> kubectl --namespace <your namespace> 
>     wait 
>     --for=condition=available 
>     --timeout=20m 
>     --selector app.kubernetes.io/instance=<release name> 
>     deployment
> ```
> 
> **オープンシフト**
> 
> ```bash
> oc --namespace <your namespace> 
>     wait 
>     --for=condition=available 
>     --timeout=20m 
>     --selector app.kubernetes.io/instance=<release name> 
>     deployment
> ```

### 5. Rasaアシスタントにアクセスする

デフォルトでは、Rasa デプロイメントは `rasa` (`<release name>`) サービスを介して公開され、Kubernetes クラスタ内でのみアクセスできます。`kubectl port-forward` を使用して Rasa Assistant にアクセスするには、次のコマンドを使用します。

**Kubernetes**

```bash
  export SERVICE_PORT=$(kubectl get --namespace <your namespace> -o jsonpath="{.spec.ports[0].port}" services <release name>)
  kubectl port-forward --namespace <your namespace> svc/<release name> ${SERVICE_PORT}:${SERVICE_PORT} &
```

**オープンシフト**

```bash
  export SERVICE_PORT=$(oc get --namespace <your namespace> -o jsonpath="{.spec.ports[0].port}" services <release name>)
  oc port-forward --namespace <your namespace> svc/<release name> ${SERVICE_PORT}:${SERVICE_PORT} &
```

その後 `http://127.0.0.1:${SERVICE_PORT}` 、

もう 1 つのオプションは、`デプロイを NodePort` に公開し、直接アクセスすることです。

1.  rasa サービスを `NodePort` に切り替える設定を準備します。

```yaml
# rasa-values.yaml
service:
  type: "NodePort"
```

2.  デプロイメントをアップグレードします。

```text
helm upgrade --namespace <NAMESPACE> --reuse-values -f rasa-values.yaml <RELEASE NAME> rasa/rasa
```

3.  rasa サービスのノード・ポートとアドレスを取得する

```text
export NODE_PORT=$(kubectl get --namespace <NAMESPACE> -o jsonpath="{.spec.ports[0].nodePort}" services <RELEASE NAME>)

$ curl http://127.0.0.1:${NODE_PORT}
Hello from Rasa: 2.8.7
```

[Rasa Helm Chart の README](https://github.com/RasaHQ/helm-charts/tree/main/charts/rasa#exposing-the-rasa-deployment-to-the-public) を参照して、デプロイメントを公開する他の方法を確認してください。

## 次のステップ

*   設定例を見つけることができる [Rasa Helm Chart リポジトリ](https://github.com/RasaHQ/helm-charts/tree/main/charts/rasa)にアクセスしてください