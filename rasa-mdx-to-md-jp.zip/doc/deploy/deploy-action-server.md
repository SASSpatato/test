---
id: deploy-action-server
sidebar_label: Deploy Action Server
title: Deploy Rasa Action Server
abstract: This page explains how to build an Action Server Image and deploy a Rasa Action Server using Helm. The second of three steps in deploying your Rasa assistant.
---

> [!note]  
> [Rasa Action Server チャート](https://github.com/RasaHQ/helm-charts/tree/main/charts/rasa-action-server)はオープンソースであり、[helm-charts リポジトリ](https://github.com/rasahq/helm-charts)で入手できます。バグを発見した場合、または改善の提案がある場合は、このリポジトリで[問題を作成](https://github.com/RasaHQ/helm-charts/issues/new)してください。

以下のセクションでは、helm を使用して Rasa Action Server をデプロイする方法と、Action Server デプロイメントを Rasa デプロイメントに接続する方法を学習できます。

## インストール要件

1.  Kubernetes または OpenShift コマンドラインインターフェイス (CLI) がインストールされていることを確認します。これは、次のコマンドを使用して確認できます。
    
    **Kubernetesの**
    
    ```bash
    kubectl version --short --client
    
    # The output should be similar to this
    # Client Version: v1.19.11
    ```
    
    **オープンシフト」**
    
    ```bash
    oc version --client
    
    # The output should be similar to this
    # Client Version: 4.7.13
    ```
    
    このコマンドでエラーが発生した場合は、 [Kubernetes CLI](https://kubernetes.io/docs/tasks/tools/install-kubectl/) または [OpenShift CLI (英語)](https://docs.openshift.com/container-platform/4.7/cli_reference/openshift_cli/getting-started-cli.html#installing-openshift-cli) 使用しているクラスターによって異なります。
    
2.  Kubernetes / OpenShift CLI がクラスターに正しく接続されていることを確認します。これを行うには、次のコマンドを使用します。
    
    **Kubernetesの**
    
    ```bash
    kubectl version --short
    
    # The output should be similar to this
    # Client Version: v1.19.11
    # Server Version: v1.19.10
    ```
    
    **オープンシフト**
    
    ```bash
    oc version
    
    # The output should be similar to this
    # Client Version: 4.7.13
    # Kubernetes Version: v1.20.0+df9c838
    ```
    
    コマンドの実行時にエラーが発生した場合は、クラスターに接続されていません。クラスターに接続するコマンドを取得するには、クラスターの管理者またはクラウドプロバイダーのドキュメントを参照してください。
    
3.  [Helm CLI](https://helm.sh/docs/intro/install/) があることを確認する インストール。これを確認するには、次のコマンドを実行します。
    
    ```bash
    helm version --short
    
    # The output should be similar to this
    # v3.6.0+g7f2df64
    ```
    
    このコマンドでエラーが発生する場合は、 [ヘルムCLI](https://helm.sh/docs/intro/install/)です。
    
    Helm のバージョン `<3.5` を使用している場合は、Helm バージョンに更新してください。 `>=3.5`です。
    

## 1. インストール

### a. 名前空間の作成

Rasa Action Serverを別の場所にインストールすることをお勧めします。 [Namespace](https://kubernetes.io/docs/concepts/overview/working-with-objects/namespaces/) 既存のクラスタ展開への干渉を回避します。新しい名前空間を作成するには 次のコマンドを実行します。

**Kubernetesの**

```bash
kubectl create namespace <your namespace>
```

**オープンシフト**

```bash
oc create namespace <your namespace>
```

### b. Rasa Action Server のデプロイ

次のコマンドを実行します。

```bash
# Add the repository which contains the Rasa Action Server Helm chart
helm repo add rasa https://helm.rasa.com

# Deploy Rasa Action Server
helm install 
    --namespace <your namespace> 
    <release name> 
    rasa/rasa-action-server
```

### c. Rasa Action Server へのアクセス

デフォルトでは、Rasa Action Server デプロイメントは `rasa-action-server` (`<release name>`) サービスを介して公開され、Kubernetes クラスタ内でのみアクセスできます。次のコマンドを使用して IP アドレスを取得できます。

**Kubernetesの**

```bash
  export SERVICE_PORT=$(kubectl get --namespace <your namespace> -o jsonpath="{.spec.ports[0].port}" services <release name>)
  kubectl port-forward --namespace <your namespace> svc/<release name> ${SERVICE_PORT}:${SERVICE_PORT} &
```

**オープンシフト**

```bash
  export SERVICE_PORT=$(oc get --namespace <your namespace> -o jsonpath="{.spec.ports[0].port}" services <release name>)
  oc port-forward --namespace <your namespace> svc/<release name> ${SERVICE_PORT}:${SERVICE_PORT} &
```

その後 `http://127.0.0.1:${SERVICE_PORT}` 、

> [!note] 
> Rasa Action Server Helm チャートでは、デフォルトで [rasa-x-demo](https://github.com/RasaHQ/rasa-x-demo) Docker イメージが使用されます。[アクション サーバー イメージの構築](#building-an-action-server-image) カスタム Action Server イメージをビルドして使用する方法を学習できます。

## アクション サーバー イメージの構築

アクションコードを含むイメージをビルドし、コンテナーレジストリーに格納すると、サーバー間でコードを移動することなく、デプロイメントの一部として実行できます。さらに、アクションコードの一部であるが、ベース `rasa/rasa-sdk` イメージには含まれていないシステムまたは Python ライブラリの依存関係を追加できます。

### アクション サーバー イメージ ビルドの自動化

新しいアクション・サーバー・イメージを手動で作成するだけでなく、[Rasa Action Server GitHub Action](https://github.com/RasaHQ/action-server-gha)を使用してイメージ・ビルドを自動化できます。GitHub Actions を初めて使用する場合は、[GitHub Actions ドキュメントに](https://docs.github.com/en/actions)精通しておくと役立つ場合があります。

次の手順では、GitHub リポジトリをすでに作成しており、DockerHub アカウントを持っていることを前提としています。

Docker イメージをビルドして DockerHub レジストリにプッシュするためのワークフローを作成するには:

1.  DockerHub ログイン名とパスワードを使用して GitHub シークレットを追加します。リポジトリの暗号化されたシークレットを作成する方法の詳細については、[Github ドキュメント](https://docs.github.com/en/actions/configuring-and-managing-workflows/creating-and-storing-encrypted-secrets#creating-encrypted-secrets-for-a-repository)を参照してください
    
    この例では、次のシークレットを使用します。
    
    *   `DOCKER_HUB_LOGIN` - DockerHubのログイン名
    *   `DOCKER_HUB_PASSWORD` - DockerHubのパスワード
2.  GitHub リポジトリで、ファイル [`.github/workflows/action_server.yml`](https://github.com/RasaHQ/action-server-gha/blob/master/examples/action_server.yml) を作成します。
    

以下の GitHub Action ワークフローでは、`actions/` ディレクトリ内のファイルが変更され、その変更が`メイン` ブランチにプッシュされるたびに、新しい Docker イメージがビルドされます。

```yaml
on:
  push:
    branches:
      - main
    paths:
    - 'actions/**'

jobs:
  build_and_deploy:
    runs-on: ubuntu-latest
    name: Build Action Server image and upgrade Rasa X/Enterprise deployment
    steps:
    - name: Checkout repository
      uses: actions/checkout@v2

    - id: action_server
      name: Build an action server with custom actions
      uses: RasaHQ/action-server-gha@main
      # Full list of parameters: https://github.com/RasaHQ/action-server-gha/tree/master#input-arguments
      with:
        docker_image_name: 'account_username/repository_name'
        docker_registry_login: ${{ secrets.DOCKER_HUB_LOGIN }}
        docker_registry_password: ${{ secrets.DOCKER_HUB_PASSWORD }}
        # More details about github context:
        # https://docs.github.com/en/actions/reference/context-and-expression-syntax-for-github-actions#github-context
        #
        # github.sha - The commit SHA that triggered the workflow run
        docker_image_tag: ${{ github.sha }}
```

3.  変更を`メイン`ブランチにプッシュします。変更がプッシュされた後、ワークフローは新しいイメージをビルドし、DockerHub レジストリにプッシュします。
    
4.  これで、新しいブランドの Docker イメージを使用できます。
    
5.  また、ワークフローを拡張して、Rasa X/Enterprise デプロイメントを手動で更新する必要がないようにすることもできます。以下の例は、Rasa X/Enterprise Helm Chart デプロイメントを更新する追加のステップを使用してワークフローを拡張する方法を示しています。
    

```yaml
on:
  push:
    branches:
      - main

jobs:
  build_and_deploy:
    runs-on: ubuntu-latest
    name: Build Action Server image and upgrade Rasa X/Enterprise deployment
    steps:
    [..]

    # This step shows only the example of output parameter usage
    # and it's not focused on deployment itself.
    - name: "Upgrade a Rasa Action Server deployment"
      run: |
        helm upgrade --install --reuse-values 
          --set image.name=${{ steps.action_server.outputs.docker_image_name }} 
          --set image.tag=${{ steps.action_server.outputs.docker_image_tag }} rasa-action-server rasa/rasa-action-server
```

ご覧のとおり、`action_server`ステップの出力変数を使用できます。変数は `steps.action_server.outputs.docker_image_name` Docker イメージ名を返し、変数は `steps.action_server.outputs.docker_image_tag` Docker イメージタグを返します。

[Rasa GitHub Actions](https://github.com/RasaHQ/action-server-gha)の使用方法とカスタマイズ方法のその他の例は、[Rasa GitHub Actions](https://github.com/RasaHQ/action-server-gha)リポジトリにあります。

#### アクション・サーバーの手動構築

イメージを作成するには:

1.  アクションが `actions/actions.py` で定義されていることを確認してください。`rasa/rasa-sdk` は image は、このファイル内のアクションを自動的に検索します。
    
2.  アクションに余分な依存関係がある場合は、それらのリストをファイルに作成します。 `actions/requirements-actions.txt` .
    
3.  プロジェクトディレクトリに `Dockerfile` という名前のファイルを作成し、公式の SDK イメージを拡張し、コードをコピーし、カスタム依存関係 (必要な場合) を追加します。例えば：
    
    ```python
    
    {`# Extend the official Rasa SDK image
    FROM rasa/rasa-sdk:[RASA_SDK_VERSION]
    
    # Use subdirectory as working directory
    WORKDIR /app
    
    # Copy any additional custom requirements, if necessary (uncomment next line)
    # COPY actions/requirements-actions.txt ./
    
    # Change back to root user to install dependencies
    USER root
    
    # Install extra requirements for actions code, if necessary (uncomment next line)
    # RUN pip install -r requirements-actions.txt
    
    # Copy actions folder to working directory
    COPY ./actions /app/actions
    
    # By best practices, don't run the code with root user
    USER 1001`}
    ```
    

その後、次のコマンドを使用してイメージをビルドできます。

```bash
docker build . -t <account_username>/<repository_name>:<custom_image_tag>
```

`<custom_image_tag>` は、この画像が他の画像とどのように異なるかを参照する必要があります。たとえば、タグのバージョン設定や日付を設定したり、本番サーバーと開発サーバー用に異なるコードを持つ異なるタグを作成したりできます。コードを更新して再デプロイするたびに、新しいタグを作成する必要があります。

### カスタム アクション サーバー イメージの使用

このイメージをビルドして別のサーバーから使用できるようにする場合は、イメージをクラウドリポジトリにプッシュする必要があります。

このドキュメントでは、イメージを [DockerHub](https://hub.docker.com/) にプッシュすることを前提としています。DockerHubでは、複数のパブリックリポジトリと1つのプライベートリポジトリを無料でホストできます。必ず最初に[アカウントを作成](https://hub.docker.com/signup/)してください をクリックし、イメージを保存するための[リポジトリを作成します](https://hub.docker.com/signup/)。また、[Google Container Registry](https://cloud.google.com/container-registry)などの別のDockerレジストリにイメージをプッシュすることもできます。 [Amazon Elastic Container Registry](https://aws.amazon.com/ecr/)、または [Azure Container Registry](https://azure.microsoft.com/en-us/services/container-registry/)。

次の方法でイメージを DockerHub にプッシュできます。

```bash
docker login --username <account_username> --password <account_password>
docker push <account_username>/<repository_name>:<custom_image_tag>
```

イメージを認証して別のコンテナレジストリにプッシュするには、選択したコンテナレジストリのドキュメントを参照してください。

## カスタム アクション サーバー イメージの設定

Rasa Action Server デプロイメントでカスタム アクション サーバー イメージを使用するには、デプロイメントに次の値を使用する必要があります。

```yaml
# values.yaml
image:
  name: "image_name"
  tag: "image_tag"
```

次に、次のコマンドを実行してデプロイメントをアップグレードします。

```text
helm upgrade --namespace <namespace> --reuse-values 
  -f values.yaml <release name> rasa/rasa-action-server
```

## 2. Rasa Action Server を Rasa デプロイメントに接続する

Rasa Helm チャートを使用してアシスタントをデプロイし、Rasa Action Server もデプロイした場合。今度はそれらをつなぎ合わせます。これは、次の手順に従って簡単に行うことができます。

ある。Rasaデプロイメントの設定を含む`rasa-values.yaml`ファイルを作成します。

```yaml
# rasa-values.yaml
rasa-action-server:
  external:
    # -- Determine if external URL is used
    enabled: true
    # -- URL to Rasa Action Server
    url: "http://rasa-action-server/webhook"
```

上記の設定は、使用する Rasa アクション サーバーを Rasa に指示します。この例では、 `http://rasa-action-server/webhook` URL が使用されており、URL は Rasa Action Server がリリース名 `rasa-action-server` でデプロイされ、Rasa サーバーのデプロイメントと同じ名前空間に配置されていることを示しています。

b.Rasa デプロイメントのアップグレード

```text
helm upgrade -n <namespace> --reuse-values -f rasa-values.yaml 
  <release name> rasa/rasa
```