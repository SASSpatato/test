---
id: deploy-rasa-pro-services
sidebar_label: "Deploy Rasa Pro Services"
title: "Deploy Rasa Pro Services"
description: Deploy Rasa Rasa Pro Services in production
---

## Rasa Pro サービスのセットアップ

Rasa Pro Services をインストールするには、Docker コンテナーのデプロイが必要です。コンテナは、Rasa Plusとは異なる環境にデプロイできます。両方のデプロイメントが通信するために同じ Kafka クラスターに接続できる必要があります。

### 前提 条件

Rasa Pro Services デプロイメントは、

*   メッセージブローカー (Kafka) と
*   データウェアハウス(PostgreSQLなど)。

Kafka デプロイメントは、実稼働デプロイメントである必要があります。おすすめの 管理されたデプロイ (例: [Amazon マネージドストリーミング for Apache Kafka](https://aws.amazon.com/msk/)。

#### システム要件

最小ハードウェア要件には、Rasa Pro Servicesをインストールして使用するために必要な要件に関する情報が含まれています。ハードウェア要件は、会話の平均数と予想されるワークロードによって異なります。ワークロードによっては、正確なニーズがさらに大きくなる場合があります。

推奨される最小ハードウェア ガイダンスを次に示します。

*   CPU:2 vCPU
*   メモリ:4 GB
*   ディスク容量: 10 GB

これらの要件は、AWS の `t3.medium` インスタンスタイプに対応しています。

#### ライセンス

Rasa Pro Services を実行するには、有効なライセンスが必要です。ライセンスを環境変数としてサービスに指定する必要があります。

### インストールと構成

Rasa Plusは、Rasa Pro Servicesによって消費されるデータをKafkaにストリーミングします。これらのさまざまなサービスを実行し、通信できるように構成する必要があります。

1.  Kafka にデータをストリーミングするように Rasa Plus を設定します。Kafka の設定は、次の`設定ファイルendpoints.yml`に入れる必要があります。
    
    ```yaml-rasa
    event_broker:
      type: kafka
      partition_by_sender: True
      topic: rasa-events
      url: <BROKER URL>
    ```
    
    `<BROKER_URL>` は、Kafka クラスターのブートストラップサーバーのアドレスに置き換える必要があります。さまざまなセキュリティープロトコルおよびその他のパラメーターの設定例は、 [[event-brokers#Kafka イベントブローカー|Kafka Event Broker]] ドキュメントを参照してください。
    
2.  Rasa Pro Services は Docker イメージです。Dockerイメージをプルするための認証:
    
    ```shell
    gcloud auth configure-docker europe-west3-docker.pkg.dev
    ```
    
    Rasa Pro Services イメージをマシンにプルします。
    
    ```shell
    docker pull europe-west3-docker.pkg.dev/rasa-releases/rasa-pro/rasa-pro
    ```
    

> [!注]  
> 実稼働環境で認証資格情報とライセンスを管理する方法の詳細なチュートリアルについては、[[deploy-rasa#4. Rasa Assistant を導入する|Rasa Plus 導入ガイド]] (**[Rasa Plus**] タブを選択)。

3.  Rasa Pro Services Docker イメージを実行し、Kafka に接続された Rasa Plus アシスタントからデータを受信するように設定します。
    
    ```shell
    docker run 
        -e RASA_PRO_LICENSE=<your_license> 
        -e KAFKA_BROKER_ADDRESS=<BROKER_URL> 
        -e KAFKA_TOPIC=rasa-events 
        europe-west3-docker.pkg.dev/rasa-releases/rasa-pro/rasa-pro
    ```
    
    運用環境のデプロイでは、 [Amazon Elastic Container Service](https://docs.docker.com/cloud/ecs-integration/)。
    

### Docker コンテナー構成 (リファレンス)

Rasa Pro Services Docker コンテナーは、いくつかの環境変数による構成をサポートします。次の表に、使用可能な環境変数を示します。

| 環境変数 | 形容 | デフォルト |
| --- | --- | --- |
| RASA_PRO_LICENSE | 必須です。Rasa Pro Servicesのライセンスキー。 |  |
| KAFKA_BROKER_ADDRESS | 必須です。Kafka ブローカーのアドレス。 |  |
| KAFKA_TOPIC | 必須です。Rasa Plusがイベントを公開し、Rasa Proが消費するトピック。 | rasa_core_events |
| LOGGING_LEVEL | アプリケーションのログレベルを設定します。有効なレベルは、DEBUG、INFO、WARNING、ERROR、CRITICALです。(3.0.2から利用可能) | INFO |
| RASA_ANALYTICS_DB_URL | 分析データを格納するデータレイクの URL。 |  |
| KAFKA_SASL_MECHANISM | 認証に使用する SASL メカニズム。有効なメカニズムは次のとおりです。 | PLAIN |
| KAFKA_SASL_USERNAME | SASL 認証のユーザー名。 |  |
| KAFKA_SASL_PASSWORD | SASL 認証のパスワード。 |  |
| KAFKA_SECURITY_PROTOCOL | Kafka との通信に使用するセキュリティープロトコル。サポートされているメカニズムは、PLAINTEXT と SASL_PLAINTEXT です。 | PLAINTEXT |
| KAFKA_SSL_CA_LOCATION | Kafka との接続に使用される SSL CA 証明書のファイルパス (3.1.0b1 から利用可能) |  |

### ヘルスチェックエンドポイント

Rasa Pro Services は、ヘルスチェックエンドポイントを `/healthcheck` に公開します。エンドポイントは、サービスが正常であれば、`200` の状態コードを返します。他の状態コードが返された場合、またはエンドポイントに到達できない場合、サービスは異常です。

`/healthcheck` の応答例:

```json
{
  "details": {
    "analytics-consumer": {
      "alive": 1,
      "isHealthy": true
    }
  },
  "isHealthy": true
}
```

### セキュアな Kafka インスタンスに接続する

セキュアな Kafka インスタンスへの接続は、 Rasa Pro dockerコンテナの次の環境変数: `KAFKA_SASL_MECHANISM`、`KAFKA_SASL_USERNAME`、`KAFKA_SASL_PASSWORD` `KAFKA_SECURITY_PROTOCOL`。パラメータの詳細な説明は、[[#Docker コンテナー構成 (リファレンス)|環境変数リファレンス]]を参照してください。

環境変数は、Rasa Pro Docker コンテナの起動時に設定する必要があります。

Kafka `トラストストア`および`キーストア`の使用は、現在サポートされていません。

### バージョンのアップグレード

Rasa Pro Services の最新バージョンにアップグレードするには、次の手順に従う必要があります。

1.  破壊的変更に関する変更ログのドキュメントをお読みください。
2.  新しい Docker コンテナをダウンロードして実行します。

> [!note] 
> コンテナの起動 コンテナは、起動の一部としてデータベーススキーマの移行を実行しているため、起動に時間がかかる場合があることに注意してください。
> 
> 移行が失敗した場合、コンテナはシャットダウンされます。