---
id: tracker-stores
sidebar_label: Tracker Stores
title: Tracker Stores
description: All conversations are stored within a tracker store. Read how Rasa provides implementations for different store types out of the box.
abstract: Your assistant's conversations are stored within a tracker store.
  Rasa provides implementations for different store types out of the box,
  or you can create your own custom one.
---

## InMemoryTrackerStore (既定値)

`InMemoryTrackerStore` は、既定のトラッカー ストアです。他のトラッカーストアが設定されていない場合に使用されます。会話履歴をメモリに格納します。

> [!note] 
> このストアはすべての履歴をメモリに保持するため、Rasa サーバーを再起動すると履歴全体が失われます。

### **構成**

`InMemoryTrackerStore` を使用するための構成は必要ありません。

## SQLTrackerStore

`SQLTrackerStore` を使用して、アシスタントの会話履歴を SQL データベースに保存できます。

### 構成

SQL を使用して Rasa を設定するには、次の手順が必要です。

1.  必要な構成を`endpoints.yml`に追加します。

```yaml-rasa
tracker_store:
    type: SQL
    dialect: "postgresql"  # the dialect used to interact with the db
    url: ""  # (optional) host of the sql db, e.g. "localhost"
    db: "rasa"  # path to your db
    username:  # username used for authentication
    password:  # password used for authentication
    query: # optional dictionary to be added as a query string to the connection URL
      driver: my-driver
```

2.  SQLバックエンドを使用してRasaサーバーを起動するには、`--endpoints`フラグを追加します。

```bash
rasa run -m models --endpoints endpoints.yml
```

3.  Docker Compose でモデルをデプロイする場合は、`サービスを docker-compose.yml` に追加します。

```yaml-rasa
postgres:
  image: postgres:latest
```

要求を新しいサービスにルーティングするには、`endpoints.yml` の `URL` はサービス名を参照します。

```yaml-rasa
  tracker_store:
      type: SQL
      dialect: "postgresql"  # the dialect used to interact with the db
      url: "postgres"
      db: "rasa"  # path to your db
      username:  # username used for authentication
      password:  # password used for authentication
      query: # optional dictionary to be added as a query string to the connection URL
        driver: my-driver
```

#### 設定パラメータ

*   `ドメイン`(デフォルト:`なし`):このトラッカーストアに関連付けられているドメインオブジェクト
    
*   `dialect` (デフォルト: `sqlite`): SQL バックエンドとの通信に使用される方言。利用可能な方言については、[SQLAlchemyのドキュメント](https://docs.sqlalchemy.org/en/latest/core/engines.html#database-urls)を参照してください。
    
*   `url` (デフォルト: `なし`): SQL サーバーの URL
    
*   `port` (デフォルト: `None`): SQL Server のポート
    
*   `db` (デフォルト: `rasa.db`): 使用するデータベースへのパス
    
*   `username` (デフォルト: `None`): 認証に使用されるユーザー名
    
*   `password` (デフォルト: `None`): 認証に使用されるパスワード
    
*   `event_broker` (デフォルト: `なし`): イベントを公開するイベントブローカー
    
*   `login_db` (デフォルト: `None`): 最初に接続し、`db` で指定されたデータベースを作成する代替データベース名 (PostgreSQL のみ)
    
*   `query` (デフォルト: `None`): 接続時にダイアレクトや DBAPI に渡されるオプションのディクショナリ
    

#### 互換性のあるデータベース

次のデータベースは、`SQLTrackerStore` と正式に互換性があります。

*   PostgreSQL
*   オラクル>11.0
*   SQLite

#### Oracle の構成

Oracle で SQLTrackerStore を使用するには、いくつかの追加手順があります。まず、Oracle データベースにデータベース `トラッカー`を作成し、それにアクセスできるユーザーを作成します。次のコマンドを使用してデータベースにシーケンスを作成します。usernameは作成したユーザーです(シーケンスの作成の詳細については、[Oracleドキュメント](https://docs.oracle.com/cd/B28359_01/server.111/b28310/views002.htm#ADMIN11794)を参照してください)。

```sql
CREATE SEQUENCE username.events_seq;
```

次に、必要なドライバーとクライアントを含めるように Rasa イメージを拡張する必要があります。まず、[Oracle Instant Client](https://www.oracle.com/database/technologies/instant-client/linux-x86-64-downloads.html)をダウンロードし、`名前をoracle.rpm`に変更して、Dockerイメージの構築元となるディレクトリに格納します。以下を `Dockerfile` というファイルにコピーします。

```
{`FROM rasa/rasa:${variables.release}-full

# Switch to root user to install packages
USER root

RUN apt-get update -qq && apt-get install -y --no-install-recommends alien libaio1 && apt-get clean && rm -rf /var/lib/apt/lists/* /tmp/* /var/tmp/*

# Copy in oracle instaclient
# https://www.oracle.com/database/technologies/instant-client/linux-x86-64-downloads.html
COPY oracle.rpm oracle.rpm

# Install the Python wrapper library for the Oracle drivers
RUN pip install cx-Oracle

# Install Oracle client libraries
RUN alien -i oracle.rpm

USER 1001`}
```

次に、dockerイメージをビルドします。

```
{`docker build . -t rasa-oracle:${variables.release}-oracle-full`}
```

これで、上記のように`endpoints.yml`でトラッカーストアを設定し、コンテナを起動できます。この設定の`ダイアレクト`・パラメータはoracle`+cx_oracle`になります。詳細については、[Rasa Assistant のデプロイ](./deploy/introduction.md)を参照してください。

## RedisTrackerStore

アシスタントの会話履歴を [Redis](https://redis.io/) に保存するには、 `RedisTrackerStore` です。Redis は、オプションでデータを永続化できる高速なメモリ内キー値ストアです。

### 構成

RedisでRasaをセットアップするには、次の手順が必要です。

1.  Redis インスタンスを起動する
    
2.  必要な構成を`endpoints.yml`に追加します。
    

```yaml-rasa
tracker_store:
    type: redis
    url: <url of the redis instance, e.g. localhost>
    port: <port of your redis instance, usually 6379>
    key_prefix: <alphanumeric value to prepend to tracker store keys>
    db: <number of your database within redis, e.g. 0>
    password: <password used for authentication>
    use_ssl: <whether or not the communication is encrypted, default `false`>
```

```bash
rasa run -m models --endpoints endpoints.yml
```

4.  Docker Compose でモデルをデプロイする場合は、`サービスを docker-compose.yml` に追加します。

```yaml-rasa
redis:
  image: redis:latest
```

要求を新しいサービスにルーティングするには、`endpoints.yml` の `URL` はサービス名を参照します。

```yaml-rasa
 tracker_store:
     type: redis
     url: <url of the redis instance, e.g. localhost>
     port: <port of your redis instance, usually 6379>
     db: <number of your database within redis, e.g. 0>
     key_prefix: <alphanumeric value to prepend to tracker store keys>
     password: <password used for authentication>
     use_ssl: <whether or not the communication is encrypted, default `false`>
```

*   `url` (デフォルト: `localhost`): redis インスタンスの URL
    
*   `port` (デフォルト: `6379`): redis が実行されているポート
    
*   `db` (デフォルト: `0`): redis データベースの数
    
*   `key_prefix` (デフォルト: `なし`): トラッカーストアキーの先頭に追加するプレフィックス。英数字である必要があります
    
*   `username` (デフォルト: `None`): 認証に使用されるユーザー名
    
*   `password` (デフォルト: `None`): 認証に使用されるパスワード (`None` は認証なしに等しい)
    
*   `record_exp` (デフォルト: `なし`): レコードの有効期限を秒単位で記録します
    
*   `use_ssl` (デフォルト: `False`): トランジット暗号化に SSL を使用するかどうか
    

## モンゴトラッカーストア

`MongoTrackerStore` を使用して、アシスタントの会話履歴を [MongoDB](https://www.mongodb.com/) に保存できます。MongoDB は、無料のオープンソースのクロスプラットフォーム ドキュメント指向の NoSQL データベースです。

### 構成

1.  MongoDB インスタンスを起動します。
    
2.  必要な構成を`endpoints.yml`に追加します。
    

```yaml-rasa
tracker_store:
    type: mongod
    url: <url to your mongo instance, e.g. mongodb://localhost:27017>
    db: <name of the db within your mongo instance, e.g. rasa>
    username: <username used for authentication>
    password: <password used for authentication>
    auth_source: <database name associated with the user's credentials>
```

url フィールドにパラメータを追加することで、より高度な設定 (ssl の有効化など) を追加することもできます `mongodb://localhost:27017/?ssl=true` 。

3.  設定された MongoDB インスタンスを使用して Rasa サーバーを起動するには、`次のように --endpoints` フラグを追加します。

```bash
rasa run -m models --endpoints endpoints.yml
```

4.  Docker Compose でモデルをデプロイする場合は、`サービスを docker-compose.yml` に追加します。

```yaml-rasa
mongo:
  image: mongo
  environment:
    MONGO_INITDB_ROOT_USERNAME: rasa
    MONGO_INITDB_ROOT_PASSWORD: example
mongo-express:  # this service is a MongoDB UI, and is optional
  image: mongo-express
  ports:
    - 8081:8081
  environment:
    ME_CONFIG_MONGODB_ADMINUSERNAME: rasa
    ME_CONFIG_MONGODB_ADMINPASSWORD: example
```

このデータベースにリクエストをルーティングするには、`endpoints.yml`の `URL` をサービス名として設定し、ユーザーとパスワードを指定してください。

```yaml-rasa
 tracker_store:
     type: mongod
     url: mongodb://mongo:27017
     db: <name of the db within your mongo instance, e.g. rasa>
     username: <username used for authentication>
     password: <password used for authentication>
     auth_source: <database name associated with the user's credentials>
```

#### 設定パラメータ

*   `url` (デフォルト: `mongodb://localhost:27017`): MongoDB の URL
    
*   `db` (デフォルト: `rasa`): 使用するデータベース名
    
*   `username` (デフォルト: `0`): 認証に使用されるユーザー名
    
*   `password` (デフォルト: `None`): 認証に使用されるパスワード
    
*   `auth_source` (デフォルト: `admin`): ユーザーの資格情報に関連付けられたデータベース名。
    
*   `collection`(デフォルト:`conversations`):会話の保存に使用されるコレクション名
    

## DynamoTrackerストア

アシスタントの会話履歴を `DynamoTrackerStore` を使用した [DynamoDB](https://aws.amazon.com/dynamodb/)。DynamoDB は、Amazon Web Services (AWS) が提供するホスト型 NoSQL データベースです。

### 構成

1.  DynamoDB インスタンスを起動します。
    
2.  必要な構成を`endpoints.yml`に追加します。
    

```yaml-rasa
tracker_store:
    type: dynamo
    table_name: <name of the table to create, e.g. rasa>
    region: <name of the region associated with the client>
```

3.  設定した `DynamoDB` インスタンスを使用して Rasa サーバーを起動するには、`次のように --endpoints` フラグを追加します。

```bash
rasa run -m models --endpoints endpoints.yml
```

#### 設定パラメータ

*   `table_name` (デフォルト: `states`): DynamoDB テーブルの名前
    
*   `region` (デフォルト: `us-east-1`): クライアントに関連付けられているリージョンの名前
    

## カスタムトラッカーストア

すぐに使えないトラッカーストアが必要な場合は、独自のトラッカーストアを実装できます。これは、基本クラス `TrackerStore` と、 `serialise_tracker`メソッド: `SerializedTrackerAsText` または `SerializedTrackerAsDict`。

カスタム トラッカー ストアを記述するには、`TrackerStore` 基本クラスを拡張します。コンストラクターはパラメーター `host` を指定する必要があります。コンストラクターは、`domain` 引数と `event_broker` 引数を使用して基本クラス `TrackerStore` への`スーパー`呼び出しも行う必要があります。

```
super().__init__(domain, event_broker, **kwargs)
```

カスタムトラッカーストアクラスでは、次の3つのメソッドも実装する必要があります。

*   `保存`: 会話をトラッカーストアに保存します。[(ソースコード - 署名を参照)。](https://github.com/RasaHQ/rasa/blob/main/rasa/core/tracker_store.py#L243)
*   `Retrieve`: 最新の会話セッションのトラッカーを取得します。[(ソースコード - 署名を参照)。](https://github.com/RasaHQ/rasa/blob/main/rasa/core/tracker_store.py#L261)
*   `keys`: トラッカーストアの主キーの値セットを返します。[(ソースコード - 署名を参照)。](https://github.com/RasaHQ/rasa/blob/main/rasa/core/tracker_store.py#L319)

### 構成

カスタムトラッカーストアへのモジュールパスと、必要なパラメーターを`endpoints.yml`に入れます。

```yaml-rasa
tracker_store:
  type: path.to.your.module.Class
  url: localhost
  a_parameter: a value
  another_parameter: another value
```

Docker Compose にデプロイする場合、このストアを Rasa に追加するには、モジュールを含めるように Rasa イメージを拡張するか、モジュールをボリュームとしてマウントするかの 2 つのオプションがあります。

対応するサービスも必ず追加してください。たとえば、ボリュームとしてマウントすると、次のようになります。

```yaml
rasa:
  <existing rasa service configuration>
  volumes:
    - <existing volume mappings, if there are any>
    - ./path/to/your/module.py:/app/path/to/your/module.py
custom-tracker-store:
  image: custom-image:tag
```

```yaml-rasa
tracker_store:
  type: path.to.your.module.Class
  url: custom-tracker-store
  a_parameter: a value
  another_parameter: another value
```

## フォールバックトラッカーストア

`endpoints.yml`で構成されたプライマリトラッカーストアが使用できなくなった場合、rasaエージェントはエラーメッセージを発行し、`InMemoryTrackerStore`実装にフォールバックします。ターンごとに新しいダイアログセッションが開始され、`InMemoryTrackerStore` フォールバックに個別に保存されます。

プライマリ トラッカー ストアが復旧するとすぐに、フォールバック トラッカー ストアが置き換えられ、この時点からの会話が保存されます。ただし、`InMemoryTrackerStore` に保存された以前の状態は フォールバックは失われます。

> [!info] ロックストアとトラッカーストアと同じredisインスタンスを使用する
> ロックストアとトラッカーストアの両方と同じRedisインスタンスを使用しないでください。Redis インスタンスが使用できなくなった場合、ロックストアにフォールバックメカニズムが実装されていないため、会話はハングします (トラッカーストアインターフェイスの場合と同様)。