---
id: sdk-events
sidebar_label: Events
title: Events
---

内部的には、Rasa 会話は[イベント](events.md)のリストとして表されます。Rasa SDKは、各イベントのクラスを提供し、イベントクラスのインスタンスを適切な形式のイベントペイロードに変換します。

このページでは、`rasa_sdk`のイベントクラスについて説明します。イベントとその基礎となるペイロードの副作用は、`rasa_sdk` または別のアクション サーバーのどちらを使用しているかに関係なく同じです。イベントの副作用、その基礎となるペイロード、および Rasa のクラスの詳細については、[すべてのアクションサーバーのイベントに関するドキュメント](events.md)を参照してください。 (各セクションにもリンクされています)。

> [!tip]  イベントのインポート
>  Rasa SDK アクションサーバーに書き込まれたすべてのイベントは、`rasa_sdk.events` からインポートする必要があります。

## イベントクラス

### スロットセット

```python
rasa_sdk.events.SlotSet(
    key: Text, 
    value: Any = None, 
    timestamp: Optional[float] = None
)
```

**基になるイベント**: [`スロット`](events.md#slot)

**パラメータ**:

*   `key`: 設定するスロットの名前
*   `value`: スロットを設定する値。データ型は、スロットの [[domain#スロットタイプ|type]] と一致する必要があります
*   `timestamp`: イベントのオプションのタイムスタンプ

**例**

```python
evt = SlotSet(key = "name", value = "Mary")
```

### すべてのスロットリセット

```python
rasa_sdk.events.AllSlotsReset(timestamp: Optional[float] = None)
```

**基礎となるイベント**: [`reset_slots`](events.md#reset_slots)

**パラメータ**:

*   `timestamp`: イベントのオプションのタイムスタンプ

**例**:

```python
evt = AllSlotsReset()
```

### リマインダースケジュール済み

```python
rasa_sdk.events.ReminderScheduled(
    intent_name: Text,
    trigger_date_time: datetime.datetime,
    entities: Optional[Union[List[Dict[Text, Any]], Dict[Text, Text]]] = None,
    name: Optional[Text] = None,
    kill_on_user_message: bool = True,
    timestamp: Optional[float] = None,
)
```

**基になるイベント**: [`リマインダー`](events.md#reminder)

**パラメータ**:

*   `intent_name`: リマインダーがトリガーするインテント
*   `trigger_date_time`: アクションの実行をトリガーする日時。
*   `entities`: インテントで送信するエンティティ
*   `name`: リマインダーの ID。同じ ID のリマインダーが複数ある場合は、最後のリマインダーのみが実行されます。
*   `kill_on_user_message`: トリガー時刻より前のユーザーメッセージでリマインダーが中止されるかどうか
*   `timestamp`: イベントのオプションのタイムスタンプ

**例**:

```python
from datetime import datetime

evt = ReminderScheduled(
    intent_name = "EXTERNAL_dry_plant",
    trigger_date_time = datetime(2020, 9, 15, 0, 36, 0, 851609),
    entities = [{"name": "plant","value":"orchid"}], 
    name = "remind_water_plants",
)
```

### リマインダーキャンセル済み

```python
ReminderCancelled(
    name: Optional[Text] = None,
    intent_name: Optional[Text] = None,
    entities: Optional[Union[List[Dict[Text, Any]], Dict[Text, Text]]] = None,
    timestamp: Optional[float] = None,
) 
```

**基礎となるイベント**: [`cancel_reminder`](events.md#cancel_reminder)

**パラメータ**:

*   `name`: リマインダーの ID。
*   `intent_name`: リマインダーがトリガーする意図
*   `entities`: インテントで送信されたエンティティ
*   `timestamp`: イベントのオプションのタイムスタンプ

**例**:

```python
evt = ReminderCancelled(name = "remind_water_plants") 
```

### 会話一時停止

```python
ConversationPaused(timestamp: Optional[float] = None)
```

**基礎となるイベント**: [`pause`](events.md#slot)

**パラメータ**:

*   `timestamp`: イベントのオプションのタイムスタンプ

**例**:

```python
evt = ConversationPaused()
```

### 会話再開

```python
ConversationResumed(timestamp: Optional[float] = None)
```

**基になるイベント**: [`再開`](events.md#resume)

**パラメータ**:

*   `timestamp`: イベントのオプションのタイムスタンプ

**例**:

```python
evt = ConversationResumed()
```

### フォローアップアクション

```python
FollowupAction(
    name: Text, 
    timestamp: Optional[float] = None
)
```

**基礎となるイベント**: [`フォローアップ`](events.md#followup)

**パラメータ**:

*   `name`: 実行されるフォローアップアクションの名前。
*   `timestamp`: イベントのオプションのタイムスタンプ

**例**:

```python
evt = FollowupAction(name = "action_say_goodbye")
```

### UserUtteranceReverted (ユーザー発話元に戻されました)

```python
UserUtteranceReverted(timestamp: Optional[float] = None)
```

**基になるイベント**: [`巻き戻し`](events.md#rewind)

**パラメータ**:

*   `timestamp`: イベントのオプションのタイムスタンプ

**例**:

```python
evt = UserUtteranceReverted()
```

### アクション元に戻された

```python
ActionReverted(timestamp: Optional[float] = None)
```

**基になるイベント**: [`元に戻す`](events.md#undo)

**パラメータ**:

*   `timestamp`: イベントのオプションのタイムスタンプ

**例**:

```python
evt = ActionReverted()
```

### 再起動

```python
Restarted(timestamp: Optional[float] = None) 
```

**基になるイベント**: [`再起動`](events.md#restart)

**パラメータ**:

*   `timestamp`: イベントのオプションのタイムスタンプ

**例**:

```python
evt = Restarted()
```

### セッション開始

```python
SessionStarted(timestamp: Optional[float] = None)
```

**基礎となるイベント**: [`session_started`](events.md#session_started)

**パラメータ**:

*   `timestamp`: イベントのオプションのタイムスタンプ

**例**:

```python
evt = SessionStarted()
```

### ユーザー発話

```python
UserUttered(
    text: Optional[Text],
    parse_data: Optional[Dict[Text, Any]] = None,
    timestamp: Optional[float] = None,
    input_channel: Optional[Text] = None,
)
```

**基になるイベント**: [`user`](events.md#user)

**パラメータ**:

*   `text`: ユーザーメッセージのテキスト
*   `parse_data`: ユーザーメッセージの解析データ。これは通常、NLUによって埋められます。
*   `input_channel`: メッセージを受信したチャネル
*   `timestamp`: イベントのオプションのタイムスタンプ

**例**:

```python
evt = UserUttered(text = "Hallo bot")
```

### ボット発話

```python
BotUttered(
    text: Optional[Text] = None,
    data: Optional[Dict[Text, Any]] = None,
    metadata: Optional[Dict[Text, Any]] = None,
    timestamp: Optional[float] = None,
)
```

**基になるイベント**: [`ボット`](events.md#bot)

**パラメータ**:

*   `text`: ボットがユーザーに送信するテキスト
*   `data`: ボット応答のテキスト以外の要素。`データの`構造は、[API 仕様](https://github.com/RasaHQ/rasa/blob/main/pages/action-server-api)で指定された`応答`の構造と一致します。
*   `metadata`: 任意のキーと値のメタデータ
*   `timestamp`: イベントのオプションのタイムスタンプ

**例**:

```python
evt = BotUttered(text = "Hallo user")
```

### アクション実行済み

```python
ActionExecuted(
    action_name,
    policy=None,
    confidence: Optional[float] = None,
    timestamp: Optional[float] = None,
)
```

**基礎となるイベント**: [`アクション`](events.md#action)

**パラメータ**:

*   `action_name`: 呼び出されたアクションの名前
*   `policy`: アクションの予測に使用されるポリシー
*   `confidence`: アクションが予測された信頼度
*   `timestamp`: イベントのオプションのタイムスタンプ

**例**:

```python
evt = ActionExecuted("action_greet_user")
```