---
id: actions
sidebar_label: Actions
title: Actions
---

Rasa アシスタントは、カスタム・アクションを呼び出すと、アクション・サーバーに要求を送信します。Rasa は、要求応答で返されるイベントと応答についてのみ知っています。Rasa が提供するアクション名に基づいて正しいコードを呼び出すのは、アクションサーバー次第です。

Rasa がカスタムアクションを呼び出したときに何が起こるかをよりよく理解するために、次の例を考えてみましょう。

気象ボットを Facebook と Slack の両方にデプロイしました。ユーザーは、意図`ask_weather`で天気を尋ねることができます。スロット`位置`あり ユーザーが場所を指定した場合に入力されます。 アクション`action_tell_weather`は、APIを使用して天気予報を取得し、ユーザーが指定しない場合はデフォルトの場所を使用します。このアクションにより、`温度`が天気予報の最高気温に設定されます。返されるメッセージは、使用しているチャネルによって異なります。

> [!note] HTTP リクエストの圧縮本文
> 
> Rasaには、カスタムアクションのHTTPリクエスト本文を圧縮する機能があります。デフォルトでは、カスタムアクションの HTTP 要求で圧縮された本文を受信しなかった古いバージョンのカスタムアクションサーバーとの下位互換性を維持するために、このオプションはオフになっています。このオプションを有効にするには、環境変数 COMPRESS_ACTION_SERVER_REQUEST を `True` に設定します。
> 
> Rasa SDKバージョン`3.2.2`、`3.3.1`、`3.4.1`以降では、カスタムアクションサーバーを実行するためのHTTPリクエストで、圧縮された本文と非圧縮された本文の両方がサポートされています。追加の設定は必要ありません。

## カスタムアクション入力

アクション・サーバーは、Rasa サーバーから以下のペイロードを受信します。

```json
{
    "next_action": "action_tell_weather",
    "sender_id": "2687378567977106",
    "tracker": {
        "sender_id": "2687378567977106",
        "slots": {
            "location": null,
            "temperature": null
        },
        "latest_message": {
            "text": "/ask_weather",
            "intent": {
                "name": "ask_weather",
                "confidence": 1
            },
            "intent_ranking": [
                {
                    "name": "ask_weather",
                    "confidence": 1
                }
            ],
            "entities": []
        },
        "latest_event_time": 1599850576.655345,
        "followup_action": null,
        "paused": false,
        "events": [
            {
                "event": "action",
                "timestamp": 1599850576.654908,
                "name": "action_session_start",
                "policy": null,
                "confidence": null
            },
            {
                "event": "session_started",
                "timestamp": 1599850576.654916
            },
            {
                "event": "action",
                "timestamp": 1599850576.654928,
                "name": "action_listen",
                "policy": null,
                "confidence": null
            },
            {
                "event": "user",
                "timestamp": 1599850576.655345,
                "text": "/ask_weather",
                "parse_data": {
                    "text": "/ask_weather",
                    "intent": {
                        "name": "ask_weather",
                        "confidence": 1
                    },
                    "intent_ranking": [
                        {
                            "name": "ask_weather",
                            "confidence": 1
                        }
                    ],
                    "entities": []
                },
                "input_channel": "facebook",
                "message_id": "3f2f2317dada4908b7a841fd3eab6bf9",
                "metadata": {}
            }
        ],
        "latest_input_channel": "facebook",
        "active_form": {},
        "latest_action_name": "action_listen"
    },
    "domain": {
        "config": {
            "store_entities_as_slots": true
        },
        "session_config": {
            "session_expiration_time": 60,
            "carry_over_slots_to_new_session": true
        },
        "intents": [
            {
                "greet": {
                    "use_entities": true
                }
            },
            {
                "ask_weather": {
                    "use_entities": true
                }
            }
        ],
        "entities": [],
        "slots": {
            "location": {
                "type": "rasa.core.slots.UnfeaturizedSlot",
                "initial_value": null,
                "auto_fill": true
            },
            "temperature": {
                "type": "rasa.core.slots.UnfeaturizedSlot",
                "initial_value": null,
                "auto_fill": true
            }
        },
        "responses": {
            "utter_greet": [
                {
                    "text": "Hey! How are you?"
                }
            ]
        },
        "actions": [
            "action_tell_weather",
            "utter_greet"
        ],
        "forms": []
    },
    "version": "2.0.0"
}
```

### `next_action`

`next_action` フィールドは、アクションサーバーに実行するアクションを示します。アクションはクラスとして実装する必要はありませんが、名前で呼び出すことができる必要があります。

この例では、アクション・サーバーがアクション`・action_tell_weather`を実行する必要があります。

### `sender_id`

`sender_id`は、会話を行っているユーザーの一意の ID を示します。その形式は入力チャンネルによって異なります。ユーザーについて何を伝えるかは、入力チャネルと、チャネルによってユーザーがどのように識別されるかによっても異なります。

この例では、`sender_id`は何にも使用されません。

### `tracker`

`トラッカー`には、イベントの履歴やすべてのスロットの記録など、会話に関する情報が含まれています。

*   `sender_id`: ペイロードの最上位レベルで使用可能なものと同じ`sender_id`
*   `slots`: ボットのドメイン内の各スロットと現在の時点での値
*   `latest_message`: 最新のメッセージの属性
*   `latest_event_time`: 最後のイベントがトラッカーに追加されたタイムスタンプ
*   `followup_action`: 呼び出されたアクションは強制的なフォローアップアクションでした
*   `paused`: 会話が現在一時停止されているかどうか
*   `events`: 以前のすべての[イベント](./events.md)のリスト
*   `latest_input_channel`: 最後のユーザー・メッセージを受信した入力チャネル
*   `active_form`: 現在アクティブなフォームの名前 (存在する場合)
*   `latest_action_name`: ボットが最後に実行したアクションの名前

この例では、カスタムアクションは`ロケーションスロットの`値 (設定されている場合) を使用して天気予報を取得します。また、`latest_input_channel` プロパティをチェックし、Facebook Messenger で正しく表示されるようにメッセージ ペイロードをフォーマットします。

### `domain`

`ドメイン`は、`domain.yaml` ファイルの json 表現です。カスタムアクションは静的であり、会話の状態を示しないため、その内容を参照する可能性は低いです。

アクションがドメインを受け取るかどうかを制御できます。[[domain#ドメインを受け取るアクションを選択する|selective-domain]]にアクセスしてください。

### `version`

これは Rasa サーバーのバージョンです。カスタム・アクションもこれを参照する可能性は低いですが、アクション・サーバーが特定の Rasa バージョンとのみ互換性がある場合は、検証ステップで使用することもできます。

## カスタムアクション出力

Rasa サーバーは、カスタムアクション呼び出しへの応答として`、イベント`と`応答`のディクショナリを想定しています。

### `events`

[イベントは](./events.md)、アクションサーバーが会話に影響を与える方法です。この例では、カスタムアクションは`温度`スロットに最高温度を格納する必要があるため、[`スロット`イベント](./events.md#slot)を返す必要があります。スロットを設定し、他に何もしない場合、応答ペイロードは次のようになります。

```json
    {
        "events": [
            {
                "event": "slot",
                "timestamp": null,
                "name": "temperature",
                "value": "30"
            }
        ],
        "responses": []
    }
```

イベントは、リストした順序でトラッカーに適用されます。`スロット`付き イベントの場合、順序は重要ではありませんが、他のイベントタイプでは重要になります。

### `responses`

応答は、[[../responses#豊富な回答|リッチレスポンスに関するドキュメント]]を参照してください。予想される形式については、[API 仕様](https://github.com/RasaHQ/rasa/blob/main/pages/action-server-api)の応答サンプルを参照してください。

この例では、天気予報を含むメッセージをユーザーに送信します。通常のテキストメッセージを送信する場合、応答ペイロードは次のようになります。

```json
    {
        "events": [
            {
                "event": "slot",
                "timestamp": null,
                "name": "temperature",
                "value": "30"
            }
        ],
        "responses": [
            {
                "text": "This is your weather forecast!"
            }
        ]
    }
```

ただし、チャネル固有の機能を利用する必要があります。`latest_input_channel`は Facebook であったため、Facebook の API 仕様に従ってメディアメッセージとしてレンダリングされるカスタムペイロードを含む応答を追加します。応答ペイロードは次のようになります。

```json
    {
        "events": [
            {
                "event": "slot",
                "timestamp": null,
                "name": "temperature",
                "value": "30"
            }
        ],
        "responses": [
            {
                "text": "This is your weather forecast!"
            },
            {
                "attachment": {
                    "type": "template",
                    "payload": {
                        "template_type": "media",
                        "elements": [
                            {
                                "media_type": "weather_forcast.gif",
                                "attachment_id": "<id from facebook upload endpoint>"
                            }
                        ]
                    }
                }
            }
        ]
    }
```

この応答が Rasa サーバーに送り返されると、Rasa は`スロット` イベントと 2 つの応答をトラッカーに適用し、両方のメッセージをユーザーに返します。

## 特殊アクションの種類

特定の状況下で自動的にトリガーされる特別なアクションタイプ、[つまりデフォルトアクション](../default-actions.md)と[スロット検証アクション](../slot-validation-actions.md)があります。これらの特殊なアクション・タイプには、自動トリガー動作を維持するために従う必要がある事前定義された命名規則があります。

まったく同じ名前のカスタムアクションを実装することで、デフォルトのアクションをカスタマイズできます。各アクションの予想される動作については[、デフォルトのアクションに関するドキュメント](../default-actions.md)を参照してください。

スロット検証アクションは、フォームがアクティブであるかどうかに応じて、ユーザーターンごとに実行されます。フォームがアクティブでないときに実行する必要があるスロット検証アクションは、`action_validate_slot_mappings`呼び出す必要があります。フォームがアクティブなときに実行するスロット検証アクションは、`validate_<form name>` と呼び出す必要があります。これらのアクションは、`SlotSet` イベントのみを返し、Rasa SDK [[validation-action#`ValidationAction` クラスの実装|`ValidationAction` クラス]] と [[validation-action#`FormValidationAction` クラスの実装|`FormValidationAction` クラス]] をそれぞれ使用します。