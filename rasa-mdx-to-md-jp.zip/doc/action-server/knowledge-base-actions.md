---
id: knowledge-bases
sidebar_label: Knowledge Base Actions
title: Knowledge Base Actions
abstract: Leverage information from knowledge bases inside conversations using `ActionQueryKnowledgeBase` in open source bot framework Rasa.
---

> [!caution] 
> この機能は実験的です。コミュニティからフィードバックを得るために実験的な機能を導入していますので、ぜひ試してみてください。ただし、この機能は将来変更または削除される可能性があります。フィードバック(肯定的または否定的)がある場合は、[フォーラム](https://forum.rasa.com)で共有してください。

サポート情報アクションを使用すると、次の種類の会話を処理できます。

<img alt="image" src={useBaseUrl("/static/img/knowledge-base-example.png")} />

会話型 AI に共通する問題は、ユーザーが特定のオブジェクトを名前で呼ぶだけでなく、「最初のもの」や「それ」などの参照用語を使用することです。これらの言及を正しいオブジェクトに解決するために提示された情報を追跡する必要があります。

さらに、ユーザーは会話中にオブジェクトに関する詳細情報 (たとえば、レストランに屋外席があるかどうか、価格が高いかどうかなど) を取得したい場合があります。これらのユーザーの要求に応えるためには、レストランドメインに関する知識が必要です。情報は変更される可能性があるため、情報をハードコーディングすることは解決策ではありません。

上記の課題に対処するために、Rasa をナレッジ ベースと統合できます。この統合を使用するには、ナレッジベースでオブジェクトとその属性をクエリするロジックを含む、事前に作成されたカスタムアクションである `ActionQueryKnowledgeBase` から継承するカスタムアクションを作成できます。

完全な例は`examples/knowledgebasebot`にあります ([ナレッジベースボット](https://github.com/RasaHQ/rasa/tree/main/examples/knowledgebasebot/))、およびこのカスタムアクションを実装するための手順を以下に示します。

## `ActionQueryKnowledgeBase` の使用

### ナレッジ ベースの作成

ユーザーのリクエストに回答するために使用されるデータは、ナレッジベースに保存されます。ナレッジ ベースを使用して、複雑なデータ構造を格納できます。`InMemoryKnowledgeBase` を使用して開始することをお勧めします。大量のデータの操作を開始したら、カスタムナレッジベースに切り替えることができます ([[knowledge-base-actions#ナレッジ ベースの作成|独自のナレッジベースの作成]])。

`InMemoryKnowledgeBase` を初期化するには、json ファイルでデータを指定する必要があります。次の例には、レストランとホテルに関するデータが含まれています。json構造体には、すべてのオブジェクトタイプ(`「restaurant」`と`「hotel」)`のキーが含まれている必要があります。すべてのオブジェクトタイプはオブジェクトのリストにマッピングされます – ここには 3 つのレストランのリストと 3 つのホテルのリストがあります。

```json
{
    "restaurant": [
        {
            "id": 0,
            "name": "Donath",
            "cuisine": "Italian",
            "outside-seating": true,
            "price-range": "mid-range"
        },
        {
            "id": 1,
            "name": "Berlin Burrito Company",
            "cuisine": "Mexican",
            "outside-seating": false,
            "price-range": "cheap"
        },
        {
            "id": 2,
            "name": "I due forni",
            "cuisine": "Italian",
            "outside-seating": true,
            "price-range": "mid-range"
        }
    ],
    "hotel": [
        {
            "id": 0,
            "name": "Hilton",
            "price-range": "expensive",
            "breakfast-included": true,
            "city": "Berlin",
            "free-wifi": true,
            "star-rating": 5,
            "swimming-pool": true
        },
        {
            "id": 1,
            "name": "Hilton",
            "price-range": "expensive",
            "breakfast-included": true,
            "city": "Frankfurt am Main",
            "free-wifi": true,
            "star-rating": 4,
            "swimming-pool": false
        },
        {
            "id": 2,
            "name": "B&B",
            "price-range": "mid-range",
            "breakfast-included": false,
            "city": "Berlin",
            "free-wifi": false,
            "star-rating": 1,
            "swimming-pool": false
        },
    ]
}
```

データが `data.json` などの json ファイルで定義されると、このデータ ファイルを使用して `InMemoryKnowledgeBase` は、ナレッジ ベースにクエリを実行するアクションに渡されます。

ナレッジベースのすべてのオブジェクトには、デフォルトの実装を使用するために、少なくとも`「name」`フィールドと`「id」`フィールドが必要です。そうでない場合は、[[knowledge-base-actions#`InMemoryKnowledgeBase` のカスタマイズ|InMemoryKnowledgeBaseのカスタマイズ]]する必要があります。

### NLU データの定義

このセクションの内容:

*   新しいインテントを導入します`query_knowledge_base`
    
*   モデルが「最初のもの」のようなオブジェクトの間接的な言及を検出できるように、`メンション`エンティティに注釈を付けます
    
*   [[training-data-format#類義 語|synonyms]] を広範囲に使用します
    

ユーザーがナレッジ ベースから情報を取得したいことをボットが理解するには、新しい意図を定義する必要があります。私たちはそれを`query_knowledge_base`と呼びます。

`ActionQueryKnowledgeBase` が処理できるリクエストは、(1) ユーザーが特定のタイプのオブジェクトのリストを取得したい、または (2) ユーザーがオブジェクトの特定の属性について知りたいという 2 つのカテゴリに分割できます。インテントには、次の両方のリクエストの多くのバリエーションが含まれている必要があります。

```yaml-rasa
nlu:
- intent: query_knowledge_base
  examples: |
    - what [restaurants]{"entity": "object_type", "value": "restaurant"} can you recommend?
    - list some [restaurants]{"entity": "object_type", "value": "restaurant"}
    - can you name some [restaurants]{"entity": "object_type", "value": "restaurant"} please?
    - can you show me some [restaurants]{"entity": "object_type", "value": "restaurant"} options
    - list [German](cuisine) [restaurants]{"entity": "object_type", "value": "restaurant"}
    - do you have any [mexican](cuisine) [restaurants]{"entity": "object_type", "value": "restaurant"}?
    - do you know the [price range]{"entity": "attribute", "value": "price-range"} of [that one](mention)?
    - what [cuisine](attribute) is [it](mention)?
    - do you know what [cuisine](attribute) the [last one]{"entity": "mention", "value": "LAST"} has?
    - does the [first one]{"entity": "mention", "value": "1"} have [outside seating]{"entity": "attribute", "value": "outside-seating"}?
    - what is the [price range]{"entity": "attribute", "value": "price-range"} of [Berlin Burrito Company](restaurant)?
    - what about [I due forni](restaurant)?
    - can you tell me the [price range](attribute) of [that restaurant](mention)?
    - what [cuisine](attribute) do [they](mention) have?
```

上記の例は、レストランドメインに関連する例を示しています。ナレッジベースに存在するすべてのオブジェクトタイプの例を同じ`query_knowledge_base`インテントに追加する必要があります。

クエリの種類ごとにさまざまなトレーニング例を追加するだけでなく、トレーニング例で次のエンティティを指定して注釈を付ける必要があります。

*   `object_type`: トレーニング例がナレッジベースの特定のオブジェクトタイプを参照する場合は、オブジェクトタイプをエンティティとしてマークする必要があります。[[training-data-format#類義 語|synonyms]] を使用して、`たとえばレストラン`を`レストラン`にマッピングし、正しいオブジェクト タイプがナレッジ ベースにキーとしてリストされます。
    
*   `メンション`: ユーザーが「最初のもの」、「そのもの」、または「それ」を介してオブジェクトを参照している場合は、それらの用語を`メンション`としてマークする必要があります。また、同義語を使用して、一部の言及を記号にマッピングします。これについては、[[knowledge-base-actions#メンションの解決|メンションの解決]]で学ぶことができます。
    
*   `attribute`: ナレッジベースで定義されているすべての属性名は、NLU データで`属性`として識別する必要があります。ここでも、シノニムを使用して、属性名のバリエーションをナレッジベースで使用されているものにマップします。
    

これらのエンティティをドメインファイルに(エンティティとスロットとして)追加することを忘れないでください。

```yaml-rasa
entities:
  - object_type
  - mention
  - attribute

slots:
  object_type:
    type: any
    influence_conversation: false
    mappings:
    - type: from_entity
      entity: object_type
  mention:
    type: any
    influence_conversation: false
    mappings:
    - type: from_entity
      entity: mention
  attribute:
    type: any
    influence_conversation: false
    mappings:
    - type: from_entity
      entity: attribute
```

### ナレッジベースをクエリするアクションの作成

独自のナレッジ ベース アクションを作成するには、`ActionQueryKnowledgeBase` を継承し、ナレッジ ベースを `ActionQueryKnowledgeBase` のコンストラクターに渡す必要があります。

```python
from rasa_sdk.knowledge_base.storage import InMemoryKnowledgeBase
from rasa_sdk.knowledge_base.actions import ActionQueryKnowledgeBase

class MyKnowledgeBaseAction(ActionQueryKnowledgeBase):
    def __init__(self):
        knowledge_base = InMemoryKnowledgeBase("data.json")
        super().__init__(knowledge_base)
```

`ActionQueryKnowledgeBase` を作成するたびに、`KnowledgeBase` をコンストラクターに渡す必要があります。これは、`InMemoryKnowledgeBase` または独自の `KnowledgeBase` 実装のいずれかです ([[knowledge-base-actions#ナレッジベースの作成|独自のナレッジベースの作成]])。 複数のナレッジ ベースを同時に使用することはサポートされていないため、1 つのナレッジ ベースからのみ情報を取得できます。

これがこのアクションのコードのすべてです。アクションの名前は`action_query_knowledge_base`です。ドメインファイルに追加することを忘れないでください。

```yaml-rasa
actions:
- action_query_knowledge_base
```

> [!note] 
> デフォルトのアクション名`を上`書きする場合は、`action_query_knowledge_base` の 3 つの非特徴スロットをドメイン ファイルに追加する必要があります `knowledge_base_last_object_type` : knowledge_base_objects、`knowledge_base_last_object`、および 。スロットは、`ActionQueryKnowledgeBase` によって内部的に使用されます。デフォルトのアクション名を維持すると、それらのスロットが自動的に追加されます。

また、インテント`query_knowledge_base`とアクション`action_query_knowledge_base`を含むストーリーをストーリーファイルに追加する必要があります。例えば：

```yaml-rasa
stories:
- story: knowledge base happy path
  steps:
  - intent: greet
  - action: utter_greet
  - intent: query_knowledge_base
  - action: action_query_knowledge_base
  - intent: goodbye
  - action: utter_goodbye
```

最後に、ドメイン ファイルで応答`utter_ask_rephrase`を定義する必要があります。アクションがユーザーの要求を処理する方法を知らない場合、この応答を使用してユーザーに言い換えを求めます。たとえば、ドメイン ファイルに次の応答を追加します。

```yaml-rasa
responses:
  utter_ask_rephrase:
  - text: "Sorry, I'm not sure I understand. Could you rephrase it?"
  - text: "Could you please rephrase your message? I didn't quite get that."
```

関連するすべての部分を追加すると、アクションはナレッジ ベースをクエリできるようになります。

## 使い方

`ActionQueryKnowledgeBase` は、要求で取得されたエンティティと、以前に設定されたスロットの両方を調べて、クエリ対象を決定します。

### ナレッジベースでオブジェクトを照会する

ナレッジベースにあらゆる種類のオブジェクトを照会するには、ユーザーの要求にオブジェクトタイプを含める必要があります。例を見てみましょう。

レストランの名前を教えてください。

この質問には、関心のあるオブジェクトタイプ「レストラン」が含まれます。ボットは、クエリを作成するためにこのエンティティを取得する必要があります - そうしないと、アクションはユーザーがどのオブジェクトに関心を持っているかを認識しません。

ユーザーが次のようなことを言うと、次のようになります。

ベルリンにはどのようなイタリアンレストランがありますか?

ユーザーは、(1) イタリア料理を提供し、(2) ベルリンにあるレストランのリストを取得したいと考えています。NER がユーザーの要求でこれらの属性を検出すると、アクションはそれらを使用してナレッジ ベースで見つかったレストランをフィルター処理します。

ボットがこれらの属性を検出するには、NLU データのエンティティとして「イタリア語」と「ベルリン」をマークする必要があります。

```yaml-rasa
intents:
- intent: query_knowledge_base
  examples: |
    - What [Italian](cuisine) [restaurant](object_type) options in [Berlin](city) do I have?.
```

属性の名前 "cuisine" と "city" は、ナレッジ ベースで使用されるものと同じである必要があります。また、これらをエンティティとスロットとしてドメイン ファイルに追加する必要があります。

### ナレッジベースでオブジェクトの属性を照会する

ユーザーがオブジェクトに関する特定の情報を取得したい場合は、要求に対象のオブジェクトと属性の両方を含める必要があります。

> [!info]  3.6 の新機能 
> ユーザーは、これより前にあらゆる種類のオブジェクトを一覧表示するためにナレッジ ベースを照会する必要はありません。`ActionQueryKnowledgeBase` は、ユーザーの要求からオブジェクトの種類を抽出し、ナレッジ ベースでオブジェクトの属性を照会します。

たとえば、ユーザーが次のような質問をした場合です。

ベルリンブリトーカンパニーの料理は何ですか?

ユーザーは、レストラン「Berlin Burrito Company」(関心のあるオブジェクト)の「料理」(関心のある属性)を取得したいと考えています。

対象の属性とオブジェクトは、NLU トレーニング データでエンティティとしてマークする必要があります。

```yaml-rasa
intents:
- intent: query_knowledge_base
  examples: |
    - What is the [cuisine](attribute) of [Berlin Burrito Company](restaurant)?
```

オブジェクトタイプ「restaurant」をエンティティとスロットとしてドメインファイルに追加してください。これにより`、ActionQueryKnowledgeBase` がサポートされます。 をクリックして、ユーザーが関心のあるオブジェクトのオブジェクトタイプを抽出します。

### メンションの解決

上記の例に従って、ユーザーはレストランを必ずしも名前で呼ぶとは限りません。ユーザーは、関心のあるオブジェクトを名前で参照するか、たとえば「Berlin Burrito Company」(オブジェクトの表現文字列)を参照するか、以前にリストされたオブジェクトを参照してメンションを介して参照できます。

おっしゃった2軒目のレストランの料理は?

私たちのアクションは、これらの言及をナレッジベースの実際のオブジェクトに解決することができます。具体的には、(1) "最初のもの" などの序数言及と、(2) "it" や "that one" などの言及の 2 つのメンション タイプを解決できます。

**序数メンション**

ユーザーがリスト内の位置によってオブジェクトを参照する場合、それは序数メンションと呼ばれます。次に例を示します。

*   ユーザー:ベルリンのどのレストランを知っていますか?
    
*   ボット: タイプ 'restaurant' の次のオブジェクトが見つかりました: 1: I due forni 2: PastaBar 3: Berlin Burrito Company
    
*   ユーザー: 最初の部屋には外席がありますか?
    

ユーザーは「I due forni」を「最初のもの」という用語で呼びました。その他の序数言及には、「2番目のもの」、「最後のもの」、「任意」、または「3」が含まれる場合があります。

序数メンションは、通常、オブジェクトのリストがユーザーに提示されたときに使用されます。 これらのメンションを実際のオブジェクトに解決するには、 `KnowledgeBase` クラス。デフォルトのマッピングは次のようになります。

```python
{
    "1": lambda l: l[0],
    "2": lambda l: l[1],
    "3": lambda l: l[2],
    "4": lambda l: l[3],
    "5": lambda l: l[4],
    "6": lambda l: l[5],
    "7": lambda l: l[6],
    "8": lambda l: l[7],
    "9": lambda l: l[8],
    "10": lambda l: l[9],
    "ANY": lambda l: random.choice(l),
    "LAST": lambda l: l[-1],
}
```

序数メンションマッピングは、"1"などの文字列をリスト内のオブジェクトにマップします(`例:ラムダl:l[0]`、インデックス`0`のオブジェクトを意味します)。

序数メンションマッピングには、たとえば「最初のもの」のエントリが含まれていないため、[[training-data-format#類義 語|Entity Synonyms]] を使用して、NLU データの "最初のもの" を "1" にマッピングします。

```yaml-rasa
intents:
- intent: query_knowledge_base
  examples: |
    - Does the [first one]{entity: "mention", value": 1} have [outside seating]{entity: "attribute", value": "outside-seating"}
```

NER は`メンション` エンティティとして "最初の 1" を検出しますが、`メンション` スロットには "1" を入れます。したがって、私たちのアクションは、序数メンションマッピングと一緒に`メンション`スロットを取得して、「最初のもの」を実際のオブジェクト「I due forni」に解決できます。

序数メンション`set_ordinal_mention_mapping`マッピングを上書きするには、 `ナレッジベースの`実装 ([[knowledge-base-actions#`InMemoryKnowledgeBase`|InMemoryKnowledgeBaseのカスタマイズ]])。

**その他の言及**

次の会話を見てください。

*   ユーザー: PastaBar の料理は何ですか?
    
*   ボット:PastaBarにはイタリア料理があります。
    
*   ユーザー:Wi-Fiはありますか?
    
*   ボット:はい。
    
*   ユーザー: 住所を教えてもらえますか?
    

「Wi-Fi はありますか?」という質問で、ユーザーは「PastaBar」を「それ」という言葉で呼んでいます。NER がエンティティ`のメンション`として "it" を検出した場合、ナレッジ ベース アクションは、会話で最後に言及されたオブジェクトである "PastaBar" に解決します。

次の入力では、ユーザーはオブジェクト「PastaBar」を明示的に言及するのではなく、間接的に参照します。ナレッジ ベース アクションは、ユーザーが特定の属性 (この場合は住所) の値を取得したいことを検出します。メンションまたはオブジェクトがNERによって検出されなかった場合、アクションは、ユーザーが最後に言及されたオブジェクト「PastaBar」を参照していると想定します。

この動作を無効にするには、アクションの初期化時に `use_last_object_mention` を `False` に設定します。

## カスタマイズ

### `ActionQueryKnowledgeBase` のカスタマイズ

ボットがユーザーに話す内容をカスタマイズする場合は、`ActionQueryKnowledgeBase` の次の 2 つの関数を上書きできます。

*   `utter_objects()`
    
*   `utter_attribute_value()`
    

`utter_objects()` は、ユーザーがオブジェクトのリストを要求した場合に使用されます。ボットがナレッジ ベースからオブジェクトを取得すると、既定で次のような形式のメッセージでユーザーに応答します。

「レストラン」タイプの次のオブジェクトが見つかりました: 1: I due forni 2: PastaBar 3: Berlin Burrito Company

または、オブジェクトが見つからない場合は、

「レストラン」タイプのオブジェクトは見つかりませんでした。

発話の形式を変更する場合は、アクションのメソッド `utter_objects()` を上書きできます。

関数 `utter_attribute_value()` は、ユーザーがオブジェクトに関する特定の情報を要求したときにボットが発する内容を決定します。

対象の属性がナレッジ ベースで見つかった場合、ボットは次の発話で応答します。

「ベルリン・ブリトー・カンパニー」は「料理」という属性の値「メキシコ」を持っています。

要求された属性の値が見つからない場合、ボットは

オブジェクト 'Berlin Burrito Company' の属性 'cuisine' に有効な値が見つかりませんでした。

ボットの発話を変更する場合は、メソッド `utter_attribute_value()` を上書きできます。

> [!NOTE]  
> カスタムアクションでナレッジベースを使用する方法に関する[チュートリアル](https://blog.rasa.com/integrating-rasa-with-knowledge-bases/)がブログにあります。このチュートリアルでは、`ActionQueryKnowledgeBase`の実装について詳しく説明します。

### 独自のナレッジベースアクションの作成

`ActionQueryKnowledgeBase` を使用すると、ナレッジ ベースのアクションへの統合を簡単に開始できます。ただし、このアクションは、次の 2 種類のユーザー要求のみを処理できます。

*   ユーザーがナレッジベースからオブジェクトのリストを取得する
    
*   ユーザーが特定のオブジェクトの属性の値を取得したい場合
    

このアクションは、ナレッジベース内のオブジェクト間の比較やオブジェクト間の関係を考慮することはできません。さらに、会話で最後に言及されたオブジェクトへの言及を解決することは、常に最適であるとは限りません。

より複雑なユースケースに取り組みたい場合は、独自のカスタムアクションを作成できます。`rasa_sdk.knowledge_base.utils`にいくつかのヘルパー関数を追加しました ([コードへのリンク](https://github.com/RasaHQ/rasa-sdk/tree/main/rasa_sdk/knowledge_base/))を使用して、独自のソリューションを実装する際に役立ちます。`ActionQueryKnowledgeBase` を引き続き使用できるように、`KnowledgeBase` インターフェイスを使用することをお勧めします。 新しいカスタムアクションと並んで。

上記のユースケースの1つまたは新しいユースケースに取り組むナレッジベースのアクションを作成する場合は、[必ずフォーラム](https://forum.rasa.com)でそれについて教えてください。

### `InMemoryKnowledgeBase` のカスタマイズ

クラス `InMemoryKnowledgeBase` は `KnowledgeBase` を継承します。`InMemoryKnowledgeBase` は、次の関数を上書きすることでカスタマイズできます。

*   `get_key_attribute_of_object()`: ユーザーが最後に話していたオブジェクトを追跡するために、key 属性の値を特定のスロットに格納します。すべてのオブジェクトには、リレーショナル データベースの主キーと同様に、一意のキー属性が必要です。デフォルトでは、すべてのオブジェクトタイプのキー属性の名前は `id` に設定されています。特定のオブジェクトタイプのキー属性の名前を上書きするには、 `set_key_attribute_of_object()`です。
    
*   `get_representation_function_of_object()` : 次のレストランに焦点を当てましょう。
    
    ```json
    {
        "id": 0,
        "name": "Donath",
        "cuisine": "Italian",
        "outside-seating": true,
        "price-range": "mid-range"
    }
    ```
    
    ユーザーがボットにイタリアン レストランをリストするように要求する場合、レストランの詳細をすべて必要とする必要はありません。代わりに、レストランを識別する意味のある名前を指定する必要があります (ほとんどの場合、オブジェクトの名前で十分です)。この関数 `get_representation_function_of_object()` は、上記のレストランオブジェクトをその名前にマッピングするラムダ関数を返します。
    
    ```python
    lambda obj: obj["name"]
    ```
    
    この関数は、ボットが特定のオブジェクトについて話しているときに使用されるため、ユーザーにオブジェクトの意味のある名前が表示されます。
    
    デフォルトでは、ラムダ関数はオブジェクトの`「name」`属性の値を返します。オブジェクトに `"name"` 属性がない場合、またはオブジェクトの `"name"` が あいまいな場合は、 `set_representation_function_of_object()` .
    
*   `set_ordinal_mention_mapping()`: 序数メンション マッピングは、"2 番目のメンション" などの序数メンションをリスト内のオブジェクトに解決するために必要です。既定では、序数メンション マッピングは次のようになります。
    
    ```python
    {
        "1": lambda l: l[0],
        "2": lambda l: l[1],
        "3": lambda l: l[2],
        "4": lambda l: l[3],
        "5": lambda l: l[4],
        "6": lambda l: l[5],
        "7": lambda l: l[6],
        "8": lambda l: l[7],
        "9": lambda l: l[8],
        "10": lambda l: l[9],
        "ANY": lambda l: random.choice(l),
        "LAST": lambda l: l[-1],
    }
    ```
    
    関数`set_ordinal_mention_mapping()`を呼び出すことで上書きできます。このマッピングの使用方法の詳細については、[[knowledge-base-actions#メンションの解決|メンションの解決]]。
    

メソッドを使用する `set_representation_function_of_object()` `InMemoryKnowledgeBase` の実装例については、[サンプル ボット](https://github.com/RasaHQ/rasa/blob/main/examples/knowledgebasebot/actions/actions.py)を参照してください をクリックして、オブジェクトタイプ「hotel」のデフォルト表現を上書きします。 `InMemoryKnowledgeBase`自体の実装は、 [rasa-sdk](https://github.com/RasaHQ/rasa-sdk/tree/main/rasa_sdk/knowledge_base/) パッケージ。

### 独自のナレッジ ベースの作成

より多くのデータがある場合、または異なるオブジェクト間の関係などを含むより複雑なデータ構造を使用する場合は、独自のナレッジベース実装を作成できます。`ナレッジベース`を継承し、`メソッドget_objects()`、`get_object()`、`get_object_types()`を実装するだけです。 `get_attributes_of_object()`です。[ナレッジ ベース コード](https://github.com/RasaHQ/rasa-sdk/tree/main/rasa_sdk/knowledge_base/) これらのメソッドが何をすべきかについての詳細情報を提供します。

[[knowledge-base-actions#`InMemoryKnowledgeBase` のカスタマイズ|InMemoryKnowledgeBaseのカスタマイズ]]。

> [!NOTE] 
> 独自のナレッジ ベースを設定する方法を説明する[ブログ記事](https://blog.rasa.com/set-up-a-knowledge-base-to-encode-domain-knowledge-for-rasa/)を書きました。