---
id: sdk-tracker
sidebar_label: Tracker
title: Tracker
---

`Tracker`クラスは、Rasa会話トラッカーを表します。これにより、カスタム アクションでボットのメモリにアクセスできます。トラ`ッカー`の属性とメソッドを通じて、過去のイベントと会話の現在の状態に関する情報を取得できます。

## 属性

`Tracker`オブジェクトの属性として、次のものを使用できます。

*   `sender_id` - ボットと会話しているユーザーの一意の ID。
    
*   `slots` - "ref" ドメインで定義されているように埋めることができるスロットのリスト。
    
*   `latest_message` - 最新のメッセージの属性(`インテント`、`エンティティ`、`テキスト`)を含む辞書。
    
*   `events` - 以前のすべてのイベントのリスト。
    
*   `active_loop` - 現在アクティブなループの名前。
    
*   `latest_action_name` - ボットが最後に実行したアクションの名前。
    

## メソッド

`トラッカー`から使用できる方法は次のとおりです。

### Tracker.current_state

現在のトラッカーの状態をオブジェクトとして返します。

*   **戻り値の型**

`Dict[str, Any]`

### Tracker.is_paused

トラッカーが現在一時停止されているかどうかを指定します。

*   **戻り値の型**

`bool`

### Tracker.get_latest_entity_values

最新のメッセージで、渡されたエンティティの種類とオプションのロールとグループに対して見つかったエンティティ値を取得します。特定の型の最初のエンティティのみに関心がある場合は、次のようにします。

```python
next(tracker.get_latest_entity_values(“my_entity_name”), None)
```

エンティティが見つからない場合は、デフォルトの結果が `None` になります。

*   **パラメーター**
    
    *   `entity_type` – 関心のあるエンティティタイプ
        
    *   `entity_role` – 関心のあるオプションのエンティティ ロール
        
    *   `entity_group` – 関心のあるオプションのエンティティグループ
        
*   **収益**
    

エンティティ値のリスト。

*   **戻り値の型**

`Iterator[str]`

### Tracker.get_latest_input_channel

最新の UserUttered イベントのinput_channelの名前を取得する

*   **戻り値の型**

`Optional[str]`

### Tracker.events_after_latest_restart

直近の再起動後のイベントのリストを返します。

*   **戻り値の型**

`List[Dict]`

### Tracker.get_slot

スロットの値を取得します。

*   **パラメーター**
    
    *   `key` – 値を取得するスロットの名前
*   **戻り値の型**
    

`Optional[Any]`

### Tracker.get_intent_of_latest_message

ユーザーの最新のインテントを取得します。

*   **パラメーター**
    
    *   `skip_fallback_intent` (デフォルト: `True`) – オプションで、`nlu_fallback`インテントをスキップし、次に高いランクを返します。
*   **収益**
    

最新のメッセージの意図 (使用可能な場合)。

*   **戻り値の型**

`Optional[Text]`