---
id: sdk-dispatcher
sidebar_label: Dispatcher
title: Dispatcher
---

ディスパッチャーは、ユーザーに送り返す応答を生成するために使用される `CollectingDispatcher` クラスのインスタンスです。

## CollectingDispatcher (ディスパッチャーの収集)

`CollectingDispatcher` には、`utter_message` という 1 つのメソッドと `messages` という 1 つの属性があります。これは、アクションの`実行`メソッドで、Rasa サーバーに返されたペイロードに応答を追加するために使用されます。Rasaサーバーは、応答ごとに`BotUttered`イベントをトラッカーに追加します。したがって、ディスパッチャーを使用して追加された応答は、[イベント](events.md)として明示的に返されるべきではありません。たとえば、次のカスタム アクションはイベントを明示的に返しませんが、ユーザーに "こんにちは、ユーザー!" という応答を返します。

```python
class ActionGreetUser(Action):
    def name(self) -> Text:
        return "action_greet_user"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[EventType]:

        dispatcher.utter_message(text = "Hi, User!")

        return []
```

### CollectingDispatcher.utter_message

`utter_message`メソッドを使用して、任意のタイプの応答をユーザーに返すことができます。

#### **パラメーター**

`utter_message` メソッドは、次のオプションの引数を取ります。引数を渡さないと、空のメッセージがユーザーに返されます。複数の引数を渡すと、豊富な応答 (テキストやボタンなど) がユーザーに返されます。

*   `text`: ユーザーに返されるテキスト。

```python
dispatcher.utter_message(text = "Hey there")
```

*   `image`: ユーザーに画像を表示するために使用される画像の URL またはファイル パス。

```python
dispatcher.utter_message(image = "https://i.imgur.com/nGF1K8f.jpg")
```

*   `json_message`: ディクショナリとしてのカスタム json ペイロード。[チャネル固有の応答](../responses.md)を送信するために使用できます。次の例では、Slack の日付ピッカーを返します。

```python
date_picker = {
  "blocks":[
    {
      "type": "section",
      "text":{
        "text": "Make a bet on when the world will end:",
        "type": "mrkdwn"
      },
      "accessory":
      {
        "type": "datepicker",
        "initial_date": "2019-05-21",
        "placeholder":
        {
          "type": "plain_text",
          "text": "Select a date"
        }
      }
    }
  ]
}
dispatcher.utter_message(json_message = date_picker)
```

*   `response`: ユーザーに返される応答の名前。この応答は、アシスタント[・ドメイン](../domain.md)で指定する必要があります。

```python
dispatcher.utter_message(response = "utter_greet")
```

*   `attachment`: ユーザーに返される添付ファイルの URL またはファイル パス。

```python
dispatcher.utter_message(attachment = "")
```

*   `buttons`: ユーザーに返すボタンのリスト。各ボタンは辞書であり、`タイトル`と`ペイロード`キーが必要です。ボタンには他のキーを含めることができますが、これらは特定のチャンネルがそれらを検索する場合にのみ使用されます。ユーザーがボタンをクリックすると、ボタンの`ペイロード`がユーザーメッセージとして送信されます。

```
dispatcher.utter_message(buttons = [
                {"payload": "/affirm", "title": "Yes"},
                {"payload": "/deny", "title": "No"},
            ])
```

*   `要素`: これらは、Facebook をメッセージング チャネルとして使用する場合に固有のものです。予想される形式の詳細については[、Facebook のドキュメント](https://developers.facebook.com/docs/messenger-platform/send-messages/template/generic/)を参照してください
    
*   `**kwargs`: [応答バリエーションの変数補間の](../responses.md)値を指定するために使用できる任意のキーワード引数。たとえば、次の応答があるとします。
    

```yaml
responses:
  utter_greet_name:
  - text: Hi {name}!
```

名前は次のように指定できます。

```python
dispatcher.utter_message(response = "utter_greet_name", name = "Aimee")
```

#### **戻り値の型**

`None`