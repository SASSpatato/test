---
id: sanic-extensions
sidebar_label: Sanic Extensions
title: Sanic Extensions
---

> [!info]  3.6 の新機能 
> ミドルウェア、リスナー、バックグラウンドタスク、追加ルートなどの Sanic 機能を拡張できるようになりました。

アクションサーバーによって作成されたアプリオブジェクトにアクセスして、追加の Sanic 拡張機能を作成できるようになりました。プラグインパッケージに実装されたフックを使用すると、アクションサーバーの起動時に`rasa-sdk`によって作成されたSanicアプリオブジェクトにアクセスできます。

## rasa_sdkで独自の Sanic 拡張機能を作成するためのステップバイステップ ガイド

この例では、プラグインを使用して Sanic リスナーを作成する方法を示します。

### rasa_sdk_pluginsパッケージを作成する

アクション サーバー プロジェクトにパッケージを作成し、`rasa_sdk_plugins` という名前を付ける必要があります。Rasa SDKは、プラグインを起動するために、プロジェクトでこのパッケージをインスタンス化しようとします。プラグインが見つからない場合は、プロジェクトにプラグインがないことを示すデバッグログが出力されます。

### フックを含むモジュールを登録する

パッケージ`rasa_sdk_plugins`を作成し、プラグインマネージャーがフックが実装されているモジュールを探す`__init__.py`ファイルを作成してフックを初期化します。

```
def init_hooks(manager: pluggy.PluginManager) -> None:
    """Initialise hooks into rasa sdk."""
    import sys
    import rasa_sdk_plugins.your_module

    logger.info("Finding hooks")
    manager.register(sys.modules["rasa_sdk_plugins.your_module"])
```

### フックを実装する

フック`attach_sanic_app_extensions`を実装します。このフックは、`rasa_sdk`でSanicによって作成されたアプリオブジェクトを転送し、追加のルート、ミドルウェア、リスナー、バックグラウンドタスクを作成できます。リスナーを作成するこの実装の例を次に示します。

あなたの `rasa_sdk_plugins.your_module.py` :

```
from __future__ import annotations

import logging
import pluggy

from asyncio import AbstractEventLoop
from functools import partial


logger = logging.getLogger(__name__)
hookimpl = pluggy.HookimplMarker("rasa_sdk")


@hookimpl  # type: ignore[misc]
def attach_sanic_app_extensions(app: Sanic) -> None:
    logger.info("hook called")
    app.register_listener(
        partial(before_server_start),
        "before_server_start",
    )


async def before_server_start(app: Sanic, loop: AbstractEventLoop):
    logger.info("BEFORE SERVER START")
```