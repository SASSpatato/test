---
id: events
sidebar_label: Events
title: Events
---

Rasa での会話は、一連のイベントとして表されます。カスタムアクションは、アクションサーバー要求への応答でイベントを返すことで、会話の過程に影響を与えることができます。

Rasaによって自動的に追跡されるため、通常、すべてのイベントがカスタムアクションによって返されるわけではありません(ユーザーメッセージなど)。その他のイベントは、カスタム アクションによって返された場合にのみ追跡できます。

## イベントタイプ

### `slot`

トラッカーにスロットを設定します。スロットを値に設定することも、値を `null` に設定してスロットをリセットすることもできます。

**自動追跡**:

*   スロットが同じ名前のエンティティによって埋められている場合。

エンティティによって自動入力されないスロットを設定するには、カスタムアクションが必要です。

**JSON**です。

```json
{
    "event": "slot",
    "name": "departure_airport", 
    "value": "BER"
}
```

**パラメータ**:

*   `name`: 設定するスロットの名前
*   `value`: スロットを設定する値。データ型は、スロットの [[domain#スロットタイプ|type]] と一致する必要があります

**Rasaクラス**:`rasa.core.events.SlotSet`

### `reset_slots`

トラッカー上のすべてのスロットを `null` にリセットします。

**自動追跡**:なし

**JSON**です。

```json
{
    "event": "reset_slots"
}
```

**ラサクラス**: `rasa.core.events.AllSlotsReset`

### `reminder`

将来の特定の時点でトリガーされるインテントをスケジュールします。

**自動追跡**:なし

**JSON**です。

```json
{
  "event": "reminder",
  "intent": "my_intent",
  "entities": {"entity1": "value1", "entity2": "value2"},
  "date_time": "2018-09-03T11:41:10.128172",
  "name": "my_reminder",
  "kill_on_user_msg": true,
}
```

**パラメータ**:

*   `intent`: リマインダーがトリガーするインテント
*   `entities`: インテントで送信するエンティティ
*   `date_time`: アクションの実行をトリガーする日付。これは UTC またはタイムゾーンを含める必要があります。
*   `name`: リマインダーの ID。同じ ID のリマインダーが複数ある場合は、最後のリマインダーのみが実行されます。
*   `kill_on_user_msg`: トリガー時刻より前のユーザーメッセージでリマインダーが中止されるかどうか

**ラサクラス**: `rasa.core.events.ReminderScheduled`

### `cancel_reminder`

スケジュールされたリマインダーをキャンセルします。指定されたパラメーターに一致するすべてのリマインダーはキャンセルされます。

**自動追跡**:なし

**JSON**です。

```json
{
  "event": "cancel_reminder",
  "name": "my_reminder",
  "intent": "my_intent",
  "entities": [
        {"entity": "entity1", "value": "value1"},
        {"entity": "entity2", "value": "value2"},
    ],
  "date_time": "2018-09-03T11:41:10.128172",
}
```

**パラメータ**:

*   `intent`: リマインダーがトリガーするインテント
*   `entities`: インテントで送信するエンティティ
*   `date_time`: アクションの実行をトリガーする日付。これは UTC またはタイムゾーンを含める必要があります。
*   `name`: リマインダーの ID。

**ラサクラス**: `rasa.core.events.ReminderCancelled`

### `pause`

ボットがユーザーメッセージに応答しないようにします。会話は一時停止したままになり、会話が明示的に[再開](#resume)されるまでアクションは予測されません。

**自動追跡**:なし

**JSON**です。

```json
{
    "event": "pause"
}
```

**ラサクラス**: `rasa.core.events.ConversationPaused`

### `resume`

以前に一時停止した会話を再開します。このイベントがトラッカーに追加されると、ボットはアクションの予測を再び開始します。会話が一時停止されている間に受信したユーザーメッセージのアクションは予測されません。

**自動追跡**:なし

**JSON**です。

```json
{
    "event": "resume"
}
```

**ラサクラス**: `rasa.core.events.ConversationResumed`

### `followup`

アクション予測をバイパスして、フォローアップアクションを強制します。

**自動追跡**:なし

**JSON**です。

```json
{
    "event": "followup",
    "name": "my_action"
}
```

**パラメータ**:

*   `name`: 実行されるフォローアップアクションの名前。

**ラサクラス**: `rasa.core.events.FollowupAction`

### `rewind`

最後のユーザーメッセージのすべての副作用を元に戻し、トラッカーから最後の`ユーザー`イベントを削除します。

**自動追跡**:

**JSON**です。

```json
{
    "event": "rewind"
}
```

**ラサクラス**: `rasa.core.events.UserUtteranceReverted`

### `undo`

最後のボットアクションのすべての副作用を元に戻し、最後のボットアクションをトラッカーから削除します。

**自動追跡**:

**JSON**です。

```json
{
    "event": "undo"
}
```

**ラサクラス**: `rasa.core.events.ActionReverted`

### `restart`

トラッカーをリセットします。`再起動`イベントの後、会話履歴や再起動の記録はなくなります。

**自動追跡**:

*   `/restart` 既定の意図がトリガーされたとき。

**JSON**です。

```json
{
    "event": "restart"
}
```

**Rasaクラス**:`rasa.core.events.Restarted`

### `session_started`

トラッカーをリセットし、デフォルトのアクション `ActionSessionStart` を実行して、新しい会話を開始します。このアクションは、デフォルトで既存の `SlotSet` イベントを新しい会話セッションに引き継ぎます。この動作は、`ドメインファイルの session_config` で設定できます。

**自動追跡**:

*   ユーザーがボットとの会話を初めて開始するたびに。
*   セッションの有効期限が切れて (ドメインで指定された`session_expiration_time`後)、ユーザーが会話を再開するたびに

[`restart`](#restart) イベントで会話を再開しても、`session_started` イベントは自動的に発生**しません**。

**JSON**です。

```json
{
    "event": "session_started"
}
```

**ラサクラス**: `rasa.core.events.SessionStarted`

### `user`

ユーザーはボットにメッセージを送信しました。

**自動追跡**:

*   ユーザーがボットにメッセージを送信するとき。

このイベントは通常、カスタム アクションによって返されません。

**JSON**です。

```json
{
    "event": "user",
    "text": "Hey",
    "parse_data": {
        "intent": {
            "name": "greet",
            "confidence": 0.9
        },
        "entities": []
    },
    "metadata": {},
}
```

**パラメータ**:

*   `text`: ユーザーメッセージのテキスト
*   `parse_data`: ユーザーメッセージの解析データ。これは通常、NLUによって埋められます。
*   `metadata`: ユーザーメッセージに付属する任意のメタデータ

**Rasaクラス**:`rasa.core.events.UserUttered`

### `bot`

ボットはユーザーにメッセージを送信しました。

**自動追跡**:

*   カスタムアクションによって`応答`が返されるたびに
*   カスタムアクション(`utter_アクション`など)によって返されずに応答が直接ユーザーに送信されるたびに

このイベントは通常、カスタム アクションによって明示的に返されません。代わりに`応答`が返されます。

**JSON**です。

```json
{
    "event": "bot",
    "text": "Hey there!",
    "data": {}
}
```

**パラメータ**:

*   `text`: ボットがユーザーに送信するテキスト
*   `data`: ボット応答のテキスト以外の要素。`データの`構造は、[API 仕様](https://github.com/RasaHQ/rasa/blob/main/pages/action-server-api)で指定された`応答`の構造と一致します。

**Rasaクラス**:`rasa.core.events.BotUttered`

### `action`

ボットによって呼び出されたアクションをログに記録します。アクション自体のみがログに記録されます。アクションによって作成されるイベントは、適用時に個別にログに記録されます。

**自動追跡**:

*   呼び出されるすべてのアクション (カスタム アクションと応答を含む) は、アクションが正常に実行されなくても使用されます。

通常、このイベントはカスタム アクションによって明示的に返されません。

**JSON**です。

```json
{
    "event": "action",
    "name": "my_action"
}
```

**パラメータ**:

*   `name`: 呼び出されたアクションの名前

**ラサクラス**: `rasa.core.events.ActionExecuted`