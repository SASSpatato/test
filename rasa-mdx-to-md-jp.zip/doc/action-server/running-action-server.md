---
id: running-action-server
sidebar_label: Running a Rasa SDK Server
title: Running a Rasa SDK Action Server
---

アクションサーバーを実行するには、次の 2 つの方法があります。 環境を使用している `RASA`のインストールの有無:

`rasa` がインストールされている場合は、`rasa` コマンドを使用してアクション・サーバーを実行できます。

```bash
rasa run actions
```

または、`SANIC_HOST` 環境変数を使用して、アシスタントに特定のアドレスをリッスンさせることもできます。

```bash
SANIC_HOST=192.168.69.150 rasa run actions
```

`rasa` がインストールされていない場合は、アクションサーバーを Python モジュールとして直接実行できます。

```bash
python -m rasa_sdk --actions actions
```

アクションサーバーをPythonモジュールとして直接実行すると、`SANIC_HOST`も可能になります。

```bash
SANIC_HOST=192.168.69.150 python -m rasa_sdk --actions actions
```

上記のコマンドを使用すると、`rasa_sdk という`ファイルでアクションを見つけることが期待されます actions.py または`actions`というパッケージディレクトリにあります。 別のアクションモジュールまたはパッケージを `--actions` フラグを使用します。

いずれかのコマンドでアクションサーバーを実行するためのオプションの完全なリストは次のとおりです。