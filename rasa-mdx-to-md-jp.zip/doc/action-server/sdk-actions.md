---
id: sdk-actions
sidebar_label: Actions
title: Actions
---

`Action` クラスは、カスタム アクションの基本クラスです。カスタムアクションを定義するには、`Action`クラスのサブクラスを作成し、`name`と`run`の2つの必須メソッドを上書きします。アクション・サーバーは、アクションの実行要求を受け取ると、`その name` メソッドの戻り値に従ってアクションを呼び出します。

スケルトンカスタムアクションは次のようになります。

```python
class MyCustomAction(Action):

    def name(self) -> Text:

        return "action_name"

    async def run(
        self, dispatcher, tracker: Tracker, domain: Dict[Text, Any],
    ) -> List[Dict[Text, Any]]:

        return []
```

## メソッド

### Action.name

アクションの名前を定義します。このメソッドによって返される名前は、ボットのドメインで使用される名前です。

*   **戻り値**:
    
    アクションの名前
    
*   **戻り値の型**:
    
    `str`
    

### アクション実行

```python
async Action.run(dispatcher, tracker, domain)
```

`run` メソッドは、アクションの副作用を実行します。

#### **パラメーター**

*   **ディスパッチャー** – に使用されるディスパッチャー ユーザーにメッセージを送り返します。使う `dispatcher.utter_message()` またはその他の `rasa_sdk.executor.CollectingDispatcher` 方式。[ディスパッチャーのドキュメント](sdk-dispatcher.md)を参照してください
    
*   **tracker** – 現在の状態トラッカー 利用者。スロット値には、 `tracker.get_slot(slot_name)` の場合、最新のユーザーメッセージは `tracker.latest_message.text` で、その他の `rasa_sdk。Tracker` プロパティ。[トラッカーのドキュメント](sdk-tracker.md)を参照してください。
    
*   **ドメイン** – ボットのドメイン
    

#### **収益**

`rasa_sdk.events.Event` インスタンスのリスト。[イベントについては、ドキュメント](sdk-events.md)を参照してください。

#### **戻り値の型**

  `List`[`Dict`[`str`, `Any`]]

## 例

レストラン ボットでは、ユーザーが "メキシコ料理レストランを見せてください" と言うと、ボットは次のようなアクション `ActionCheckRestaurants` を実行できます。

```python
from typing import Text, Dict, Any, List
from rasa_sdk import Action
from rasa_sdk.events import SlotSet

class ActionCheckRestaurants(Action):
   def name(self) -> Text:
      return "action_check_restaurants"

   def run(self,
           dispatcher: CollectingDispatcher,
           tracker: Tracker,
           domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

      cuisine = tracker.get_slot('cuisine')
      q = "select * from restaurants where cuisine='{0}' limit 1".format(cuisine)
      result = db.query(q)

      return [SlotSet("matches", result if result is not None else [])]
```

このアクションは、データベースにクエリを実行して、要求された料理に一致するレストランを検索し、見つかったレストランのリストを使用して`一致`スロットの値を設定します。