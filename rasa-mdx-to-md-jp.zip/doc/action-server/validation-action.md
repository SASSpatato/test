---
id: validation-action
sidebar_label: Slot Validation Actions
title: Slot Validation Actions
abstract: Learn how `ValidationAction` class is implemented in the Rasa SDK.
---

Rasa SDKには、カスタムスロットの抽出と検証を実行する役割を持つ2つのヘルパークラスがあります。

*   `ValidationAction`: フォームコンテキストの外部で設定または更新できるスロットを抽出および検証するカスタムアクションの基本クラス。
*   `FormValidationAction`: フォームのコンテキスト内でのみ設定されるスロットを抽出および検証するカスタム アクションの基本クラス。

カスタムスロット抽出および検証ロジックを実装するには、次のいずれかをサブクラス化するオプションがあります `ValidationAction` または `FormValidationAction` クラス (スロットを設定または更新するコンテキストによって異なります)。

## `ValidationAction` クラス

Rasa SDK の `ValidationAction` クラスを拡張して、フォームコンテキストの外部で設定または更新できるスロットのカスタム抽出および/または検証を定義できます。

> [!note] 
>  `ValidationAction` は、フォームのコンテキスト**外**のスロットを抽出することを目的としています。[[domain#マッピング条件|slot mapping's `conditions`]] で指定された形式を持つスロットの抽出メソッドと検証メソッドは無視されます。これらのメソッドは、指定されたフォームがアクティブな場合、またはアクティブなフォームがない場合には実行されません。[[validation-action#`FormValidationAction` クラス|`FormValidationAction`]] クラスを使用して、フォームのコンテキスト内でのみカスタム スロット マッピングを適用できます。

### `ValidationAction` をサブクラス化する方法

まず、このアクションの名前 `action_validate_slot_mappings` をドメイン `アクション` リストに追加する必要があります。name `メソッドは`既に実装されているため、`ValidationAction` を拡張するカスタムアクションに実装する必要はありません。`name` メソッドをオーバーライドすると、既定のアクションがアクション サーバーに対して行う呼び出しで元の名前がハードコードされているため、カスタム検証アクションは実行されません`action_extract_slots`。

ユースケースに応じて、異なるスロットのすべての抽出メソッドと検証メソッドを含む`ValidationAction`のサブクラスを1つだけ作成する必要があります。

このオプションでは、デフォルトのアクション[`action_extract_slots action_validate_slot_mappings`](../default-actions.md#action_extract_slots)実行されるため、[[domain#カスタムスロットマッピング|custom slot mapping]]で`アクション`キーを指定する必要はありません。 ドメインの `[アクション`] セクションに存在する場合は、自動的に。

#### 事前定義されたマッピングを使用したスロットの検証

事前定義されたマッピングを使用してスロットを検証するには、`validate_<slot_name>` という名前の関数を記述する必要があります。

次の例では、抽出された値が文字列型の場合にのみ、スロット`位置`の値が大文字になります。

```python
from typing import Text, Any, Dict

from rasa_sdk import Tracker, ValidationAction
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.types import DomainDict


class ValidatePredefinedSlots(ValidationAction):
    def validate_location(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: DomainDict,
    ) -> Dict[Text, Any]:
        """Validate location value."""
        if isinstance(slot_value, str):
            # validation succeeded, capitalize the value of the "location" slot
            return {"location": slot_value.capitalize()}
        else:
            # validation failed, set this slot to None
            return {"location": None}
```

#### カスタムスロットマッピングの抽出

カスタム抽出コードを定義するには、カスタムスロットマッピングを使用して、すべてのスロットに`extract_<slot_name>`メソッドを記述します。

次の例は、ユーザーの態度を追跡するためにスロット`count_of_insults`を抽出するカスタムアクションの実装を示しています。

```python
from typing import Dict, Text, Any

from rasa_sdk import Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import ValidationAction


class ValidateCustomSlotMappings(ValidationAction):
    async def extract_count_of_insults(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> Dict[Text, Any]:
        intent_of_last_user_message = tracker.get_intent_of_latest_message()
        current_count_of_insults = tracker.get_slot("count_of_insults")
        if intent_of_last_user_message == "insult":
           current_count_of_insults += 1

        return {"count_of_insults": current_count_of_insults}
```

### `ValidationAction` クラスの実装

`ValidationAction` は、`Action` Rasa SDK クラスと抽象 Python `ABC` クラスのサブクラスです。したがって、クラスは `Action` から継承された`名前`メソッドと`実行`メソッドを実装します。さらに、`ValidationAction` は、`run` メソッドで呼び出されるより特殊なメソッドを実装します。

*   `get_extraction_events`: 使用可能な`extract_<slot name>`メソッドを使用してカスタムスロットを抽出します。
*   `get_validation_events`: 各スロットに対して使用可能な `validate_<slot name>` メソッドを呼び出してスロットを検証します。
*   `required_slots`: 検証アクションが埋めるスロットを返します

#### メソッド

##### ValidationAction.name

アクションの名前を定義します。これは`action_validate_slot_mappings`としてハードコードする必要があります。

*   **戻り値**:
    
    アクションの名前
    
*   **戻り値の型**:
    
    `str`
    

##### ValidationAction.run を実行します。

```python
async ValidationAction.run(dispatcher, tracker, domain)
```

`run` メソッドは、`extract_<slot name>` メソッドで定義されたカスタム抽出コードを、 `get_extraction_events`メソッドを使用して、返されたイベントでトラッカーを更新します。run `メソッドは`、`validate_<slot name>` メソッドで定義されたカスタム検証コードも、 メソッド`get_validation_events`し、返されたイベントをトラッカーに追加します。

###### **パラメーター**

*   **ディスパッチャー** – に使用されるディスパッチャー ユーザーにメッセージを送り返します。使う `dispatcher.utter_message()` またはその他の `rasa_sdk.executor.CollectingDispatcher` 方式。[ディスパッチャーのドキュメント](./sdk-dispatcher.md)を参照してください
    
*   **tracker** – 現在の状態トラッカー 利用者。スロット値には、 `tracker.get_slot(slot_name)` の場合、最新のユーザーメッセージは `tracker.latest_message.text` で、その他の `rasa_sdk。Tracker` プロパティ。[トラッカーのドキュメント](./sdk-tracker.md)を参照してください。
    
*   **ドメイン** – ボットのドメイン
    

###### **収益**

`rasa_sdk.events.Event` インスタンスのリスト。[イベントについては、ドキュメント](./sdk-events.md)を参照してください。

###### **戻り値の型**

  `List`[`Dict`[`str`, `Any`]]

##### ValidationAction.required_slots

```python
async ValidationAction.required_slots(domain_slots, dispatcher, tracker, domain)
```

`required_slots`メソッドは、条件付きのスロットマッピングを含まないドメインにマップされたすべてのスロット名のリストである`domain_slots`を返します。`domain_slots` は `domain_slots` メソッドによって返され、 引数としての`ドメイン`。

###### **収益**

`テキスト`型のスロット名のリスト。

##### ValidationAction.get_extraction_events

```python
async ValidationAction.get_extraction_events(dispatcher, tracker, domain)
```

`get_extraction_events`メソッドは、メソッド呼び出しを介してスロット名のリストを収集し`required_slots`すべてのスロット名をループして、使用可能な場合は`extract_<slot name>`メソッドを実行します。

##### **収益**

`rasa_sdk.events.SlotSet` インスタンスのリスト。[SlotSet イベントのドキュメント](./sdk-events.md#スロットセット)を参照してください。

##### ValidationAction.get_validation_events

```python
async ValidationAction.get_validation_events(dispatcher, tracker, domain)
```

`get_validation_events`メソッドは、メソッド呼び出しを介して検証するスロット名のリスト`required_slots`収集します。次に、最近設定されたスロットとその値のマッピング`tracker.slots_to_validate`呼び出しを介して取得されます。最近抽出されたスロットのこのマッピングをループして、スロットが`required_slots`にあるかどうかを確認し、 `validate_<スロット名>` メソッド (そのスロットで使用可能な場合)。

###### **収益**

`rasa_sdk.events.SlotSet` インスタンスのリスト。[SlotSet イベントのドキュメント](./sdk-events.md#スロットセット)を参照してください。

## `FormValidationAction` クラス

`FormValidationAction` カスタム アクションは、名前で指定したフォームがアクティブになっている場合にのみ実行されます。特定のカスタムスロットマッピングをフォームのコンテキスト内でのみ抽出および/または検証する必要がある場合、カスタムアクションは`ValidationAction`ではなく`FormValidationAction`から継承する必要があります。

`FormValidationAction` を拡張するカスタム アクションは、フォームがアクティブな間のみ、ユーザー ターンごとに実行されるため、この場合、マッピング条件を使用する必要はありません。

このクラスの実装方法の詳細については、Forms [[forms#高度な使用法|高度な使用法]]。

### `FormValidationAction` クラスの実装

`FormValidationAction` は、`ValidationAction` Rasa SDK クラスと抽象 Python `ABC` クラスのサブクラスです。 `FormValidationAction` は、ほとんどのメソッドを `ValidationAction` クラスから継承しますが、`名前`と メソッド`domain_slots`、新しいメソッド`next_requested_slot`を実装し、`run` メソッドの実装を拡張します。

#### メソッド

##### FormValidationAction.name

ボットのカスタムアクションが`FormValidationAction`をサブクラス化する場合、メソッド`名`は`NotImplementedError`例外を発生させます は、`validate_<form name>` という命名規則に従うカスタム名を返しません。

##### FormValidationAction.required_slots

メソッド `required_slots` は、フォームに含まれるすべてのスロット名のリストである`domain_slots`を返します。 `required_slots`。`domain_slots`は、`domain_slots`メソッドによって返され、 引数としての`ドメイン`。

##### FormValidationAction.next_requested_slot

メソッド`next_requested_slot`は、次の未設定スロットに `REQUESTED_SLOT` の値を設定します。 `required_slots`メソッドは、カスタム アクションのサブクラス`化 FormValidationAction` によってオーバーライドされました。

ユーザーが`required_slots`をオーバーライドしなかった場合は、Rasa Open Source内の`FormAction`に次のスロットをリクエストさせ、メソッドは`None`を返します。

メソッドに必要なパラメータは次のとおりです。

*   [ディスパッチャ](./sdk-dispatcher.md)
*   [sdk-tracker](./sdk-tracker.md)
*   ボットのドメイン

##### FormValidationAction.runを実行します。

`ValidationAction.run` メソッドの元の実装は、 `next_requested_slot` への呼び出しを追加するために拡張されています 方式。`next_requested_slot`メソッド呼び出しの出力 (`None` でない場合) は、`実行`されるイベントのリストに追加されます メソッドが戻ります。