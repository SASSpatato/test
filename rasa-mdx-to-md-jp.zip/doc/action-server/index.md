---
slug: /action-server
sidebar_label: Introduction
title: Introduction to Rasa Action Server
---

Rasa アクション・サーバーは、Rasa Open Source 会話型アシスタントの[カスタム・アクション](../custom-actions.md)を実行します。

## 仕組み

アシスタントがカスタム・アクションを予測すると、Rasa サーバーは、予測されたアクションの名前、会話 ID、トラッカーの内容、およびドメインの内容を含む json ペイロードを含む `POST` 要求をアクション・サーバーに送信します。

アクションサーバーは、カスタムアクションの実行を終了すると、[応答](../responses.md)と[イベント](./events.md)のjsonペイロードを返します。リクエストとレスポンスのペイロードの詳細については、[API 仕様](https://github.com/RasaHQ/rasa/blob/main/pages/action-server-api)を参照してください。

次に、Rasa サーバーは応答をユーザーに返し、イベントを会話トラッカーに追加します。

## カスタムアクション用のSDK

任意の言語で記述されたアクションサーバーを使用して、[必要な API](https://github.com/RasaHQ/rasa/blob/main/pages/action-server-api) を実装している限り、カスタムアクションを実行できます。

### Rasa SDK (Python)

Rasa SDKは、カスタムアクションを実行するためのPython SDKです。必要な API を実装するだけでなく、会話トラッカーと対話し、イベントと応答を作成するためのメソッドを提供します。アクションサーバーをまだ持っておらず、Python以外の言語で行う必要がない場合は、Rasa SDKを使用するのが最も簡単な方法です。

### その他のアクションサーバー

別の言語のレガシーコードまたは既存のビジネスロジックがある場合は、Rasa SDKを使用しない場合があります。この場合、任意の言語で独自のアクションサーバーを作成できます。アクションサーバーの唯一の要件は、RasaサーバーからのHTTP `POST`リクエストを受け入れ、[イベント](./events.md)と応答のペイロードを返す/`webhook`エンドポイントを提供することです。必要な `/webhook` エンドポイントの詳細については、[API 仕様](https://github.com/RasaHQ/rasa/blob/main/pages/action-server-api)を参照してください。