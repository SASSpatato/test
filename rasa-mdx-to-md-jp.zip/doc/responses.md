---
id: responses
sidebar_label: Responses
title: Responses
abstract: Responses are messages that your assistant sends to the user. A response is usually only text, but can also include content like images and buttons.
---

## 応答の定義

応答は、ドメイン ファイルまたは別の「responses.yml」ファイルの`応答`キーの下に配置されます。各応答名は `utter_` で始まる必要があります。たとえば、挨拶と別れの応答を`utter_greet`と`utter_bye`の応答名の下に追加できます。

```yaml-rasa
intents:
  - greet

responses:
  utter_greet:
  - text: "Hi there!"
  utter_bye:
  - text: "See you!"
```

アシスタントで [[glossary.md#[取得インテント](./chitchat-faqs.md)|取得インテント]] を使用している場合は、これらのインテントに対するアシスタントの応答の応答も追加する必要があります。

```yaml-rasa
intents:
  - chitchat

responses:
  utter_chitchat/ask_name:
  - text: Oh yeah, I am called the retrieval bot.

  utter_chitchat/ask_weather:
  - text: Oh, it does look sunny right now in Berlin.
```

> [!note] 
> 検索インテントの応答名の特殊な形式に注意してください。各名前は`utter_`で始まり、その後に検索インテントの名前(ここでは`chitchat`)、最後にさまざまな応答キーを指定するサフィックス(ここでは`ask_name`と`ask_weather`)が続きます。詳細については、[[./training-data-format.md#トレーニング例|NLU トレーニング例のドキュメント]] を参照してください。

### 応答での変数の使用

変数を使用して、応答に情報を挿入できます。応答内では、変数は中括弧で囲まれます。たとえば、以下の変数`名`を参照してください。

```yaml-rasa
responses:
  utter_greet:
  - text: "Hey, {name}. How are you?"
```

`utter_greet`応答を使用すると、Rasa は `name` というスロットで見つかった値を変数に自動的に入力します。そのようなスロットが存在しないか空の場合、変数は `None` で埋められます。

変数を入力する別の方法は、[カスタムアクション](./custom-actions.md)内です。カスタムアクションコードでは、特定の変数を入力するために応答に値を指定できます。アクションサーバーにRasa SDKを使用している場合は、変数の値をキーワード引数として渡すことができます[`dispatcher.utter_message`](./action-server/sdk-dispatcher.md)。

```python
dispatcher.utter_message(
    template="utter_greet",
    name="Sara"
)
```

[[./action-server/index.md#その他のアクションサーバー|different custom action server]] を使用する場合は、サーバーが返す応答にパラメーターを追加して値を指定します。

```json
{
  "events":[
    ...
  ],
  "responses":[
    {
      "template":"utter_greet",
      "name":"Sara"
    }
  ]
}
```

### 応答の変動

特定の応答名に対して選択できる複数の応答バリエーションを指定すると、アシスタントの応答をより興味深いものにすることができます。

```yaml-rasa
responses:
  utter_greet:
  - text: "Hey, {name}. How are you?"
  - text: "Hey, {name}. How is your day going?"
```

この例では、次のアクションとして予測されると、`utter_greet` は 2 つの応答バリエーションから 1 つをランダムに選択して使用します。

#### 応答の ID

> [!NOTE] Rasa 3.6 の新機能 
> 任意の応答に ID を設定できるようになりました。これは、[NLG サーバー](./nlg.md)を使用して応答を生成する場合に便利です。
> 
> ID の型は文字列です。

ID を使用した応答の変動の例:

```yaml-rasa
responses:
  utter_greet:
  - id: "greet_1"
    text: "Hey, {name}. How are you?"
  - id: "greet_2"
    text: "Hey, {name}. How is your day going?"
```

### チャネル固有の応答変動

ユーザーが接続しているチャネルに応じて異なる応答バリエーションを指定するには、チャネル固有の応答バリエーションを使用します。

次の例では、`チャネル`キーは、最初の応答バリエーションを`スラック`チャネルのチャネル固有にし、2番目のバリエーションをチャネル固有ではありません。

```yaml-rasa
responses:
  utter_ask_game:
  - text: "Which game would you like to play on Slack?"
    channel: "slack"
  - text: "Which game would you like to play?"
```

> [!note] 
> `チャンネル`キーの値が、入力チャンネルの`name()`メソッドによって返される値と一致していることを確認してください。組み込みチャネルを使用している場合、この値は`credentials.yml`ファイルで使用されているチャネル名とも一致します。

アシスタントは、特定の応答名で適切な応答バリエーションを検索すると、最初に現在のチャネルのチャネル固有のバリエーションから選択しようとします。そのようなバリエーションがない場合、アシスタントはチャネル固有ではない応答バリエーションから選択します。

上記の例では、2 番目の応答バリエーションには`チャネル`が指定されておらず、アシスタントは `slack` 以外のすべてのチャネルに使用できます。

> [!caution]
> 応答ごとに、`チャネル`キーなしで少なくとも 1 つの応答バリエーションを使用するようにしてください。これにより、アシスタントは、新しいチャネル、シェル、対話式学習など、すべての環境で適切に応答できます。

### 条件付き応答の変動

条件付き応答変動を使用して、1 つ以上のスロット値に基づいて特定の応答変動を選択することもできます。条件付き応答のバリエーションは、標準の応答バリエーションと同様にドメインまたは応答 YAML ファイルで定義されますが、`追加の条件`キーがあります。このキーは、スロット`名`と`値`の制約のリストを指定します。

対話中に応答がトリガーされると、各条件付き応答バリエーションの制約が現在の対話状態に対してチェックされます。すべての制約スロット値が現在の対話状態の対応するスロット値と等しい場合、応答バリエーションは会話アシスタントによって使用されます。

> [!note] 
> ダイアログ状態スロット値と制約スロット値の比較は、スロット値のタイプも一致させる必要がある等価 "==" 演算子によって実行されます。たとえば、制約が `value: true` として指定されている場合、スロットは文字列 `"true"` ではなくブール値 `true` で埋める必要があります。

次の例では、`logged_in`スロットが`true`に設定される1つの制約を持つ1つの条件付き応答バリエーションを定義します。

```yaml-rasa
slots:
  logged_in:
    type: bool
    influence_conversation: False
    mappings:
    - type: custom
  name:
    type: text
    influence_conversation: False
    mappings:
    - type: custom

responses:
  utter_greet:
    - condition:
        - type: slot
          name: logged_in
          value: true
      text: "Hey, {name}. Nice to see you again! How are you?"

    - text: "Welcome. How is your day going?"
```

```yaml-rasa
stories:
- story: greet
  steps:
  - action: action_log_in
  - slot_was_set:
    - logged_in: true
  - intent: greet
  - action: utter_greet
```

上記の例では、`utter_greet`アクションが実行され、`logged_in`スロットが`true`に設定されているときはいつでも、最初の応答バリエーション( `"Hey, {name}. Nice to see you again! How are you?"` )が使用されます。条件のない 2 番目のバリエーションはデフォルトとして扱われ、`logged_in` が `true` と等しくない場合に使用されます。

> [!caution]
> 条件付き応答が満たされたスロットに一致しない場合を防ぐために、条件なしでデフォルトの応答バリエーションを常に提供することを強くお勧めします。

対話中、Rasa は制約が満たされるすべての条件付き応答バリエーションから選択します。適格な条件付き応答のバリエーションが複数ある場合、Rasa はランダムに 1 つを選択します。たとえば、次の応答について考えてみましょう。

```yaml-rasa
responses:
  utter_greet:
    - condition:
        - type: slot
          name: logged_in
          value: true
      text: "Hey, {name}. Nice to see you again! How are you?"

    - condition:
        - type: slot
          name: eligible_for_upgrade
          value: true
      text: "Welcome, {name}. Did you know you are eligible for a free upgrade?"

    - text: "Welcome. How is your day going?"
```

`logged_in`と`eligible_for_upgrade`の両方が`true`に設定されている場合、1番目と2番目の応答バリエーションの両方が使用でき、会話アシスタントによって同じ確率で選択されます。

以下の例に示すように、チャネル固有の応答バリエーションを条件付き応答バリエーションと一緒に引き続き使用できます。

```yaml-rasa
slots:
  logged_in:
    type: bool
    influence_conversation: False
    mappings:
    - type: custom
  name:
    type: text
    influence_conversation: False
    mappings:
    - type: custom

responses:
  utter_greet:
    - condition:
        - type: slot
          name: logged_in
          value: true
      text: "Hey, {name}. Nice to see you again on Slack! How are you?"
      channel: slack

    - text: "Welcome. How is your day going?"
```

Rasa は、次の順序で回答の選択に優先順位を付けます。

1.  チャネルが一致する条件付き応答の変動
2.  一致するチャネルを持つデフォルトの応答
3.  一致するチャネルのない条件付き応答の変動
4.  一致するチャネルのないデフォルトの応答

## 豊富な回答

視覚的要素とインタラクティブな要素を追加することで、応答を豊かにすることができます。多くのチャネルでサポートされている要素には、いくつかのタイプがあります。

### ボタン

ボタンを使用する応答の例を次に示します。

```yaml-rasa
responses:
  utter_greet:
  - text: "Hey! How are you?"
    buttons:
    - title: "great"
      payload: "/mood_great"
    - title: "super sad"
      payload: "/mood_sad"
```

ボタンのリスト内の各ボタン`には`、次の 2 つのキーが必要です。

*   `title`: ユーザーに表示されるボタンに表示されるテキスト。
*   `ペイロード`: ボタンがクリックされたときにユーザーからアシスタントに送信されるメッセージ。

ボタンでエンティティもアシスタントに渡す場合は、次のようにします。

```yaml-rasa
responses:
  utter_greet:
  - text: "Hey! Would you like to purchase motor or home insurance?"
    buttons:
    - title: "Motor insurance"
      payload: '/inform{{"insurance":"motor"}}'
    - title: "Home insurance"
      payload: '/inform{{"insurance":"home"}}'
```

複数のエンティティを渡すこともできます。

```
'/intent_name{{"entity_type_1":"entity_value_1", "entity_type_2": "entity_value_2"}}'
```

> [!NOTE] ボタンで nlu を上書きする
> ボタンを使用して、NLU 予測を上書きし、特定のインテントとエンティティをトリガーできます。
> 
> `/` で始まるメッセージは、 `RegexInterpreter` は、短縮された `/intent{entities}` 形式での NLU 入力を想定しています。上記の例では、ユーザーがボタンをクリックすると、ユーザー入力は`mood_great`インテントまたは`mood_sad`インテントとして分類されます。
> 
> 次の形式を使用して、`RegexInterpreter` に渡す意図を持つエンティティを含めることができます。
> 
> `/inform{"ORG":"Rasa", "GPE":"Germany"}`
> 
> `RegexInterpreter`は、上記のメッセージをインテント`通知`で分類し、エンティティを抽出します `Rasa` と `Germany` は、それぞれタイプ `ORG` と `GPE` です。

> [!note] domain.ymlで中括弧をエスケープする 
> `/intent{entities}` 短縮形の応答を domain.yml で二重中括弧で記述して、アシスタントが [[#応答での変数の使用]] として扱わないようにし、中括弧内の内容を補間する必要があります。

> [!caution] チャンネルを確認する 
> 出力の実装次第であることに注意してください 定義されたボタンを表示する方法をチャネル化します。たとえば、一部の チャンネルの数に制限があります 提供できるボタン。チャンネルのドキュメントを **概念 > チャネル コネクタ** チャネル固有の制限。

### 画像

画像キーの下に画像への URL を指定することで、応答に画像を追加できます。

```yaml-rasa
  utter_cheer_up:
  - text: "Here is something to cheer you up:"
    image: "https://i.imgur.com/nGF1K8f.jpg"
```

### カスタム出力ペイロード

任意の出力を出力チャネルに送信するには、 `カスタム`キー。出力チャネルは、`カスタム`キーの下に格納されているオブジェクトをJSONペイロードとして受信します。

日付[ピッカー](https://api.slack.com/reference/block-kit/block-elements#datepicker)を [Slack 出力チャネル](connectors/slack.md)に送信する方法の例を次に示します。

```yaml-rasa
responses:
  utter_take_bet:
  - custom:
      blocks:
      - type: section
        text:
          text: "Make a bet on when the world will end:"
          type: mrkdwn
        accessory:
          type: datepicker
          initial_date: '2019-05-21'
          placeholder:
            type: plain_text
            text: Select a date
```

## 会話での応答の使用

### アクションとしての応答の呼び出し

応答の名前が`utter_`で始まる場合、ドメインの`アクション` セクションに表示されなくても、応答をアクションとして直接使用できます。ドメインに応答を追加します。

```yaml-rasa
responses:
  utter_greet:
  - text: "Hey! How are you?"
```

同じ応答をストーリーのアクションとして使用できます。

```yaml-rasa
stories:
- story: greet user
  steps:
  - intent: greet
  - action: utter_greet
```

`utter_greet` アクションが実行されると、応答からのメッセージがユーザーに送り返されます。

> [![注] 応答の変更
> テキストまたは応答の他の部分を変更する場合は、これらの変更が取得される前にアシスタントを再トレーニングする必要があります。

### カスタムアクションからの応答の呼び出し

レスポンスを使用して、カスタムアクションからレスポンスメッセージを生成できます。Rasa SDKをアクションサーバーとして使用している場合は、ディスパッチャーを使用して、次のようなレスポンスメッセージを生成できます。

```python
from rasa_sdk.interfaces import Action

class ActionGreet(Action):
    def name(self):
        return 'action_greet'

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(template="utter_greet")
        return []
```

[[./action-server/index.md#その他のアクションサーバー|different custom action server]] を使用する場合、サーバーは次の JSON を返して `utter_greet` 応答を呼び出す必要があります。

```json
{
  "events":[],
  "responses":[
    {
      "template":"utter_greet"
    }
  ]
}
```