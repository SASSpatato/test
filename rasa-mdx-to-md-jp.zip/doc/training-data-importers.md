---
id: training-data-importers
sidebar_label: Importers
title: Training Data Importers
description: Change the way Rasa imports training data by replacing the default importer or writing your own importer.
abstract: Rasa has built-in logic to collect and load training data written in Rasa format, but
  you can also customize how your training data gets imported using custom training data importers.
---

[`--data` コマンドライン引数](command-line-interface.md)を使用すると、Rasa がディスク上のトレーニングデータを検索する場所を指定できます。次に、Rasa は潜在的なトレーニング・ファイルをロードし、それらを使用してアシスタントをトレーニングします。

必要に応じて、Rasa がトレーニングデータをインポートする方法をカスタマイズすることもできます。この潜在的な使用例は次のとおりです。

*   カスタムパーサーを使用して他の形式のトレーニングデータを読み込む
    
*   トレーニングデータを収集するためにさまざまなアプローチを使用する(例:異なるリソースから読み込む)
    

[[#カスタムインポーターの作成|カスタムインポーターを作成]]し、セクションを追加することでRasaにそれを使用するように指示できます `importers` を構成ファイルに追加し、インポーターを完全なクラス パスで指定します。

```yaml-rasa
importers:
- name: "module.CustomImporter"
  parameter1: "value"
  parameter2: "value2"
- name: "RasaFileImporter"
```

`名前`キーは、ロードするインポーターを決定するために使用されます。余分なパラメータは、ロードされたインポーターにコンストラクター引数として渡されます。

> [!NOTE] 
> `TrainingDataImporter` とそのサブクラスには、Rasa 3.0 以降の非同期メソッドは含まれていません。カスタムインポーターを移行して Rasa 3.0 で動作させるには、非同期メソッドを同期メソッドに置き換える必要もあります。詳細は [[migration-guide.md#Rasa 2.x から 3.0 へ|migration guide]] を参照してください。

> [!TIP]
> 複数のインポーターを指定できます。Rasaは結果を自動的にマージします。

## RasaFileImporter (デフォルト)

デフォルトでは、Rasaはインポー`ターRasaFileImporter`を使用します。単独で使用する場合は、構成ファイルで何も指定する必要はありません。他のインポーターと一緒に使用する場合は、構成ファイルに追加します。

```yaml-rasa
importers:
- name: "module.CustomImporter"
  parameter1: "value"
  parameter2: "value2"
- name: "RasaFileImporter"
```

## MultiProjectImporter (実験的)

> [!NOTE] 1.3 の新機能
> この機能は現在実験段階であり、将来的に変更または削除される可能性があります。[フォーラム](https://forum.rasa.com)でフィードバックを共有して、この機能を本番環境に準備する準備に役立ててください。

このインポーターを使用すると、複数の再利用可能な Rasa プロジェクトを組み合わせてモデルをトレーニングできます。たとえば、あるプロジェクトで雑談を処理し、別のプロジェクトでユーザーに挨拶することができます。これらのプロジェクトは単独で開発し、アシスタントをトレーニングするときに組み合わせることができます。

たとえば、次のディレクトリ構造について考えてみましょう。

```bash
.
├── config.yml
└── projects
    ├── GreetBot
    │   ├── data
    │   │   ├── nlu.yml
    │   │   └── stories.yml
    │   └── domain.yml
    └── ChitchatBot
        ├── config.yml
        ├── data
        │   ├── nlu.yml
        │   └── stories.yml
        └── domain.yml
```

ここで、コンテキスト AI アシスタントは `ChitchatBot` プロジェクトをインポートし、次に `GreetBot` プロジェクトをインポートします。プロジェクトのインポートは、各プロジェクトの構成ファイルで定義されます。

`MultiProjectImporter` モジュールを使用するように Rasa に指示するには、ルート`config.yml`の`インポーター`リストに追加する必要があります。

```yaml-rasa
importers:
- name: MultiProjectImporter
```

次に、同じファイルで、インポートリストに追加して、インポートするプロジェクトを指定します。

```yaml-rasa
imports:
- projects/ChitchatBot
```

`ChitchatBot` の設定ファイルは `GreetBot` を参照する必要があります。

```yaml-rasa
imports:
- ../GreetBot
```

`GreetBot` プロジェクトはインポートするプロジェクトを指定しないため、`config.yml`は必要ありません。

Rasaは、構成ファイルからの相対パスを使用してプロジェクトをインポートします。これらは、ファイル アクセスが許可されているファイル システム上の任意の場所に配置できます。

トレーニングプロセス中に、Rasaは必要なすべてのトレーニングファイルをインポートし、それらを組み合わせて、統合されたAIアシスタントをトレーニングします。トレーニング データは実行時にマージされるため、追加のトレーニング データ ファイルは作成されません。

> [!caution] ポリシーと NLU パイプライン
> Rasaは、トレーニング中にルートプロジェクトディレクトリのポリシーとNLUパイプライン構成を使用します。**インポートされたプロジェクトのポリシーおよび NLU 構成は無視されます。**

> [!caution] マージに注意してください 
> インテント、エンティティ、スロット、応答、アクション、フォームはマージされます (たとえば、2 つのプロジェクトがインテント `グリート`のトレーニング データを持っている場合、それらのトレーニング データは結合されます)。

## カスタムインポーターの作成

カスタムインポーターを作成している場合、このインポーターは [`TrainingDataImporter`](reference/rasa/shared/importers/importer.md#trainingdataimporter-objects)です。

```python
from typing import Optional, Text, Dict, List, Union

import rasa
from rasa.shared.core.domain import Domain
from rasa.shared.nlu.interpreter import RegexInterpreter
from rasa.shared.core.training_data.structures import StoryGraph
from rasa.shared.importers.importer import TrainingDataImporter
from rasa.shared.nlu.training_data.training_data import TrainingData


class MyImporter(TrainingDataImporter):
    """Example implementation of a custom importer component."""

    def __init__(
        self,
        config_file: Optional[Text] = None,
        domain_path: Optional[Text] = None,
        training_data_paths: Optional[Union[List[Text], Text]] = None,
        **kwargs: Dict
    ):
        """Constructor of your custom file importer.

        Args:
            config_file: Path to configuration file from command line arguments.
            domain_path: Path to domain file from command line arguments.
            training_data_paths: Path to training files from command line arguments.
            **kwargs: Extra parameters passed through configuration in configuration file.
        """

        pass

    def get_domain(self) -> Domain:
        path_to_domain_file = self._custom_get_domain_file()
        return Domain.load(path_to_domain_file)

    def _custom_get_domain_file(self) -> Text:
        pass

    def get_stories(
        self,
        interpreter: "NaturalLanguageInterpreter" = RegexInterpreter(),
        exclusion_percentage: Optional[int] = None,
    ) -> StoryGraph:
        from rasa.shared.core.training_data.story_reader.yaml_story_reader import (
            YAMLStoryReader,
        )

        path_to_stories = self._custom_get_story_file()
        return YAMLStoryReader.read_from_file(path_to_stories, self.get_domain())

    def _custom_get_story_file(self) -> Text:
        pass

    def get_config(self) -> Dict:
        path_to_config = self._custom_get_config_file()
        return rasa.utils.io.read_config_file(path_to_config)

    def _custom_get_config_file(self) -> Text:
        pass

    def get_nlu_data(self, language: Optional[Text] = "en") -> TrainingData:
        from rasa.shared.nlu.training_data import loading

        path_to_nlu_file = self._custom_get_nlu_file()
        return loading.load_data(path_to_nlu_file)

    def _custom_get_nlu_file(self) -> Text:
        pass
```