<?php

namespace Drupal\drupal_kafka\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

class KafkaSettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'drupal_kafka.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'drupal_kafka_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // 读取现有的配置
    $config = $this->config('drupal_kafka.settings');

    $form['broker_address'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Kafka Broker Address'),
      '#description' => $this->t('E.g. host.docker.internal:9092'),
      '#default_value' => $config->get('broker_address') ?? 'host.docker.internal:9092',
      '#required' => TRUE,
    ];

    $form['topic'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Topic Name'),
      '#description' => $this->t('The Kafka topic to subscribe to.'),
      '#default_value' => $config->get('topic'),
      '#required' => TRUE,
    ];

    $form['group_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Consumer Group ID'),
      '#default_value' => $config->get('group_id') ?? 'drupal_kafka_consumer_v1',
      '#required' => TRUE,
    ];

    $form['content_type'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Target Content Type'),
      '#description' => $this->t('The machine name of the content type (e.g. article, page, student).'),
      '#default_value' => $config->get('content_type') ?? 'page',
      '#required' => TRUE,
    ];

    $form['auto_offset_reset'] = [
      '#type' => 'select',
      '#title' => $this->t('Auto Offset Reset'),
      '#options' => [
        'latest' => $this->t('Latest (Only new messages)'),
        'earliest' => $this->t('Earliest (Read from beginning)'),
      ],
      '#default_value' => $config->get('auto_offset_reset') ?? 'earliest',
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // 保存配置
    $this->config('drupal_kafka.settings')
      ->set('broker_address', $form_state->getValue('broker_address'))
      ->set('topic', $form_state->getValue('topic'))
      ->set('group_id', $form_state->getValue('group_id'))
      ->set('content_type', $form_state->getValue('content_type'))
      ->set('auto_offset_reset', $form_state->getValue('auto_offset_reset'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}