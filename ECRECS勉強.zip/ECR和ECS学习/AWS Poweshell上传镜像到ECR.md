
安装:

打开powershell

1.
```
`PS >` `Install-Module -Name AWS.Tools.Installer`
```

2.
更改策略

```
Get-ExecutionPolicy

Set-ExecutionPolicy RemoteSigned

```

3.
安装对应模块

```
Install-AWSToolsModule AWS.Tools.EC2,AWS.Tools.S3 -CleanUp
Install-AWSToolsModule AWS.Tools.ECR -CleanUp
```




上传镜像:

1 打tag
```
docker tag java_test_hello:latest 700335172932.dkr.ecr.us-east-1.amazonaws.com/study/java:latest
```


1.5 身份认证：

先到iam 中 创建 密钥，记录下id 和 key


然后到 ps 中 执行如下命令

![[Pasted image 20251028172726.png]]



(Get-ECRLoginCommand).Password | docker login --username AWS --password-stdin aws_account_id.dkr.ecr.region.amazonaws.com

```
(Get-ECRLoginCommand).Password | docker login --username AWS --password-stdin 700335172932.dkr.ecr.us-east-1.amazonaws.com
```







2 上传

```
docker push 700335172932.dkr.ecr.us-east-1.amazonaws.com/study/java:latest
```

