---
id: sdk_changelog
sidebar_label: Rasa SDK Change Log
title: Rasa SDK Change Log
---

The Rasa SDK changelog can be found in the [Rasa SDK repository](https://github.com/RasaHQ/rasa-sdk/blob/main/CHANGELOG.mdx)