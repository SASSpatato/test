/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.flowable.ui.idm.conf;

import org.flowable.idm.api.IdmIdentityService;
import org.flowable.ui.common.properties.FlowableRestAppProperties;
import org.flowable.ui.common.security.ApiHttpSecurityCustomizer;
import org.flowable.ui.common.security.DefaultPrivileges;
import org.flowable.ui.common.security.SecurityConstants;
import org.flowable.ui.idm.properties.FlowableIdmAppProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.servlet.util.matcher.MvcRequestMatcher;
import org.springframework.web.servlet.handler.HandlerMappingIntrospector;

/**
 * Based on http://docs.spring.io/spring-security/site/docs/3.2.x/reference/htmlsingle/#multiple-httpsecurity
 *
 * @author Joram Barrez
 * @author Tijs Rademakers
 * @author Filip Hrisafov
 */
@Configuration(proxyBeanMethods = false)
@EnableGlobalMethodSecurity(prePostEnabled = true, jsr250Enabled = true)
public class IdmSecurityConfiguration {

    //
    // GLOBAL CONFIG
    //

    @Autowired
    protected IdmIdentityService identityService;
    
    @Autowired
    protected FlowableIdmAppProperties idmAppProperties;
    
    @Bean
    public org.flowable.ui.idm.security.UserDetailsService userDetailsService() {
        org.flowable.ui.idm.security.UserDetailsService userDetailsService = new org.flowable.ui.idm.security.UserDetailsService();
        userDetailsService.setUserValidityPeriod(idmAppProperties.getSecurity().getUserValidityPeriod());
        return userDetailsService;
    }

    //
    // BASIC AUTH
    //
    @EnableWebSecurity
    @Configuration
    @Order(SecurityConstants.IDM_API_SECURITY_ORDER)
    public static class IdmApiWebSecurityConfigurationAdapter {

        protected final FlowableRestAppProperties restAppProperties;
        protected final FlowableIdmAppProperties idmAppProperties;
        protected final ApiHttpSecurityCustomizer apiHttpSecurityCustomizer;

        public IdmApiWebSecurityConfigurationAdapter(FlowableRestAppProperties restAppProperties,
                FlowableIdmAppProperties idmAppProperties, ApiHttpSecurityCustomizer apiHttpSecurityCustomizer) {
            this.restAppProperties = restAppProperties;
            this.idmAppProperties = idmAppProperties;
            this.apiHttpSecurityCustomizer = apiHttpSecurityCustomizer;
        }

        @Bean
        protected SecurityFilterChain idmSecurityChain(HttpSecurity http, HandlerMappingIntrospector introspector) throws Exception {
        	
        	// create MvcRequestMatcher 
            MvcRequestMatcher.Builder mvcMatcherBuilder = new MvcRequestMatcher.Builder(introspector);

            http
                    .sessionManagement()
                    .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                    .and()
                    .csrf()
                    .disable();

            if (idmAppProperties.isRestEnabled()) {
            	// 使用 MvcRequestMatcher 来限定这个 HttpSecurity 配置只应用于 DispatcherServlet 处理的 /api/idm/** 路径
                http.securityMatcher(mvcMatcherBuilder.pattern("/api/idm/**"));

                if (restAppProperties.isVerifyRestApiPrivilege()) {
//                    http.antMatcher("/api/idm/**").authorizeRequests().antMatchers("/api/idm/**").hasAuthority(DefaultPrivileges.ACCESS_REST_API);
                	http
//                    .securityMatcher("/api/idm/**")     //  替代 antMatcher()，作用相同
                    .authorizeHttpRequests(auth -> auth  // 
                    	.requestMatchers(mvcMatcherBuilder.pattern("/api/idm/**")) // 明确使用 MvcRequestMatcher
                        .hasAuthority(DefaultPrivileges.ACCESS_REST_API)
                    );
                } else {
//                    http.antMatcher("/api/idm/**").authorizeRequests().antMatchers("/api/idm/**").authenticated();
                	http
//                    .securityMatcher("/api/idm/**")  // 替代 antMatcher()
                    .authorizeHttpRequests(auth -> auth
                    	.requestMatchers(mvcMatcherBuilder.pattern("/api/idm/**")) // 明确使用 MvcRequestMatcher
                        .authenticated()  
                    );
                    
                }

                apiHttpSecurityCustomizer.customize(http);
                
            } else {
//                http.antMatcher("/api/idm/**").authorizeRequests().antMatchers("/api/idm/**").denyAll();
            	http.securityMatcher(mvcMatcherBuilder.pattern("/api/idm/**"));
            	http
            	.authorizeHttpRequests(auth -> auth
            			.requestMatchers(mvcMatcherBuilder.pattern("/api/idm/**")) // 明确使用 MvcRequestMatcher
            			.denyAll());
                
            }
            return http.build();
            
        }
    }
}
