import re
from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker, FormValidationAction
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.types import DomainDict

class ValidateTransferMoneyForm(FormValidationAction):
    """这个类将处理转账表单的所有自定义逻辑。"""

    def name(self) -> Text:
        """为这个验证动作提供一个唯一的名称。"""
        return "validate_transfer_money_form"

    async def required_slots(  
        self,
        domain_slots: List[Text],
        dispatcher: "CollectingDispatcher",
        tracker: "Tracker",
        domain: "DomainDict",
    ) -> List[Text]:
        """动态决定下一步需要填充哪个槽位。"""
        
        # 检查用户是否已经提供了信息
        recipient = tracker.get_slot("recipient")
        amount = tracker.get_slot("amount")

        # 如果用户已经说了金额但没说收款人
        if amount and not recipient:
            # 那么我们优先询问收款人
            return ["recipient", "amount"]

        # 默认情况下，还是按照先人后钱的顺序
        return ["recipient", "amount"]

    def extract_recipient(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> Dict[Text, Any]:
        #从用户输入中抽取收款人信息
        recipient_entity = next(tracker.get_latest_entity_values("recipient"), None)
        if recipient_entity:
            return {"recipient": recipient_entity}
        return {}

    def extract_amount(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> Dict[Text, Any]:
        #从用户输入中抽取金额信息
        amount_entity = next(tracker.get_latest_entity_values("amount"), None)
        if amount_entity:
            # 使用正则提取数字部分
            match = re.search(r"([\d,.]+)", amount_entity)
            if match:
                number_str = match.group(1).replace(',', '')  # 如果有千位分隔符，可以去掉
                try:
                    amount_value = float(number_str)
                    return {"amount": amount_value}
                except ValueError:
                    # 转换失败，返回空字典或其他处理
                    return {}
        return {}
