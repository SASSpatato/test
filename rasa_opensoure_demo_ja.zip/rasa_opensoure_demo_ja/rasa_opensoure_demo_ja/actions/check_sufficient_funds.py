from typing import Any, Dict, List, Text

from rasa_sdk import Action, Tracker
from rasa_sdk.events import SlotSet
from rasa_sdk.executor import CollectingDispatcher


class ActionCheckSufficientFunds(Action):
    def name(self) -> Text:
        return "action_check_sufficient_funds"

    def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict[Text, Any]]:
        # hard-coded balance for tutorial purposes. in production this
        # would be retrieved from a database or an API
        balance = 1000.0
        transfer_amount_raw = tracker.get_slot("amount")
        try:
            transfer_amount = float(transfer_amount_raw)
        except (TypeError, ValueError):
            dispatcher.utter_message(response="utter_ask_svalid_amount")
            # 重置金额槽位，让表单重新提问
            return [SlotSet("amount", None)]

        has_sufficient_funds = transfer_amount <= balance

        if has_sufficient_funds:
            # 资金充足：主动向用户发起确认
            dispatcher.utter_message(response="utter_ask_final_confirmation")
        else:
            # 资金不足：告知用户并询问是否重试
            #dispatcher.utter_message(text="余额不足")
            dispatcher.utter_message(response="utter_ask_retry_transfer")

        # 最后，返回设置槽位的事件
        return [SlotSet("has_sufficient_funds", has_sufficient_funds)]