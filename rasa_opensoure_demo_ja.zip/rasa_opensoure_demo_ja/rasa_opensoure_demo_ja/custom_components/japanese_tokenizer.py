from rasa.engine.recipes.default_recipe import DefaultV1Recipe
from rasa.nlu.tokenizers.tokenizer import Token, Tokenizer

from typing import List
import MeCab

@DefaultV1Recipe.register(
    [DefaultV1Recipe.ComponentType.MESSAGE_TOKENIZER], 
    is_trainable=False
)
class MeCabTokenizer(Tokenizer):
    def __init__(self, component_config=None):
        # 保持兼容，传入空字典避免KeyError
        if component_config is None:
            component_config = {}
        super().__init__(component_config)
        # 指定字典路径（如果使用neologd请设置路径）
        self.tagger = MeCab.Tagger("-r /etc/mecabrc -d /home/limeng/rasa-opensource/rasa-demo-ja/mecab-ipadic-neologd/libexec/../build/mecab-ipadic-2.7.0-20070801-neologd-20200910")  

    def tokenize(self, message, attribute):
        text = message.get(attribute)
        if not text:
            return []

        node = self.tagger.parseToNode(text)
        tokens: List[Token] = []

        index = 0
        while node:
            if node.surface != '':
                start_pos = text.find(node.surface, index)
                if start_pos == -1:
                    start_pos = index
                tokens.append(Token(text=node.surface, start=start_pos))
                index = start_pos + len(node.surface)
            node = node.next

        return tokens


