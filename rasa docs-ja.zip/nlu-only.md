---
id: nlu-only
sidebar_label: Using NLU Only
title: Using NLU Only
abstract: Find out how to use only Rasa NLU as a standalone NLU service for your chatbot or virtual assistant.
---

Rasa を NLU コンポーネントとしてのみ使用したい場合は、できます。

## NLU のみのモデルのトレーニング

NLU モデルのみをトレーニングするには、以下を実行します。

```bash
rasa train nlu
```

これにより、`data/` ディレクトリ内の NLU トレーニング データ ファイルが検索され、トレーニング済みモデルが `models/` ディレクトリに保存されます。モデルの名前は `nlu-` で始まります。

## コマンドラインでの NLU モデルのテスト

コマンドラインで NLU モデルを試すには、次のコマンドを実行します。

```bash
rasa shell nlu
```

これにより、rasa シェルが起動し、テストするメッセージを入力するように求められます。メッセージを好きなだけ入力し続けることができます。

または、`nlu`引数を省略して、nluのみのモデルを直接渡すこともできます。

```bash
rasa shell -m models/nlu-20190515-144445.tar.gz
```

## NLU サーバーの実行

NLU モデルでサーバーを起動するには、実行時にモデル名を渡します。

```bash
rasa run --enable-api -m models/nlu-20190515-144445.tar.gz
```

その後、`/model/parse` エンドポイントを使用してモデルから予測をリクエストできます。これを行うには、次のコマンドを実行します。

```bash
curl localhost:5005/model/parse -d '{"text":"hello"}'
```