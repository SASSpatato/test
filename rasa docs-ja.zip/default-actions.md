---
id: default-actions
sidebar_label: Default Actions
title: Default Actions
abstract: Default actions are actions that are built into the dialogue manager by default. Most of these are automatically predicted based on certain conversation situations. You may want to customize these to personalize your assistant.
---

これらの各アクションには、以下のセクションで説明するデフォルトの動作があります。このデフォルトの動作を上書きするには、`name()` メソッドがデフォルトアクションと同じ名前を返すカスタム[アクション](./custom-actions.md)を記述します。

```python
class ActionRestart(Action):

  def name(self) -> Text:
      return "action_restart"

  async def run(
      self, dispatcher, tracker: Tracker, domain: Dict[Text, Any]
  ) -> List[Dict[Text, Any]]:

      # custom behavior

      return [...]
```

このアクションをドメイン・ファイルのアクション・セクションに追加して、アシスタントがデフォルトの定義ではなくカスタム定義を使用することを認識できるようにします。

```yaml-rasa
actions:
  - action_restart
```

> [!warning] 
> このアクションをドメインファイルに追加した後、 `rasa train --force`。そうしないと、Rasa はあなたが何も変更したことに気づかず、対話モデルの再トレーニングをスキップする可能性があります。

## action_listen

このアクションは、アシスタントが何もせず、次のユーザー入力を待つ必要があることを知らせると予測されます。

## action_restart

このアクションにより、会話中に設定されたスロットを含む会話履歴全体がリセットされます。

[RulePolicy](./rules.md) がモデル構成に含まれている場合は、会話でユーザーが "/restart" メッセージを送信することでトリガーできます。ドメインで`utter_restart`応答を定義すると、この応答もユーザーに送信されます。

## action_session_start

このアクションは、新しい会話セッションを開始し、次の状況で実行されます。

*   新しい会話の開始時
*   ドメインの [[./domain.md#セッション構成|セッション構成]] の `session_expiration_time` パラメータで定義された期間、ユーザが非アクティブになった後
*   ユーザーが会話中に「/session_start」メッセージを送信したとき

このアクションにより会話トラッカーがリセットされますが、デフォルトでは、設定されたスロットはクリアされません。

### カスタマイズ

セッション開始アクションのデフォルトの動作は、既存のすべてのスロットを取得し、 それらを次のセッションに持ち越します。すべてを引き継ぎたくないとしましょう スロットですが、ユーザーの名前と電話番号のみ。そのためには、 `action_session_start`次のようなカスタムアクションを使用します。

```python
from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.events import SlotSet, SessionStarted, ActionExecuted, EventType


class ActionSessionStart(Action):
    def name(self) -> Text:
        return "action_session_start"

    @staticmethod
    def fetch_slots(tracker: Tracker) -> List[EventType]:
        """Collect slots that contain the user's name and phone number."""

        slots = []
        for key in ("name", "phone_number"):
            value = tracker.get_slot(key)
            if value is not None:
                slots.append(SlotSet(key=key, value=value))
        return slots

    async def run(
      self, dispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:

        # the session should begin with a `session_started` event
        events = [SessionStarted()]

        # any slots that should be carried over should come after the
        # `session_started` event
        events.extend(self.fetch_slots(tracker))

        # an `action_listen` should be added at the end as a user message follows
        events.append(ActionExecuted("action_listen"))

        return events
```

セッション開始をトリガーしたユーザーメッセージとともに送信されたメタデータにアクセスする場合は、特別なスロットsession_started_metadataにアクセスできます。

```python
from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.events import SessionStarted, ActionExecuted


class ActionSessionStart(Action):
    def name(self) -> Text:
        return "action_session_start"

    async def run(
      self, dispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:
        metadata = tracker.get_slot("session_started_metadata")

        # Do something with the metadata
        print(metadata)

        # the session should begin with a `session_started` event and an `action_listen`
        # as a user message follows
        return [SessionStarted(), ActionExecuted("action_listen")]
```

## action_default_fallback

このアクションは、最後のユーザーとボットの対話を元に戻し、定義されている場合は`utter_default`応答を送信します。これは、この[フォールバックメカニズム](./fallback-handoff.md)を有効にしている場合、アクション予測の信頼度が低いことによってトリガーされます。

## action_deactivate_loop

このアクションにより、アクティブループが非アクティブになり、要求されたスロットがリセットされます。これは、[[./forms.md#ストーリーを書く / 不幸なフォームパスのルール|フォーム内の不幸なパスの処理]]

> [! note] 
> すべてのスロットをリセットする場合は、フォームの非アクティブ化後に [`AllSlotsReset`](https://rasa.com/docs/rasa/reference/rasa/shared/core/events#allslotsreset-objects) イベントを返すカスタム アクションを使用することをお勧めします。

## action_two_stage_fallback

これは、低い NLU 信頼度を処理するために使用できるフォールバック ループです。[[./fallback-handoff.md#NLU フォールバック|低 NLU 信頼度の処理]] の詳細をお読みください。

## action_default_ask_affirmation

このアクションは、`action_two_stage_fallback`ループによって使用されます。ユーザーにメッセージの意図を確認するよう求めます。このアクションは、特定のユースケースに合わせてカスタマイズできます。

## action_default_ask_rephrase

このアクションは、ユーザーがインテント `action_default_ask_affirmation` の表示を拒否した場合に`action_two_stage_fallback`ループによって使用されます。ユーザーにメッセージを言い換えるように求めます。

## action_back

このアクションにより、最後のユーザーとボットの対話が元に戻されます。これは、アシスタントに「/back」メッセージを送信することで、ユーザーがトリガーできます。RulePolicy]] が設定されています。

## フォームアクション

デフォルトでは、Rasaはフォーム[ロジック](forms.md)の処理に`FormAction`を使用します。フォーム名を含むカスタムアクションをドメインに追加することで、このデフォルトのアクションをカスタムアクションで上書きできます。フォームのデフォルトアクションのオーバーライドは、Rasa 1.0 から 2.0 への移行プロセス中**にのみ**使用してください。

## action_unlikely_intent

Rasa `action_unlikely_intent`は [[./policies.md#UnexpecTED インテント ポリシー|UnexpecTED インテント ポリシー]]です。このアクションが予測される頻度を制御するには、[[./policies.md#UnexpecTED インテント ポリシー|`tolerance`]] `パラメーターを使用します。`

### カスタマイズ

アシスタントの動作をカスタマイズして、`action_unlikely_intent`がトリガーされた後に何が起こるかを構成できます。たとえば、フォローアップとして、ルールを使用して人間のエージェントへのハンドオフをトリガーできます。

```yaml
- rule: trigger human handoff with action_unlikely_intent
  steps:
    - action: action_unlikely_intent
    - action: ask_human_handoff
    - intent: affirm
    - action: trigger_human_handoff
```

または、ドメイン内のアクションのリストに`action_unlikely_intent`を追加し、カスタム動作を実装することで、その動作を[`カスタムアクション`](./custom-actions.md)としてオーバーライドすることもできます。

```python
class ActionUnlikelyIntent(Action):

    def name(self) -> Text:
        return "action_unlikely_intent"

    async def run(
        self, dispatcher, tracker: Tracker, domain: Dict[Text, Any],
    ) -> List[Dict[Text, Any]]:

        # Implement custom logic here
        return []
```

> [!note] 
> `action_unlikely_intent`は推論中の任意の会話ステップでトリガーできるため、ストーリーデータのみでトレーニングされたすべてのポリシー(`TEDPolicy`、`UnexpecTEDIntentPolicy`、`MemoizationPolicy`など)は、予測を行うときにトラッカーでのその存在を無視します。ただし、`RulePolicy` はその存在を考慮に入れるため、[[./default-actions.md#カスタマイズ|会話の動作はカスタマイズ可能]]。

> [!note] 
> `action_unlikely_intent`はトレーニングストーリーに含めることはできません。ルールにのみ**追加できます。**

## action_extract_slots

このアクションは、各ユーザターンの後、次のアシスタントアクションの予測と実行の前に実行されます。`action_extract_slots` は、各ドメイン スロットの [[./domain.md#スロットマッピング|スロットマッピング]] をループして、最新のユーザ メッセージから抽出された情報を使用して、会話全体でスロットを設定または更新します。

`action_extract_slots` が [[./domain.md#カスタムスロットマッピング|カスタムスロットマッピング]] を見つけた場合、まず`アクション`キーを使用してマッピングでカスタムアクションが定義されているかどうかを確認してから実行します。

すべてのスロットマッピングを適用した後、`action_extract_slots`カスタム検証アクションがドメインアクションに存在するかどうか`action_validate_slot_mappings`実行します。それ以外の場合は、すでに抽出されたスロットをすぐに返します。

スロットマッピングまたはスロットマッピング検証で使用されるカスタムアクションは、`SlotSet` 型または `BotUttered` 型のイベントのみを返す必要があることに注意してください。その他のタイプのイベントは許可されず、トラッカーの更新時に無視されます。

デフォルトのアクションは、`FormAction` によって以前に実行されたスロット抽出を置き換え`action_extract_slots`。フォームをトリガーするインテントから抽出された情報に基づいてスロットを設定する場合は、`条件`キーを含まないマッピングを明示的に指定する必要があります。`条件`を含むスロットマッピングは、指定されたフォームがアクティブな場合にのみ適用されます。 `action_extract_slots`は、各ユーザーメッセージの直後に実行されるため、フォームがアクティブ化される前に実行されます。したがって、フォームをトリガーするユーザーメッセージに適用するマッピングは、`条件`を指定する必要がありません。そうしないと、フォームはスロットがアクティブ化されるとスロットを再要求します。

> [!note ] 
> アシスタントによって予測および実行された次のアクションが`action_default_fallback`である場合、`UserUtteranceReverted` イベントが発生し、最後のユーザー ターンで以前に埋められたスロットの設定が解除されます。