---
id: rules
sidebar_label: Rules
title: Rules
description: Use Rasa rules to respond to FAQs, fill forms, or handle fallbacks gracefully.
abstract: Rules are a type of training data used to train your assistant's dialogue management model.
  Rules describe short pieces of conversations that should always follow the same path.
---

**ルールを使いすぎないでください**。ルールは、小さな特定の会話パターンを処理するのに最適ですが、[ストーリー](./stories.md)とは異なり、ルールには目に見えない会話パスに一般化する権限がありません。ルールとストーリーを組み合わせて、アシスタントを堅牢にし、実際のユーザーの行動を処理できるようにします。

特定の動作を実装するためにストーリーまたはルールを記述するかどうかを決定できない場合は、[会話データの記述](./writing-stories.md)のベスト プラクティスを参照してください)。

Rasa アシスタントでのルールの実装に関するその他の例については、[ルールの例ボットを参照してください](https://github.com/RasaHQ/rasa/tree/main/examples/rules)。

## ルールの作成

ルールの作成を開始する前に、 [[./policies.md#ルールポリシー|ルールポリシー]]がモデル構成に追加されます。

```yaml-rasa
policies:
- ... # Other policies
- name: RulePolicy
```

その後、トレーニングデータの`ルール`セクションにルールを追加できます。

ルールが会話の任意の時点で適用できることを示すには、会話を開始するインテントから始めて、それに応じてアシスタントが実行する必要があるアクションを追加します。

```yaml-rasa
rules:

- rule: Say `hello` whenever the user sends a message with intent `greet`
  steps:
  - intent: greet
  - action: utter_greet
```

このルール例は、会話の開始時と、ユーザーが進行中の会話の途中で意図的な`挨拶`を含むメッセージを送信することを決定した場合に適用されます。

トレーニングデータにはルールとしてのみ表示され、ストーリーには表示されないダイアログターンは、予測時に `TEDPolicy` などの ML のみのポリシーによって無視されます。

```yaml-rasa
rules:
- rule: Say `hello` whenever the user sends a message with intent `greet`
  steps:
  - intent: greet
  - action: utter_greet

stories:
- story: story to find a restaurant
  steps:
  - intent: find_restaurant
  - action: restaurant_form
  - action: utter_restaurant_found
```

たとえば、上記のようにグリーティング ルールを定義し、どのストーリーにも追加しない場合、`RulePolicy が``utter_greet`を予測した後、`TEDPolicy` はグ`リーティング utter_greet` ターンが発生しなかったかのように予測します。

### 会話開始のルール

会話の開始時にのみ適用されるルールを記述するには、 `conversation_start: あなたのルールに忠実`です:

```yaml-rasa
rules:

- rule: Say `hello` when the user starts a conversation with intent `greet`
  conversation_start: true
  steps:
  - intent: greet
  - action: utter_greet
```

ユーザーが会話の後半でインテント `グリート`を含むメッセージを送信した場合、ルールは一致しません。

### 条件付きルール

条件は、ルールが 適用。これを行うには、前の会話に関する情報を `条件`キー:

```yaml-rasa
rules:

- rule: Only say `hello` if the user provided a name
  condition:
  - slot_was_set:
    - user_provided_name: true
  steps:
  - intent: greet
  - action: utter_greet
```

`条件`に含めることができる情報には、`slot_was_set` イベントと`active_loop`イベントが含まれます。

### ルールの最後にユーザー入力を待機するスキップ

デフォルトでは、ルールは最後のステップが終了すると、次のユーザーメッセージを待機します。

```yaml-rasa
rules:

- rule: Rule which will wait for user message when it was applied
  steps:
  - intent: greet
  - action: utter_greet
  # - action: action_listen
  # Every rule implicitly includes a prediction for `action_listen` as last step.
  # This means that Rasa will wait for the next user message.
```

次のアクション予測を別のストーリーまたはルールに引き継ぐ場合は、 `wait_for_user_input: あなたの`ルールに false:

```yaml-rasa
rules:

- rule: Rule which will not wait for user message once it was applied
  steps:
  - intent: greet
  - action: utter_greet
  wait_for_user_input: false
```

これは、アシスタントが追加のユーザー入力を待つ前に別のアクションを実行する必要があることを示しています。

### ルールの中止

ルールは、チャットボットの複数の出力ステップを処理するように設計されています。ユーザーの操作が必要になるとすぐに終了します。これは、最初のスロットのユーザー入力から始まるため、[[#ルールとフォーム|フォームの起動]]を介して自動的に行われます。したがって、起動後のすべてのステップは無視されます。

ただし、終了は手動で行うこともできます。これは、条件付き終了基準を実装するのに役立ちます。次に例を示します。

```yaml-rasa
rules:

- rule: Rule which will be conditionaly terminated
  steps:
  - intent: greet
  - action: action_check_termination
  - action: utter_greet
  wait_for_user_input: true
```

```python
from rasa_sdk import Action
from rasa_sdk.events import FollowupAction

class ActionCheckTermination(Action):

    def name(self):
        return "action_check_termination"

    def run(self, dispatcher, tracker, domain):

        # your business logic here
        should_terminate = check_for_termination(<params>)

        if should_terminate:
            return [FollowupAction("action_listen")]

        return []
```

utter_greetは、新しいインテント予測を引き起こすため、ユーザー入力後であっても、終了が実行されることはありません。

### ルールとフォーム

[フォーム](./forms.md)がアクティブな場合、ボットはルールを無視して、フォームの定義方法に基づいて予測を行います。次の場合、ルールが再び適用されます。

*   フォームは、必要なすべてのスロットに入力します
*   フォームはその実行を拒否します ([[./forms.md#ストーリーを書く / 不幸なフォームパスのルール|Handling Unhappy Paths]] を参照してください)