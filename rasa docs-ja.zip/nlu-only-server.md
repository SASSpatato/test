---
id: nlu-only-server
sidebar_label: NLU-Only Server
title: NLU-Only Server
description: Read about connecting to a Rasa NLU-only server using the HTTP API.
abstract: You can run an NLU-only server and use the HTTP API to connect to it.
---

## NLU サーバーへの接続

[[./nlu-only.md#NLU サーバーの実行|NLU サーバーの実行]] を、ダイアログ管理サーバーのエンドポイント構成ファイルに接続の詳細を追加することで、個別に実行されている Rasa ダイアログ管理専用サーバーに転送します。

```yaml
nlu:
    url: "http://<your nlu host>:<your nlu port>"
    token: <token>  # [optional]
    token_name: <name of the token> # [optional] (default: token)
```

`トークン`と`token_name`は、オプションの [[./http-api.md#トークンベースの認証|authentication parameters]] を参照します。

ダイアログ管理サーバーは、NLU モデルを含まないモデルを提供する必要があります。対話管理のみのモデルを取得するには、`rasa train core` を使用してモデルを学習させるか、`rasa train` を使用しますが、すべての NLU データを除外します。

ダイアログ管理サーバーは、メッセージを受信すると、[](https://rasa.com/docs/rasa/pages/http-api#operation/parseModelMessage) `http://<your nlu host>:<your nlu port>/model/parse` そして、返された解析情報を使用します。

> [!NOTE] エンドポイント設定
> ダイアログ管理サーバのエンドポイント設定には、NLU のみのサーバを参照する `nlu` エンドポイントが含まれます。したがって、`NLU` エンドポイントを除き、NLU サーバーには**別のエンドポイント構成ファイルを使用**する必要があります。

カスタム NLU サーバー (つまり、Rasa NLU ではない) を実装する場合、サーバーは Rasa NLU サーバーと同じ形式でリクエストに応答する `/model/parse` エンドポイントを提供する必要があります。