---
id: secrets-managers
sidebar_label: Secrets Managers
title: Secrets Managers
description: Safeguard credentials your service uses to authenticate to external resources.
abstract: You can store your assistant's secrets in an external credentials manager.
    Rasa Pro currently supports credentials manager for the Tracker Store
---

> [!warning] Rasa Proのみ

> [!warning] Rasa Pro 3.5.0以降で利用可能

Rasa Proは、次のシークレットマネージャーをサポートしています。

*   [ハシコープ保管庫](https://www.hashicorp.com/products/vault)

現在、Rasa Proは、次のサービスの資格情報の保護をサポートしています。

*   [トラッカーストア](./tracker-stores.md)

## HashiCorp Vault シークレットマネージャー

Vault Secrets Manager を使用して、外部サービスへのアクセスの認証に使用される資格情報を格納します。 資格証明は Vault インスタンスに格納され、保存時に暗号化できます。 Vault インスタンスに認証情報を保存するには、Vault の公式ドキュメントを参照してください。 [Vault へのシークレットの保存](https://developer.hashicorp.com/vault/tutorials/getting-started/getting-started-first-secret)。

保存中の資格情報を暗号化することもできます。 [Vault Transit Engine](https://www.vaultproject.io/docs/secrets/transit)です。

> [!note] 
> 有効期限が切れるトークンは定期的に更新する必要があり、更新プロセスはネットワーク経由で行われるため、Rasa Pro は有効期限が切れる 15 秒前にトークンの更新を試みます。トークンの有効期間 (TTL) が 15 秒未満の場合、1 秒後に更新を試みますが、ネットワーク遅延により失敗する可能性があります。
> 
> Rasa Pro には、トークンを更新するための再試行メカニズムが組み込まれています。
> 
> トークンが正常に更新されない場合、トークンは期限切れとみなされ、Rasa Proはシークレットにアクセスできなくなります。新しい更新可能なトークンを作成し、新しいトークンでRasa Proを再起動する必要があります。

### 認証

Rasa Proは、[トークン認証](https://www.vaultproject.io/docs/auth/token)を介してVaultに認証できます。

`有効期限`と`期限切れ(`いわゆるルートトークン)の両方のトークンがサポートされています。Rasa Proは、トークンの有効期限が切れると自動的に更新します。

### Vault へのアクセスを設定する方法

Vault シークレット・マネージャーへのアクセスは、環境変数と構成ファイルを使用して構成できます`endpoints.yml`。

環境変数と`設定ファイルendpoints.yml`マージされ、**環境変数の値が優先されます**。

次の環境変数を使用できます。

| 環境変数 | 形容 | デフォルト |
| --- | --- | --- |
| SECRET_MANAGER | 必須です。使用するシークレットマネージャー。現在、"vault" のみがサポートされています | vault |
| VAULT_HOST | 必須です。ボールト サーバーのアドレス |  |
| VAULT_TOKEN | 必須です。ボールト・サーバーに対して認証するためのトークン |  |
| VAULT_RASA_SECRETS_PATH | ボールト・サーバー内のシークレットへのパス | rasa-secrets |
| VAULT_TRANSIT_MOUNT_POINT | トランジットシークレットエンジンが有効になっている場合は、これをトランジットエンジンのマウントポイントに設定します |  |

Vault シークレットマネージャーを設定するには、`endpoints.yml`ファイルに次のセクションを入力します。

```
secrets_manager:
    type: vault # required - the secrets manager to use
    token: <token> # required - token to authenticate to the vault server
    url: "http://localhost:1234" # required - the address of the vault server
    secrets_path: rasa-secrets  # path to the secrets in the vault server if not       set it defaults to `rasa-secrets`
    transit_mount_point: transit # if transit secrets engine is enabled, set this      to mount point of the transit engine
```

#### アクセス資格情報を環境変数に格納する

環境変数と構成ファイルを組み合わせる簡単な例`endpoints.yml`、アクセストークンを環境変数に格納し、残りの構成を`endpoints.yml`ファイルに格納します。

```bash
# environment variables
VAULT_TOKEN=<token used to authenticate to Vault>
```

```yaml-rasa
secrets_manager:
    type: vault
    url: "http://localhost:1234"
    secrets_path: rasa-secrets  # if not set it defaults to `rasa-secrets`
    transit_mount_point: transit # if you have enabled transit secrets engine, and you want to use it
```

### Vault Secrets Manager でトラッカーストアを設定する方法

1.  Vault インスタンスにアクセスするための Rasa の構成
    
    詳細については、[[#Vault へのアクセスを設定する方法]] セクションを確認してください。
    
2.  Vault シークレットマネージャーを使用してトラッカーストアの認証情報を取得するように Rasa を設定します。
    
    ```yaml-rasa
    tracker_store:
          type: SQL
          url: localhost:5432
          username:
                source: secrets_manager.vault
                secret_key: sql_store_username
          password:
                source: secrets_manager.vault
                secret_key: sql_store_password
    ```