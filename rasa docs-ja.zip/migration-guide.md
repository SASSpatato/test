---
id: migration-guide
sidebar_label: Version Migration Guide
title: Version Migration Guide
description: |
  Information about changes between major versions of chatbot framework Rasa Core
  and how you can migrate from one version to another.
---

このページには、メジャー バージョン間の変更と、あるバージョンから別のバージョンへの移行方法に関する情報が含まれています。

## Rasa 3.0 から 3.1

### 機械学習コンポーネント

#### TensorFlow のアップグレード

TensorFlow のアップグレードにより、構成で `LanguageModelFeaturizer` を使用している場合、まったく同じ出力とモデルのパフォーマンスを保証できません。これは、構成、ランダムシード、データを変更せずにモデルが新しいバージョンの Rasa で再トレーニングされる場合、および以前のバージョンの Rasa でトレーニングされたモデルが推論のためにこの新しいバージョンでロードされる場合にも当てはまります。

トレーニング済みのモデルが期待どおりに動作するかどうかを確認し、必要に応じて再トレーニングしてください。

### NLU JSON 形式

JSON 形式の [NLU トレーニング データは](nlu-training-data.md)非推奨となり、Rasa 4.0 で削除されます。NLU JSON データのサポートが削除される前に、NLU JSON データを YAML 形式に変換するために使用 `rasa data convert nlu -f yaml --data <path to NLU data>` してください。

## Rasa 2.x から 3.0 へ

### マークダウンデータ

Markdown はサポートされなくなりました — 以前に非推奨だったすべてのサポートコードが削除され、コンバーターも削除されました。

関連する CLI コマンド `rasa data convert responses` と `rasa data convert config` 削除されました。

Markdown 形式のトレーニング データがまだある場合は、Rasa 2.x を使用してデータを Markdown から YAML に変換することをお勧めします。[[./migration-guide.md#トレーニングデータファイル|here]]で説明されているコマンドを使用してください。

### モデル構成

使用する`レシピ`を [モデル構成](model-configuration.md)。現時点では、Rasa は `default.v1` レシピのみをサポートしており、モデル構成でレシピを指定しなくても引き続き使用できます。将来の破壊的変更を回避するには、モデル構成の先頭に `recipe: "default.v1"` を指定する必要があります。

**Rasa 2.0 (旧):**

```
language: en

pipeline:
  ...
policies:
  ...
```

**Rasa 3.0 (新機能):**

```
recipe: default.v1

language: en

pipeline:
  ...
policies:
  ...
```

### カスタムポリシーとカスタムコンポーネント

Rasa 3.0 は、[NLU コンポーネント](components.md)と [ポリシー](policies.md)は推論中にトレーニングされ、実行されます。これらの変更の一環として、NLU コンポーネントとポリシーのインターフェイスが統合され、適応されました。

次のセクションでは、Rasa 3.0 でカスタム NLU コンポーネントとポリシーを実行するために必要な適応について概説します。

> [!caution] 
> カスタム[グラフコンポーネントに関する](custom-graph-components.md)更新されたガイドをこちらからお読みになり、ステップバイステップのガイドに従って独自のカスタムグラフコンポーネントを移行してください。

**型注釈**

Rasa 3.0 までは、カスタムポリシーやカスタム NLU コンポーネントでは、[型注釈](https://docs.python.org/3/library/typing.html)は必要ありませんでした。カスタム NLU コンポーネントおよびポリシーで[型アノテーション](https://docs.python.org/3/library/typing.html)を使用する必要があります。Rasa は、これらの型アノテーションを使用して、グラフコンポーネントに互換性があり、正しく構成されていることを検証します。カスタム[コンポーネントガイド](custom-graph-components.md)で概説されているように、[前方参照](https://www.python.org/dev/peps/pep-0484/#forward-references)を使用することは許可されていません。

> [!note] Python 3.7 での前方参照 
> Python 3.7 での前方参照の使用を回避するには、 [`from __future__ import annotations`](https://www.python.org/dev/peps/pep-0563/#enabling-the-future-behavior-in-python-3-7) インポートを使用します。

```
from typing import List, Any
from rasa.core.policies.policy import Policy

class MyPolicy(Policy):
    def train(
        self,
        training_trackers: List["TrackerWithCachedStates"],
        domain,
        **kwargs: Any,
    ):
        ...
```

```
from __future__ import annotations
from typing import List, Any

from rasa.core.policies.policy import Policy
from rasa.engine.storage.resource import Resource
from rasa.shared.core.domain import Domain
from rasa.shared.core.generator import TrackerWithCachedStates

class MyPolicy(Policy):
    def train(
        self,
        training_trackers: List[TrackerWithCachedStates],
        domain: Domain,
        **kwargs: Any,
    ) -> Resource:
        ...
```

#### カスタム NLU コンポーネントの変更

**`GraphComponent` からの継承**

以前に次のクラスのいずれかから継承した NLU コンポーネントは、さらに [[custom-graph-components.md#`GraphComponent` インターフェイス|`GraphComponent` インターフェイス]]:

*   `SparseFeaturizer`
*   `DenseFeaturizer`
*   `IntentClassifier`
*   `EntityExtractor`
*   `Component`

次のスニペットは、必要な変更を示しています。

**Rasa 2.0 (旧):**

```
from rasa.nlu.featurizers.sparse_featurizer.sparse_featurizer import SparseFeaturizer

class MyNLUComponent(SparseFeaturizer):
    ...
```

**Rasa 3.0 (新機能):**

```
from rasa.engine.graph import GraphComponent
from rasa.nlu.featurizers.sparse_featurizer.sparse_featurizer import SparseFeaturizer

class MyNLUComponent(GraphComponent, SparseFeaturizer):
    ...
```

`EntityExtractor`ではなく`EntityExtractorMixin`から継承

`EntityExtractor` クラスの名前が `EntityExtractorMixin` に変更されました。 **Rasa 2.0 (旧):**

```
from rasa.nlu.extractors.extractor import EntityExtractor

class MyNLUComponent(EntityExtractor):
    ...
```

**Rasa 3.0 (新機能):**

```
from rasa.engine.graph import GraphComponent
from rasa.nlu.extractors.extractor import EntityExtractorMixin

class MyNLUComponent(GraphComponent, EntityExtractorMixin):
    ...
```

**トレーニング用の NLU コンポーネントのインスタンス化**

NLU コンポーネントは、コンストラクタを介してインスタンス化されなくなりました。代わりに、すべての NLU コンポーネントは [[custom-graph-components.md#`GraphComponent` インターフェイス|`GraphComponent` インターフェイス]]を使用します。渡された構成は、モデル構成ファイルからの更新を含む NLU コンポーネントの既定の構成です。

**Rasa 2.0 (旧):**

```
from typing import Optional, Dict, Text, Any
from rasa.nlu.classifiers.classifier import IntentClassifier

class MyNLUComponent(IntentClassifier):

  def __init__(self, component_config: Optional[Dict[Text, Any]] = None) -> None:
      super().__init__(component_config)
      ...
```

**Rasa 3.0 (新機能):**

```
from typing import Dict, Text, Any

from rasa.engine.graph import GraphComponent, ExecutionContext
from rasa.engine.storage.resource import Resource
from rasa.engine.storage.storage import ModelStorage
from rasa.nlu.classifiers.classifier import IntentClassifier

class MyNLUComponent(GraphComponent, IntentClassifier):

  def __init__(self, component_config: Dict[Text, Any]) -> None:
      self.component_config = component_config
    ...

  @classmethod
  def create(
      cls,
      config: Dict[Text, Any],
      model_storage: ModelStorage,
      resource: Resource,
      execution_context: ExecutionContext,
  ) -> GraphComponent:
      return cls(config)
```

**トレーニング済み NLU コンポーネントの永続化**

NLU コンポーネントは、NLU コンポーネント自体の外部から NLU コンポーネントの `persist` メソッドを呼び出すことによって永続化されていました。Rasa 3.0では、NLUコンポーネントはそれ自体を永続化する責任があります。提供された`model_storage`パラメータと`リソース`パラメータを使用して、トレーニングの最後にNLUコンポーネントを永続化し、`リソース`を返します NLU コンポーネントの`トレーニング`メソッドの結果として。詳細については、[[custom-graph-components.md#モデルの永続性|モデルの永続性]]を参照してください。

**Rasa 2.0 (旧):**

```
from pathlib import Path
from typing import Optional, Any, Text, Dict

from rasa.nlu.classifiers.classifier import IntentClassifier
from rasa.nlu.config import RasaNLUModelConfig
from rasa.shared.nlu.training_data.training_data import TrainingData

class MyNLUComponent(IntentClassifier):
    def train(
        self,
        training_data: TrainingData,
        config: Optional[RasaNLUModelConfig] = None,
        **kwargs: Any,
    ) -> None:
        ...

    def persist(self, file_name: Text, model_dir: Text) -> Dict[Text, Any]:
        file_path = Path(model_dir) / "{file_name}.model_data.json"
        rasa.shared.utils.io.create_directory_for_file(file_path)
        rasa.shared.utils.io.dump_obj_as_json_to_file(file_path,
            self.get_model_data())

        return {"file": file_name}
    ...
```

**Rasa 3.0 (新機能):**

```
from rasa.engine.graph import GraphComponent
from rasa.engine.storage.resource import Resource
from rasa.nlu.classifiers.classifier import IntentClassifier
from rasa.shared.nlu.training_data.training_data import TrainingData

class MyNLUComponent(GraphComponent, IntentClassifier):
    def train(self, training_data: TrainingData) -> Resource:
        ...
        self.persist()
        return self._resource

    def persist(self) -> None:
        with self._model_storage.write_to(self._resource) as directory:
            model_data_file = directory / "model_data.json"
            rasa.shared.utils.io.dump_obj_as_json_to_file(model_data_file,
                self.get_model_data())
    ...
```

**トレーニング済み NLU コンポーネントのインスタンス化**

以前は、NLU コンポーネントは独自の構成を保持する必要がありました。これで、`load` に渡された構成には、モデルがトレーニングされた構成が自動的に含まれます。永続化された NLU コンポーネントをインスタンス化するには、NLU コンポーネントの `load` メソッドで `model_storage` と`リソース`を使用する必要があります。

**Rasa 2.0 (旧):**

```
import json
from pathlib import Path
from typing import Text, Dict, Any, Optional

from rasa.nlu.classifiers.classifier import IntentClassifier
from rasa.nlu.model import Metadata

class MyNLUComponent(IntentClassifier):
    @classmethod
    def load(
        cls,
        meta: Dict[Text, Any],
        model_dir: Text,
        model_metadata: Metadata = None,
        cached_component: Optional["DIETClassifier"] = None,
        should_finetune: bool = False,
        **kwargs: Any,
    ) -> "MyNLUComponent":
        file_name = meta.get("file")
        file_path = Path(model_dir) / "{file_name}.model_data.json"
        model_data = json.loads(rasa.shared.utils.io.read_file(file_path))

        return cls(model_data)
    ...
```

**Rasa 3.0 (新機能):**

```
from __future__ import annotations
import json
from typing import Any, Text, Dict

from rasa.engine.graph import GraphComponent, ExecutionContext
from rasa.engine.storage.resource import Resource
from rasa.engine.storage.storage import ModelStorage
from rasa.nlu.classifiers.classifier import IntentClassifier
from rasa.shared.exceptions import FileIOException

class MyNLUComponent(GraphComponent, IntentClassifier):
    @classmethod
    def load(
        cls,
        config: Dict[Text, Any],
        model_storage: ModelStorage,
        resource: Resource,
        execution_context: ExecutionContext,
        **kwargs: Any,
    ) -> MyNLUComponent:
        model_data = {}

        try:
            with model_storage.read_from(resource) as path:

                model_data_file = path / "model_data.json"
                model_data = json.loads(rasa.shared.utils.io.read_file(model_data_file))

        except (ValueError, FileNotFoundError, FileIOException):
            logger.debug(
                f"Couldn't load metadata for component '{cls.__name__}' as the persisted "
                f"model data couldn't be loaded."
            )

        return cls(
            config, model_data=model_data
        )
```

**NLU コンポーネントのデフォルト構成の提供**

デフォルトの構成は、静的クラスプロパティではなく、静的メソッドによって返されます`get_default_config`。

**Rasa 2.0 (旧):**

```
from rasa.nlu.classifiers.classifier import IntentClassifier

class MyNLUComponent(IntentClassifier):
    ...
    defaults = {"key1": "value1"}
```

**Rasa 3.0 (新機能):**

```
from typing import Text, Any, Dict

from rasa.engine.graph import GraphComponent
from rasa.nlu.classifiers.classifier import IntentClassifier

class MyNLUComponent(GraphComponent, IntentClassifier):
    ...
    @staticmethod
    def get_default_config() -> Dict[Text, Any]:
        return {"key1": "value1"}

```

**NLU コンポーネントでのトレーニングデータの拡張**

[トークナイザー](components.md#トークナイザー)や[フィーチャライザー](components.md#フィーチャライザー)などの NLU コンポーネントは、モデルのトレーニング中に出力でトレーニング データを拡張します。これらの出力は、パイプラインの後半の NLU コンポーネントで必要になります。通常、特徴付けには*トークン化された*メッセージが必要であり、意図分類子にはそれ自体をトレーニングするために*特徴化された*トレーニング データが必要です。Rasa 3.0 では、これらのさまざまな目的が明確になります。以前は、NLU コンポーネントのトレーニングとトレーニング データの拡張の両方が`トレーニング` メソッドの一部として行われていました。Rasa 3.0 では、`それらは train` と `process_training_data` に分割されます。

**Rasa 2.0 (旧):**

```
from typing import Optional, Any

from rasa.nlu.featurizers.sparse_featurizer.sparse_featurizer import SparseFeaturizer
from rasa.nlu.config import RasaNLUModelConfig
from rasa.shared.nlu.training_data.training_data import TrainingData

class MyNLUComponent(SparseFeaturizer):
    def train(
        self,
        training_data: TrainingData,
        config: Optional[RasaNLUModelConfig] = None,
        **kwargs: Any,
    ) -> None:
        self.train_featurizer(training_data)

        for message in training_data.training_examples:
            self.add_features(message)
```

**Rasa 3.0 (新機能):**

```
from rasa.engine.graph import GraphComponent
from rasa.engine.storage.resource import Resource
from rasa.nlu.featurizers.sparse_featurizer.sparse_featurizer import SparseFeaturizer
from rasa.shared.nlu.training_data.training_data import TrainingData

class MyNLUComponent(GraphComponent, SparseFeaturizer):
    def train(self, training_data: TrainingData) -> Resource:
        self.train_featurizer(training_data)

        self.persist()
        return self._resource

    def process_training_data(self, training_data: TrainingData) -> TrainingData:
        for message in training_data.training_examples:
            self.add_features(message)

        return training_data
```

**NLU コンポーネントでの推論中のメッセージのリストの処理**

NLU コンポーネントは、推論中に 1 つの `Message` オブジェクトを受信するために使用される。Rasa 3.0以降、すべてのNLUコンポーネントは推論中にメッセージのリストをサポートする必要があります。コンポーネントがバッチ予測をサポートしていない限り、これを処理する最も簡単な方法は、メッセージをループすることです。また、`プロセス`メソッドの最後にメッセージオブジェクトを返す必要もあります。

**Rasa 2.0 (旧):**

```
from typing import Any

from rasa.nlu.classifiers.classifier import IntentClassifier
from rasa.shared.nlu.training_data.message import Message

class MyNLUComponent(IntentClassifier):
    def process(self, message: Message, **kwargs: Any) -> None:
      self.predict(message)
```

**Rasa 3.0 (新機能):**

```
from typing import List

from rasa.engine.graph import GraphComponent
from rasa.nlu.classifiers.classifier import IntentClassifier
from rasa.shared.nlu.training_data.message import Message

class MyNLUComponent(GraphComponent, IntentClassifier):
    def process(self, messages: List[Message]) -> List[Message]:
        for message in messages:
            self.predict(message)

        return messages
```

**NLU コンポーネントの登録**

カスタム NLU コンポーネントを使用する前に、`DefaultV1Recipe.register` デコレータを使用して NLU コンポーネントを登録する必要があります。NLU コンポーネント型は、既存の親クラスに対応します。

*   `トークナイザー`: `ComponentType.MESSAGE_TOKENIZER`
*   `SparseFeaturizer` / `DenseFeaturizer`: `ComponentType.MESSAGE_FEATURIZER`
*   `IntentClassifier` を使用します。 `ComponentType.INTENT_CLASSIFIER`
*   `EntityExtractor`: `ComponentType.ENTITY_EXTRACTOR`
*   NLU コンポーネントが事前トレーニング済みモデルを提供し、トレーニングおよび推論中に他の NLU コンポーネントが使用する必要がある場合は、`ComponentType.MODEL_LOADER を使用します。`

トレーニング中にコンポーネントの`トレーニング`メソッドを呼び出す場合は、`is_trainable=True` を指定します。

**Rasa 2.0 (旧):**

```
from rasa.nlu.classifiers.classifier import IntentClassifier

class MyNLUComponent(IntentClassifier):
    ...
```

**Rasa 3.0 (新機能):**

```
from rasa.engine.recipes.default_recipe import DefaultV1Recipe
from rasa.nlu.classifiers.classifier import IntentClassifier
from rasa.engine.graph import GraphComponent

@DefaultV1Recipe.register(
    DefaultV1Recipe.ComponentType.INTENT_CLASSIFIER, is_trainable=True
)
class MyNLUComponent(GraphComponent, IntentClassifier):
    ...
```

**NLU コンポーネントでのモデル プロバイダーの使用**

NLU コンポーネントに [スペーシーNLP](components.md#スペーシーNLP) などの事前トレーニング済みモデルが必要な場合、 [ミティエNLP](components.md#ミティエNLP) 言語モデルでは、モデルを必要とする NLU コンポーネントの前に、モデルのパイプラインでこのモデルを提供する NLU コンポーネントを指定する必要があります。これに加えて、`レジスタ`デコレータの`model_from`パラメータでモデルロードコンポーネントを指定する必要もあります。その後、モデルはモデルの`トレーニング`、`process_training_data`、`およびプロセス`メソッドに渡されます。

**Rasa 2.0 (旧):**

```
from typing import Optional, Any

from rasa.nlu.config import RasaNLUModelConfig
from rasa.nlu.classifiers.classifier import IntentClassifier
from rasa.shared.nlu.training_data.message import Message
from rasa.shared.nlu.training_data.training_data import TrainingData

class MyNLUComponent(IntentClassifier):
    def train(
        self,
        training_data: TrainingData,
        cfg: Optional[RasaNLUModelConfig] = None,
        **kwargs: Any,
    ) -> None:
        """Train the featurizer."""
        spacy_nlp = kwargs.get("spacy_nlp")
        ...

    def process(self, message: Message, **kwargs: Any) -> None:
        spacy_nlp = kwargs.get("spacy_nlp", None)
        ...
```

**Rasa 3.0 (新機能):**

```
from typing import List

from rasa.engine.graph import GraphComponent
from rasa.engine.recipes.default_recipe import DefaultV1Recipe
from rasa.engine.storage.resource import Resource
from rasa.nlu.classifiers.classifier import IntentClassifier
from rasa.nlu.utils.spacy_utils import SpacyModel
from rasa.shared.nlu.training_data.message import Message
from rasa.shared.nlu.training_data.training_data import TrainingData

@DefaultV1Recipe.register(
    DefaultV1Recipe.ComponentType.INTENT_CLASSIFIER, is_trainable=True, model_from="SpacyNLP"
)
class MyNLUComponent(GraphComponent, IntentClassifier):
    def train(
        self, training_data: TrainingData, model: SpacyModel) -> Resource:
        spacy_nlp = model.model
        ...

    def process(self, messages: List[Message], model: SpacyModel) -> List[Message]:
        spacy_nlp = model.model
        ...
```

#### カスタムポリシーの変更

このガイドでは、カスタムポリシーの移行を段階的に説明します。

**トレーニングのポリシーのインスタンス化**

ポリシーは、コンストラクターを介してインスタンス化されなくなりました。代わりに、すべてのポリシーで `create` メソッドを実装する必要があります。ポリシーのインスタンス化中に、[モデル構成](model-configuration.md)の構成は、個別のパラメーターとしてではなく、ディクショナリとして渡されます。同様に、`フィーチャライザー`はポリシーの外部でインスタンス化されなくなりました。代わりに、スーパークラス `rasa.core.policies.policy.Policy` は特徴付け器自体をインスタンス化します。

**Rasa 2.0 (旧):**

```
from typing import Optional, Any

from rasa.core.constants import DEFAULT_POLICY_PRIORITY
from rasa.core.featurizers.tracker_featurizers import TrackerFeaturizer
from rasa.core.policies.policy import Policy

class MyPolicy(Policy):
    def __init__(
        self,
        featurizer: Optional[TrackerFeaturizer] = None,
        priority: int = DEFAULT_POLICY_PRIORITY,
        max_history: Optional[int] = None,
        **kwargs: Any
    ) -> None:
        super().__init__(featurizer, priority, **kwargs)
        ...
```

**Rasa 3.0 (新機能):**

```
from typing import Optional, Dict, Text, Any

from rasa.core.featurizers.tracker_featurizers import TrackerFeaturizer
from rasa.core.policies.policy import Policy
from rasa.engine.graph import ExecutionContext
from rasa.engine.storage.resource import Resource
from rasa.engine.storage.storage import ModelStorage

class MyPolicy(Policy):
    def __init__(
        self,
        config: Dict[Text, Any],
        model_storage: ModelStorage,
        resource: Resource,
        execution_context: ExecutionContext,
        featurizer: Optional[TrackerFeaturizer] = None,
    ) -> None:
        super().__init__(
          config, model_storage, resource, execution_context, featurizer
        )
        ...
    ...

  @classmethod
  def create(
      cls,
      config: Dict[Text, Any],
      model_storage: ModelStorage,
      resource: Resource,
      execution_context: ExecutionContext,
  ) -> MyPolicy:
      return cls(config, model_storage, resource, execution_context)

```

**トレーニング済みポリシーの永続化**

ポリシーは、ポリシー自体の外部からポリシーの `persist` メソッドを呼び出すことで永続化されていました。Rasa 3.0では、ポリシーはそれ自体を永続化する責任があります。提供された`model_storage`パラメータと`リソース`パラメータを使用して、トレーニングの最後にグラフコンポーネントを永続化し、ポリシーの`トレーニング`メソッドの結果として`リソース`を返します。詳細については、[[custom-graph-components.md#モデルの永続性|モデルの永続性]]を参照してください。

**Rasa 2.0 (旧):**

```
from pathlib import Path
from typing import List, Any, Union, Text

from rasa.core.policies.policy import Policy
from rasa.shared.core.domain import Domain
from rasa.shared.core.generator import TrackerWithCachedStates
from rasa.shared.nlu.interpreter import NaturalLanguageInterpreter

class MyPolicy(Policy):
    def train(
        self,
        training_trackers: List[TrackerWithCachedStates],
        domain: Domain,
        interpreter: NaturalLanguageInterpreter,
        **kwargs: Any,
    ) -> None:
        ...

    def persist(self, path: Union[Text, Path]) -> None:
        if self.featurizer is not None:
            self.featurizer.persist(path)

        file_path = Path(path) / "model_data.json"
        rasa.shared.utils.io.create_directory_for_file(file_path)
        rasa.shared.utils.io.dump_obj_as_json_to_file(file_path,
            self.get_model_data())
    ...
```

**Rasa 3.0 (新機能):**

```
from typing import List, Any

from rasa.core.policies.policy import Policy
from rasa.engine.storage.resource import Resource
from rasa.shared.core.domain import Domain
from rasa.shared.core.generator import TrackerWithCachedStates

class MyPolicy(Policy):
    def train(
        self,
        training_trackers: List[TrackerWithCachedStates],
        domain: Domain,
        **kwargs: Any,
    ) -> Resource:
        ...
        self.persist()
        return self._resource

    def persist(self) -> None:
        with self._model_storage.write_to(self._resource) as directory:
            if self.featurizer is not None:
                self.featurizer.persist(directory)

            file_path = directory / "model_data.json"
            rasa.shared.utils.io.dump_obj_as_json_to_file(file_path,
                self.get_model_data())
    ...
```

**トレーニング済みポリシーのインスタンス化**

以前は、ポリシーは独自の設定を保持する必要がありました。これで、`load` に渡された構成には、モデルがトレーニングされた構成が自動的に含まれます。

永続化されたポリシーをインスタンス化するには、ポリシーの`ロード`・メソッドで`model_storage`と`リソース`を使用する必要があります。

**Rasa 2.0 (旧):**

```
import json
from pathlib import Path
from types import Union
from typing import Text, Any

from rasa.core.policies.policy import Policy

class MyPolicy(Policy):
    @classmethod
    def load(cls, path: Union[Text, Path], **kwargs: Any) -> "Policy":
        featurizer = None
        if (Path(path) / FEATURIZER_FILE).is_file():
            featurizer = TrackerFeaturizer.load(path)

        model_data = {}
        model_data_file = Path(path) / "model_data.json"
        if metadata_file.is_file():
            model_data = json.loads(rasa.shared.utils.io.read_file(model_data_file))

        return cls(model_data, featurizer)
    ...
```

**Rasa 3.0 (新機能):**

```
import json
from typing import Dict, Text, Any

from rasa.core.featurizers.tracker_featurizers import TrackerFeaturizer
from rasa.core.policies.policy import Policy
from rasa.engine.graph import ExecutionContext
from rasa.engine.storage.resource import Resource
from rasa.engine.storage.storage import ModelStorage
from rasa.shared.exceptions import FileIOException

class MyPolicy(Policy):
    @classmethod
    def load(
        cls,
        config: Dict[Text, Any],
        model_storage: ModelStorage,
        resource: Resource,
        execution_context: ExecutionContext,
        **kwargs: Any,
    ) -> MyPolicy:
        featurizer = None
        model_data = {}

        try:
            with model_storage.read_from(resource) as path:
                if (Path(path) / FEATURIZER_FILE).is_file():
                    featurizer = TrackerFeaturizer.load(path)

                model_data_file = path / "model_data.json"
                model_data = json.loads(rasa.shared.utils.io.read_file(model_data_file))

        except (ValueError, FileNotFoundError, FileIOException):
            logger.debug(
                f"Couldn't load metadata for policy '{cls.__name__}' as the persisted "
                f"metadata couldn't be loaded."
            )

        return cls(
            config, model_storage, resource, execution_context,
            featurizer=featurizer, model_data=model_data
        )
```

**ポリシーのデフォルト設定の指定**

デフォルト設定は、ポリシーのコンストラクタのデフォルト値を介して提供されなくなり、代わりに静的メソッドによって返されます`get_default_config`。

**Rasa 2.0 (旧):**

```
from typing import Text
from rasa.core.policies.policy import Policy

class MyPolicy(Policy):

    def __init__(key1: Text = "value1") -> None:
        ...
```

**Rasa 3.0 (新機能):**

```
from typing import Dict, Text, Any
from rasa.core.policies.policy import Policy

class MyPolicy(Policy):

    def __init__(self, config: Dict[Text, Any]) -> None:
        ...

    @staticmethod
    def get_default_config() -> Dict[Text, Any]:
        return {"key1": "value1"}
```

**ポリシーでのエンドツーエンド機能の使用**

Rasa Open Source 2 でカスタム [[stories.md#エンドツーエンドのトレーニング|エンドツーエンドのトレーニング]] を使用するには、`インタープリター` パラメーターを使用してトラッカー イベントを手動で特徴付けする必要がありました。Rasa 3.0では、 タイプ `ComponentType.POLICY_WITH_END_TO_END_SUPPORT` のエンドツーエンド機能を必要とするポリシーを[[custom-graph-components.md#モデル構成へのグラフコンポーネントの登録|register]] する必要があります。特徴量は事前に計算され、トレーニングと推論中にポリシーに渡されます。

> [!caution] 
> エンドツーエンドの特徴量は、トレーニングデータに実際に [[stories.md#エンドツーエンドのトレーニング|エンドツーエンドのトレーニング]] が含まれている場合にのみ計算され、ポリシーに提供されます。

**Rasa 2.0 (旧):**

```
from typing import List, Any

from rasa.core.policies.policy import Policy, PolicyPrediction
from rasa.shared.core.domain import Domain
from rasa.shared.core.generator import TrackerWithCachedStates
from rasa.shared.core.trackers import DialogueStateTracker
from rasa.shared.nlu.interpreter import NaturalLanguageInterpreter

class MyPolicy(Policy):
    def train(
        self,
        training_trackers: List[TrackerWithCachedStates],
        domain: Domain,
        interpreter: NaturalLanguageInterpreter,
        **kwargs: Any,
    ) -> None:
        ...
        model_data, label_ids = self._prepare_for_training(
            training_trackers, domain, interpreter, **kwargs
        )
        ...

    def predict_action_probabilities(
        self,
        tracker: DialogueStateTracker,
        domain: Domain,
        interpreter: NaturalLanguageInterpreter,
        **kwargs: Any,
    ) -> PolicyPrediction:
        ...
        tracker_state_features = self._featurize_tracker_for_e2e(
            tracker, domain, interpreter
        )
        ...
```

**Rasa 3.0 (新機能):**

```
from typing import List, Optional, Dict, Text, Any

from rasa.core.featurizers.precomputation import MessageContainerForCoreFeaturization
from rasa.core.policies.policy import PolicyPrediction, Policy
from rasa.engine.recipes.default_recipe import DefaultV1Recipe
from rasa.engine.storage.resource import Resource
from rasa.shared.core.domain import Domain
from rasa.shared.core.generator import TrackerWithCachedStates
from rasa.shared.core.trackers import DialogueStateTracker

@DefaultV1Recipe.register(
    DefaultV1Recipe.ComponentType.POLICY_WITH_END_TO_END_SUPPORT, is_trainable=True
)
class MyPolicy(Policy):
    def train(
        self,
        training_trackers: List[TrackerWithCachedStates],
        domain: Domain,
        precomputations: Optional[MessageContainerForCoreFeaturization] = None,
    ) -> Resource:
        ...
        model_data, label_ids = self._prepare_for_training(
          training_trackers, domain, precomputations,
        )
        ...

    def predict_action_probabilities(
        self,
        tracker: DialogueStateTracker,
        domain: Domain,
        precomputations: Optional[MessageContainerForCoreFeaturization] = None,
        rule_only_data: Optional[Dict[Text, Any]] = None,
        **kwargs: Any,
    ) -> PolicyPrediction:
        ...
        tracker_state_features = self._featurize_tracker(
            tracker, domain, precomputations, rule_only_data=rule_only_data
        )
        ...
```

**ポリシーの登録**

カスタムポリシーを使用する前に、 `DefaultV1Recipe.register` デコレータを使用します。ポリシーでエンドツーエンドの機能が必要な場合は、グラフコンポーネントタイプ `POLICY_WITH_END_TO_END_SUPPORT` を指定します。それ以外の場合は、 `POLICY_WITHOUT_END_TO_END_SUPPORT` です。`トレイン`の場合は `is_trainable=True` を指定します。 メソッドは、トレーニング中に呼び出す必要があります。ポリシーが 推論中に使用されます `use is_trainable=False`。

**Rasa 2.0 (旧):**

```
from rasa.core.policies.policy import Policy

class MyPolicy(Policy):
    ...
```

**Rasa 3.0 (新機能):**

```
from rasa.core.policies.policy import Policy
from rasa.engine.recipes.default_recipe import DefaultV1Recipe

@DefaultV1Recipe.register(
    DefaultV1Recipe.ComponentType.POLICY_WITH_END_TO_END_SUPPORT,
    is_trainable=True
)
class MyPolicy(Policy):
    ...
```

**ポリシーへのルールのみのデータの提供**

Rasaでは、[ルール](rules.md)によって完全に処理される[フォーム](forms.md)や[スロット](domain.md#スロット)を除外し、他のポリシーの機能になることはありません。Rasa 2 では、この情報は、ポリシー属性を設定する `set_shared_policy_states` メソッドを使用してポリシーに渡されました `_rule_only_data`。Rasa は、ルールのみのスロットの名前とフォームを `predict_action_probabilities`メソッド。渡された`rule_only_data`は `None` にすることができます [[policies.md#ルールポリシー|ルールポリシー]] はモデル構成の一部ではありません。

**Rasa 2.0 (旧):**

```
from rasa.core.policies.policy import Policy
from typing import Any

class MyPolicy(Policy):

    def set_shared_policy_states(self, **kwargs: Any) -> None:
        """Sets policy's shared states for correct featurization."""
        self._rule_only_data = kwargs.get("rule_only_data", {})
```

**Rasa 3.0 (新機能):**

```
from typing import Optional, Dict, Text, Any

from rasa.core.policies.policy import Policy, PolicyPrediction
from rasa.shared.core.domain import Domain
from rasa.shared.core.trackers import DialogueStateTracker

class MyPolicy(Policy):
    def predict_action_probabilities(
        self,
        tracker: DialogueStateTracker,
        domain: Domain,
        rule_only_data: Optional[Dict[Text, Any]] = None,
  ) -> PolicyPrediction:
      ...
```

### トレーニングデータ

#### `バージョンを 2.0` `から` `3.0` にアップグレードする

トレーニング データ ファイルの先頭で、`バージョン: "2.0"` を`バージョン: "3.1"` に変更する必要があります。

トレーニング データ バージョンについては、セマンティック バージョン管理に従います。つまり、破壊的変更により新しいメジャーバージョンが作成され、新機能によって新しいマイナーバージョンが作成されます。最新のトレーニング データ バージョンは 3.1 です。

Rasa 3.0 の`スロット マッピング`の改善は重大な変更だったため、メジャー バージョン `2.0` からメジャー バージョン `3.0` にアップグレードする必要がありました。

#### `TrainingDataImporter`

`TrainingDataImporter` とそのすべての実装は、同期メソッドのみを含むように更新されます。カスタムデータインポーターがある場合、または`TrainingDataImporter`によって提供される一部の関数に依存している場合は、実装と関数呼び出しを更新する必要があります。

たとえば、Rasa 3.0 でのデータ読み込みは次のようになります。

```python
from typing import Text
from rasa.shared.importers.importer import TrainingDataImporter

def load_data(domain_path: Text, config_path: Text):
    file_importer = TrainingDataImporter.load_from_config(
        config_path, domain_path
    )
    # note that all the functions below were async before:
    config = file_importer.get_config()
    domain = file_importer.get_domain()
    stories = file_importer.get_stories()
    nlu_data = file_importer.get_nlu_data()
```

カスタムインポーターは `TrainingDataImporter` を実装するため、同期メソッドのみを含むようにカスタムインポーターも更新する必要があります。

```python
from typing import Dict

from rasa.shared.core.domain import Domain
from rasa.shared.importers.importer import TrainingDataImporter


class MyImporter(TrainingDataImporter):
    """Example partial implementation of a custom importer component."""

    # this function was async before
    def get_domain(self) -> Domain:
        pass

    # this function was also async before
    def get_config(self) -> Dict:
        pass

    # ...
```

`template_variables`引数と `e2e` 引数も `TrainingDataImporter` のメソッドから削除`get_stories`されました。その新しいシグネチャは次のようになります。

```python
from typing import Optional

from rasa.shared.nlu.interpreter import RegexInterpreter
from rasa.shared.core.training_data.structures import StoryGraph

class TrainingDataImporter:
    # ...

    def get_stories(
        self,
        interpreter: "NaturalLanguageInterpreter" = RegexInterpreter(),
        exclusion_percentage: Optional[int] = None,
    ) -> StoryGraph:
        pass

    # ...
```

### 訓練

#### `rasa train --dry-run`

モデルアーキテクチャの変更により、`rasa train --dry-run` の動作が変更されました。終了コードには、次の意味があります。

*   `0` は、モデルにコストのかかる再トレーニングが必要ないことを意味します。ただし、`rasa train` を実行して応答を更新する必要がある場合があります
*   `1` は、1 つまたは複数のコンポーネントを再トレーニングする必要があることを意味します。
*   `8` は、`--force` フラグが使用されたため、キャッシュされた結果は無視され、モデル全体が再トレーニングされることを意味します。

### 機械学習コンポーネント

#### `DIETClassifier` と `ResponseSelector` の信頼度の正規化

`DIETClassifier` と `ResponseSelector` は、`ranking_length` が `0` より大きい値に設定されている場合、再正規化された信頼度を自動的に報告しなくなりました。この変更は、報告された信頼度に影響しますが、ポリシーで使用される可能性のある最終的な予測インテントには影響しません。ただし、報告された信頼度は影響を受けるため、フォールバックメカニズムのしきい値を再度調整する必要がある場合があります。以前の動作は、`renormalize_confidences=True` を設定することで引き続き適用できます `model_confidence=softmax` を使用する場合。

#### `TEDPolicy`における信頼度の正規化

`TEDPolicy`の予測は、マスキングやリオーマライズによって変更されなくなります 打ち明ける。この変更は、 `TEDポリシー`、それによって政策アンサンブルの最終結果に影響を与えます。 ただし、以前の動作は、 `ranking_length=10` および `renormalize_confidences=True` です。

#### 削除されたポリシー

Rasa 2.x で非推奨だったいくつかの対話ポリシーは、Rasa 3.0 で削除されました。ポリシーが削除された設定ファイルを移行する場合は、個々のポリシーについて次の移行ガイドを参照してください。

*   `FallbackPolicy` [[#フォールバックポリシーからの手動移行]]
*   `TwoStageFallbackPolicy` [[#2 段階フォールバック ポリシーからの手動移行|移行ガイドからの移行]]
*   `MappingPolicy` [[#マッピングポリシーからの手動移行]]
*   `フォームポリシー` [[#フォーム]]
*   `SklearnPolicy` は [[./policies#TEDポリシー|TEDポリシー]]。[[./model-configuration#推奨される構成|default TEDPolicy config]]を出発点として使用することをお勧めします。

#### 削除されたトークナイザーと特徴付け

`ConveRTTokenizer`、`LanguageModelTokenizer`、`HFTransformersNLP` フィーチャチャライザー コンポーネントは Rasa 2.x で非推奨となり、Rasa 3.0 で削除されました。パイプライン内のこれらのコンポーネントを置き換えるには、[[#非推奨|Rasa 2.x の移行ガイド]] を参照してください。

### スロットマッピング

バージョン 3.0 では、ドメインファイルの `slots` セクションで各スロットのスロットマッピングを定義することで、スロットを埋めるための明示的なメカニズムが 1 つあります。このアプローチにより、会話の過程でスロットを最新の状態に保ち、同じスロットを複数のフォームでマッピングする際の重複作業が排除されます。任意のカスタムアクションからスロットを埋め、その動作が必要な場合は、会話のターンごとに更新しないことは可能です。

この新しいメカニズムは、スロットの自動入力による暗黙的なスロット設定を、同じ名前のエンティティに置き換えます。ドメイン内の`auto_fill`キーと、`Slot`クラスのコンストラクターの`auto_fill`パラメーターは使用できなくなりました。

フォームが次のスロットを要求し続ける間、スロットの抽出はデフォルトのアクション [[./default-actions.md#action_extract_slots|`action_extract_slots`]]。このアクションは、各ユーザターン後にバックグラウンドで自動的に実行されます。`action_listen`のように、それは物語に含めるべきではありません。

`スロット`セクションの各スロットには`、マッピング`キーが含まれている必要があります。2.0 で定義済みのマッピングに使用されたのと同じキーが 3.0 でも使用できます。さらに、カスタム アクションに実装されたカスタム マッピングを使用してスロットを定義し、ユーザー ターンごとに実行されます。

```yaml
slots:
  is_existing_customer:
    type: bool
    mappings:
    - type: custom
      action: action_verify_customer_status
```

[スロット検証アクション](./slot-validation-actions.md)を使用して、事前定義されたマッピングを使用してスロットを検証するか、カスタムマッピングを使用してスロットを抽出および検証することができます。

会話の過程で任意のカスタムアクションによって埋められ、ユーザーターンごとに更新されるべきではないスロットは、`カスタム`型でアクションなしのマッピングで一覧表示する必要があります。例えば：

```yaml
slots:
  handoff_completed:
    type: bool
    initial_value: false
    mappings:
    - type: custom
```

このスロットの値は、それを設定するカスタムアクションが予測された場合にのみ変更されます。このマッピングは、エンティティまたはフォーム内のスロットマッピングによって入力されなかったスロットの 2.x からの動作を維持します。

> [!note]
>  フォームの`required_slots`は、以前はスロットマッピングのリストでした。スロットマッピングはドメインの`スロット`セクションに再配置されるため、`required_slots`スロット名のみのリストに変換されました。

#### 2.0 ドメイン形式から 3.0 形式への自動移行

フォーマットが変更されたデータファイルはドメインファイルのみです。3.0 ドメイン形式に自動的に移行するには、次のコマンドを実行します。

```bash
rasa data migrate -d DOMAIN --out OUT_PATH
```

このコマンドは、指定された出力パスに有効な 3.0 ドメインを作成するだけでなく、代わりにディレクトリが指定されている場合は、`original_domain.yml` または `original_domain` ディレクトリというラベルの付いたファイルに元のドメイン ファイルを自動的にバックアップします。

2.0 形式のフォームの動作を維持するために、移行されたすべてのスロット マッピングには、各フォームのマッピング条件が含まれます。これは、ユースケースに応じて手動で変更できます。詳細については、[[./domain.md#マッピング条件|マッピング条件]]のドキュメントを参照してください。

#### 2.0 ドメイン形式から 3.0 形式への手動移行

ドメインの`スロット`セクションの各スロットには、新しいキー`マッピング`が必要です。このキーはフォームから移動されたマッピングのリストであり、`required_slots`フィールドはスロット名のリストに折りたたまれます。

次の 2.0 ドメイン ファイルを考えてみましょう。

```yaml
entities:
 - cuisine
 - number
slots:
   cuisine:
     type: text
   num_people:
     type: float
   outdoor_seating:
     type: bool
forms:
   restaurant_form:
     required_slots:
         cuisine:
           - type: from_entity
             entity: cuisine
         num_people:
           - type: from_entity
             entity: number
         outdoor_seating:
           - type: from_intent
             intent: affirm
             value: true
           - type: from_intent
             intent: deny
             value: false
```

このドメインを 3.0 形式に移行した場合の初期結果は、次のようになります。

```yaml
entities:
 - cuisine
 - number
slots:
   cuisine:
     type: text
     mappings:
     - type: from_entity
       entity: cuisine
   num_people:
     type: float
     mappings:
     - type: from_entity
       entity: number
   outdoor_seating:
     type: bool
     mappings:
     - type: from_intent
       intent: affirm
       value: true
     - type: from_intent
       intent: deny
       value: false
forms:
   restaurant_form:
     required_slots:
     - cuisine
     - num_people
     - outdoor_seating
```

フォームのコンテキストでのみ入力する必要があるスロットの場合は、[[./domain.md#マッピング条件|マッピング条件]] を追加して、どのフォームをアクティブにするかを指定し、`requested_slot`を同じスロットにする必要があるかどうかを指定します。スロットマッピングの動作を維持するには、`2.0からの条件`を追加する必要がありますが、条件がないと、フォームがアクティブかどうかに関係なく、マッピングがユーザーターンごとに適用されるためです。

```yaml
 slots:
   outdoor_seating:
     type: bool
     mappings:
     - type: from_intent
       intent: affirm
       value: true
       conditions:
       - active_loop: restaurant_form
         requested_slot: outdoor_seating
     - type: from_intent
       intent: deny
       value: false
       conditions:
       - active_loop: restaurant_form
         requested_slot: outdoor_seating
```

#### Rasa-SDK の変更

`FormValidationAction` を使用して、`required_slots` メソッドをオーバーライドするカスタム抽出および検証コードを定義した場合は、`引数slots_mapped_in_domain` `domain_slots` 引数に置き換えられていることに注意してください。カスタムコードを引き続き使用するには、この置換を行う必要があります。

`domain.yml` ファイルで定義されているフォームの`required_slots`に存在しないスロットを動的に埋めている場合、この動作は 3.x ではサポートされなくなったことに注意してください。最後のユーザーターンに設定されたカスタムマッピングを持つ動的スロットは、`FormValidationAction` から継承するカスタムアクションの`required_slots`メソッドによって返された**場合にのみ**埋められます。2.x の動作を維持するには、[[./forms.md#動的フォームの動作|動的フォームのドキュメント]] に記載されている強力な推奨事項に従って、このカスタムアクションの`required_slots`メソッドをオーバーライドする必要があります。

フォームの`required_slots`で定義されていないカスタムスロットを抽出するには、グローバル [[./domain.md#カスタムスロットマッピング|カスタムスロットマッピング]] を使用し、[[./action-server/validation-action.md#validationaction class|ValidationAction クラス]] を使用します。


> [!note] 
> メソッドをオーバーライドする `FormValidationAction` を拡張するカスタム検証アクションがある場合は、移行されたアシスタントの動的なフォーム動作を再確認`required_slots`必要があります。既定のアクション [[./default-actions.md#action_extract_slots|`action_extract_slots`]] によって設定されたスロットは、フォームの必要なスロットのカスタム検証アクションによって、フォームのコンテキスト内でリセットする必要がある場合があります。たとえば、最初のスロットがいっぱいになった後、フォームで必要なスロットが動的に追加される場合、最初の必須スロットの検証方法の一部として、必要なスロットをリセットして、追加時に空になるようにすることができます。

## ラサ 2.7 から 2.8

> [!caution] 
> このリリースでは**、機械学習モデルの下位互換性が損なわれます**。以前のバージョンの Rasa でトレーニングされたモデルを読み込むことはできません。このバージョンを使用する前に、アシスタントを再トレーニングしてください。

### 非推奨

#### トラッカー機能化

`TrackerFeaturizer`、`FullDialogueTrackerFeaturizer`、および`MaxHistoryTrackerFeaturizer`クラスの `training_states_actions_and_entities` メソッドは非推奨であり、Rasa 3.0で削除されます。上記のクラスのいずれかからこのメソッドに依存するカスタムトラッカー特徴付け器がある場合は、代わりに使用 `training_states_labels_and_entities` してください。

`TrackerFeaturizer`、`FullDialogueTrackerFeaturizer`、`MaxHistoryTrackerFeaturizer` クラスのメソッド`training_states_and_actions`非推奨となり、Rasa 3.0 で削除されます。上記のクラスのいずれかのこのメソッドに依存するカスタムトラッカー特徴付け器がある場合は、代わりに`training_states_and_labels`を使用してください。

#### 状態特徴付け

`SingleStateFeaturizer`クラスの`メソッドencode_all_actions`非推奨であり、Rasa 3.0で削除されます。代わりにメソッド`encode_all_labels`を使用することをお勧めします。

### 増分トレーニング

ユーザーは、増分トレーニング中にスパース特徴付け器に追加のバッファー サイズを指定する必要がなくなりました。

新しいスパース特徴量のためのスペースは、下流の機械学習モデル(`DIETClassifier`、`ResponseSelector`)内に動的に作成されます。つまり、追加の語彙項目に対して追加のバッファーが事前に作成されず、モデル内でそれらの項目にスペースが動的に割り当てられます。

つまり、`additional_vocabulary_size`を指定する必要はありません。 [`CountVectorsFeaturizer`](./components.md#countvectorsfeaturizer) または [`RegexFeaturizer`](./components.md#regexfeaturizer) の`number_additional_patterns`。これらのパラメーターは非推奨になりました。

**以前は**

```yaml
pipeline:
  - name: "WhitespaceTokenizer"
  - name: "RegexFeaturizer"
    number_additional_patterns: 100
  - name: "CountVectorsFeaturizer"
    additional_vocabulary_size: {text: 100, response: 20}
```

**今**

```yaml
pipeline:
  - name: "WhitespaceTokenizer"
  - name: "RegexFeaturizer"
  - name: "CountVectorsFeaturizer"
```

### 機械学習コンポーネント

オプション `model_confidence=linear_norm` は非推奨であり、Rasa `3.0.0` で削除されます。

Rasa `2.3.0` では、`model_confidence` の可能な値として `linear_norm` が導入されました。 `DIETClassifier`、`ResponseSelector`、`TEDPolicy`などの機械学習コンポーネントのパラメーター。ユーザーからのフィードバックに基づいて、このオプションに関する複数の問題が特定されました。したがって、`model_confidence=linear_norm` は非推奨となり、Rasa `3.0.0` で削除されます。上記のコンポーネントのいずれかに `model_confidence=linear_norm` を使用していた場合は、`model_confidence=softmax` に戻してアシスタントを再トレーニングすることをお勧めします。再トレーニング後、[フォールバックコンポーネントのしきい値を再調整](./fallback-handoff.md#フォールバック)することもお勧めします。

## ラサ2.5から2.6

### フォーム

#### フォームの新しい`ignored_intents`パラメーター

フォームの下に`ignored_intents`という新しいパラメータがあります。このパラメーターを使用して、フォーム内の必要なスロットに指定されたインテントが入力されないようにすることができます。`domain.yml`ファイルでの使用方法の例と詳細については、[フォームのドキュメント](forms.md)を参照してください。

以前は、ユーザーがフォームのスロットに指定されたインテントを埋めたくない場合は、次の例に示すように、すべてのスロットマッピングの `not_intent` パラメーターで定義する必要がありました。

```yaml-rasa
forms:
  restaurant_form:
      cuisine:
      - type: from_entity
        entity: cuisine
        not_intent: chitchat
      num_people:
      - type: from_entity
        entity: number
        intent: [inform, request_restaurant]
        not_intent: chitchat
      feedback:
      - type: from_entity
        entity: feedback
        not_intent: chitchat
```

`ignored_intents`パラメータを導入することで、1か所で定義するだけでよくなり、次の形式のすべてのスロットに影響します。

```yaml-rasa
forms:
  restaurant_form:
    ignored_intents: chitchat
    required_slots:
      cuisine:
      - type: from_entity
        entity: cuisine
      num_people:
      - type: from_entity
        entity: number
        intent: [inform, request_restaurant]
      feedback:
      - type: from_entity
        entity: feedback
      - type: from_text
```

## ラサ 2.4 から 2.5

### 機械学習コンポーネント

#### `DIET、``TED`、および`ResponseSelector`

`DIETClassifier` の以前の `weight_sparsity` パラメーター、`TEDPolicy`、および `ResponseSelector` は非推奨になり、新しい `connection_density` パラメーターに置き換えられました。古い`weight_sparsity`は、非常に低い密度(高いスパーリティ)を除いて、`ほぼ1〜connection_density`に相当します。

非推奨の問題を回避するには、`connection_density` を 構成ファイル `1 - your former weight_sparsity setting` 全体。(去った場合 `weight_sparsity`デフォルト設定では、何もする必要はありません。

#### SpaCy 3.0 (英語)

RasaはspaCy 3.0をサポートするようになりました。これは、より多くの機能をサポートできることを意味します 言語ですが、これにより破壊的変更も導入されました。SpaCy 3.0 では、 `spacy link <language model>` コマンドを使用します。したがって、これからは `config.yml` ファイル内の[完全なモデル名](https://spacy.io/models)。

**以前は**

`spacy link en en_core_web_md`を実行する前に、`言語`パラメータから正しいモデルを取得できるようになりました。

```yaml
language: en

pipeline:
   - name: SpacyNLP
```

**今**

この動作は非推奨になり、代わりに`config.yml`で明示的にする必要があります。

```yaml
language: en

pipeline:
   - name: SpacyNLP
     model: en_core_web_md
```

**フォールバック**

移行を容易にするために、Rasa は、`モデル`を指定しなくても、`config.yml` のパイプライン全体に対して互換性のある言語が構成されるたびに、中程度の spaCy モデルへのフォールバックを試みます。このフォールバック動作は一時的なものであり、Rasa 3.0.0 では非推奨になります。

これらの変更を反映するためにドキュメントを更新しました。すべての例で、正しい spaCy モデルへの直接リンクが表示されるようになりました。また、[スペーシーNLP](components.md#スペーシーNLP) に警告を追加しました フォールバック動作を説明するドキュメント。

## Rasa 2.3 から Rasa 2.4 へ

### `応答`の`テンプレート`の非推奨

NLGサーバー

*   リクエスト形式を変更し、`応答`と`テンプレート`をフィールドとして送信するように変更しました。`テンプレート`フィールドは、Rasa 3.0.0で削除されます。

`rasa.core.agent`

*   用語`テンプレート`は非推奨になり、`応答`に置き換えられます。NLG 応答からの`テンプレート`のサポートは、Rasa 3.0.0 で削除されます。詳しくは[こちら](./nlg.md)をご覧ください。

`rasa.core.nlg.generator`

*   `generate() は``utter_action`をパラメータとして受け取るようになりました。
*   用語`テンプレート`は非推奨になり、`応答`に置き換えられます。`NaturalLanguageGenerator` での`テンプレート`のサポートは、Rasa 3.0.0 で削除されます。

`rasa.shared.core.domain`

*   プロパティ `テンプレート`は非推奨です。代わりに`応答`を使用してください。Rasa 3.0.0 では削除されます。
*   `retrieval_intent_templates`は Rasa 3.0.0 で削除されます。代わりに`retrieval_intent_responses`をご利用ください。
*   `is_retrieval_intent_template`は Rasa 3.0.0 で削除されます。代わりに`is_retrieval_intent_response`をご利用ください。
*   `check_missing_templates`は Rasa 3.0.0 で削除されます。代わりに`check_missing_responses`をご利用ください。

応答セレクター

*   フィールド`template_name`は、Rasa 3.0.0 で非推奨になります。代わりに`utter_action`をご利用ください。詳しくは[こちら](./components.md#selectors)をご覧ください。
*   フィールド`response_templates`は、Rasa 3.0.0 では非推奨になります。代わりに`応答`を使用してください。詳しくは[こちら](./components.md#selectors)をご覧ください。

## Rasa 2.3.3 から Rasa 2.3.4 へ

> [!caution] 
> これは、**機械学習モデルの下位互換性を損なう**リリースです。以前にトレーニングされたモデルが `model_confidence=cosine` または `model_confidence=内部`設定。この改良版でアシスタントを使用する前に、必ずアシスタントを再トレーニングしてください。

### 機械学習コンポーネント

Rasa `2.3.0`では、`model_confidence=cosine`を設定することで、モデルの信頼度にコサイン類似性を使用するオプションが導入されました。いくつかのリリース後の実験では、`model_confidence=cosine`を使用すると、予測されたラベルの順序が変わる可能性があるため、間違っていることが明らかになりました。そのため、このオプションはRasaバージョン`2.3.4`で削除されました。

`model_confidence=inner` は、他のさまざまな場所でアシスタントのロジックを壊す可能性がある無制限の範囲の信頼度を生成するため、非推奨です。

`model_confidence=linear_norm` を試してみると、範囲 `[0,1]` 内の各値との内積類似性の線形正規化バージョンが生成されます。これは、次の設定で実行できます。

```
- name: DIETClassifier
  model_confidence: linear_norm
  constrain_similarities: True
```

以前のバージョンの Rasa を使用して `model_confidence=cosine` または `model_confidence=inner` 設定でモデルをトレーニングした場合は、構成から `model_confidence` オプションを削除するか、`linear_norm` に設定して再トレーニングしてください。

## Rasa 2.2 から Rasa 2.3 へ

### 全般

`DIETClassifier`、`ResponseSelector`、または`TEDPolicy`にTensorboardを使用し、(ミニ)バッチごとにメトリックをログに記録する場合は、 'tensorboard_log_level'として 'minibatch' ではなく 'batch' を使用してください。

### 機械学習コンポーネント

機械学習 (ML) コンポーネント `DIETClassifier`、`ResponseSelector`、`および TEDPolicy` 内の損失関数にいくつかの変更が加えられました。これらには次のものが含まれます。

1.  構成オプション `loss_type=softmax` は非推奨となり、Rasa 3.0.0 で削除されます。代わりに `loss_type=cross_entropy` を使用してください。
2.  デフォルトの損失関数 (`loss_type=cross_entropy`) は、すべての類似性値のオプションのシグモイドクロスエントロピー損失を追加して、それらをおおよその範囲に制限できます。このオプションを有効にするには、`constrain_similarities=True` を設定します。これにより、実際のテストセットでモデルのパフォーマンスが向上します。

各 ML コンポーネントに新しいオプション`model_confidence`が追加されました。これは、推論中に各ラベルに対するモデルの信頼度がどのように計算されるかに影響します。次の 3 つの値のいずれかを取ることができます。

1.  `softmax` - 入力埋め込みとラベル埋め込みの間の内積の類似性は、softmax関数で後処理され、その結果、すべてのラベルの信頼度の合計は1になります。
2.  `cosine` - 入力埋め込みとラベル埋め込みのコサイン類似性。各ラベルの信頼度は `[-1,1]` の範囲になります。
3.  `linear_norm` - 入力埋め込みとラベル埋め込みの間の内積の類似性は、線形正規化関数で後処理されます。各ラベルの信頼度は `[0,1]` の範囲になります。

デフォルト値は `softmax` ですが、`linear_norm`試すことをお勧めします。これにより、[フォールバックをトリガーするためのしきい値を簡単に調整](./fallback-handoff.md#フォールバック)できるようになります。このオプションの値は、`DIETClassifier` でのエンティティ予測の信頼度の計算方法には影響しません。

上記の推奨事項の両方を試してみることをお勧めします。これは、次の設定で実行できます。

```
- name: DIETClassifier
  model_confidence: linear_norm
  constrain_similarities: True
  ...
```

アシスタントが上記の構成で再トレーニングされたら、ユーザーは[フォールバック信頼度のしきい値も調整](./fallback-handoff.md#フォールバック)する必要があります。

**編集**:リリース後のいくつかの実験では、`model_confidence = cosine`を使用すると、予測されたラベルの順序が変わる可能性があるため、間違っていることが明らかになりました。そのため、このオプションはRasaバージョン`2.3.4`で削除されました。

## Rasa 2.1 から Rasa 2.2 へ

### 全般

`TEDPolicy` の `transformer_size`、`number_of_transformer_layers`、`および dense_dimensions` パラメーターの名前が変更されました。次のマッピングを使用して構成ファイルを更新してください。

| 古いモデルパラメータ | 新しいモデルパラメータ |
| --- | --- |
| transformer_size | キー付き辞書transformer_size |
|  | テキスト、action_text、label_action_text、対話 |
| number_of_transformer_layers | キー付きディクショナリnumber_of_transformer_layers |
|  | テキスト、action_text、label_action_text、対話 |
| dense_dimension | キー付き辞書dense_dimension |
|  | テキスト、action_text、label_action_text、インテント、 |
|  | action_name、label_action_name、エンティティ、スロット、 |
|  | active_loop |

例えば：

```yaml-rasa
policies:
  - name: TEDPolicy
    transformer_size:
      text: 128
      action_text: 128
      label_action_text: 128
      dialogue: 128
    number_of_transformer_layers:
      text: 1
      action_text: 1
      label_action_text: 1
      dialogue: 1
    dense_dimension:
      text: 128
      action_text: 128
      label_action_text: 128
      intent: 20
      action_name: 20
      label_action_name: 20
      entities: 20
      slots: 20
      active_loop: 20
```

### 非推奨

#### マークダウンデータ

Markdown 形式のトレーニング データとテスト データは非推奨になりました。これも:

*   Markdown 形式のストーリー ファイルの読み取りと書き込み
*   Markdown 形式の NLU データの読み取りと書き込み
*   Markdown 形式での検索意図データの読み取りと書き込み

Markdown データのサポートは、Rasa 3.0.0 で完全に削除されます。

[[./migration-guide.md#トレーニングデータファイル|here]] で説明されているコマンドを使用して、既存の Markdown データを変換してください。

### 檄

[ポリシーでは、](./policies.md)コンストラクターと `load` メソッドに `**kwargs` 引数が必要になりました。`**kwargs` のないポリシーは、Rasa バージョン `3.0.0` までサポートされます。ただし、[[./command-line-interface.md#段階的なトレーニング|段階的なトレーニング]] **`kwargs` を含める**必要があります**。

#### 他

*   `Domain.random_template_for`は非推奨であり、Rasa 3.0.0 で削除されます。または、 を使用する `TemplatedNaturalLanguageGenerator` こともできます。
*   `Domain.action_names`は非推奨であり、Rasa 3.0.0 で削除されます。代わりに`Domain.action_names_or_texts`をご利用ください。

## Rasa 2.0 から Rasa 2.1 へ

### 非推奨

`ConveRTTokenizer` は非推奨になりました。[ConveRTFeaturizer](./components.md#convertfeaturizer) は、その動作を実装するようになりました。移行するには、`ConveRTTokenizer` を他のトークナイザーに置き換えます。

```yaml
pipeline:
    - name: WhitespaceTokenizer
    - name: ConveRTFeaturizer
      model_url: <Remote/Local path to model files>
    ...
```

`HFTransformersNLP` および `LanguageModelTokenizer` コンポーネントは非推奨になりました。 [LanguageModelFeaturizer](./components.md#languagemodelfeaturizer) は、その動作を実装するようになりました。移行するには、上記の両方のコンポーネントを任意のトークナイザーに置き換え、モデル アーキテクチャとモデルの重みを `LanguageModelFeaturizer` の一部として指定します。

```yaml
pipeline:
    - name: WhitespaceTokenizer
    - name: LanguageModelFeaturizer
      model_name: "bert"
      model_weights: "rasa/LaBSE"
    ...
```

## Rasa 1.10からRasa 2.0へ

### 全般

バージョン2.0では多くの変更が加えられました。このガイドをよく読んで、ボットのすべての部分が更新されていることを確認してください。多くの更新は組み込みコマンドで自動的に実行できますが、手動変換が必要なものもあります。これらの更新プログラムまたは移行プロセスに関するフィードバックがある場合は、[フォーラム](https://forum.rasa.com/t/rasa-open-source-2-0-is-out-now-internal-draft/35577)に投稿してください。

### トレーニングデータファイル

バージョン 2.0 では、新しい既定のトレーニング データ形式は yaml です。Markdown は引き続きサポートされていますが、これは Rasa 3.0.0 で非推奨になります。

次のコマンドを使用して、Markdown 形式の既存の NLU、ストーリー、および NLG (`つまり responses.md`) トレーニング データ ファイルを新しい YAML 形式に変換できます。

```bash
rasa data convert nlu -f yaml --data={SOURCE_DIR} --out={TARGET_DIR}
rasa data convert nlg -f yaml --data={SOURCE_DIR} --out={TARGET_DIR}
rasa data convert core -f yaml --data={SOURCE_DIR} --out={TARGET_DIR}
```

変換されたファイルは元のファイルと同じ名前になりますが、 `_converted.yml`接尾辞。

[[./migration-guide.md#フォーム|フォーム]]または [[./migration-guide.md#応答セレクター|応答セレクター]] を使用している場合は、それぞれのセクションで説明されているように、いくつかの追加変更を行う必要があります。

### 檄

[ルール](./rules.md)の導入と [[./policies.md#ルールポリシー|RulePolicy]]の場合、次のポリシーは非推奨です。

*   [マッピングポリシー](https://rasa.com/docs/rasa/2.x/policies#mapping-policy)
*   [フォールバックポリシー](https://rasa.com/docs/rasa/2.x/policies#fallback-policy)
*   [2 段階のフォールバック ポリシー](https://rasa.com/docs/rasa/2.x/policies#two-stage-fallback-policy)
*   [フォームポリシー](https://rasa.com/docs/rasa/2.x/policies#form-policy)

ポリシーを自動的に移行するには、次のコマンドを実行します。

```bash
rasa data convert config
```

このコマンドは、`.bak` サフィックスを使用して既存のファイルのバックアップを作成しながら、`config.yml`と`domain.yml`を更新します。また、 必要に応じて`rules.yml`してください。

この更新後も、フォームは古い形式で通常どおり機能しますが、このコマンドではフォームが自動的に新しい形式に変換されることはありません。これは、[フォーム](./migration-guide.md#forms)のセクションで説明されているように、手動で行う必要があります。

自動変換コマンドを使用しない場合は、個々のポリシーを手動で移行することもできます。

#### マッピングポリシーからの手動移行

以前に[マッピングポリシー](https://rasa.com/docs/rasa/2.x/policies#mapping-policy)を使用した場合は、[FAQ](./chitchat-faqs.md)のドキュメントに従って、マッピングされたインテントをルールに変換できます。以前にインテント`ask_is_bot`を次のようにマッピングしたとします。

```yaml-rasa
intents:
 - ask_is_bot:
     triggers: action_is_bot
```

これは次のルールになります。

```yaml-rasa
rules:
- rule: Rule to map `ask_is_bot` intent
  steps:
  - intent: ask_is_bot
  - action: action_is_bot
```

また、次の`トリガー`を安全に削除できます。

```yaml-rasa
intents:
 - ask_is_bot
```

最後に、マッピング ポリシーを [[./policies.md#ルールポリシー|ルールポリシー]] をモデル構成で使用します。

```yaml-rasa
policies:
  # Other policies
  - name: RulePolicy
```

#### フォールバックポリシーからの手動移行

以前に[フォールバック ポリシー](https://rasa.com/docs/rasa/2.x/policies#fallback-policy)を使用した場合、次のモデル構成は、次のような以前の構成の場合、次のように変換されます。

```yaml-rasa
policies:
  - name: "FallbackPolicy"
    nlu_threshold: 0.4
    core_threshold: 0.3
    fallback_action_name: "action_default_fallback"
    ambiguity_threshold: 0.1
```

新しい構成は次のようになります。

```yaml-rasa
recipe: default.v1
pipeline:
  # Other components
  - name: FallbackClassifier
    threshold: 0.4
    ambiguity_threshold: 0.1

policies:
  # Other policies
  - name: RulePolicy
    core_fallback_threshold: 0.3
    core_fallback_action_name: "action_default_fallback"
```

さらに、NLU の信頼度が低い場合に実行するアクション[を指定するルールを追加](./rules.md)する必要があります。

```yaml-rasa
rules:
  - rule: Ask the user to rephrase whenever they send a message with low NLU confidence
    steps:
    - intent: nlu_fallback
    - action: utter_please_rephrase
```

詳細については、[フォールバック](./fallback-handoff.md#フォールバック)に関するドキュメントを参照してください。

#### 2 段階フォールバック ポリシーからの手動移行

以前に [2 段階フォールバック ポリシー](https://rasa.com/docs/rasa/2.x/policies#two-stage-fallback-policy)を使用した場合、次のような構成で、次のようになります。

```yaml-rasa
policies:
  - name: TwoStageFallbackPolicy
    nlu_threshold: 0.4
    ambiguity_threshold: 0.1
    core_threshold: 0.3
    fallback_core_action_name: "action_default_fallback"
    fallback_nlu_action_name: "action_default_fallback"
    deny_suggestion_intent_name: "out_of_scope"
```

新しい設定は次のようになります。

```yaml-rasa
recipe: default.v1
pipeline:
  # Other components
  - name: FallbackClassifier
    threshold: 0.4
    ambiguity_threshold: 0.1

policies:
  # Other policies
  - name: RulePolicy
    core_fallback_threshold: 0.3
    core_fallback_action_name: "action_default_fallback"
```

さらに、NLU の信頼度が低いメッセージに対して 2 段階フォールバックをアクティブにする[ルール](./rules.md)を追加する必要があります。

```yaml-rasa
rules:
  - rule: Implementation of the TwoStageFallbackPolicy
    steps:
    # This intent is automatically triggered by the `FallbackClassifier` in the NLU
    # pipeline in case the intent confidence was below the specified threshold.
    - intent: nlu_fallback
    # The Fallback is now implemented as a form.
    - action: action_two_stage_fallback
    - active_loop: action_two_stage_fallback
```

前の`fallback_nlu_action_name`パラメータは、 `deny_suggestion_intent_name`は構成できなくなり、固定値になります `action_default_fallback`と`out_of_scope`。

詳細については、[フォールバック](./fallback-handoff.md#フォールバック)のドキュメントを参照してください。

### フォーム

バージョン 2.0 以降、[フォーム](./forms.md)のロジックは Rasa SDK から Rasa に移行され、実装が簡素化され、他の言語でのアクション サーバーの作成が容易になりました。

つまり、フォームは `FormAction` を使用して実装されなくなり、代わりにドメインで定義されます。スロットの要求または [[./forms.md#フォーム入力の検証|フォーム入力の検証]] に関するカスタマイズは、`FormValidationAction` で処理できます。

次のように、1.x からのカスタムフォームアクションを考えてみましょう。

```python
from typing import Text, List, Any, Dict, Union
from rasa_sdk import Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms  import FormAction

class RestaurantForm(FormAction):
    def name(self) -> Text:
        return "restaurant_form"

    @staticmethod
    def required_slots(tracker: Tracker) -> List[Text]:
        return ["cuisine"]

    def slot_mappings(self) -> Dict[Text, Union[Dict, List[Dict]]]:
        return {
            "cuisine": self.from_entity(entity="cuisine", not_intent="chitchat"),
        }

    @staticmethod
    def cuisine_db() -> List[Text]:
        """Database of supported cuisines"""

        return ["caribbean", "chinese", "french"]

    def validate_cuisine(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validate cuisine value."""

        if value.lower() in self.cuisine_db():
            # validation succeeded, set the value of the "cuisine" slot to value
            return {"cuisine": value}
        else:
            dispatcher.utter_message(template="utter_wrong_cuisine")
            # validation failed, set this slot to None, meaning the
            # user will be asked for the slot again
            return {"cuisine": None}

    def submit(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Define what the form has to do
            after all required slots are filled"""

        # utter submit template
        dispatcher.utter_message(template="utter_submit")
        return []
```

FormPolicy を削除し、[[./policies.md#ルールポリシー|ルールポリシー]] (まだ存在していない場合) をモデル構成に追加します。

```yaml-rasa
policies:
  # Other policies
  # ...
  - name: RulePolicy
```

次に、[[./forms.md#フォームの定義|forms]] のドキュメントで説明されているように、ドメイン内のフォーム、必要なスロット、およびそれらのスロットマッピングを定義する必要があります。

```yaml-rasa
forms:
  restaurant_form:
    cuisine:
    - type: from_entity
      entity: cuisine
      not_intent: chitchat
```

[[./migration-guide.md#トレーニングデータファイル|convert your stories]] コマンドを実行すると、次のようにフォームのアクティブ化と非アクティブ化を処理するストーリーが作成されます。

```yaml-rasa
stories:
  - story: cuisine form
    steps:
    - intent: request_restaurant
    - action: restaurant_form
    - active_loop: restaurant_form
    - active_loop: null
    - action: utter_submit
```

これは正常に機能しますが、フォームの動作を処理する最善の方法は、このストーリーを削除し、代わりにフォームのアクティブ化と送信に関する 2 つの個別のルールを定義することです。

```yaml-rasa
rules:
  - rule: Activate form
    steps:
    - intent: request_restaurant
    - action: restaurant_form
    - active_loop: restaurant_form

  - rule: Submit form
    condition:
    # Condition that form is active.
    - active_loop: restaurant_form
    steps:
    - action: restaurant_form
    - active_loop: null
    # The action we want to run when the form is submitted.
    - action: utter_submit
```

最後のステップは、フォームスロットを検証するカスタムアクションを実装することです。まず、カスタム アクションをドメインに追加します。

```yaml-rasa
actions:
  # Other actions
  # ...
  - validate_restaurant_form
```

次に、`料理`スロットを検証するカスタムアクションを追加します。

```python
from typing import Text, List, Any, Dict, Union
from rasa_sdk import Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk import FormValidationAction
from rasa_sdk.types import DomainDict

class RestaurantFormValidator(FormValidationAction):
    def name(self) -> Text:
        return "validate_restaurant_form"

    @staticmethod
    def cuisine_db() -> List[Text]:
        """Database of supported cuisines"""

        return ["caribbean", "chinese", "french"]

    def validate_cuisine(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: DomainDict,
    ) -> Dict[Text, Any]:
        """Validate cuisine value."""

        if slot_value.lower() in self.cuisine_db():
            # validation succeeded, set the value of the "cuisine" slot to value
            return {"cuisine": slot_value}
        else:
            # validation failed, set this slot to None, meaning the
            # user will be asked for the slot again
            return {"cuisine": None}
```

また、Rasa SDK から Rasa 2 にフォームを繰り返し移行することもできます。たとえば、1 つのフォームを Rasa 2 実装に移行し、別のフォームには非推奨の Rasa SDK 実装を引き続き使用できます。非推奨の Rasa SDK `FormAction`を引き続き使用するには、フォームの名前を含むカスタムアクションをドメインに追加します。非推奨の `FormAction` が Rasa 3 の Rasa SDK から削除されるため、できるだけ早く移行を完了する必要があることに注意してください。

```yaml-rasa
actions:
# Adding a custom action for a form will
# instruct Rasa to use the
# deprecated Rasa SDK implementation of forms.
- my_form

forms:
 my_form:
```

詳細については、[フォーム](./forms.md)のドキュメントを参照してください。

### 応答セレクター

レスポンスセレクターは、バージョン2.0の時点で安定した機能です。

[[./migration-guide.md#トレーニングデータファイル|変換コマンド]] は、`responses.md` ファイル、ストーリー、および nlu トレーニング データを新しい yaml 形式に自動的に変換します。また、回答に`utter_`プレフィックスを追加することも処理します。さらに、ストーリーファイル内の`respond_`アクションの名前を変更して、 代わりにプレフィックス`utter_`。次のコマンドを実行して、これらの変更を適用します。

```bash
rasa data convert responses --data {SOURCE_DIR} --out={TARGET_DIR}
```

これらの変更を手動で適用することもできます。例えば：

```yaml-rasa
stories:
  - story: chitchat
    steps:
    - intent: chitchat
    - action: respond_chitchat
```

なる

```yaml-rasa
stories:
  - story: chitchat
    steps:
    - intent: chitchat
    - action: utter_chitchat
```

また、`responses.md` の応答名に`utter_`プレフィックスを追加する必要があります にも。例えば：

```yaml-rasa
responses:
  chitchat/ask_name:
    - text: Oh yeah, I am called the retrieval bot.

  chitchat/ask_weather:
    - text: Oh, it does look sunny right now in Berlin.
```

なる

```yaml-rasa
responses:
  utter_chitchat/ask_name:
    - text: Oh yeah, I am called the retrieval bot.

  utter_chitchat/ask_weather:
    - text: Oh, it does look sunny right now in Berlin.
```

最後に、ドメインのアクション リストから `respond_` プレフィックスを持つアクションを削除する必要があります。

この動作は、ストーリーとして定義されている場合は正常に機能しますが、ルールとして定義されている場合はさらに優れています。取得ストーリーをルールに転送することを検討する必要があります。それがどのようなものかの詳細については、[おしゃべりとFAQのドキュメント](./chitchat-faqs.md)をご覧ください。

応答セレクターは、実際の応答テキストではなく、デフォルトで検索インテントラベルでトレーニングされるようになりました。ほとんどのモデルでは、これにより `ResponseSelector` のトレーニング時間と精度が向上します。

2.0 より前のデフォルトの動作に戻す場合は、`use_text_as_label` true を追加します。 パラメーターを `ResponseSelector` コンポーネントに追加します。

```yaml-rasa
pipeline:
  # other components
  - name: ResponseSelector
    use_text_as_label: true
```

`ResponseSelector` の出力スキーマが変更されました。出力例は次のようになります。

```json
{
  "response_selector": {
    "all_retrieval_intents": [
      "faq"
    ],
    "default": {
      "response": {
        "id": 1388783286124362000,
        "confidence": 1,
        "intent_response_key": "faq/is_legit",
        "response_templates": [
          {
            "text": "absolutely",
            "image": "https://i.imgur.com/nGF1K8f.jpg"
          },
          {
            "text": "I think so."
          }
        ]
        "template_name": "utter_faq/is_legit"
      },
      "ranking": [
        {
          "id": 1388783286124362000,
          "confidence": 1,
          "intent_response_key": "faq/is_legit"
        }
      ]
    }
  }
}
```

この結果、以前にキーを照会していた場合、次のように`full_retrieval_intent`。

```python
response_selector_output.get("default")
                        .get("full_retrieval_intent")
```

代わりに、次の操作を行う必要があります。

```python
response_selector_output.get("default")
                        .get("response")
                        .get("intent_response_key")
```

### 特徴のないスロット

非`特徴化された`タイプの[スロット](domain.md#slots)は非推奨であり、バージョン 3.0 で削除されます。会話中にスロット値を無視するには、スロットの `influence_conversation` プロパティを `false` に設定します。

次のスニペットは、非推奨の非特長スロットの使用例です。

```yaml-rasa
slots:
  username:
    type: unfeaturized
```

これを新しい形式に更新するには、予期されるデータ型`テキスト`を指定し、会話中にスロットを無視するように定義します。

```yaml-rasa
slots:
  username:
    type: text
    # Set `influence_conversation` to `false`
    # to ignore the slot value during the conversation.
    influence_conversation: false
```

スロットに特定のデータ型が必要ない場合は、新しいスロットタイプ [[domain.md#任意のスロット|任意のスロット]] を使用できます。このスロットタイプは、会話中は常に無視され、スロット値のデータタイプに関する仮定は行われません。

```yaml-rasa
slots:
  username:
    type: any
```

詳細については、更新された[スロットのドキュメント](domain.md#スロット)を参照してください。

### 会話セッション

[[domain.md#セッション構成|Conversation sessions]] は、[ドメイン](domain.md)にセッション構成が含まれていない場合にデフォルトで有効になりました。以前は、欠落しているセッション構成は、会話セッションが無効になっているかのように扱われていました。次のスニペットを使用して、会話セッションを明示的に無効にすることができます。

```yaml-rasa
session_config:
  # A session expiration time of `0`
  # disables conversation sessions
  session_expiration_time: 0
```

### ダイアログの特徴付け

このセクションは、ポリシー構成で[特徴付けを](./policies.md#フィーチャライザー)明示的に定義した場合にのみ関連します。

LabelTokenizerSingleStateFeaturizer は非推奨であり、将来的に削除される予定です。SingleStateFeaturizer に置き換え、NLU パイプラインにいくつかの変更を加える必要があります。オプション `intent_tokenization_flag: True` と `CountVectorsFeaturizer` を含む `Tokenizer` を NLU パイプラインに追加します。

例えば：

```yaml-rasa
language: en
pipeline:
  - name: WhitespaceTokenizer
    intent_tokenization_flag: True
  - name: CountVectorsFeaturizer
  # other components
policies:
  # other policies
  - name: TEDPolicy
    featurizer:
    - name: SingleStateFeaturizer

```

BinarySingleStateFeaturizer は非推奨であり、将来削除される予定です。これを `SingleStateFeaturizer と、Tokenizer` の`intent_tokenization_flag`が `False` に設定されている NLU パイプラインに置き換える必要があります。

例えば：

```yaml-rasa
language: en
pipeline:
  - name: WhitespaceTokenizer
    intent_tokenization_flag: False
  # other components
policies:
  # other policies
  - name: TEDPolicy
    featurizer:
    - name: SingleStateFeaturizer

```

### 非推奨

非推奨の[イベント ブローカー](./event-brokers.md) FileProducer、KafkaProducer、PikaProducer および SQLProducer は削除されました。これらのブローカーを `endpoints.yml`代わりに、名前を変更したバリアントを使用してください。

*   FileProducer は FileEventBroker になりました
*   KafkaProducer が KafkaEventBroker になりました
*   PikaProducerがPikaEventBrokerに
*   SQLProducer が SQLEventBroker になりました

非推奨の EmbeddingIntentClassifier は削除されました。パイプライン構成 (`config.yml`) でこのコンポーネントを使用した場合は、[DIETClassifier](./components.md#dietclassifier) に置き換えることができます。同じ設定パラメータを受け入れます。

非推奨の KerasPolicy は削除されました。ポリシー設定 (`config.yml`) でこのコンポーネントを使用した場合は、[[./policies.md#TEDポリシー|TEDポリシー]]。同じ設定パラメータを受け入れます。

## Rasa 1.7 から Rasa 1.8 へ

> [!caution] 
> これは、**下位互換性を損なう**リリースです。以前にトレーニングされたモデルを読み込むことはできません。この改良版でモデルを使用する前に、必ずモデルを再トレーニングしてください。

### 全般

*   [[./policies.md#TEDポリシー|TEDポリシー]] は、推奨される機械学習ポリシーとして`keras_policy`に取って代わりました。`rasa init` で生成された新しいプロジェクトでは、このポリシーが自動的に使用されます。既存のモデル構成を変更して [[./policies.md#TEDポリシー|TEDポリシー]] これを`config.yml`の`ポリシー`セクションに追加してください 既存の可能性のある `KerasPolicy` エントリを削除します。
    
    ```yaml-rasa
    policies:
    # - ... other policies
    - name: TEDPolicy
      max_history: 5
      epochs: 100
    ```
    
    指定されたスニペットは、パラメーター `max_history` のデフォルト値を指定します。 `エポック。``max_history`は特に重要であり、あなたのストーリーに大きく依存します。Please see the docs of the [[./policies.md#TEDポリシー|TEDポリシー]]をカスタマイズしたい場合は、
    
*   定義済みのパイプライン テンプレートはすべて非推奨です。**使用するテンプレートはすべて新しい構成にマップされますが、基になるアーキテクチャは同じです**。[モデルのチューニング](./tuning-your-model.md)を参照して、構成ファイルで使用するコンポーネントを決定してください。
    
*   埋め込みポリシーの名前が [[./policies.md#TEDポリシー|TEDポリシー]]。ポリシーの機能は同じままでした。`EmbeddingPolicy` の代わりに `TEDPolicy` を使用するように設定ファイルを更新してください。
    
*   `EmbeddingPolicy`、`EmbeddingIntentClassifier`、`ResponseSelector` のほとんどのモデル オプションの名前が変更されました。次のマッピングを使用して構成ファイルを更新してください。
    

| 旧モデルオプション | 新しいモデルオプション |
| --- | --- |
| hidden_layers_sizes_a | キー "text" を持つ辞書 "hidden_layers_sizes" |
| hidden_layers_sizes_b | キー "label" を持つ辞書 "hidden_layers_sizes" |
| hidden_layers_sizes_pre_dial | 辞書「hidden_layers_sizes」キー「dialogue」付き |
| hidden_layers_sizes_bot | キー "label" を持つ辞書 "hidden_layers_sizes" |
| num_transformer_layers | number_of_transformer_layers |
| num_heads | number_of_attention_heads |
| max_seq_length | maximum_sequence_length |
| dense_dim | dense_dimension |
| embed_dim | embedding_dimension |
| num_neg | number_of_negative_examples |
| mu_pos | maximum_positive_similarity |
| mu_neg | maximum_negative_similarity |
| use_max_sim_neg | use_maximum_negative_similarity |
| C2 | regularization_constant |
| C_emb | negative_margin_scale |
| droprate_a | droprate_dialogue |
| droprate_b | droprate_label |
| evaluate_every_num_epochs | evaluate_every_number_of_epochs |
| evaluate_on_num_examples | evaluate_on_number_of_examples |
| 古い設定オプションは新しい名前にマッピングされ、警告がスローされます。ただし、これらは将来のリリースで非推奨になります。 |  |

*   埋め込みインテント分類子は非推奨となり、将来的には [DIETClassifier](./components.md#dietclassifier) に置き換えられる予定です。 `DIETClassfier`は、エンティティ認識だけでなく、インテント分類も実行します。現在の `EmbeddingIntentClassifier` と同じモデル動作を取得する場合は、`次の DIETClassifier` 設定を使用できます。
    
    ```yaml-rasa
    pipeline:
    # - ... other components
    - name: DIETClassifier
      hidden_layers_sizes:
        text: [256, 128]
      number_of_transformer_layers: 0
      weight_sparsity: 0
      intent_classification: True
      entity_recognition: False
      use_masked_language_model: False
      BILOU_flag: False
      scale_loss: True
      use_sparse_input_dropout: False
      use_dense_input_dropout: False
      # ... any other parameters
    ```
    
    新しいコンポーネントの詳細については、「[DIETClassifier](./components.md#dietclassifier)」を参照してください。構成で `EmbeddingIntentClassifier` を指定すると、上記のコンポーネント定義にマップされ、同じ Rasa バージョン内で同じ動作が発生します。
    
*   `CRFEntityExtractor` は現在非推奨であり、将来的には `DIETClassifier` に置き換えられる予定です。現在の `CRFEntityExtractor` と同じモデル動作を取得する場合は、次の構成を使用できます。
    
    ```yaml-rasa
    pipeline:
    # - ... other components
    - name: LexicalSyntacticFeaturizer
      features: [
        ["low", "title", "upper"],
        [
          "BOS",
          "EOS",
          "low",
          "prefix5",
          "prefix2",
          "suffix5",
          "suffix3",
          "suffix2",
          "upper",
          "title",
          "digit",
        ],
        ["low", "title", "upper"],
      ]
    - name: DIETClassifier
      intent_classification: False
      entity_recognition: True
      use_masked_language_model: False
      number_of_transformer_layers: 0
      # ... any other parameters
    ```
    
    `CRFEntityExtractor` は、ユーザー メッセージを独自に特徴付けし、特徴付けには依存しません。コンポーネントから新しい特徴付け [LexicalSyntacticFeaturizer](./components.md#lexicalsyntacticfeaturizer) に特徴付けを抽出しました。したがって、以前と同じ結果を得るには、[DIETClassifier](./components.md#dietclassifier) の前にこの特徴付け器をパイプラインに追加する必要があります。構成で`CRFEntityExtractor`を指定すると、上記のコンポーネント定義にマップされ、動作は以前のバージョンから変更されていません。
    
*   パイプラインに `CRFEntityExtractor` と `EmbeddingIntentClassifier` が含まれている場合は、両方のコンポーネントを [DIETClassifier](./components.md#dietclassifier) に置き換えることができます。そのためには、次のパイプラインを使用できます。
    
    ```yaml-rasa
    pipeline:
    # - ... other components
    - name: LexicalSyntacticFeaturizer
      features: [
        ["low", "title", "upper"],
        [
          "BOS",
          "EOS",
          "low",
          "prefix5",
          "prefix2",
          "suffix5",
          "suffix3",
          "suffix2",
          "upper",
          "title",
          "digit",
        ],
        ["low", "title", "upper"],
      ]
    - name: DIETClassifier
      number_of_transformer_layers: 0
      # ... any other parameters
    ```
    

## Rasa 1.6 から Rasa 1.7 へ

### 全般

*   デフォルトでは、`loss_type`が`「softmax」`の場合、`EmbeddingIntentClassifier`、`EmbeddingPolicy`、`およびResponseSelector`は、上位10の信頼度結果を正規化するようになりました(これは1.3からデフォルトです、[[./migration-guide.md#Rasa 1.2 から Rasa 1.3 へ|Rasa 1.2 から Rasa 1.3]]。これは、`ranking_length` 設定パラメータを使用して設定できます。前の動作に一致するように正規化をオフにするには、`ranking_length: 0` を設定します。

## Rasa 1.2 から Rasa 1.3 へ

> [!caution] 
> これは、**下位互換性を損なう**リリースです。以前にトレーニングされたモデルを読み込むことはできません。この改良版でモデルを使用する前に、必ずモデルを再トレーニングしてください。

### 全般

*   `EmbeddingIntentClassifier` の既定のパラメーターが変更されました。詳細については、「コンポーネント」ページを参照してください。アーキテクチャの実装も変更されるため、**古いトレーニング済みモデルをロードできません**。`EmbeddingPolicy` の既定のパラメーターとアーキテクチャが変更されます。詳細については、[「ポリシー」](./policies.md)を参照してください。lstm の代わりにトランスフォーマーを使用します。**古いトレーニング済みモデルは読み込めません**。デフォルトでは、`内部`類似性と`ソフトマックス`損失を使用します。 `コサイン`類似性と`マージン`損失(構成ファイルで設定可能)。クラスの不均衡の問題に対抗するために、デフォルトで`バランスのとれた`バッチ処理戦略を使用します。`evaluate_on_num_examples`の意味が変わります。ゼロ以外の場合、ランダムな例は層別分割によって選択され、**ホールドアウト**検証セットとして使用されるため、トレーニングデータから除外されます。データセットにダイアログターンのユニークな例が多数含まれている場合は、ゼロ(デフォルト)に設定することをお勧めします。コンポーネントから`label_tokenization_flag`と`label_split_symbol`を削除しました。代わりに、インテントの分割を`intent_tokenization_flag`と`intent_split_symbol`フラグを介してトー`クナイザー`コンポーネントに移動しました。
    
*   `EmbeddingPolicy` の既定`のmax_history`は `None` で、`FullDialogueTrackerFeaturizer` を使用します。`MaxHistoryTrackerFeaturizer` を使用するには、`max_history` を有限値に設定することをお勧めします より**迅速なトレーニング**のために。詳細については、「[特徴付け」](./policies.md#フィーチャライザー)を参照してください。`MaxHistoryTrackerFeaturizer` の`batch_size`を増やすことをお勧めします (例:「`batch_size」: [32, 64]`)
    
*   `rasa train core`の**比較**モードにより、コア全体の構成比較が可能です。そこで、学習したモデルの命名を変更しました。ポリシー名ではなく、構成ファイル名で名前が付けられます。古い命名スタイルは、**比較**プロット(`rasaテストコア`)を作成するときに正しく読み取れません。比較フォルダー内の古いトレーニング済みモデルを削除し、再トレーニングしてください。通常の体幹トレーニングは影響を受けません。
    
*   **NER**の**評価指標**を更新しました。重み付け精度と f1 スコアを報告します。これまでのところ、このレポートには`エンティティは含まれていません`。ただし、ほとんどのトークンには実際にはエンティティセットがないため、これは重み付けされた精度とf1スコアにかなり影響します。今後は、評価から`エンティティーを除外`します。全体的なメトリックには、適切なエンティティのみが含まれるようになりました。評価を再度実行すると、パフォーマンス スコアが低下する場合があります。
    
*   `/` は、取得意図と対応する応答テキスト識別子を区別するための区切り文字トークンとして予約されています。インテントの名前に `/` 記号を含めないようにしてください。
    

## Rasa NLU 0.14.x および Rasa Core 0.13.x から Rasa 1.0

> [!caution] 
> これは、**下位互換性を損なう**リリースです。以前にトレーニングされたモデルを読み込むことはできません。この改良版でモデルを使用する前に、必ずモデルを再トレーニングしてください。

### 全般

*   `rasa.core`と`rasa.nlu`のスクリプトは実行できなくなりました。トレーニング、テスト、実行、...NLU または Core モデルの場合は、コマンドラインインターフェイス `rasa` を使用する必要があります。機能は、ほとんどの場合、以前と同じです。コマンドの変更の一部は、NLU モデルと Core モデルのトレーニングと実行の組み合わせを反映していますが、NLU と Core は個別にトレーニングして使用できます。`rasa.core` または `rasa.nlu` で古いスクリプトの 1 つを実行しようとすると、代わりに使用する必要があるコマンドを示すエラーがスローされます。コマンド[ラインインターフェイス](./command-line-interface.md)のすべての新しいコマンドを参照してください。
    
*   カスタム出力チャネルを記述した場合、`OutputChannel`クラスからサブクラス化された`すべてのsend_`メソッドは、追加の`**kwargsを取得する`必要があります 引数。これらのキーワード引数は、カスタムアクションコードまたは templates を使用して、ドメイン ファイルで使用される追加のパラメータを送信します。 チャネルの send メソッド。
    
*   以前に `Button` クラスまたは `Element` クラスを `rasa_core.dispatcher`、これらは `rasa_sdk.utils` からインポートされます。
    
*   Rasa NLU と Core は、以前は[別々の構成ファイル](https://legacy-docs.rasa.com/docs/nlu/0.15.1/migrations/?&_ga=2.218966814.608734414.1560704810-314462423.1543594887#id1)を使用していました。これら 2 つのファイルは、`config.yml` という名前の 1 つのファイルにマージするか、`--config` パラメーターを介して渡す必要があります。
    

### スクリプト パラメーター

*   すべてのスクリプト パラメーター名は、同じスキーマに従うように統一されています。引数のアンダースコア (`_`) はダッシュ (`-`) に置き換えられました。例: `--max_history` は `--max-history` に変更されました。すべてのスクリプトパラメータは、[コマンドラインインタフェースの](./command-line-interface.md)コマンドの`--help`出力で確認できます。
    
*   `--num_threads` パラメーターが `run` コマンドから削除されました。サーバーは常にシングルスレッドで実行されますが、非同期で実行されるようになりました。複数のプロセスを利用したい場合は、[Sanic サーバーのドキュメント](https://sanicframework.org/en/guide/deployment/running.html#gunicorn)を自由にチェックしてください。
    
*   スクリプト パラメーター名の競合を回避するために、`-c` はサポートされなくなったため、`run` コマンドのコネクタを `--connector` で指定する必要があります。`rasa visualize` コマンドの最大履歴は、`--max-history` で定義する必要があります。出力パスとログファイルは、`-o` で指定できなくなりました。`--out` と `--log-file` を使用する必要があります。NLU データは `--nlu` に標準化され、あらゆる種類のデータファイルまたはディレクトリの名前は `--data` になります。
    

### HTTP API

*   HTTP API エンドポイントの変更は多数ありますが、[こちら](./http-api.md)で確認できます。