---
id: sdk_changelog
sidebar_label: Rasa SDK Change Log
title: Rasa SDK Change Log
---

Rasa SDK の変更ログは、[Rasa SDK リポジトリ](https://github.com/RasaHQ/rasa-sdk/blob/main/CHANGELOG.mdx)にあります