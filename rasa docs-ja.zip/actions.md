---
id: actions
sidebar_label: Overview
title: Actions
abstract: After each user message, the model will predict an action that the assistant should perform next. This page gives you an overview of the different types of actions you can use.
---

## 応答

[応答](./responses.md)は、アシスタントがユーザーに送り返すメッセージです。これは、アシスタントにテキスト、画像、ボタンなどをユーザーに送信させたい場合に、最も頻繁に使用するアクションです。

## カスタムアクション

[カスタムアクション](./custom-actions.md)は、任意のコードを実行できるアクションです。これは、API 呼び出しを行ったり、データベースをクエリしたりするために使用できます。

## フォーム

[フォーム](./forms.md)は、ビジネス ロジックを処理するように設計された特別なタイプのカスタム アクションです。アシスタントが特定の情報セットを要求することを想定する会話デザインがある場合は、フォームを使用する必要があります。

## デフォルトアクション

[既定のアクション](./default-actions.md)は、既定でダイアログ マネージャーに組み込まれているアクションです。これらのほとんどは、特定の会話状況に基づいて自動的に予測されます。これらをカスタマイズして、アシスタントをパーソナライズすることもできます。

## スロット検証アクション

[スロット検証アクション](./slot-validation-actions.md)は、スロット値のカスタム抽出や検証を処理するように設計された特別なタイプのカスタムアクションです。これを使用して、事前定義されたマッピングを使用してスロットを検証したり、カスタムマッピングを使用してスロットを抽出したりできます。