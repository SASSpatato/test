---
id: reaching-out-to-user
sidebar_label: Reaching Out to the User
title: Reaching Out to the User
abstract: Sometimes you want your assistant to reach out to the user without the user's prompting. For example, you might want the assistant to send a message when the user opens the chat window, or you might want to prompt the user if they haven't sent a message for a while. This page is a guide to enabling your assistant to reach out to the user proactively.
---

## 最初に連絡を取る

ほとんどのユースケースでは、ユーザーがアシスタントとのチャット・ウィンドウを開くと、アシスタントに最初のメッセージを送信させる必要があります。これにより、ボットが何ができるか、何ができないかをユーザーに把握し、より成功した会話を行えるように設定できます。一部の[メッセージングまたは音声チャネルには](./messaging-and-voice-channels.md)、ユーザーが最初に会話を開始したときにアシスタントにペイロードを送信するための既存の構成オプションがありますが、このオプションを[独自のカスタムチャネル](./connectors/your-own-website.md)に追加することもできます。

ペイロードを送信するようにチャネルを設定したら、アシスタントがユーザーにどのように反応し、挨拶するかを指定する必要があります。これには、既存のインテントの動作を再利用するか、新しいインテントとルールを指定することができます。ウェルカムルールを指定する方法のガイドを次に示します。

### 1. 構成を更新する

この動作にルールを使用しているため、[[./policies.md#ルールポリシー|ルールポリシー]] を構成ファイルに追加します。

```yaml-rasa
policies:
  # other policies
  - name: RulePolicy
```

### 2. ルールを追加する

アシスタントが会話の開始時にのみウェルカムメッセージでインテント`グリート`に応答できるようにするには、次のルールを追加します。

```yaml-rasa
rules:
  - rule: welcome user
    conversation_start: true  # this rule only applies at the beginning of a conversation
    steps:
      - intent: greet
      - action: utter_welcome
```

### 3. 応答を追加する

最後に、ドメインへの`utter_welcome` utterアクションの応答を追加します。

```yaml-rasa
responses:
  utter_welcome:
  - text: Hi there! What can I help you with today?
```

## 外部イベント

外部デバイスを使用して、進行中の会話の流れを変更したい場合があります。たとえば、Raspberry Pi に水分センサーが取り付けられている場合、それを使用して、植物に水やりが必要なときにアシスタントを介して通知できます。

以下の例は、リマインダーと外部イベントの両方を含むリ[マインダーボットのサンプルボット](https://github.com/RasaHQ/rasa/blob/main/examples/reminderbot)からのものです。

### 1. インテントをトリガーする

外部デバイスからのイベントで進行中の会話のコースを変更するには、デバイスを会話の[`trigger_intent`エンドポイント](/pages/http-api#operation/triggerConversationIntent)に投稿します。`trigger_intent`エンドポイントは、ユーザーの意図 (場合によってはエンティティを含む) を会話に挿入します。Rasa の場合、それはあたかもその特定の意図とエンティティで分類されたメッセージを入力したかのようです。その後、アシスタントは通常どおり次のアクションを予測して実行します。

たとえば、次の投稿リクエストでは、インテント`EXTERNAL_dry_plant`と`プラント`エンティティが ID `user123` の会話に挿入されます。

```
curl -H "Content-Type: application/json" -X POST 
  -d '{"name": "EXTERNAL_dry_plant", "entities": {"plant": "Orchid"}}' 
  "http://localhost:5005/conversations/user123/trigger_intent?output_channel=latest"
```

### 2. 会話 ID を取得する

実際のシナリオでは、外部デバイスは API またはデータベースから会話 ID を取得します。乾燥植物の例では、植物、植物に水をやるユーザー、およびユーザーの会話 ID のデータベースがある場合があります。Raspberry Pi は、データベースから直接会話 ID を取得します。リマインダーボットの例をローカルで試すには、会話 ID を手動で取得する必要があります。詳細については、リマインダーボットの[README](https://github.com/RasaHQ/rasa/blob/main/examples/reminderbot)を参照してください。

### 3. NLU トレーニング データを追加する

ドライプラントの例では、Raspberry Pi はインテントを含むメッセージを送信する必要があります `trigger_intent`エンドポイントに`EXTERNAL_dry_plant`します。このインテントは Raspberry Pi で使用するために予約されるため、NLU トレーニングの例はありません。

```yaml-rasa
intents:
  - EXTERNAL_dry_plant
```

> [!note] 
> 他のデバイスからのインテントには、トレーニング データを操作するときに外部デバイスから来ると予想されるインテントを簡単に確認できるため、`EXTERNAL_` プレフィックスを付ける必要があります。

### 4. ドメインを更新する

どの植物に水やりが必要かをアシスタントに伝えるために、インテントと一緒に投稿するエンティティを定義できます。応答でエンティティ値を直接使用できるようにするには、`プラント`スロットの`from_entity`スロットマッピングを定義します。

```yaml-rasa
entities:
  - plant

slots:
  plant:
    type: text
    influence_conversation: false
    mappings:
    - type: from_entity
      entity: plant
```

#### 5. ルールを追加する

アシスタントが Raspberry Pi からメッセージを受信したときに応答する方法を指示するルールが必要です。

```yaml-rasa
rules:
  - rule: warn about dry plant
    steps:
    - intent: EXTERNAL_dry_plant
    - action: utter_warn_dry
```

#### 6. 応答を追加する

`utter_warn_dry`の応答テキストを定義する必要があります。

```yaml-rasa
responses:
  utter_warn_dry:
  - text: "Your {plant} needs some water!"
```

応答は、スロット `プラント`の値を使用して、水やりが必要な特定のプラントについて警告します。

### 試してみる

乾燥プラント通知の例を試すには、[CallbackChannel](./connectors/your-own-website.md#callbackinput) を開始する必要があります。

> [!caution]
> 外部イベントとリマインダーは、`rest` チャネルや `rasa シェル`などの要求/応答チャネルでは機能しません。リマインダーまたは外部イベントを実装するアシスタント用のカスタム コネクタは、RestInput チャネルではなく [CallbackInput チャネル](./connectors/your-own-website.md#callbackinput)から構築する必要があります。
> 
> リマインダーをローカルでテストする方法については、[reminderbot の README](https://github.com/RasaHQ/rasa/blob/main/examples/reminderbot/README.md) を参照してください。

この POST リクエストを実行して、会話 ID を使用して外部イベントをシミュレートします。

```bash
curl -H "Content-Type: application/json" -X POST -d 
'{"name": "EXTERNAL_dry_plant", "entities": {"plant": "Orchid"}}' 
"http://localhost:5005/conversations/user1234/trigger_intent?output_channel=latest"
```

ボットがチャネルで応答するのがわかります。

あなたの蘭には水が必要です!

## アラーム

アシスタントは、[リマインダー](./action-server/events.md#リマインダー)を使用して、一定時間後にユーザーに連絡させることができます。以下の例は、[reminderbot サンプル ボット](https://github.com/RasaHQ/rasa/blob/main/examples/reminderbot)からのものです。クローンを作成し、`README` の指示に従ってフル バージョンを試すことができます。

### スケジューリングリマインダー

#### 1. リマインダーを定義する

リマインダーをスケジュールするには、`ReminderScheduled` イベントを返すカスタム アクションを定義する必要があります。たとえば、次のカスタムアクションは、今から 5 分間のリマインダーをスケジュールします。

```python
import datetime
from rasa_sdk.events import ReminderScheduled
from rasa_sdk import Action

class ActionSetReminder(Action):
    """Schedules a reminder, supplied with the last message's entities."""

    def name(self) -> Text:
        return "action_set_reminder"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict[Text, Any]]:

        dispatcher.utter_message("I will remind you in 5 minutes.")

        date = datetime.datetime.now() + datetime.timedelta(minutes=5)
        entities = tracker.latest_message.get("entities")

        reminder = ReminderScheduled(
            "EXTERNAL_reminder",
            trigger_date_time=date,
            entities=entities,
            name="my_reminder",
            kill_on_user_message=False,
        )

        return [reminder]
```

`ReminderScheduled` イベントの最初の引数は、リマインダーの名前 (この場合は `EXTERNAL_reminder`) です。 リマインダー名は、後でリマインダーに対するリアクションをトリガーする意図として使用されます。 リマインダー名に EXTERNAL_プレフィックスを`付け`て、トレーニングデータで何が起こっているかを簡単に確認できるようにします。

最後のメッセージの`エンティティ`もリマインダーに渡されることがわかります。これにより、リマインダーに反応するアクションは、ユーザーのスケジュール メッセージのエンティティを利用できるようになります。

たとえば、アシスタントに友人に電話するように通知してもらいたい場合は、「ポールに電話するように通知してください」などのメッセージをアシスタントに送信できます。「パウロ」を`人として`抽出した場合 エンティティに反応するアクションは、リマインダーを使用して「ポールに電話することを忘れないでください!」と言うことができます。

#### 2. ルールを追加する

リマインダーをスケジュールするには、ルールを追加します。

```yaml-rasa
rules:
- rule: Schedule a reminder
  steps:
  - intent: ask_remind_call
    entities:
    - PERSON
  - action: action_set_reminder
```

#### 3. トレーニングデータを追加する

リマインダーをスケジュールするための NLU トレーニング例を追加する必要があります。

```yaml-rasa
nlu:
- intent: ask_remind_call
  examples: |
    - remind me to call John
    - later I have to call Alan
    - Please, remind me to call Vova
    - please remind me to call Tanja
    - I must not forget to call Juste
```

また、ドメインに追加する必要があります。

```yaml-rasa
intents:
  - ask_remind_call
```

#### 4. パイプラインを更新する

config.yml のパイプラインに SpacyNLP と SpacyEntityExtractor を追加すると、Spacy には `PERSON` ディメンションがあるため、トレーニング データの名前に注釈を付ける必要はありません。

```yaml-rasa
pipeline:
# other components
- name: SpacyNLP
  model: "en_core_web_md"
- name: SpacyEntityExtractor
  dimensions: ["PERSON"]
```

### リマインダーへの対応

#### 1. 反応を定義する

ボットは、`trigger_intent` エンドポイントへの POST 要求を受信した後、ユーザーに連絡します。ただし、リマインダーは、`ReminderScheduled` イベントで定義した名前を使用して、一定時間が経過すると、要求を適切な会話 ID に自動的に送信します。

リマインダーに対する反応を定義するには、リマインダーの意図を受信したときに実行するアクションをボットに指示する[ルール](./rules.md)を記述するだけで済みます。

通話リマインダーの例では、リマインダーに付属するエンティティを使用して、特定のユーザーに電話をかけるようにリマインダーする必要があるため、それを行うカスタム アクションを記述する必要があります。

```python
class ActionReactToReminder(Action):
    """Reminds the user to call someone."""

    def name(self) -> Text:
        return "action_react_to_reminder"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict[Text, Any]]:

        name = next(tracker.get_slot("PERSON"), "someone")
        dispatcher.utter_message(f"Remember to call {name}!")

        return []
```

#### 2. ルールを追加する

リマインダーがトリガーされたときに実行するアクションをボットに指示するには、ルールを追加します。

```yaml-rasa
rules:
- rule: Trigger `action_react_to_reminder` for `EXTERNAL_reminder`
  steps:
  - intent: EXTERNAL_reminder
  - action: action_react_to_reminder
```

#### 3. トレーニングデータを追加する

リマインダーへの反応をトリガーする意図を定義する必要があります。インテントはリマインダー用に予約されているため、トレーニング例を追加する必要はありません。

```yaml-rasa
intents:
- intent: EXTERNAL_reminder
```

### リマインダーのキャンセル

#### 1. リマインダーをキャンセルするアクションを定義する

すでにスケジュールしたリマインダーをキャンセルするには、`ReminderCancelled()` イベントを返すカスタムアクションが必要です。

`ReminderCancelled()` を返すと、現在スケジュールされているすべてのリマインダーがキャンセルされます。特定のリマインダーのみをキャンセルする場合は、スケジュールされたリマインダーを絞り込むためのいくつかのパラメーターを指定できます。

*   意図`EXTERNAL_greet`ですべてのリマインダー `ReminderCancelled(intent="EXTERNAL_greet")` をキャンセルします。
    
*   指定されたエンティティーですべてのリマインダーを取り `ReminderCancelled(entities={})` 消します。
    
*   `ReminderCancelled("...")` は、作成時に指定した名前 "`...`" の 1 つの一意のリマインダーを取り消します
    

通話リマインダーの例では、すべてのリマインダーをキャンセルするカスタムアクション`action_forget_reminders`を定義できます。

```python
class ForgetReminders(Action):
    """Cancels all reminders."""

    def name(self) -> Text:
        return "action_forget_reminders"

    async def run(
        self, dispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:

        dispatcher.utter_message(f"Okay, I'll cancel all your reminders.")

        # Cancel all reminders
        return [ReminderCancelled()]
```

> [!caution]
> Rasaサーバーをシャットダウンするたびに、すべてのリマインダーがキャンセルされます。

#### 2. ルールを追加する

リマインダーをキャンセルするためのルールを追加する必要があります。

```yaml-rasa
rules:
- rule: Cancel a reminder
  steps:
  - intent: ask_forget_reminders
  - action: action_forget_reminders
```

#### 3. トレーニングデータを追加する

リマインダーのキャンセルをトリガーするインテントを定義する必要があります。

```yaml-rasa
nlu:
- intent: ask_forget_reminders
  examples: |
    - Forget about the reminder
    - do not remind me
    - cancel the reminder
    - cancel all reminders please
```

また、次のdomain.ymlに追加する必要があります。

```yaml-rasa
intents:
- intent: ask_forget_reminders
```

### 試してみる

リマインダーを試すには、[CallbackChannel](./connectors/your-own-website.md#callbackinput)を開始する必要があります。また、アクションサーバーを起動して、リマインダーをスケジュール、対応、キャンセルする必要があります。詳細については、[リマインダーボットのREADME](https://github.com/RasaHQ/rasa/blob/main/examples/reminderbot)を参照してください。

次に、ボットに「`ポール・ポッツに電話するようにリマインダー`」のようなメッセージを送信すると、5分後に「`ポール・ポッツに電話することを忘れないでください!」`というリマインダーが返ってくるはずです。