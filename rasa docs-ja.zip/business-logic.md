---
id: business-logic
sidebar_label: Handling Business Logic
title: Handling Business Logic
abstract: Conversational assistants often need to ask users for information in order to help them. You can use Forms to collect the required user information and fulfill a request.
---

会話型アシスタントは、多くの場合、ユーザーのために何かを行う前に、ユーザーから必要な情報を収集することを含むユーザーの目標をサポートします。たとえば、レストラン検索ボットは、適切なレストランを見つけるために、ユーザーの好みに関するいくつかの情報を収集する必要があります。

**利用者**：レストラン探しを手伝ってください

**ボット**：どんな料理? **User**:トスカーナ料理を探しています

**ボット**：何人ですか? **ユーザー**:5

**ボット**：外に座りたいですか? **ユーザー**:はい

**ボット**：すべて完了です! **

**ボット**：次のパラメータを使用してレストラン検索を実行します:
-料理: トスカーナ 
-num_people: 5 
-outdoor_seating: True

このページでは、リクエストを満たすためにユーザー情報を収集する**ビジネスロジック**の処理に関するガイドです。上記の例では、ビジネス ロジックには、ユーザーの好みの料理、パーティーの規模、座席の好みを知る必要があることが含まれます。このページの例は、[formbot サンプル ボット](https://github.com/RasaHQ/rasa/tree/main/examples/formbot)から取得したものです。

## フォームを使用してビジネス ロジックを処理するためのステップバイステップ ガイド

[フォームは](forms.md)、必要な情報をすべて収集するまで、ユーザーに情報の入力を求めることによって機能します。情報は[スロットに保存されます](domain.md#スロット)。必要なスロットがすべて埋まると、ボットはユーザーの元のリクエストを満たします。

### 1. フォームの定義

フォームを定義するには、以下を定義する必要があります。

*   スロットマッピング: 収集する必要な情報
*   応答: ボットが各情報を要求する方法

#### スロットマッピング

レストラン検索の例では、ユーザーから次の情報を収集します。

*   料理
*   人数
*   外に座りたいかどうか

ドメイン内のフォームを定義するには、フォーム名の下に必要なスロットのリストを指定します。

```yaml-rasa
forms:
  restaurant_form:
    required_slots:
        - cuisine
        - num_people
        - outdoor_seating
```

これらのスロットは、スロットを埋める方法を定義する [[domain.md#スロットマッピング|スロットマッピング]] とともに、ドメインの`スロット` セクションに追加する必要があります。スロットがいっぱいの`from_entity`については、エンティティもドメインに追加する必要があります。フォームで入力されたスロットは通常、会話に影響を与えないため、`influence_conversation` を 'false:

```yaml-rasa
entities:
  - cuisine
  - number
slots:
  cuisine:
    type: text
    mappings:
    - type: from_entity
      entity: cuisine
  num_people:
    type: float
    mappings:
    - type: from_entity
      entity: number
  outdoor_seating:
    type: bool
    mappings:
    - type: from_intent
      intent: affirm
      value: true
      conditions:
       - active_loop: restaurant_form
         requested_slot: outdoor_seating
    - type: from_intent
      intent: deny
      value: false
      conditions:
      - active_loop: restaurant_form
        requested_slot: outdoor_seating
```

`番号`スロットはエンティティから埋められます。数値などのエンティティは、[DucklingEntityExtractor](./components.md#ducklingentityextractor)で抽出できます。これを使用するには、DucklingEntityExtractor を NLU パイプラインに追加します。

```yaml-rasa
language: en
pipeline:
# other components
- name: DucklingEntityExtractor
  dimensions: ["number"]
```

##### 条件付きスロットマッピング

`outdoor_seating`スロットはユーザーの意図に基づいて埋められます:`肯定`の場合は`true`、`deny`の場合は`false`になります。

ただし、スロットは、ユーザーが「`外に座りたいですか?」`という質問に回答している場合にのみ、`true` または `false` に設定する必要があります。この条件を適用するには、`outdoor_seating` スロットの`条件`で、`restaurant_form`がアクティブであり、要求されたスロットが`outdoor_seating`である必要があります。条件がなく、ユーザーが会話の早い段階で`肯定`または`拒否`の意図を含むメッセージを送信した場合、フォームがアクティブ化されたときに`outdoor_seating`スロットはすでにいっぱいになっています。したがって、フォームはユーザーに屋外の座席の好みを尋ねることはありません。詳細については、[[./domain.md#マッピング条件|マッピング条件]]を参照してください。

#### スロットの検証

多くの場合、ユーザーの入力を受け入れる前に、たとえば、特定の料理がアシスタントの利用可能な料理のデータベースにあるかどうかを確認するなどして、ユーザーの入力を検証する必要があります。検証アクションの詳細については、[[forms.md#フォーム入力の検証|フォーム入力の検証]] のドキュメントを参照してください。

#### スロットの要求

ボットが必要な情報をどのように要求するかを指定するには、ドメインで `utter_ask_{slotname}` という[`応答`](domain.md#responses)を定義します。

```yaml-rasa
responses:
  utter_ask_cuisine:
    - text: "What cuisine?"
  utter_ask_num_people:
    - text: "How many people?"
  utter_ask_outdoor_seating:
    - text: "Do you want to sit outside?"
```

### 2. 設定の更新

フォームの [[glossary.md#幸せ/不幸な道|ハッピーパス]] を[ルール](rules.md)として定義する必要があるため、[[policies.md#ルールポリシー|RulePolicy]] をポリシーに追加します。

```yaml-rasa
policies:
  - name: RulePolicy
```

### 3. ルールの作成

フォーム自体は、必要なすべての情報をユーザーに求めるロジックを処理するため、フォームのハッピーパスに必要なルールは、フォームがいつ開始されるかを定義するルールと、フォームが入力されたときに何が起こるかを定義するルールの2つだけです。レストラン検索の例では、実際にはアシスタントがユーザーの好みに基づいてレストランを検索します。この場合、ボットは検索に使用される詳細を含む応答を発します。

```yaml-rasa
rules:
  - rule: activate restaurant form
    steps:
      - intent: request_restaurant   # intent that triggers form activation
      - action: restaurant_form      # run the form
      - active_loop: restaurant_form # this form is active

  - rule: submit form
    condition:
    - active_loop: restaurant_form   # this form must be active
    steps:
      - action: restaurant_form      # run the form
      - active_loop: null            # the form is no longer active because it has been filled
      - action: utter_submit         # action to take after the form is complete
      - action: utter_slots_values   # action to take after the form is complete
```

フォームのアクティブ化と送信を分割することで、ユーザーが[予期しない入力](unexpected-input.md)を提供したり、[おしゃべり](chitchat-faqs.md)でフォームを中断したりしても、ルールは引き続き適用されます。

### 4. NLUトレーニングデータの更新

フォームをアクティブにするインテントの例と、ユーザーが必要な情報を提供する方法の例を追加する必要があります。

#### フォームの有効化インテント

フォームをアクティブにするインテントのトレーニング例を提供する必要があります。インテント`request_restaurant`の例を追加します。

```yaml-rasa
nlu:
- intent: request_restaurant
  examples: |
    - im looking for a restaurant
    - can i get [swedish](cuisine) food in any area
    - a restaurant that serves [caribbean](cuisine) food
    - id like a restaurant
    - im looking for a restaurant that serves [mediterranean](cuisine) food
    - can i find a restaurant that serves [chinese](cuisine)
```

`from_entity`で埋められたスロットは、正しいエンティティが抽出されている限り、意図に関係なく、既定で任意のユーザーの発話で埋めることができます。つまり、ユーザーが最初のメッセージの一部として`料理`エンティティを提供した場合、スロットはフォームの先頭に入力され、ボットは再び料理を要求しません。

#### フォーム入力の意図

フォームがスロットを埋めている間は、スロットマッピングがインテントを明示的に要求または除外しない限り、どのインテントが予測されたかには注意を払いません。

レストラン検索の例では、`outdoor_seating`スロットは 2 つのインテントにマッピングされているため、これらのインテントのトレーニング データを追加する必要があります。

`料理`スロットと`数字`スロットにはインテントが指定されていないため、一般的な`インフォーム`インテントに例を追加できます。DIETClassifier が抽出方法を学習できるように、`料理`エンティティに注釈を付ける必要があります。DucklingEntityExtractor はトレーニング データでトレーニングされていないルールベースの抽出ツールであるため、`数値`エンティティに注釈を付ける必要はありません。各インテントについて、いくつかの例のみを示します。ボットが適切に機能するには、次に示すよりも多くのトレーニング データを追加する必要があります。

```yaml-rasa
nlu:
- intent: affirm
  examples: |
    - Yes
    - yes, please
    - yup
- intent: deny
  examples: |
    - no don't
    - no
    - no I don't want that

- intent: inform
  examples: |
    - [afghan](cuisine) food
    - how bout [asian oriental](cuisine)
    - what about [indian](cuisine) food
    - uh how about [turkish](cuisine) type of food
    - um [english](cuisine)
    - im looking for [tuscan](cuisine) food
    - id like [moroccan](cuisine) food
    - for ten people
    - 2 people
    - for three people
    - just one person
    - book for seven people
    - 2 please
    - nine people
```

ドメインを更新して、次のインテントを含めます。

```yaml-rasa
intents:
  - request_restaurant
  - affirm
  - deny
  - inform
```

### 5. 応答の定義

フォームの送信後に送信される応答を追加します。

```yaml-rasa
responses:
  utter_submit:
  - text: "All done!"
  utter_slots_values:
  - text: "I am going to run a restaurant search using the following parameters:n
            - cuisine: {cuisine}n
            - num_people: {num_people}n
            - outdoor_seating: {outdoor_seating}"
```

## 概要

フォームを使用すると、ユーザー情報を収集するロジックを簡略化できます。上記のレストラン検索の例のような最小限のフォームを定義するには、次のことを行う必要があることをまとめます。

- [ ] RulePolicy を config.yml に追加する
- [ ] ドメイン内の必要なスロットを含むフォームを定義する
- [ ] ドメイン内の必要なすべてのスロットのスロット マッピングを追加する
- [ ] フォームをアクティブ化して送信するためのルールを追加する
- [ ] フォームをアクティブ化するインテントの例を追加する
- [ ] 必要なスロットを埋めるためのインテントの例を追加する
- [ ] フォームが完成したときにボットが実行するアクションまたは応答を定義する
- [ ] 定義した新しいインテントとアクションでドメインを更新する

新しく定義したフォームを試すには、`rasa train` と `start rasa shell` を実行してボットのモデルを再トレーニングします。DucklingEntityExtractor はエンティティの抽出に使用されているため、バックグラウンドでも Duckling を起動する必要があります ([Duckling を実行する手順](components.md#DucklingEntityExtractor)を参照してください)。