---
id: jupyter-notebooks
sidebar_label: Jupyter Notebooks
title: Jupyter Notebooks
description: Learn how to integrate open source chatbot platform Rasa into Jupyter notebooks, alongside all your machine learning code.
---

このページには、Jupyter ノートブックで Rasa を使用するための最も重要な方法が含まれています。

Jupyter Notebook はすでにイベントループで実行されているため、Jupyter Notebook で非同期 Rasa コードを実行するには追加の要件が必要です。jupyterを起動する前に、コマンドラインにこの要件をインストールします。

```bash
pip3 install nest_asyncio
```

次に、ノートブックの最初のセルに、次の内容を含めます。

```bash
import nest_asyncio

nest_asyncio.apply()
print("Event loop ready.")
```

まず、プロジェクトをまだ持っていない場合は作成する必要があります。これを行うには、このセルを実行すると、`test-project` ディレクトリが作成され、それを作業ディレクトリにします。

```bash
from rasa.cli.scaffold import create_initial_project
import os

project = "test-project"
create_initial_project(project)

# move into project directory and show files
os.chdir(project)
print(os.listdir("."))
```

モデルをトレーニングするには、関連するファイルの場所を`トレーニング`関数に指示する必要があります。これらのパスを含む変数を定義するには、次のコマンドを実行します。

```bash
config = "config.yml"
training_files = "data/"
domain = "domain.yml"
output = "models/"
print(config, training_files, domain, output)
```

## モデルのトレーニング

これで、`rasa.train`関数へのパスを渡すことでモデルをトレーニングできます。トレーニング ファイルはリストとして渡されることに注意してください。トレーニングが終了すると、`rasa.train` はトレーニングされたモデルが保存されたパスを返します。

```bash
import rasa

model_path = rasa.train(domain, config, [training_files], output)
print(model_path)
```

## アシスタントとチャットする

アシスタントとのチャットを開始するには、`チャット`関数を呼び出して、保存したモデルへのパスを渡します。カスタムアクションがない場合は、`endpoints = None` を設定するか、省略できます。

```bash
from rasa.jupyter import chat

endpoints = "endpoints.yml"
chat(model_path, endpoints)
```

## テストデータに対してモデルを評価する

Rasaには、トレーニングデータを取得するための便利な機能があります。Rasa の`get_core_directory`と `get_nlu_directory` は、すべてのストーリーまたは NLU データ ファイルを再帰的に検索し、それらを一時ディレクトリにコピーする関数です。戻り値は、これらの新しく作成されたディレクトリへのパスです。

```bash
import rasa.shared.data as data
nlu_data_directory = data.get_nlu_directory(training_files)
stories_directory = data.get_core_directory(training_files)
print(stories_directory, nlu_data_directory)
```

モデルをテストするには、`test` 関数を呼び出して、保存したモデルへのパスと、評価するストーリーと nlu データを含むディレクトリを渡します。

```bash
rasa.test(model_path, stories_directory, nlu_data_directory)
print("Done testing.")
```

コア評価の結果は、`結果`というファイルに書き込まれます。NLU エラーは `errors.json` に報告されます。これらには、モデルの予測の精度やその他のメトリクスに関する情報が含まれています。

```bash
if os.path.isfile("errors.json"):
    print("NLU Errors:")
    print(open("errors.json").read())
else:
    print("No NLU errors.")

if os.path.isdir("results"):
      print("n")
      print("Core Errors:")
      print(open("results/failed_test_stories.yml").read())
```