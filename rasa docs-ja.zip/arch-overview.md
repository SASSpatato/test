---
id: arch-overview
sidebar_label: Overview
title: Rasa Architecture Overview
abstract: Rasa has a scalable architecture. Read about the key components of the Rasa architecture.
---

以下の図は、Rasa アーキテクチャの概要を示しています。2 つの主要なコンポーネントは、自然言語理解 (NLU) と対話管理です。

NLU は、インテントの分類、エンティティの抽出、応答の取得を処理する部分です。トレーニングされたパイプラインによって生成された NLU モデルを使用してユーザーの発話を処理するため、*NLU パイプライン*として以下に示されています。

対話管理コンポーネントは、コンテキストに基づいて会話の次のアクションを決定します。これは、図に*ダイアログ ポリシー*として表示されます。![image](/static/img/architecture.png)