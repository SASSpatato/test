---
id: spaces
sidebar_label: Spaces
title: Spaces
description: Learn about Spaces for Rasa.
abstract: Spaces are a way to modularize your assistant that increases isolation between subparts and classification performance for intents and entities that are only relevant in specific contexts.
---

> [!warning] Rasa Proのみ

> [!note] 3.6.0a1 の新機能
> これはアルファ リリースです。このアルファ版リリースにより、ユーザーからのフィードバックを収集し、将来のリリースに統合できるようになります。ぜひお試しください!このアルファ リリースの機能は、将来変更される可能性があります。フィードバック (肯定的または否定的) がある場合は、サポート連絡先を通じて共有してください。

スペースは、アシスタントをモジュール化する方法です。アシスタントの規模と範囲が拡大するにつれて、インテント、エンティティ、およびその他の [[./glossary.md#ラサプリミティブ|Rasa プリミティブ]] 間の競合の可能性も高まります。これは、通常の rasa アシスタントでは、すべてのインテント、エンティティ、およびアクションがいつでも使用可能であり、アシスタントは追加されるものを区別するための選択肢が増えるためです。スペースは、 [[./glossary.md#ラサプリミティブ|Rasa プリミティブ]] 。これらの各グループは、スペースと呼ばれます。スペースは、エントリインテントと呼ばれる特定の指定されたインテントが予測されるとアクティブになります。スペースをアクティブにすると、スペースのすべてのプリミティブが、ユーザーとの後続の対話に使用できるようになります。空間について考える良い方法は次のとおりです。

*   後続のプリミティブを指定でき、別のインテントが事前に来た後にのみアクセス可能になります
*   それらは、プリミティブを共有する可能性を備えた複数のサブボットを 1 つに統合したようなものです

## スペースを使用する場合

スペースは、1 つのアシスタントでビジネスの複数のドメインを扱う場合に役立ちます。多くの場合、これにより、ある時点で重複し始める多数のフォーム、エンティティ、および通知インテントが発生します。フォーム入力とインフォームインテントは、上記のこのフォローアップ構造を持つ典型的なケースです。別の良いケースは、ユーザーが属しているサブドメインまたはプロセスに基づいて、ヘルプまたは説明要求に対して異なる動作を定義できるようにする場合です。これは、今日、ストーリーでは技術的に可能ですが、すべてのインタラクション ルートの完全なイベント ホライズンを記述するのは面倒な場合があります。

## スペースを使用しない場合/制限事項

スペースは rasa ボットを複数の部分に分割するため、rasa ボットの既存のほぼすべての機能と対話しています。ほとんどすべてのもので動作させましたが、いくつかの例外があります。ただし、rasa の通常の動作方法に沿ったコンポーネント以外のカスタマイズを作成した場合、スペースは機能しない可能性があります。

もう 1 つの重要な制限は、スペースが現在ストーリーをサポートしていないことです。これは、多くの既存のボットにとって大きな制限であることは承知しています。ただし、ストーリーとその既存のポリシーは固定された事象の地平線 (`max_history`) で機能するため、現時点では、カプセル化された論理単位を適切に記述できるという考えと互換性がありません。

現在、スペースが作成する境界で動作する唯一のエンティティ抽出器は、`CRFEntityExtractor` の適応バージョンです。これについては、次のセクションで詳しく説明します。

## スペース ボットの例

スペースを使用してボットを作成し、見て、学び、実験できるようにしました。金融領域に3つの異なるスペースがあります。[これがリポジトリです](https://github.com/RasaHQ/financial-spaces-bot)

## スペースの使い方

スペースは、ドメイン、nlu、およびルールファイルの個別のセットによって定義されます。次に、これらの個別のセットを組み立てて、統一されたアシスタントを作成します。組立計画は、新しく導入された`スペース`キーを使用して`config.yml`に追加する必要があります。第二に、あなたは必要です 組立計画を読み取って実行する特別なデータインポータを使用します。第三に、あなたは必要です をクリックして、NLU パイプラインに特定のスペース対応コンポーネントを追加します。以下は、 上記のリンク先のFinancial Spacesボット`のconfig.yml`:

```yaml
# https://rasa.com/docs/rasa/model-configuration/
recipe: default.v1

# Configuration for Rasa NLU.
# https://rasa.com/docs/rasa/nlu/components/
language: en

spaces:
  - name: main
    domain: main/domain.yml
    nlu: main/nlu/training_data.yml
    nlu_test: main/nlu/test_data.yml
    rules: main/rules.yml
  - name: transfer_money
    domain: transfer_money/domain.yml
    nlu: transfer_money/nlu/training_data.yml
    nlu_test: transfer_money/nlu/test_data.yml
    rules: transfer_money/rules.yml
    entry_intents:
      - transfer_money
  - name: investment
    domain: investment/domain.yml
    nlu: investment/nlu/training_data.yml
    nlu_test: investment/nlu/test_data.yml
    rules: investment/rules.yml
    entry_intents:
      - buy_stock
  - name: pay_cc
    domain: pay_cc/domain.yml
    nlu: pay_cc/nlu/training_data.yml
    nlu_test: pay_cc/nlu/test_data.yml
    rules: pay_cc/rules.yml
    entry_intents:
      - pay_cc

importers:
  - name: "rasa_plus.spaces.space_data_importer.SpaceDataImporter"
    temporary_working_directory: spaces

pipeline:
  - name: WhitespaceTokenizer
  - name: RegexFeaturizer
  - name: LexicalSyntacticFeaturizer
  - name: CountVectorsFeaturizer
  - name: CountVectorsFeaturizer
    analyzer: char_wb
    min_ngram: 1
    max_ngram: 4
  - name: rasa_plus.spaces.components.spaces_crf_entity_extractor.SpacesCRFEntityExtractor
  - name: EntitySynonymMapper
  - name: DIETClassifier
    epochs: 100
    ranking_length: 0
    entity_recognition: false
    BILOU_flag: false
  - name: rasa_plus.spaces.components.filter_and_rerank.FilterAndRerank
  - name: FallbackClassifier
    threshold: 0.3
    ambiguity_threshold: 0.1

policies:
  - name: RulePolicy

```

上記の設定ファイルでは、共有プリミティブのスペースの指定名であるメインスペースと、送金、投資、クレジットカード決済の3つのサブスペースを含むスペース定義を見ることができます。メインスペースは必須ではありませんが、スペース間でプリミティブを共有する唯一の方法です。各パス値は、単一のファイルまたはディレクトリを指すことができます。

次に、インポーターも表示されます 使用 `rasa_plus.spaces.space_data_importer.SpaceDataImporter` されています。このインポーターは、上記のスペース定義を読み取り、ボットをアセンブルします。結果は、一時作業ディレクトリで確認できます。

3 番目に、スペースを機能させるために必要な特定の NLU コンポーネントを確認できます。最も重要なのは、インテントのランキングとエンティティの抽出を後処理してスペースを機能させるための中心となる `FilterAndRerank` コンポーネントです。エンティティ抽出も必要な場合は、`SpacesCRFEntityExtractor` を使用してスペースを操作する必要があります。

最後に、ここでは `RulePolicy` のみを使用していることがわかります。

スペースを作成し、`config.yml`を調整した後、`rasa train -c config.yml`を使用して新しいアシスタントをトレーニングし、その後で `rasa シェル`。

### 特定の部分空間のみを学習させる

rasa trainコマンドに`--space`引数を追加して、1つの特定の部分空間のみをトレーニングするオプションを提供しました。

`rasa train` ->は、すべてのスペースでフルアシスタントをトレーニングします `rasa train --space investment` ->は、投資とメインスペースのみを含むアシスタントをトレーニングします

他のコマンドは、訓練されたアシスタントを入力として使用するため、調整されませんでした。

## スペースはどのように機能しますか?

以下では、必要な場合に何が起こっているのかをよりよく理解できるように、スペースの内部で物事がどのように機能するかを見ていきます。

最も重要な側面の 1 つは、スペースが 2 つのレイヤーで階層を形成することです。上部には、すべてのスペースで使用できる共有プリミティブを含むメインスペースがあります。メインスペースは常にアクティブです。部分空間で定義されているものはすべて、その空間でのみ使用でき、他の部分空間やメイン空間では使用できません。

<img alt="2層空間階層" src={useBaseUrl("/img/spaces_hierarchy.png")} />

### 組み立て中は何が起こりますか?

組み立て中の最も重要なステップはプレフィックスです。このステップでは、すべての インテント、エンティティ、スロット、アクション、フォーム、スペースのドメインファイルで定義されている発話 は、このスペースの名前のプレフィックス (発話の場合は中置) です。たとえば、インテント `transfer_money`ドメインの`ask_transfer_charge`は次のようになります `transfer_money.ask_transfer_charge` そして、この意図のすべての参照が調整されるでしょう。その後、最後のアシスタントは接頭辞付きのデータを処理します。

これに対する例外はメインスペースです。メイン スペース内のものと、他のスペースで使用されるすべてのプリミティブには、プレフィックスは付けられません。

もう一つの例外はルールです。プレフィックスを付けることができる名前はありません。代わりに、各ルールに、スペースがアクティブな間のみ適用されるという条件を追加します。

### スペースのアクティベーションはどのように追跡されますか?

スペースは、入力インテントのいずれかが予測されるとアクティブになります。スペースには複数のエントリインテントを含めることができます。ただし、一度にアクティブにできるスペースは 1 つだけです。したがって、スペース A がアクティブで、スペース B のエントリ インテントが予測されると、スペース A は非アクティブ化され、スペース B はこれからアクティブになります。

スペースの活性化は、組み立て中に自動的に生成されるスロットを介して追跡されます。

### フィルターと再ランク付けはどのように機能しますか?

フィルターと再ランクコンポーネントは、[[./components.md#インテント分類子|インテント分類コンポーネント]] のインテントランク付けを後処理します。[トラッカー](./action-server/sdk-tracker.md)にアクセスし、エントリインテントが一番上にある場合に備えて、どのスペースがアクティブであるか、またはアクティブになるかをチェックします。

次に、不可能なインテントをランキングから削除します。さらに、スペースのアクティブ化ステータスが与えられない場合、または予測されようとしているエントリー・インテントが与えられないエンティティーも削除されます。

### エンティティ認識の仕組みはどのように異なりますか?

通常、Rasa のエンティティ認識エンジンは、メッセージ内のトークンごとに 1 つのラベルのみを返します。したがって、インテントの場合のように後処理できるランキングはありません。`SpacesCRFEntityExtractor` は、複数の抽出器を作成する方法で構築しました。各スペースに1つずつ。これで、後処理ステップ中に、アクティブ化されていないスペースの抽出器を除外できます。

### カスタムアクション

カスタムアクションは以前と同様に機能します。ただし、トラッカー、ドメイン、スロットは、アクションに渡される前に、他のスペースから情報が取り除かれます。さらに、スロットセットなどのすべてのイベントには、アクションによって返された後にプレフィックスが付けられます。これらすべてにより、カスタムアクションの観点から、他のスペースや誤って情報が漏洩したり変更されたりすることを心配する必要はありません。これにより、スペース間の分離が保証されます。メイン スペースからのカスタム アクションは、サブスペースに継承されないことに注意してください。

### 応答選択

応答の選択は以前と同様に機能します。唯一の小さな違いは、 `config.yaml` では、最終プレフィックスを含む取得インテントを指定する必要があります。検索インテントが`投資`スペースで`investment_faq`されている場合は、設定で`investment.investment_faq`検索インテントとして設定する必要があります。取得インテントがメイン・スペースに属している場合、プレフィックスは追加されません。そのため、この場合、検索意図の定義中は接頭辞は必要ありません。

### ルックアップテーブルと同義語

[[./training-data-format.md#ルックアップテーブル|ルックアップテーブル]]と[[./training-data-format.md#類義 語|同義語]]スペースで機能します。ただし、それらは空間間で完全に分離されているわけではありません。そのため、予期しないやり取りが発生する可能性があります。同義語の場合、具体的には:

*   2 つのスペースが同じシノニムを定義するとします。スペースA:「IB」->「インスタントバンキング」。スペースB:「IB」->「鉄の銀行」。一方の値が他方の値を上書きするという警告が表示されます。
*   「IB」が両方のスペースのエンティティであるが、1つだけが同義語を定義している場合、同様のことが起こる可能性があります。値 IB を持つエンティティは、どのスペースがアクティブであっても、常にそのシノニムにマップされます。

ルックアップ テーブルの場合、不利な相互作用は不明です。