---
id: event-brokers
sidebar_label: Event Brokers
title: Event Brokers
description: Find out how open source chatbot framework Rasa allows you to stream events to a message broker.
---

イベント・ブローカーを使用すると、会話から入ってくるデータを処理する他のサービスに実行中のアシスタントを接続できます。イベントブローカーは、メッセージをメッセージストリーミングサービス(メッセージブローカーとも呼ばれます)に公開し、Rasaサーバーから他のサービスにRasa [Events](./action-server/events.md)を転送します。

## 形式

すべてのイベントは、トラッカーが状態を更新するたびに、シリアル化されたディクショナリとしてブローカーにストリーミングされます。`デフォルト`から出力されるイベントの例 トラッカーは次のようになります。

```json
{
    "sender_id": "default",
    "timestamp": 1528402837.617099,
    "event": "bot",
    "text": "what your bot said",
    "data": "some data about e.g. attachments"
    "metadata" {
          "a key": "a value",
     }
}
```

`イベント`フィールドは、イベントの`type_name`を受け取ります(イベントタイプの詳細については、[イベント](./action-server/events.md)ドキュメントを参照してください)。

## Pikaイベントブローカー

ここで紹介する実装例では、 [Pika](https://pika.readthedocs.io) 、[RabbitMQ](https://www.rabbitmq.com) 用の Python クライアント ライブラリ。

### エンドポイント設定を使用した Pika イベントブローカーの追加

`event_broker` セクションを `endpoints.yml`:

`endpoints.yml` ファイルでカスタマイズできるすべての引数の包括的なリストは、[リファレンス ドキュメント](https://rasa.com/docs/rasa/reference/rasa/core/brokers/pika/#__init__)にあります。Rasaサーバーを再起動すると、Rasaは自動的にイベントのストリーミングを開始します。

### Pika イベントブローカーへの SSL オプションの追加

RabbitMQ SSL オプションを作成するには、次の必須環境変数を設定します。

*   `RABBITMQ_SSL_CLIENT_CERTIFICATE` : SSL クライアント証明書へのパス
*   `RABBITMQ_SSL_CLIENT_KEY`: SSL クライアントキーへのパス

環境変数による「RABBITMQ_SSL_CA_FILE」の指定や、環境変数`RABBITMQ_SSL_KEY_PASSWORD`指定はサポートされなくなりましたので、代わりに暗号化されていないキーファイルを使用してください。

### Python での Pika イベント ブローカーの追加

Python コードを使用して追加する方法は次のとおりです。

```python
import asyncio

from rasa.core.brokers.pika import PikaEventBroker
from rasa.core.tracker_store import InMemoryTrackerStore

pika_broker = PikaEventBroker('localhost',
                              'username',
                              'password',
                              queues=['rasa_events'],
                              event_loop=event_loop
                              )
asyncio.run(pika_broker.connect())

tracker_store = InMemoryTrackerStore(domain=domain, event_broker=pika_broker)
```

### Pika イベント コンシューマーの実装

RabbitMQ サーバーと別のアプリケーションを実行する必要があります イベントを消費します。このコンシューマーは、Pikaの `start_consuming()` メソッドを`コールバック`アクションで指定します。簡単な例を次に示します。

```python
import json
import pika


def _callback(ch, method, properties, body):
        # Do something useful with your incoming message body here, e.g.
        # saving it to a database
        print("Received event {}".format(json.loads(body)))

if __name__ == "__main__":

    # RabbitMQ credentials with username and password
    credentials = pika.PlainCredentials("username", "password")

    # Pika connection to the RabbitMQ host - typically 'rabbit' in a
    # docker environment, or 'localhost' in a local environment
    connection = pika.BlockingConnection(
        pika.ConnectionParameters("rabbit", credentials=credentials)
    )

    # start consumption of channel
    channel = connection.channel()
    channel.basic_consume(queue="rasa_events", on_message_callback=_callback, auto_ack=True)
    channel.start_consuming()
```

## Kafka イベントブローカー

RabbitMQ はデフォルトのイベントブローカーですが、[Kafka](https://kafka.apache.org/) をイベントのメインブローカーとして使用することもできます。Rasa は、Python で記述された Kafka クライアントである [confluent-kafka](https://docs.confluent.io/platform/current/clients/confluent-kafka-python/html/index.html#) ライブラリを使用します。実行中の Kafka サーバーが必要です。

### パーティションキー

RasaのKafkaプロデューサーは、オプションで会話IDでメッセージをパーティション分割するように構成できます。これは、`endpoints.yml` ファイルの `partition_by_sender` を True に設定することで構成できます。デフォルトでは、このパラメータは `False` に設定されており、プロデューサーは各メッセージにパーティションをランダムに割り当てます。

```yaml-rasa
event_broker:
  type: kafka
  partition_by_sender: True
  security_protocol: PLAINTEXT
  topic: topic
  url: localhost
  client_id: kafka-python-rasa
```

### 認証と承認

Rasa の Kafka プロデューサーは、`SASL_PLAINTEXT`、`SSL`、`PLAINTEXT`、`SASL_SSL` のタイプのセキュリティプロトコルを受け入れます。

開発環境の場合、またはブローカーサーバーとクライアントが同じマシンにある場合は、`SASL_PLAINTEXT`または`PLAINTEXT`による簡易認証を使用できます。このプロトコルを使用すると、クライアントとサーバー間で交換される資格情報とメッセージがプレーンテキストで送信されます。したがって、これは最も安全なアプローチではありませんが、構成が簡単なため、単純なクラスター構成に役立ちます。 `SASL_PLAINTEXT`プロトコルでは、`ユーザー名`と`パスワード`の設定が必要です ブローカーサーバーで以前に構成されている。

kafka クラスター内のクライアントまたはブローカーが異なるマシンにある場合は、`SSL` または `SASL_SSL` プロトコルを使用して、データとクライアント認証の暗号化を確実にすることが重要です。ブローカーとクライアントに対して有効な証明書を生成した後、プロデューサー用に生成された証明書とキーへのパス、および CA のルート証明書を引数として指定する必要があります。

`SASL_PLAINTEXT`プロトコルと`SASL_SSL`プロトコルを使用する場合、`sasl_mechanism`はオプションで設定でき、デフォルトでは`PLAIN`に設定されています。`sasl_mechanism`の有効な値 `PLAIN、``GSSAPI、``OAUTHBEARER`、`SCRAM-SHA-256`、および `SCRAM-SHA-512` です。

`sasl_mechanism`に`GSSAPI`を使用する場合は、追加でインストールする必要があります [python-gssapi](https://pypi.org/project/python-gssapi/) と必要な C ライブラリの Kerberos 依存関係。

`ssl_check_hostname` パラメーターが有効になっている場合、クライアントはブローカーのホスト名が証明書と一致するかどうかを確認します。これは、中間者攻撃を防ぐために、クライアントの接続とブローカー間接続で使用されます。

### エンドポイント設定を使用した Kafka イベントブローカーの追加

`endpoints.yml`に`event_broker`セクションを追加することで、すべてのイベントを Kafka イベントブローカーにストリーミングするように Rasa に指示できます。

`SASL_PLAINTEXT` プロトコルを使用する場合、エンドポイントファイルには次のエントリが必要です。

`PLAINTEXT` プロトコルを使用すると、エンドポイントファイルには次のエントリが必要です。

`SSL` プロトコルを使用する場合、エンドポイント ファイルは次のようになります。

`SASL_SSL` プロトコルを使用する場合、エンドポイント ファイルは次のようになります。

## SQL イベント ブローカー

SQL データベースをイベント ブローカーとして使用できます。データベースへの接続は、[SQLite](https://sqlite.org/index.html)、[PostgreSQL](https://www.postgresql.org/)など、さまざまな種類のSQLデータベースと対話できるPythonライブラリである[SQLAlchemy](https://www.sqlalchemy.org/)を使用して確立されます。デフォルトの Rasa インストールでは、SQLite および PostgreSQL データベースへの接続が可能です。その他のオプションについては、[SQL 方言に関する SQLAlchemy のドキュメント](https://docs.sqlalchemy.org/en/13/dialects/index.html)を参照してください。

### エンドポイント構成を使用したSQLイベント・ブローカの追加

すべてのイベントを SQL イベントブローカーに保存するように Rasa に指示するには、`endpoints.yml`に`event_broker`セクションを追加します。たとえば、有効な SQLite 構成は次のようになります。

```yaml-rasa
event_broker:
  type: SQL
  dialect: sqlite
  db: events.db
```

PostgreSQLデータベースも使用できます。

```yaml-rasa
event_broker:
  type: SQL
  url: 127.0.0.1
  port: 5432
  dialect: postgresql
  username: myuser
  password: mypassword
  db: mydatabase
```

この構成を適用すると、Rasaはデータベース上に`events`というテーブルを作成し、そこにすべてのイベントが追加されます。

## ファイルイベントブローカー

`FileEventBroker` をイベント ブローカーとして使用できます。この実装では、イベントが json 形式のファイルに記録されます。デフォルトのファイル名 `rasa_event.log` をオーバーライドする場合は、`endpoints.yml` ファイルにパスキーを指定できます。

## カスタムイベントブローカー

すぐに使えないイベントブローカーが必要な場合は、独自のイベントブローカーを実装できます。これは、基本クラス `EventBroker` を拡張することによって行われます。

カスタム イベント ブローカー クラスでは、次の基本クラス メソッドも実装する必要があります。

*   `from_endpoint_config`: エンドポイント構成から`EventBroker`オブジェクトを作成します。 [(ソースコード - 署名を参照)。](https://github.com/RasaHQ/rasa/blob/main/rasa/core/brokers/broker.py#L45)
*   `publish`: json 形式の [Rasa イベント](https://rasa.com/docs/rasa/reference/rasa/shared/core/events/)をイベントキューに公開します。 [(ソースコード - 署名を参照)。](https://github.com/RasaHQ/rasa/blob/main/rasa/core/brokers/broker.py#L63)
*   `is_ready`: イベントブローカーの準備ができているかどうかを判断します。[(ソースコード - 署名を参照)。](https://github.com/RasaHQ/rasa/blob/main/rasa/core/brokers/broker.py#L67)
*   `close`: イベントブローカーへの接続を閉じます。[(ソースコード - 署名を参照)。](https://github.com/RasaHQ/rasa/blob/main/rasa/core/brokers/broker.py#L75)

### 構成

カスタムイベントブローカーへのモジュールパスと、必要なパラメータを`endpoints.yml`に配置します。

```yaml-rasa
event_broker:
  type: path.to.your.module.Class
  url: localhost
  a_parameter: a value
  another_parameter: another value
```