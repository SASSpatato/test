---
id: slot-validation-actions
sidebar_label: Slot Validation Actions
title: Slot Validation Actions
abstract: A slot validation action is a special type of custom action, designed to handle custom extraction and/or validation of slot values. This can be used to validate slots with predefined mappings or extract slots with custom mappings.
---

スロット値のカスタム抽出と検証は、3 つの異なる方法でカスタムアクションを記述することで行うことができます。

## `action_validate_slot_mappings`

`action_validate_slot_mappings`アクションを使用して、フォームコンテキストの外部で設定または更新できるスロットのカスタム抽出や検証を定義できます。

このアクションは、デフォルトのアクション[`action_extract_slots`](./default-actions.md#action_extract_slots)の最後に自動的に呼び出されるため、名前を変更しないでください。Rasa SDKを使用している場合は、Rasa SDK [[./action-server/validation-action.md#validationaction|`ValidationAction` クラス]] を使用します。別のアクションサーバーを使用している場合は、Rasa SDKクラスと同等の機能を持つアクションクラスを実装する必要があります。詳細については、[[./action-server/validation-action.md#validationaction class implementation|the action server docs]] を参照してください。

このオプションでは、デフォルトのアクション[`action_extract_slots action_validate_slot_mappings`](./default-actions.md#action_extract_slots)実行されるため、[[./domain.md#カスタムスロットマッピング|カスタムスロットマッピング]]で`アクション`キーを指定する必要はありません ドメインの `[アクション`] セクションに存在する場合は、自動的に。

## `validate_<form name>`

`validate_<form name>` という名前のカスタム アクションは、名前で指定したフォームがアクティブになっている場合、自動的に実行されます。Rasa SDKを使用している場合、カスタムアクションはRasa SDK [[./action-server/validation-action.md#formvalidationaction class|`FormValidationAction` クラス]] を使用します。 Rasa SDKを使用していない場合は、 `FormValidationClass` をカスタムアクションサーバーで使用します。詳細については、[[./action-server/validation-action.md#validationaction class implementation|the action server docs]] を参照してください。

## 通常のカスタムアクション

[`スロット`](./action-server/events.md#スロット)を返す通常のカスタムアクション[カスタムアクション](./custom-actions.md)を使用できます カスタムスロット抽出のイベント。このオプションは、 [[#`action_validate_slot_mappings`|`action_validate_slot_mappings`]] または [[#`validate_<form name>`]]は、お客様のニーズにお応えします。たとえば、ストーリーまたはルールで同じカスタムアクションを明示的に再利用する場合は、カスタムスロット抽出に通常のカスタムアクションを使用する必要があります。スロット検証アクションは、`スロット`イベントと[`ボット`](./action-server/events.md#bot)イベントのみを返す必要があります。その他のイベントタイプは、デフォルトのアクション[`action_extract_slots`](./default-actions.md#action_extract_slots)によって除外されます。カスタムアクションの名前は、ドメイン内の関連する[[./domain.md#カスタムスロットマッピング|カスタムスロットマッピング]]の`アクション`キーで指定する必要があります。アクション名は、ドメイン`アクション`セクションにも記載されている必要があることに注意してください。

> [!note]  抽出と検証に異なるアクションを使用する
> 通常のカスタム アクションと`action_validate_slot_mappings`の両方を使用して、スロットを抽出して検証できます。たとえば、`カスタム`スロットマッピングの`アクション`として通常のカスタムアクションを指定したり、同じスロットの検証ロジックを`action_validate_slot_mappings`に追加したりできます。カスタムスロットマッピングで指定されたカスタムアクションが最初に呼び出され、その後に`action_validate_slot_mappings`が呼び出されます。