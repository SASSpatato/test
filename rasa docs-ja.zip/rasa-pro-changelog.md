---
id: rasa-pro-changelog
sidebar_label: Rasa Pro Change Log
title: Rasa Pro Change Log
---

Rasa Pro に対するすべての重要な変更は、このページに記載されています。本製品は、バージョン3.3(初期バージョン)以降の[セマンティックバージョニング](https://semver.org/)に準拠しています。

Rasa Pro は、Rasa Plus と Rasa Pro Services の 2 つのデプロイ可能な成果物で構成されています。両方のアーティファクトの変更ログは以下で読むことができます。

Rasa Open Sourceに関連するすべての変更は、専用の[Rasa Open Source変更ログ](./changelog.md)で確認できます。

## ラサプロ3.6

### ラサプラス3.6

#### 顔立ち

*   Microsoft Presidio をエンティティ アナライザーおよび匿名化エンジンとして使用した PII (個人を特定できる情報) 管理を実装しました。この機能は、次のことをカバーします。
    
    *   `endpoints.yml`で指定された Kafka イベントブローカーの匿名化トピックにストリーミングされる前に、Rasa イベント (`UserUttered`、`BotUttered`、`SlotSet`、`EntitiesAdded`) を匿名化します。
    *   PII データを公開する Rasa ログの匿名化
    
    この機能の主なコンポーネントは次のとおりです。
    
    *   匿名化するPIIエンティティと使用する匿名化方法を`endpoints.yml`で定義する匿名化ルール
    *   特定のテキストに対して匿名化ルールを実行する匿名化エグゼキュータ
    *   匿名化ルールの実行を調整し、匿名化されたイベントを一致した Kafka トピックに公開する匿名化オーケストレーター。
    *   オーケストレーターのリストを含み、シングルトン プロバイダー コンポーネントに登録されている匿名化パイプラインで、イベントとログを匿名化するためにパイプラインを取得する必要がある場合に、Rasa Open Source のフック呼び出しで呼び出されます。
    
    開始方法については、公式ドキュメントの「[PII 管理](./pii-management.md)」セクションをお読みください。
    
*   Analytics Data Pipeline を使用した[マーカー](./monitoring/analytics/realtime-markers.md)のリアルタイム評価のサポートを実装しました。この機能では、`rasa markers upload`コマンドのサポートを追加しました。このコマンドを実行すると、マーカー設定ファイルがドメインファイルに対して検証され、設定が Analytics Data Pipeline にアップロードされます。
    

### 改善

*   Rasa Pro Servicesにマーカーをアップロードする「`rasa marker upload`」コマンドを追加します。
    
*   必須フィールドと重複 ID のチェックを導入することで、`endpoints.yaml` の`匿名化`キーの検証を強化します。
    

### バグ修正

*   structlog キー `rasa_events`匿名化します。
*   ローカルでトレーニングされたモデルをクラウド rasa-plus インスタンスにアップロードする際、スロットが正しく設定されていないために会話が期待どおりに進まない問題を修正しました (例: "存在しないスロット 'placeholder_slot_name' を設定しようとしました) エラーがログに記録されます。すべてのスロットをドメインファイルに追加したことを確認してください。これは、クラウドアップロード中に更新されたドメインが、`AuthRetryTrackerStore` rasa-plusコンポーネントのラップされたトラッカーストアに渡されなかったためです。修正は、ドメイン プロパティとセッター メソッドを `AuthRetryTrackerStore` コンポーネントに追加することでした。
*   `rasa studio upload` を使用する場合、ユーザーが特定の`インテント`または`エンティティ`を指定していない場合、更新には使用可能なすべての`インテント`または`エンティティ`が含まれるようになりました。

#### 非推奨と削除

*   Python 3.7 のサポートは [2023 年 6 月にサポート終了を迎](https://devguide.python.org/versions/)えるため削除されました

### Rasa Pro サービス 3.1

#### 顔立ち

*   Analytics Data Pipelineで[マーカー](./monitoring/analytics/realtime-markers.md)をリアルタイムで処理できるようになり、貴重な洞察を得て、Rasa Assistantのパフォーマンスを向上させることができます。

## ラサプロ3.5

### ラサプラス3.5

#### 顔立ち

*   [[./testing-your-assistant.md#エンドツーエンドのテスト|エンドツーエンドのテスト]] は、さまざまな事前設定済みコンテキストで会話シナリオをテストし、カスタムアクションを実行し、応答テキストまたは名前を検証し、スロットがいっぱいになったときにアサートできる、拡張された包括的な CLI ベースのテストツールです。これは、新しい `rasa test e2e` コマンドを使用して使用できます。
*   これで、アシスタントのシークレットを[外部資格情報マネージャー](./secrets-managers.md)に保管できます。このリリースでは、Rasa Pro は現在、HashiCorp Vault を使用したトラッカーストアの資格情報マネージャーをサポートしています。

### Rasa Pro サービス 3.0

*前回のマイナーバージョンから大きな変更はありません。*

## ラサプロ3.4

### ラサプラス3.4

#### 顔立ち

*   アシスタントをAudioCodes VoiceAI Connectに接続するための新しい[IVRチャネルコネクタ](./connectors/audioodes-voiceai-connect.md)を追加しました。

#### 改善

*   Rasa Pro は Python 3.10 をサポートするようになりました。

### Rasa Pro サービス 3.0

*前回のマイナーバージョンから大きな変更はありません。*

## ラサプロ3.3

### ラサプラス3.3

#### 顔立ち

*   Rasa Pro アシスタントの[トレース機能](./monitoring/tracing.md)。分散トレースは、分散システム (この場合は Rasa アシスタント) を通過するリクエストを追跡し、リクエストに関するデータをトレース バックエンドに送信し、トレース バックエンドがすべてのトレース データを収集して検査できるようにします。このバージョンのトレース機能では、Rasa ProはOpenTelemetryをサポートしています。
*   [Concurrent Lock Store](./lock-stores.md#concurrentredislockstore) は、Redis を永続化レイヤーとして使用する新しいロックストアであり、複数の Rasa サーバーレプリカで安全に使用できます。

### Rasa Pro サービス 3.0

#### 顔立ち

*   [Analytics Data Pipeline](./monitoring/analytics/getting-started-with-analytics.md)は、選択したツール(BIツール、データウェアハウス)でRasaアシスタントの指標を視覚化して処理するのに役立ちます。生産アシスタントとその会話の視覚化と分析により、ROIを評価し、時間の経過とともにアシスタントのパフォーマンスを向上させることができます。