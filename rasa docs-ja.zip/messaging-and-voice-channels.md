---
id: messaging-and-voice-channels
sidebar_label: Connecting to a Channel
title: Connecting to Messaging and Voice Channels
description: Check out how to make your Rasa assistant available on platforms like Facebook Messenger, Slack, Telegram or even your very own website.
abstract: Rasa provides many built-in connectors to connect to common messaging and voice channels.
  You can also connect to your website or app with pre-configured REST channels or build your own custom connector.
---

## チャネルへの接続

アシスタントを以下で使用できるようにする方法については、こちらをご覧ください。

*   [あなた自身のウェブサイト](./connectors/your-own-website.md)
    
*   [Facebookメッセンジャー](./connectors/facebook-messenger.md)
    
*   [スラック](./connectors/slack.md)
    
*   [電報](./connectors/telegram.md)
    
*   [ツイリオ](./connectors/twilio.md)
    
*   [Microsoft Bot Framework](./connectors/microsoft-bot-framework.md)
    
*   [Cisco Webex チーム](./connectors/cisco-webex-teams.md)
    
*   [ロケットチャット](./connectors/rocketchat.md)
    
*   [マターモスト](./connectors/mattermost.md)
    
*   [Google ハングアウト チャット](./connectors/hangouts.md)
    
*   [カスタムコネクタ](./connectors/custom-connectors.md)
    

## ローカルマシンでのチャネルのテスト

`localhost` で Rasa サーバーを実行している場合、`localhost` はインターネットに対して開いていないため、ほとんどの外部チャネルはサーバーの URL を見つけることができません。

ローカル コンピューター上のポートをインターネット上でパブリックに利用できるようにするには、[ngrok](https://ngrok.com/) を使用できます。または、他のトンネリング ソリューションの追跡と比較に関するこの[リスト](https://github.com/anderspitman/awesome-tunneling)を参照してください。

ngrokをインストールした後、次のコマンドを実行します。

```bash
ngrok http 5005; rasa run
```

指示に従ってチャネルでアシスタントを使用できるようにする場合は、ngrok URL を使用します。具体的には、手順に `https://<host>:<port>/webhooks/<CHANNEL>/webhook` 、 を使用する `<ngrok_url>/webhooks/<CHANNEL>/webhook` ように指示されている場合は、 `を使用し、 <ngrok_url>` を ngrok ターミナル ウィンドウに表示されるランダムに生成された URL に置き換えます。たとえば、ボットを Slack に接続する場合、URL は `https://26e7e7744191.ngrok.io/webhooks/slack/webhook` のようになります。

> [!caution] 
> ngrok の無料利用枠では、1 分あたりにできる接続数に制限が発生する可能性があります。これを書いている時点では、40接続/分に設定されています。

または、`-i` コマンド行オプションを使用して、アシスタントに特定のアドレスをリッスンさせることもできます。

```bash
rasa run -p 5005 -i 192.168.69.150
```

これは、インターネットに接続するマシンが VPN インターフェイスを使用してバックエンド サーバーに接続する場合に特に便利です。