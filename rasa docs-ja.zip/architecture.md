---
id: architecture
sidebar_label: Rasa Architecture
title: Rasa Architecture
description: Check the architecture to understand how Rasa uses machine learning, context and state of the conversation to predict the next action of the AI Assistant.
---

## メッセージ処理

次の図は、Rasa で構築されたアシスタントがメッセージに応答する方法の基本的なステップを示しています。

![[architecture-img.png]]

手順は次のとおりです。

1.  メッセージは受信されて`インタープリター`に渡され、インタープリターは元のテキスト、インテント、および見つかったエンティティを含む辞書に変換されます。この部分はNLUが担当します。
    
2.  メッセージは`インタープリター`から`トラッカー`に渡されます。`トラッカー`は、会話の状態を追跡するオブジェクトです。
    
3.  トラッカーの現在の状態が各ポリシーに送信されます。
    
4.  各ポリシーは、次に実行するアクションを選択します。
    
5.  選択したアクションはトラッカーによってログに記録されます。
    
6.  応答がユーザーに送信されます。