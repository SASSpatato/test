---
id: policies
sidebar_label: Policies
title: Policies
abstract: Your assistant uses policies to decide which action to take at each step in a conversation. There are machine-learning and rule-based policies that your assistant can use in tandem.
---

`ポリシー`を指定することで、アシスタントが使用するポリシーをカスタマイズできます プロジェクトの`config.yml`にキーを入力します。さまざまなポリシーから選択でき、1 つの構成に複数のポリシーを含めることができます。ポリシーのリストの例を次に示します。

```yaml-rasa
recipe: default.v1
language:  # your language
pipeline:
  # - <pipeline components>

policies:
  - name: MemoizationPolicy
  - name: TEDPolicy
    max_history: 5
    epochs: 200
  - name: RulePolicy
```

> [!tip] ゼロから始める?
> どのポリシーを選択すればよいかわからない場合は、`config.yml`から`ポリシー`キーを完全に省略します。その場合、[[./model-configuration.md#推奨される構成|推奨される構成]]機能は、デフォルトのポリシーを提供します。

## アクション選択

すべてのターンで、構成で定義された各ポリシーは、特定の信頼レベルで次のアクションを予測します。各ポリシーがどのように決定されるかの詳細については、以下のポリシーの説明をお読みください。最も高い信頼度で予測するポリシーによって、アシスタントの次のアクションが決定されます。

> [!note] 
> 予測の最大数デフォルトでは、アシスタントは各ユーザーメッセージの後に最大10の次のアクションを予測できます。この値を更新するには、環境変数を `MAX_NUMBER_OF_PREDICTIONS` 必要な最大予測数に。

### ポリシーの優先順位

2つのポリシーが等しい信頼度で予測する場合(例えば、メモ化ポリシーとルール・ポリシーの両方が信頼度1で予測する場合)、ポリシーの優先順位が考慮されます。Rasa ポリシーには、同点の場合に期待される結果を保証するために設定されたデフォルトの優先順位があります。これらは次のようになりますが、数値が大きいほど優先度が高くなります。

*   6 - `ルールポリシー`
    
*   3 - `MemoizationPolicy` または `AugmentedMemoizationPolicy`
    
*   2 - `UnexpecTEDIntentPolicy`
    
*   1 - `TEDポリシー`
    

一般に、設定の優先度レベルごとに複数のポリシーを設定することはお勧めしません。同じ優先度を持つ 2 つのポリシーがあり、それらが同じ信頼度で予測する場合、結果のアクションはランダムに選択されます。

独自のポリシーを作成する場合は、これらの優先順位を、ポリシーの優先順位を把握するためのガイドとして使用してください。ポリシーが機械学習ポリシーの場合、`ほとんどの場合、TEDPolicy` と同じ優先度 1 が必要です。

> [!warning] 
> ポリシーの優先順位を上書きするすべてのポリシーの優先順位は、ポリシーの設定の `priority` パラメーターを使用して構成できますが、カスタム ポリシーなどの特定のケース以外で変更することは**お勧めしません**。そうすると、予期しない望ましくないボットの動作につながる可能性があります。

## 機械学習ポリシー

### TEDポリシー

Transformer Embedding Dialogue (TED) ポリシーは、次のアクションの予測とエンティティ認識のためのマルチタスク アーキテクチャです。アーキテクチャは、両方のタスクで共有されるいくつかのトランスエンコーダーで構成されています。エンティティ ラベルのシーケンスは、トークンの入力シーケンスに対応するユーザー シーケンス トランスフォーマー エンコーダー出力の上にある条件付きランダム フィールド (CRF) タグ付けレイヤーを介して予測されます。次のアクション予測では、ダイアログトランスフォーマーエンコーダー出力とシステムアクションラベルが単一のセマンティックベクトル空間に埋め込まれます。ドット積損失を使用して、ターゲットラベルとの類似性を最大化し、ネガティブサンプルとの類似性を最小化します。

モデルについて詳しく知りたい場合は、[私たちの論文](https://arxiv.org/abs/1910.00486)と [YouTubeチャンネル](https://www.youtube.com/watch?v=j90NvurJI4I&list=PL75e0qA87dlG-za8eLI6t0_Pbxafk-cxb&index=14&ab_channel=Rasa)。ここで、モデルアーキテクチャを詳細に説明します。

TED ポリシーのアーキテクチャは、次の手順で構成されます。

1.  の機能を連結する
    
    *   ユーザー入力(ユーザーインテントおよびエンティティ)またはユーザーシーケンストランスフォーマーエンコーダーを介して処理されたユーザーテキスト、
    *   ボット シーケンス トランスフォーマー エンコーダーを介して処理された以前のシステム アクションまたはボット発話、
    *   スロットとアクティブなフォーム
    
    ダイアログトランスフォーマーの前の埋め込みレイヤーへの入力ベクトルへのタイムステップごとに。
    
2.  入力ベクトルの埋め込みをダイアログトランスフォーマーエンコーダーにフィードします。
    
3.  ダイアログトランスフォーマーの出力に密なレイヤーを適用して、各タイムステップのダイアログの埋め込みを取得します。
    
4.  密なレイヤーを適用して、各タイム ステップのシステム アクションの埋め込みを作成します。
    
5.  ダイアログ埋め込みと埋め込みシステムアクションの類似性を計算します。このステップは、[StarSpace](https://arxiv.org/abs/1709.03856) のアイデアに基づいています。
    
6.  ユーザーシーケンストランスフォーマーエンコーダーのトークンレベルの出力を、各タイムステップのダイアログトランスフォーマーエンコーダーの出力と連結します。
    
7.  CRF アルゴリズムを適用して、各ユーザー テキスト入力のコンテキスト エンティティを予測します。
    

**構成：**

`config.yml` ファイルを使用して、構成パラメーターを `TEDPolicy` に渡すことができます。モデルを微調整する場合は、まず次のパラメーターを変更します。

*   `epochs`: このパラメータは、アルゴリズムがトレーニングデータを表示する回数を設定します (デフォルト: `1`)。1 `エポック`は、すべてのトレーニング例の 1 つのフォワードパスと 1 つのバックワードパスに相当します。モデルが適切に学習するには、より多くのエポックが必要な場合があります。エポックが増してもパフォーマンスに影響を与えない場合があります。エポック数が少ないほど、モデルのトレーニングが速くなります。構成は次のようになります。
    
    ```yaml-rasa
    policies:
    - name: TEDPolicy
      epochs: 200
    ```
    
*   `max_history`: このパラメータは、モデルが次に実行するアクションを決定するために参照する対話履歴の量を制御します。このポリシーのデフォルト`max_history`は `None` で、セッションの再起動以降の完全な対話履歴が考慮されます。モデルが特定の数の前のダイアログ ターンのみを表示するように制限する場合は、`max_history`を有限値に設定できます。モデルが正しい予測を作成するのに十分な前の対話ターンを持つように、`慎重に選択max_history`必要があることに注意してください。詳細については、[[#フィーチャライザー]] を参照してください。構成は次のようになります。
    
    ```yaml-rasa
    policies:
    - name: TEDPolicy
      max_history: 8
    ```
    
*   `number_of_transformer_layers`: このパラメータは、ユーザー、アクション、アクションのラベルテキストのシーケンシャルトランスフォーマーエンコーダー、およびダイアログトランスフォーマーエンコーダーに使用するシーケンストランスフォーマーエンコーダーレイヤーの数を設定します。(デフォルト: `text: 1, action_text: 1, label_action_text: 1, dialogue: 1` )。シーケンストランスフォーマーエンコーダー層の数は、モデルに使用するトランスフォーマーブロックに対応します。
    
*   `transformer_size`: このパラメータは、ユーザー、アクション、アクションのラベルテキストのシーケンシャルトランスフォーマーエンコーダー、およびダイアログトランスフォーマーエンコーダーに使用するシーケンストランスフォーマーエンコーダーレイヤーの単位数を設定します。(デフォルト: `text: 128, action_text: 128, label_action_text: 128, dialogue: 128` )。トランスエンコーダーから出てくるベクトルは、指定された`transformer_size`を持ちます。
    
*   `connection_density`: このパラメータは、モデル内のすべてのフィードフォワード層(デフォルト:`0.2`)に対してゼロ以外の値に設定されたカーネル重みの割合を定義します。値は 0 から 1 の間である必要があります。`connection_density`を1に設定すると、カーネルの重みは0に設定されず、レイヤーは標準のフィードフォワードレイヤーとして機能します。`connection_density`を0に設定すると、すべてのカーネルの重みが0になり、モデルが学習できないため、設定しないでください。
    
*   `split_entities_by_comma`: このパラメータは、コンマで区切られた隣接するエンティティを 1 として扱うか、分割するかを定義します。たとえば、"apple, banana" などのタイプ`成分`を持つエンティティは、"apple" と "banana" に分割できます。"Schönhauser Allee 175, 10119 Berlin" のようなタイプ `アドレス`を持つエンティティは、1 つとして扱う必要があります。
    
    グローバルに`True`/`False`のいずれかにすることができます。
    
    ```yaml-rasa
    policies:
      - name: TEDPolicy
        split_entities_by_comma: True
    ```
    
    または、エンティティタイプごとに設定します。
    
    ```yaml-rasa
    policies:
      - name: TEDPolicy
        split_entities_by_comma:
          address: False
          ingredients: True
    ```
    
*   `constrain_similarities`: このパラメータを `True` に設定すると、すべての類似性項にシグモイド クロス エントロピー損失が適用されます。これは、入力ラベルと負のラベルの類似性をより小さな値に保つのに役立ちます。これは、モデルを実際のテストセットに一般化するのに役立つはずです。
    
*   `model_confidence`: このパラメーターを使用すると、ユーザーは推論中に信頼度を計算する方法を構成できます。現在、サポートされている値は 1 つだけです。
    
    *   `softmax`: 信頼度は `[0, 1]` の範囲です (古い動作と現在のデフォルト)。計算された類似性は、`softmax`活性化関数で正規化されます。
*   `use_gpu`: このパラメーターは、GPU (利用可能な場合) をトレーニングに使用するかどうかを定義します。デフォルトでは、GPU が利用可能な場合 (つまり、`use_gpu` が `True`) の場合、`TEDPolicy` は GPU でトレーニングされます。`TEDPolicy` がトレーニングに CPU のみを使用するようにするには、`use_gpu` を `False` に設定します。
    

上記の構成パラメーターは、モデルをデータに適合させるために構成する必要があるパラメーターです。ただし、適応できる追加のパラメーターが存在します。

```
+---------------------------------------+------------------------+--------------------------------------------------------------+
| Parameter                             | Default Value          | Description                                                  |
+=======================================+========================+==============================================================+
| hidden_layers_sizes                   | text: []               | Hidden layer sizes for layers before the embedding layers    |
|                                       | action_text: []        | for user messages and bot messages in previous actions       |
|                                       | label_action_text: []  | and labels. The number of hidden layers is                   |
|                                       |                        | equal to the length of the corresponding list.               |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| dense_dimension                       | text: 128              | Dense dimension for sparse features to use after they are    |
|                                       | action_text: 128       | converted into dense features.                               |
|                                       | label_action_text: 128 |                                                              |
|                                       | intent: 20             |                                                              |
|                                       | action_name: 20        |                                                              |
|                                       | label_action_name: 20  |                                                              |
|                                       | entities: 20           |                                                              |
|                                       | slots: 20              |                                                              |
|                                       | active_loop: 20        |                                                              |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| concat_dimension                      | text: 128              | Common dimension to which sequence and sentence features of  |
|                                       | action_text: 128       | different dimensions get converted before concatenation.     |
|                                       | label_action_text: 128 |                                                              |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| encoding_dimension                    | 50                     | Dimension size of embedding vectors                          |
|                                       |                        | before the dialogue transformer encoder.                     |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| transformer_size                      | text: 128              | Number of units in user text sequence transformer encoder.   |
|                                       | action_text: 128       | Number of units in bot text sequence transformer encoder.    |
|                                       | label_action_text: 128 | Number of units in bot text sequence transformer encoder.    |
|                                       | dialogue: 128          | Number of units in dialogue transformer encoder.             |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| number_of_transformer_layers          | text: 1                | Number of layers in user text sequence transformer encoder.  |
|                                       | action_text: 1         | Number of layers in bot text sequence transformer encoder.   |
|                                       | label_action_text: 1   | Number of layers in bot text sequence transformer encoder.   |
|                                       | dialogue: 1            | Number of layers in dialogue transformer encoder.            |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| number_of_attention_heads             | 4                      | Number of self-attention heads in transformers.              |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| unidirectional_encoder                | True                   | Use a unidirectional or bidirectional encoder                |
|                                       |                        | for `text`, `action_text`, and `label_action_text`.          |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| use_key_relative_attention            | False                  | If 'True' use key relative embeddings in attention.          |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| use_value_relative_attention          | False                  | If 'True' use value relative embeddings in attention.        |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| max_relative_position                 | None                   | Maximum position for relative embeddings.                    |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| batch_size                            | [64, 256]              | Initial and final value for batch sizes.                     |
|                                       |                        | Batch size will be linearly increased for each epoch.        |
|                                       |                        | If constant `batch_size` is required, pass an int, e.g. `8`. |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| batch_strategy                        | "balanced"             | Strategy used when creating batches.                         |
|                                       |                        | Can be either 'sequence' or 'balanced'.                      |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| epochs                                | 1                      | Number of epochs to train.                                   |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| random_seed                           | None                   | Set random seed to any 'int' to get reproducible results.    |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| learning_rate                         | 0.001                  | Initial learning rate for the optimizer.                     |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| embedding_dimension                   | 20                     | Dimension size of dialogue & system action embedding vectors.|
+---------------------------------------+------------------------+--------------------------------------------------------------+
| number_of_negative_examples           | 20                     | The number of incorrect labels. The algorithm will minimize  |
|                                       |                        | their similarity to the user input during training.          |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| similarity_type                       | "auto"                 | Type of similarity measure to use, either 'auto' or 'cosine' |
|                                       |                        | or 'inner'.                                                  |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| loss_type                             | "cross_entropy"        | The type of the loss function, either 'cross_entropy'        |
|                                       |                        | or 'margin'.                                                 |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| ranking_length                        | 0                      | Number of top actions to include in prediction. Confidences  |
|                                       |                        | of all other actions will be set to 0. Set to 0 to let the   |
|                                       |                        | prediction include confidences for all actions.              |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| renormalize_confidences               | False                  | Normalize the top predictions. Applicable only with loss     |
|                                       |                        | type 'cross_entropy' and 'softmax' confidences.              |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| maximum_positive_similarity           | 0.8                    | Indicates how similar the algorithm should try to make       |
|                                       |                        | embedding vectors for correct labels.                        |
|                                       |                        | Should be 0.0 < ... < 1.0 for 'cosine' similarity type.      |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| maximum_negative_similarity           | -0.2                   | Maximum negative similarity for incorrect labels.            |
|                                       |                        | Should be -1.0 < ... < 1.0 for 'cosine' similarity type.     |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| use_maximum_negative_similarity       | True                   | If 'True' the algorithm only minimizes maximum similarity    |
|                                       |                        | over incorrect intent labels, used only if 'loss_type' is    |
|                                       |                        | set to 'margin'.                                             |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| scale_loss                            | True                   | Scale loss inverse proportionally to confidence of correct   |
|                                       |                        | prediction.                                                  |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| regularization_constant               | 0.001                  | The scale of regularization.                                 |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| negative_margin_scale                 | 0.8                    | The scale of how important it is to minimize the maximum     |
|                                       |                        | similarity between embeddings of different labels.           |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| drop_rate_dialogue                    | 0.1                    | Dropout rate for embedding layers of dialogue features.      |
|                                       |                        | Value should be between 0 and 1.                             |
|                                       |                        | The higher the value the higher the regularization effect.   |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| drop_rate_label                       | 0.0                    | Dropout rate for embedding layers of label features.         |
|                                       |                        | Value should be between 0 and 1.                             |
|                                       |                        | The higher the value the higher the regularization effect.   |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| drop_rate_attention                   | 0.0                    | Dropout rate for attention. Value should be between 0 and 1. |
|                                       |                        | The higher the value the higher the regularization effect.   |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| connection_density                    | 0.2                    | Connection density of the weights in dense layers.           |
|                                       |                        | Value should be between 0 and 1.                             |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| use_sparse_input_dropout              | True                   | If 'True' apply dropout to sparse input tensors.             |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| use_dense_input_dropout               | True                   | If 'True' apply dropout to sparse features after they are    |
|                                       |                        | converted into dense features.                               |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| evaluate_every_number_of_epochs       | 20                     | How often to calculate validation accuracy.                  |
|                                       |                        | Set to '-1' to evaluate just once at the end of training.    |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| evaluate_on_number_of_examples        | 0                      | How many examples to use for hold out validation set.        |
|                                       |                        | Large values may hurt performance, e.g. model accuracy.      |
|                                       |                        | Keep at 0 if your data set contains a lot of unique examples |
|                                       |                        | of dialogue turns.                                           |
|                                       |                        | Set to 0 for no validation.                                  |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| tensorboard_log_directory             | None                   | If you want to use tensorboard to visualize training         |
|                                       |                        | metrics, set this option to a valid output directory. You    |
|                                       |                        | can view the training metrics after training in tensorboard  |
|                                       |                        | via 'tensorboard --logdir <path-to-given-directory>'.        |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| tensorboard_log_level                 | "epoch"                | Define when training metrics for tensorboard should be       |
|                                       |                        | logged. Either after every epoch ('epoch') or for every      |
|                                       |                        | training step ('batch').                                     |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| checkpoint_model                      | False                  | Save the best performing model during training. Models are   |
|                                       |                        | stored to the location specified by `--out`. Only the one    |
|                                       |                        | best model will be saved.                                    |
|                                       |                        | Requires `evaluate_on_number_of_examples > 0` and            |
|                                       |                        | `evaluate_every_number_of_epochs > 0`                        |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| e2e_confidence_threshold              | 0.5                    | The threshold that ensures that end-to-end is picked only if |
|                                       |                        | the policy is confident enough.                              |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| featurizers                           | []                     | List of featurizer names (alias names). Only features        |
|                                       |                        | coming from the listed names are used. If list is empty      |
|                                       |                        | all available features are used.                             |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| entity_recognition                    | True                   | If 'True' entity recognition is trained and entities are     |
|                                       |                        | extracted.                                                   |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| constrain_similarities                | False                  | If `True`, applies sigmoid on all similarity terms and adds  |
|                                       |                        | it to the loss function to ensure that similarity values are |
|                                       |                        | approximately bounded.                                       |
|                                       |                        | Used only when `loss_type=cross_entropy`.                    |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| model_confidence                      | "softmax"              | Affects how model's confidence for each action               |
|                                       |                        | is computed. Currently, only one value is supported:         |
|                                       |                        | 1. `softmax` - Similarities between input and action         |
|                                       |                        | embeddings are post-processed with a softmax function,       |
|                                       |                        | as a result of which confidence for all labels sum up to 1.  |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| BILOU_flag                            | True                   | If 'True', additional BILOU tags are added to entity labels. |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| split_entities_by_comma               | True                   | Splits a list of extracted entities by comma to treat each   |
|                                       |                        | one of them as a single entity. Can either be `True`/`False` |
|                                       |                        | globally, or set per entity type, such as:                   |
|                                       |                        | ```                                                          |
|                                       |                        | - name: TEDPolicy                                            |
|                                       |                        |   split_entities_by_comma:                                   |
|                                       |                        |     address: True                                            |
|                                       |                        | ```                                                          |
+---------------------------------------+------------------------+--------------------------------------------------------------+
```

> [!note] 
> パラメータ `maximum_negative_similarity` は、元の宇宙アルゴリズム `maximum_negative_similarity = maximum_positive_similarity` を模倣するために負の値に設定され、 `use_maximum_negative_similarity = False` です。[宇宙の論文](https://arxiv.org/abs/1709.03856)を見る 詳しくは。

> [!note]
>上記の設定パラメータに加えて、`TEDPolicy` 予測のパフォーマンスとトレーニング時間は、`rasa train` の `--augmentation` 引数の影響を受けます 命令。詳細については、[[./policies.md#データ拡張|データ拡張]]。

### UnexpecTED インテント ポリシー

> [!note] 2.8 の新機能
> この機能は実験的です。コミュニティからフィードバックを得るために実験的な機能を導入していますので、ぜひ試してみてください。ただし、この機能は将来変更または削除される可能性があります。フィードバック(肯定的または否定的)がある場合は、[Rasaフォーラム](https://forum.rasa.com)で共有してください。

`UnexpecTEDIntentPolicy` は、会話を確認するのに役立ち、ボットが思いがけないユーザーのターンに反応できるようにします。これは補助ポリシーであり、トリガーできるアクションは特別な[[./default-actions.md#action_unlikely_intent|`action_unlikely_intent`]]アクションのみであるため、少なくとも 1 つの他のポリシーと組み合わせてのみ使用する必要があります。

`UnexpecTEDIntentPolicy` は、[[./policies.md#TEDポリシー|`TEDポリシー`]]。 違いはタスク レベルにあります。次にトリガーされる最適なアクションを学習する代わりに、 `UnexpecTEDIntentPolicy` は、トレーニング ストーリーから会話コンテキストが与えられた場合、ユーザーが表現する可能性が最も高い一連の意図を学習します。NLU によって予測された意図が最も可能性の高い意図であるかどうかをチェックすることにより、推論時に学習した情報を使用します。NLU によって予測されたインテントが会話コンテキストを考慮して実際に発生する可能性が高い場合、`UnexpecTEDIntentPolicy` はアクションをトリガーしません。それ以外の場合は、信頼度 `1.00` の[`action_unlikely_intent`](./default-actions.md#action_unlikely_intent)がトリガーされます。

`UnexpecTEDIntentPolicy` は、`TEDPolicy` の補助として見なすべきです。それ以来、`TEDPolicy` は改善されることが期待されています アシスタントがトレーニングデータで処理することが期待される固有の会話パスをより適切にカバーすることで、 `UnexpecTEDIntentPolicy` は、過去の会話からこれらの一意の会話パスを表示するのに役立ちます。たとえば、トレーニングデータに次のストーリーがあったとします。

```yaml-rasa
stories:
- story: book_restaurant_table
  steps:
  - intent: request_restaurant
  - action: restaurant_form
  - active_loop: restaurant_form
  - action: restaurant_form
  - active_loop: null
  - slot_was_set:
    - requested_slot: null
```

しかし、実際の会話では、あなたが考慮していないフォーム内で感嘆詞に遭遇する可能性があります。

```yaml-rasa
stories:
- story: actual_conversation
  steps:
  - user: |
        I'm looking for a restaurant.
    intent: request_restaurant
  - action: restaurant_form
  - active_loop: restaurant_form
  - slot_was_set:
    - requested_slot: cuisine
  - user: |
        Does it matter? I want to be quick.
    intent: deny
```

`拒否`インテントがトリガーされるとすぐに、トレーニング ストーリーではこのケースを別の方法で扱う必要があるとは記載されていないため、フォームを処理するポリシーは`料理`スロットを埋めるよう要求し続けます。この時点で、ユーザーの`拒否`意図を処理する特別なストーリーが欠落している可能性があることを特定するために、 `UnexpecTEDIntentPolicy` は、インテント`を拒否した`直後に`action_unlikely_intent`アクションをトリガーできます。その後、この特定のケースを処理する新しいトレーニング・ストーリーを追加することで、アシスタントを改善できます。

誤った警告を減らすために、`UnexpecTEDIntentPolicy` には推論時に 2 つのメカニズムが導入されています。

1.  `UnexpecTEDIntentPolicy` の [[./policies.md#ポリシーの優先順位|ポリシーの優先順位]] は、意図的にすべてよりも低く保たれています [[./policies.md#ルールベースのポリシー|ルールベースのポリシー]] `TEDPolicy` または `UnexpecTEDIntentPolicy` を使用します。
    
2.  `UnexpecTEDIntentPolicy` は、最後に予測されたインテントがどのトレーニング ストーリーにも存在しない場合、インテントがルールでのみ使用されている場合に発生する可能性がある`action_unlikely_intent`を予測しません。
    

#### `action_unlikely_intent`の予測

`UnexpecTEDIntentPolicy` は、ユーザーの発話の直後に呼び出され、`action_unlikely_intent`をトリガーするか棄権することができます (この場合、他のポリシーがアクションを予測します)。`action_unlikely_intent`トリガーする必要があるかどうかを判断するために、`UnexpecTEDIntentPolicy` は、現在のダイアログ コンテキストにおけるユーザーの意図のスコアを計算し、このスコアが特定のしきい値スコアを下回っているかどうかをチェックします。

このしきい値スコアは、多くの「ネガティブな例」に関する ML モデルの出力を収集することによって計算されます。これらの否定的な例は、対話コンテキストとユーザーの意図が*正しくない*組み合わせです。`UnexpecTEDIntentPolicy` は、ランダムなストーリー部分を選択し、この時点では発生しないランダムなインテントとペアにすることで、トレーニングデータからこれらの否定的な例を生成します。たとえば、トレーニング ストーリーが 1 つだけあるとします。

```rasa-yaml
version: 2.0
stories:
- story: happy path 1
  steps:
  - intent: greet
  - action: utter_greet
  - intent: mood_great
  - action: utter_goodbye
```

そして意図`が肯定`すると、有効な否定的な例は次のようになります。

```rasa-yaml
version: 2.0
stories:
- story: negative example with affirm unexpected
  steps:
  - intent: greet
  - action: utter_greet
  - intent: affirm
```

ここでは、`肯定`意図は、すべてのトレーニング ストーリーのこの特定の会話コンテキストで発生するわけではないため、予期しません。意図ごとに、`UnexpecTEDIntentPolicy` はこれらの否定的な例を使用して、モデルが予測するスコアの範囲を把握します。しきい値スコアは、負の例の一定の割合の予測スコアがしきい値スコアよりも高くなるように、このスコアの範囲から選択されます`action_unlikely_intent` はトリガーされません。この負の例の割合は、`許容値`パラメーターによって制御できます。`許容範囲`が高いほど、`UnexpecTEDIntentPolicy` が`action_unlikely_intent`アクションをトリガーする前に、意図のスコアが低くなる必要があります (意図の可能性が低いほど)。

**構成：**

`config.yml` ファイルを使用して、構成パラメーターを `UnexpecTEDIntentPolicy` に渡すことができます。モデルのパフォーマンスを微調整する場合は、まず次のパラメーターを変更します。

*   `epochs`: このパラメータは、アルゴリズムがトレーニングデータを表示する回数を設定します (デフォルト: `1`)。1 `エポック`は、すべてのトレーニング例の 1 つのフォワードパスと 1 つのバックワードパスに相当します。モデルが適切に学習するには、より多くのエポックが必要な場合があります。エポックが増してもパフォーマンスに影響を与えない場合があります。エポック数が少ないほど、モデルのトレーニングが速くなります。構成は次のようになります。
    
    ```yaml-rasa
    policies:
    - name: UnexpecTEDIntentPolicy
      epochs: 200
    ```
    
*   `max_history`: このパラメータは、モデルが推論を行う前に確認する対話履歴の量を制御します。このポリシーのデフォルト`max_history`は `None` で、セッション (再)開始以降の完全な対話履歴が考慮されることを意味します。モデルが特定の数の前のダイアログ ターンのみを表示するように制限する場合は、`max_history`を有限値に設定できます。モデルが正しい予測を作成するのに十分な前の対話ターンを持つように、`慎重に選択max_history`必要があることに注意してください。データセットによっては、`max_history`の値が高いほど、`action_unlikely_intent`の予測頻度が高くなります より多くの対話コンテキストが取られるにつれて、一意の可能な会話パスの数が増加するため 考慮に入れます。同様に、`max_history`の値を下げると、`action_unlikely_intent`がトリガーされる頻度が減る可能性がありますが、対応する会話パスが非常に一意であるため、予期しないものであることを示す強力な指標にもなります。`UnexpecTEDIntentPolicy` の`max_history`を `TEDPolicy` のと等しく設定することをお勧めします。構成は次のようになります。
    
    ```yaml-rasa
    policies:
    - name: UnexpecTEDIntentPolicy
      max_history: 8
    ```
    
*   `ignore_intents_list`: このパラメータを使用すると、インテントのサブセットの`action_unlikely_intent`を予測しないように `UnexpecTEDIntentPolicy` を構成できます。これは、生成された誤った警告が多すぎるインテントの特定のリストに遭遇した場合に行うことをお勧めします。
    
*   `tolerance`: `tolerance` パラメータは、`0.0` から `1.0` (両端を含む) の範囲の数値です。推論時に [[./policies.md#`action_unlikely_intent`の予測|`prediction of action_unlikely_intent`]] 中に使用されるしきい値スコアを調整するのに役立ちます。
    
    ここで、`0.0` は、トレーニング中に遭遇した否定的な例の `0%` がしきい値スコアよりも低いスコアで予測されるようにしきい値スコアが調整されることを意味します。したがって、すべての否定的な例からの会話のコンテキストは、`action_unlikely_intent`アクションをトリガーします。
    
    許容範囲`が 0.1` の場合、トレーニング中に遭遇した否定的な例の 10% がしきい値スコアよりも低いスコアで予測されるようにしきい値スコアが調整されることを意味します。
    
    許容範囲`が 1.0` の場合、しきい値スコアが非常に低いため、`UnexpecTEDIntentPolicy` はトレーニング中に発生した否定的な例に対して `action_unlikely_intent` をトリガーしないことを意味します。
    
*   `use_gpu`: このパラメーターは、GPU (利用可能な場合) をトレーニングに使用するかどうかを定義します。デフォルトでは、GPU が使用可能な場合 (つまり、`use_gpu` が `True`) の場合、`UnexpecTEDIntentPolicy` は GPU でトレーニングされます。`UnexpecTEDIntentPolicy` がトレーニングに CPU のみを使用するようにするには、`use_gpu` を `False` に設定します。
    

上記の構成パラメーターは、ユースケースとトレーニングデータに応じて微調整してみるべきものです。ただし、適応できる追加のパラメーターが存在します。

```
+---------------------------------------+------------------------+--------------------------------------------------------------+
| Parameter                             | Default Value          | Description                                                  |
+=======================================+========================+==============================================================+
| hidden_layers_sizes                   | text: []               | Hidden layer sizes for layers before the embedding layers    |
|                                       |                        | for user messages and bot messages in previous actions       |
|                                       |                        | and labels. The number of hidden layers is                   |
|                                       |                        | equal to the length of the corresponding list.               |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| dense_dimension                       | text: 128              | Dense dimension for sparse features to use after they are    |
|                                       | intent: 20             | converted into dense features.                               |
|                                       | action_name: 20        |                                                              |
|                                       | label_intent: 20       |                                                              |
|                                       | entities: 20           |                                                              |
|                                       | slots: 20              |                                                              |
|                                       | active_loop: 20        |                                                              |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| concat_dimension                      | text: 128              | Common dimension to which sequence and sentence features of  |
|                                       |                        | different dimensions get converted before concatenation.     |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| encoding_dimension                    | 50                     | Dimension size of embedding vectors                          |
|                                       |                        | before the dialogue transformer encoder.                     |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| transformer_size                      | text: 128              | Number of units in user text sequence transformer encoder.   |
|                                       | dialogue: 128          | Number of units in dialogue transformer encoder.             |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| number_of_transformer_layers          | text: 1                | Number of layers in user text sequence transformer encoder.  |
|                                       | dialogue: 1            | Number of layers in dialogue transformer encoder.            |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| number_of_attention_heads             | 4                      | Number of self-attention heads in transformers.              |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| unidirectional_encoder                | True                   | Use a unidirectional or bidirectional encoder                |
|                                       |                        | for `text`, `action_text`, and `label_action_text`.          |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| use_key_relative_attention            | False                  | If 'True' use key relative embeddings in attention.          |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| use_value_relative_attention          | False                  | If 'True' use value relative embeddings in attention.        |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| max_relative_position                 | None                   | Maximum position for relative embeddings.                    |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| batch_size                            | [64, 256]              | Initial and final value for batch sizes.                     |
|                                       |                        | Batch size will be linearly increased for each epoch.        |
|                                       |                        | If constant `batch_size` is required, pass an int, e.g. `8`. |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| batch_strategy                        | "balanced"             | Strategy used when creating batches.                         |
|                                       |                        | Can be either 'sequence' or 'balanced'.                      |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| epochs                                | 1                      | Number of epochs to train.                                   |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| random_seed                           | None                   | Set random seed to any 'int' to get reproducible results.    |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| learning_rate                         | 0.001                  | Initial learning rate for the optimizer.                     |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| embedding_dimension                   | 20                     | Dimension size of dialogue & system action embedding vectors.|
+---------------------------------------+------------------------+--------------------------------------------------------------+
| number_of_negative_examples           | 20                     | The number of incorrect labels. The algorithm will minimize  |
|                                       |                        | their similarity to the user input during training.          |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| ranking_length                        | 10                     | Number of top actions to normalize scores for. Applicable    |
|                                       |                        | only with loss type 'cross_entropy' and 'softmax'            |
|                                       |                        | confidences. Set to 0 to disable normalization.              |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| scale_loss                            | True                   | Scale loss inverse proportionally to confidence of correct   |
|                                       |                        | prediction.                                                  |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| regularization_constant               | 0.001                  | The scale of regularization.                                 |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| drop_rate_dialogue                    | 0.1                    | Dropout rate for embedding layers of dialogue features.      |
|                                       |                        | Value should be between 0 and 1.                             |
|                                       |                        | The higher the value the higher the regularization effect.   |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| drop_rate_label                       | 0.0                    | Dropout rate for embedding layers of label features.         |
|                                       |                        | Value should be between 0 and 1.                             |
|                                       |                        | The higher the value the higher the regularization effect.   |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| drop_rate_attention                   | 0.0                    | Dropout rate for attention. Value should be between 0 and 1. |
|                                       |                        | The higher the value the higher the regularization effect.   |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| use_sparse_input_dropout              | True                   | If 'True' apply dropout to sparse input tensors.             |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| use_dense_input_dropout               | True                   | If 'True' apply dropout to sparse features after they are    |
|                                       |                        | converted into dense features.                               |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| evaluate_every_number_of_epochs       | 20                     | How often to calculate validation accuracy.                  |
|                                       |                        | Set to '-1' to evaluate just once at the end of training.    |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| evaluate_on_number_of_examples        | 0                      | How many examples to use for hold out validation set.        |
|                                       |                        | Large values may hurt performance, e.g. model accuracy.      |
|                                       |                        | Keep at 0 if your data set contains a lot of unique examples |
|                                       |                        | of dialogue turns.                                           |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| tensorboard_log_directory             | None                   | If you want to use tensorboard to visualize training         |
|                                       |                        | metrics, set this option to a valid output directory. You    |
|                                       |                        | can view the training metrics after training in tensorboard  |
|                                       |                        | via 'tensorboard --logdir <path-to-given-directory>'.        |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| tensorboard_log_level                 | "epoch"                | Define when training metrics for tensorboard should be       |
|                                       |                        | logged. Either after every epoch ('epoch') or for every      |
|                                       |                        | training step ('batch').                                     |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| checkpoint_model                      | False                  | Save the best performing model during training. Models are   |
|                                       |                        | stored to the location specified by `--out`. Only the one    |
|                                       |                        | best model will be saved.                                    |
|                                       |                        | Requires `evaluate_on_number_of_examples > 0` and            |
|                                       |                        | `evaluate_every_number_of_epochs > 0`                        |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| featurizers                           | []                     | List of featurizer names (alias names). Only features        |
|                                       |                        | coming from the listed names are used. If list is empty      |
|                                       |                        | all available features are used.                             |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| ignore_intents_list                   | []                     | This parameter lets you configure `UnexpecTEDIntentPolicy` to ignore|
|                                       |                        | the prediction of `action_unlikely_intent` for a subset of   |
|                                       |                        | intents. You might want to do this if you come across a      |
|                                       |                        | certain list of intents for which there are too many false   |
|                                       |                        | warnings generated.                                          |
+---------------------------------------+------------------------+--------------------------------------------------------------+
| tolerance                             | 0.0                    | The `tolerance` parameter is a number that ranges from `0.0` |
|                                       |                        | to `1.0` (inclusive). It helps to adjust the threshold score |
|                                       |                        | used during prediction of `action_unlikely_intent` at        |
|                                       |                        | inference time. Here, `0.0` means that the score threshold   |
|                                       |                        | is the one that `UnexpecTEDIntentPolicy` had determined at training |
|                                       |                        | time. A tolerance of `1.0` means that the threshold score    |
|                                       |                        | is so low that `IntentTED` would not trigger                 |
|                                       |                        | `action_unlikely_intent` for any of the "negative examples"  |
|                                       |                        | that it has encountered during training. These negative      |
|                                       |                        | examples are combinations of dialogue contexts and user      |
|                                       |                        | intents that are _incorrect_. `UnexpecTEDIntentPolicy` generates    |
|                                       |                        | these negative examples from your training data by picking a |
|                                       |                        | random story part and pairing it with a random intent that   |
|                                       |                        | doesn't occur at this point.                                 |
+---------------------------------------+------------------------+--------------------------------------------------------------+
```

#### 許容値パラメータの調整

[実際の会話を確認する](./conversation-driven-development.md#復習)場合は、`UnexpecTEDIntentPolicy` の構成で `tolerance` パラメーターを調整して、誤った警告 (実際に会話コンテキストが与えられている可能性が高い意図) の数を減らすことをお勧めします。`許容値`の値を `0.05` 単位で `0` から `1` に増やすと、誤警告の数は減少します。ただし、`許容範囲`を増やすと、`action_unlikely_intent`のトリガーも少なくなるため、トレーニング ストーリーに存在しない会話パスがフラグ付き会話のセットに欠落します。`max_history`値を変更してモデルを再トレーニングする場合は、`許容値`も再調整する必要がある場合があります。

> [!note] 
> `UnexpecTEDIntentPolicy` は、[ストーリー](./stories.md)に対してのみトレーニングされ、トレーニング データの[ルール](./rules.md)ではトレーニングされません。

### メモ化ポリシー

`MemoizationPolicy` は、 トレーニングデータ。現在の会話が `stories.yml`ファイル。その場合、トレーニングデータの一致するストーリーから次のアクションを `1.0` の信頼度で予測します。一致する会話が見つからない場合、ポリシーは信頼度 `0.0` で `None` を予測します。

トレーニング データで一致するものを探す場合、ポリシーは最後のものを取ります 会話のターン数`max_history`考慮に入れます。1 つの「ターン」には、ユーザーが送信したメッセージと、次のメッセージを待つ前にアシスタントが実行したアクションが含まれます。

`MemoizationPolicy`が設定で使用するターン数を設定できます。

```yaml
policies:
  - name: "MemoizationPolicy"
    max_history: 3
```

### 拡張メモ化ポリシー

`AugmentedMemoizationPolicy` は、`MemoizationPolicy` と同様に、トレーニング ストーリーの例を最大 `max_history` ターンまで記憶します。さらに、会話履歴の一定量のステップを忘れ、減少した履歴とストーリーの一致を見つけようとする忘却メカニズムがあります。信頼度`1.0`で次のアクションを予測します 一致が見つかった場合は、信頼度 `0.0` で `None` を予測します。

> [![注] スロットと予測
> 予測時間に設定された一部のスロットがトレーニングストーリーで設定されない可能性があるダイアログがある場合(たとえば、[リマインダー](./reaching-out-to-user.md#アラーム)で始まるトレーニングストーリーでは、以前のすべてのスロットが設定されているわけではありません)、スロットのない関連するストーリーもトレーニングデータに追加してください。

## ルールベースのポリシー

### ルールポリシー

`RulePolicy` は、固定された動作 (ビジネス ロジックなど) に従う会話部分を処理するポリシーです。トレーニングデータに含まれる`ルール`に基づいて予測を行います。ルールの定義方法の詳細については、[ルールのドキュメント](./rules.md)を参照してください。

`RulePolicy` には、次の構成オプションがあります。

```yaml
policies:
  - name: "RulePolicy"
    core_fallback_threshold: 0.3
    core_fallback_action_name: action_default_fallback
    enable_fallback_prediction: true
    restrict_rules: true
    check_for_contradictions: true
```

*   `core_fallback_threshold` (デフォルト: `0.3`): 詳細については、[[fallback-handoff.md#低いアクションの信頼度への対応|fallback documentation]] を参照してください。
    
*   `core_fallback_action_name` (デフォルト: `action_default_fallback`): 詳細については、[[fallback-handoff.md#低いアクションの信頼度への対応|fallback documentation]] を参照してください。
    
*   `enable_fallback_prediction` (デフォルト: `true`): 詳細については、[[fallback-handoff.md#低いアクションの信頼度への対応|fallback documentation]] を参照してください。
    
*   `check_for_contradictions` (デフォルト: `true`): トレーニングの前に、RulePolicy はチェックを実行して、アクションによって設定されたスロットとアクティブなループがすべてのルールに対して一観して定義されていることを確認します。次のスニペットには、不完全なルールの例が含まれています。
    
    ```yaml-rasa
    rules:
    - rule: complete rule
      steps:
      - intent: search_venues
      - action: action_search_venues
      - slot_was_set:
        - venues: [{"name": "Big Arena", "reviews": 4.5}]
    
    - rule: incomplete rule
      steps:
      - intent: search_venues
      - action: action_search_venues
    ```
    
    2 番目の`不完全なルール`では、`完全なルール`で設定されているため`action_search_venues`、`会場`スロットを設定する必要がありますが、このイベントが欠落しています。このルールを修正するには、いくつかの方法が考えられます。
    
    `action_search_venues`会場が見つからず、`会場`スロットを設定しない場合は、スロットの値を`明示的にnull`に設定する必要があります。次のストーリーでは、`RulePolicy` が`utter_venues_not_found`を予測します スロット`会場`が設定されていない場合のみ:
    
    ```yaml-rasa
    rules:
    - rule: fixes incomplete rule
      steps:
      - intent: search_venues
      - action: action_search_venues
      - slot_was_set:
        - venues: null
      - action: utter_venues_not_found
    ```
    
    スロット設定を別のルールまたはストーリーで処理する場合は、ルール スニペットの末尾に `wait_for_user_input: false` を追加する必要があります。
    
    ```yaml-rasa
    rules:
    - rule: incomplete rule
      steps:
      - intent: search_venues
      - action: action_search_venues
      wait_for_user_input: false
    ```
    
    トレーニング後、RulePolicy は、ルールまたはストーリーが互いに矛盾していないことを確認します。次のスニペットは、2 つの矛盾するルールの例です。
    

```
rules:
- rule: Chitchat
  steps:
  - intent: chitchat
  - action: utter_chitchat

- rule: Greet instead of chitchat
  steps:
  - intent: chitchat
  - action: utter_greet  # `utter_greet` contradicts `utter_chitchat` from the rule above
```

*   `restrict_rules` (デフォルト: `true`): ルールは 1 つのユーザーターンに制限されますが、フォームの入力とその後の送信など、複数のボットイベントが存在する可能性があります。このパラメーターを `false` に変更すると、予期しない動作が発生する可能性があります。

> [!caution] 
> ルールの使いすぎ[推奨されるユースケース](rules.md)以外の目的でのルールの使いすぎ 複雑さが増すにつれて、アシスタントを維持することが非常に困難になります。

## ポリシーの設定

### マックス履歴

Rasa ポリシーの重要なハイパーパラメータの 1 つは`max_history`です。これは、モデルが次に実行するアクションを決定するために参照する対話履歴の量を制御します。

`max_history`を設定するには、`config.yml`のポリシー設定でポリシーに渡します。デフォルト値は `None` で、セッションの再起動以降の完全な対話履歴がアカウントに記録されることを意味します。

```yaml-rasa
policies:
  - name: TEDPolicy
    max_history: 5
    epochs: 200
    batch_size: 50
    max_training_samples: 300
```

> [!note] 
> `RulePolicy` には max history パラメーターがなく、常に提供されたルールの全長が考慮されます。詳細については、[ルールをご覧ください](./rules.md)。

たとえば、トピックから外れたユーザー メッセージを記述する`out_of_scope` インテントがあるとします。ボットがこの意図を連続して複数回表示する場合は、ユーザーに何を支援できるかを伝えることができます。したがって、あなたのストーリーは次のようになります。

```yaml-rasa
stories:
  - story: utter help after 2 fallbacks
    steps:
    - intent: out_of_scope
    - action: utter_default
    - intent: out_of_scope
    - action: utter_default
    - intent: out_of_scope
    - action: utter_help_message
```

モデルがこのパターンを学習するには、`max_history`が少なくとも 4 である必要があります。

`max_history`を増やすと、モデルが大きくなり、トレーニングに時間がかかります。はるか将来の対話に影響を与える情報がある場合は、それをスロットとして保存する必要があります。スロット情報は、すべてのフィーチャライザーで常に使用できます。

### データ拡張

モデルをトレーニングすると、Rasa はストーリー ファイル内のストーリーをランダムに組み合わせて、より長いストーリーを作成します。以下のストーリーを例に挙げてみましょう。

```yaml-rasa
stories:
  - story: thank
    steps:
    - intent: thankyou
    - action: utter_youarewelcome
  - story: say goodbye
    steps:
    - intent: goodbye
    - action: utter_goodbye
```

実際には、対話履歴が関連性のない場合は無視し、以前に何が起こったかに関係なく同じアクションで**対応するようにポリシー**を教えたいと考えています。これを実現するために、個々のストーリーは長いストーリーに連結されます。上記の例から、データ拡張は、`thank` と `say goodbye` を組み合わせて、次に `thank` again、次のようにストーリーを生成する可能性があります。

```yaml-rasa
stories:
  - story: thank -> say goodbye -> thank
    steps:
    - intent: thankyou
    - action: utter_youarewelcome
    - intent: goodbye
    - action: utter_goodbye
    - intent: thankyou
    - action: utter_youarewelcome
```

この動作は、`augmentation_factor`を設定できる `--augmentation` フラグを使用して変更できます。`augmentation_factor`は、トレーニング中にサブサンプリングされる拡張ストーリーの数を決定します。拡張されたストーリーは、その数がすぐに非常に大きくなる可能性があるため、トレーニング前にサブサンプリングされ、制限する必要があります。サンプリングされたストーリーの数は `augmentation_factor` x10 です。デフォルトでは、`augmentation_factor`は 50 に設定されており、最大 500 の拡張ストーリーが作成されます。

`--augmentation 0` は、すべての拡張動作を無効にします。`TEDPolicy` は、拡張の影響を受ける**唯一の**ポリシーです。`MemoizationPolicy` や `RulePolicy` などのその他のポリシー 拡張されたすべてのストーリーを自動的に無視します(`augmentation_factor`に関係なく)。

`--augmentation` は、`TEDPolicy` トレーニング時間を短縮しようとする際の重要なパラメーターです。`augmentation_factor`を減らすと、トレーニング データのサイズが短縮され、その後、ポリシーのトレーニングにかかる時間が短縮されます。ただし、データ拡張の量を減らすと、`TEDPolicy`のパフォーマンスが低下する可能性もあります。補うためにデータ拡張の量を減らす場合は、`TEDPolicy` とともにメモ化ベースのポリシーを使用することをお勧めします。

### フィーチャライザー

機械学習アルゴリズムを会話型 AI に適用するには、会話のベクトル表現を構築する必要があります。

各ストーリーは、各アクションが実行される直前の会話の状態で構成されるトラッカーに対応します。

#### 状態の特徴付け

トラッカー履歴のすべてのイベントは、新しい状態を作成します(例:ボットアクションの実行、ユーザーメッセージの受信、スロットの設定)。トラッカーの 1 つの状態の特徴付けには、次の 2 つの手順があります。

1.  Trackerは、**アクティブな機能のバッグを提供します**。
    
    *   インテントとエンティティを示す特徴量 (これが最初のものの場合) ターンで状態、たとえば、それは後に実行する最初のアクションです ユーザーのメッセージを解析します。(例: `[intent_restaurant_search, entity_cuisine]` )
        
    *   現在定義されているスロットを示す特徴量 (例: `slot_location`ユーザーが以前にレストランを検索している地域について言及したかどうか。
        
    *   スロットに保存されているAPI呼び出しの結果を示す機能(`例:slot_matches`
        
    *   最後のボットアクションまたはボットの発話が何であったかを示す機能 (例: `prev_action_listen`)
        
    *   ループがアクティブかどうか、およびどのループがアクティブであるかを示す機能
        
2.  **すべての特徴量を数値ベクトルに変換します。**
    
    `SingleStateFeaturizer` は、Rasa NLU パイプラインを使用して、インテントとボットのアクション名またはボットの発話を数値ベクトルに変換します。Rasa NLU パイプラインの設定方法の詳細については、[NLU モデル設定](./model-configuration.md)のドキュメントを参照してください。
    
    エンティティ、スロット、およびアクティブループは、その存在を示すためにワンホットエンコーディングとして特徴付けられます。
    

> [!note] 
> ドメインで可能な`アクション` `[ActionGreet, ActionGoodbye]` が定義されている場合、さらに 4 つのデフォルト アクションが追加されます `[ActionListen(), ActionRestart(), ActionDefaultFallback(), ActionDeactivateForm()]` 。したがって、ラベル `0` はデフォルトのアクション listen を示し、ラベル `1` はデフォルトの再起動を示し、ラベル `2` は挨拶を示し、`3` はさようならを示します。

#### トラッカー機能化

ポリシーは、次の 2 種類のラベルを学習するようにトレーニングできます。

1.  アシスタントによってトリガーされる次に適切なアクション。たとえば、[[#TEDポリシー]] はこれを行うようにトレーニングされています。
2.  ユーザーが表現できる次の最も可能性の高い意図。たとえば、[[#UnexpecTED インテント ポリシー]] はこれを学習するようにトレーニングされています。

したがって、トラッカーを特徴付けて、上記のラベルの 1 つを学習できます。ポリシーに応じて、ターゲットラベルは、可能なすべてのアクションのリストのインデックスとして表されるボットアクションまたはボットの発話、または可能なすべてのインテントのリストのインデックスとして表されるインテントのセットに対応します。

Tracker Featurizers には 3 つの異なるフレーバーがあります。

##### 1. 完全な対話

`FullDialogueTrackerFeaturizer` は、対話全体がネットワークに供給され、勾配がすべてのタイム ステップから逆伝播されるリカレント ニューラル ネットワークにフィードするストーリーの数値表現を作成します。ターゲット ラベルは、会話のコンテキストでトリガーされる最も適切なボット アクションまたはボット発話です。`TrackerFeaturizer` は、トラッカーの状態を反復処理し、状態ごとに `SingleStateFeaturizer` を呼び出して、ポリシーの数値入力機能を作成します。

##### 2. マックス履歴

`MaxHistoryTrackerFeaturizer` は、ボット アクションまたはボット発話ごとに以前のトラッカー状態の配列を作成するため、`FullDialogueTrackerFeaturizer` と非常によく似た動作をしますが、パラメーターは入力特徴の各行に入る状態の数を定義する`max_history`です。`max_history`が指定されていない場合、アルゴリズムは対話の全長を考慮に入れます。重複排除は、重複したターン (ボットのアクションまたはボットの発話) を以前の状態の観点から除外するために実行されます。

一部のアルゴリズムでは、フラットな特徴ベクトルが必要なため、入力特徴を `(num_unique_turns, max_history * num_input_features)` に再形成する必要があります。

##### 3. インテント最大履歴

`MaxHistoryTrackerFeaturizer` から `IntentMaxHistoryTrackerFeaturizer` 継承します。これは [[#UnexpecTED インテント ポリシー]]の場合、作成されるターゲットラベルは、会話トラッカーのコンテキストでユーザーが表現できるインテントです。他のトラッカー特徴付け器とは異なり、複数のターゲット ラベルを持つことができます。したがって、ターゲット ラベルのリストを右側に定数値 (`-1`) で埋め込み、入力会話トラッカーごとに同じサイズのターゲット ラベルのリストを返します。

`MaxHistoryTrackerFeaturizer` と同様に、重複排除も実行して重複したターンを除外します。ただし、対応するトラッカーの正しいインテントごとに 1 つの特徴付けされたトラッカーが生成されます。たとえば、入力会話トラッカーの正しいラベルに次のインデックス (`[0, 2, 4]` ) がある場合、フィーチャライザーはフィーチャライザーとターゲット ラベルの 3 組を生成します。特徴付けされたトラッカーは互いに同一になりますが、各ペアのターゲット ラベルは `[0, 2, 4]`、[`4, 0, 2]`、[`2, 4, 0]` になります。

## カスタムポリシー

> [!info] 3.0 の新機能
> Rasa 3.0 では、NLU コンポーネントとポリシーの実装が統合されました。これには、以前のバージョンの Rasa Open Source 用に記述されたカスタムポリシーを変更する必要があります。移行のステップバイステップガイドについては、[[migration-guide.md#カスタムポリシーとカスタムコンポーネント|移行ガイド]]を参照してください。

カスタムポリシーを記述し、設定で参照することもできます。次の例では、最後の 2 行は、カスタムポリシークラスを使用して引数を渡す方法を示しています。カスタムポリシーの完全なガイドについては、[カスタムグラフコンポーネントに関するガイド](custom-graph-components.md)を参照してください。

```yaml-rasa
policies:
  - name: "TEDPolicy"
    max_history: 5
    epochs: 200
  - name: "RulePolicy"
  - name: "path.to.your.policy.class"
    arg1: "..."
```