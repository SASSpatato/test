---
id: setting-up-ci-cd
sidebar_label: Setting up CI/CD
title: Setting up CI/CD
description: Set up a CI/CD pipeline to ensure that iterative improvements to your assistant are tested and deployed with minimum manual effort
abstract: Even though developing a contextual assistant is different from developing traditional
  software, you should still follow software development best practices.
  Setting up a Continuous Integration (CI) and Continuous Deployment (CD)
  pipeline ensures that incremental updates to your bot are improving it, not harming it.
---

## 概要

継続的インテグレーション (CI) は、コードの変更を頻繁にマージし、コミットされた変更を自動的にテストする手法です。継続的デプロイ (CD) とは、統合された変更をステージング環境または運用環境に自動的にデプロイすることを意味します。これらを組み合わせることで、アシスタントをより頻繁に改善し、それらの変更を効率的にテストしてデプロイできます。

このガイドでは、Rasa プロジェクトに固有の CI/CD パイプラインで何をすべきかについて説明します。そのパイプラインをどのように実装するかは、あなた次第です。[GitHub Actions](https://github.com/features/actions)など、多くのCI/CDツールがあります。 [GitLab CI/CD](https://docs.gitlab.com/ee/ci/)、[Jenkins](https://www.jenkins.io/doc/)、[CircleCI](https://circleci.com/docs/) などです。使用する Git リポジトリと統合できるツールを選択することをお勧めします。

## 継続的インテグレーション (CI)

アシスタントを改善する最善の方法は、[増分更新](https://rasa.com/docs/rasa-enterprise/user-guide/fix-problems)を頻繁に行うことです。どんなに小さな変更であっても、新しい問題が発生したり、アシスタントのパフォーマンスに悪影響を及ぼしたりしないようにする必要があります。

通常、マージ/プルリクエストまたはコミット時にCIチェックを実行するのが最善です。ほとんどのテストは、すべての変更に対して実行できるほど高速です。ただし、リソースを大量に消費するテストを実行するのは、特定のファイルが変更された場合、または他のインジケーターが存在する場合のみです。たとえば、コードが Github でホストされている場合、プル リクエストに特定のラベル (例: "NLU テストが必要" ) がある場合にのみテスト実行を行うことができます。

### CI パイプラインの概要

CI パイプラインには、デプロイ プロセスを合理化するための手順として、モデルのトレーニングとテストを含める必要があります。新しいトレーニング データを保存した後の最初のステップは、パイプラインを開始することです。これは、手動で開始することも、pull request を作成または更新するときに開始することもできます。

次に、さまざまなテスト セットを実行して、変更の影響を確認する必要があります。これには、データ検証、NLU クロス検証、ストーリーテストのテストの実行が含まれます。テストについて詳しくは、[アシスタントのテスト](./testing-your-assistant.md)を参照してください。

最後のステップは、テストの結果を確認し、テストが成功した場合に変更をプッシュすることです。新しいモデルがトレーニングおよびテストされたら、継続的デプロイ パイプラインを使用して自動的にデプロイできます。

### GitHub Actions CI パイプライン

CI パイプラインで [Rasa Train-Test Github アクション](https://github.com/RasaHQ/rasa-train-test-gha)を使用して、データの検証、トレーニング、およびテストを自動的に実行できます。

Github アクションを使用した CI パイプラインの例を以下に示します。

```yaml
jobs:
  training-testing:
    name: Training and Testing
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v1
      - name: Rasa Train and Test GitHub Action
        uses: RasaHQ/rasa-train-test-gha@main
        with:
          requirements_file: requirements.txt
          data_validate: true
          rasa_train: true
          cross_validation: true
          rasa_test: true
          test_type: all
          publish_summary: true
          github_token: ${{ secrets.GITHUB_TOKEN }}
      - name: Upload model
        if: github.ref == 'refs/heads/main'
        uses: actions/upload-artifact@master
        with:
          name: model
          path: models
```

このパイプラインでは、Rasa Train-Test Github Actionは、最初のステップでデータ検証、モデルトレーニング、およびストーリーテストを実行し、モデルファイルは2番目のステップでアーティファクトとしてアップロードされます。

Rasa Train-Test Githubアクションの設定可能なパラメータの完全なリストは、リポジトリの[README](https://github.com/RasaHQ/rasa-train-test-gha#input-arguments)で入手できます。

`publish_summary` が `true` に設定されている場合、このアクションは、モデルのテスト結果をコメントとして関連付けられた Pull Request に自動的に公開します。

![[静的/img/train-test-github-action.png]]

プルリクエストは、評価結果に基づいて承認または拒否することができ、多くの場合、すべてのCIチェックに合格した場合は、モデルのデプロイを自動化する必要があります。継続的デプロイの詳細については、次のセクションに進んでください。

## 継続的デプロイ (CD)

改善点をユーザーに頻繁に提供するには、デプロイ プロセスを可能な限り自動化する必要があります。

CD ステップは通常、CI チェックが成功すると、特定のブランチへのプッシュまたはマージ時に実行されます。

### Rasaモデルのデプロイ

CI パイプラインで[テスト ストーリー](./testing-your-assistant.md)を実行した場合は、トレーニング済みのモデルが既にあります。CI の結果が満足のいく場合は、トレーニング済みモデルを Rasa サーバーにアップロードするように CD パイプラインをセットアップできます。たとえば、モデルを Rasa X/Enterprise にアップロードするには、次のようにします。

```bash
curl -k -F "model=@models/my_model.tar.gz" "https://example.rasa.com/api/projects/default/models?api_token={your_api_token}"
```

Rasa X/Enterprise を使用している場合は、[アップロードされたモデルにタグを付け](https://rasa.com/docs/rasa-enterprise/pages/http-api/#tag/Models/paths/~1projects~1%7Bproject_id%7D~1models~1%7Bmodel%7D~1tags~1%7Btag%7D/put)ることもできます 本番環境として (または複数の[デプロイ環境](https://rasa.com/docs/rasa-enterprise/enterprise/deployment-environments/#)を使用している場合はタグ付けするデプロイメント):

```bash
curl -X PUT "https://example.rasa.com/api/projects/default/models/my_model/tags/production"
```

> [!caution] アクション コードの更新
> 更新にモデルとアクション コードの両方に対する変更が含まれており、これらの変更が何らかの形で相互に依存している場合は、 モデルに`生産として自動的に`タグ付けします。最初に、更新されたアクションサーバーを構築してデプロイして、新しいモデルが更新前のアクションサーバーに存在しないアクションを呼び出さないようにする必要があります。

### アクションサーバーのデプロイ

アクションコードの更新ごとに、[[./deploy/deploy-action-server.mdx#building an action server image|building and uploading a new image for your action server]]をイメージリポジトリに自動化できます。前述のように、アクションサーバーが現在の本番モデルと互換性がない場合は、新しいイメージタグを本番環境に自動的にデプロイすることに注意してください。

## CI/CD パイプラインの例

例として、[Sara](https://github.com/RasaHQ/rasa-demo/blob/main/.github/workflows/continuous_integration.yml) の CI/CD パイプライン、Rasa Docs で会話できる Rasa アシスタント、および [Carbon Bot](https://github.com/RasaHQ/carbon-bot/blob/master/.github/workflows/model_ci.yml) を参照してください。どちらも [Github Actions](https://github.com/features/actions) を CI/CD ツールとして使用します。

これらの例は、多くの可能性のうちの 2 つにすぎません。気に入ったCI/CDセットアップがある場合は、[フォーラム](https://forum.rasa.com)でRasaコミュニティと共有してください。