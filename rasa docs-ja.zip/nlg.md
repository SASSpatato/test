---
id: nlg
sidebar_label: NLG
title: NLG Servers
---

テキストコピーを変更するためだけにボットを再トレーニングすることは、一部のワークフローでは最適ではない可能性があります。そのため、Rasaでは応答生成をアウトソーシングし、対話学習から分離することもできます。

アシスタントは、過去の対話に基づいてアクションを予測し、ユーザー入力に反応することを学習しますが、ユーザーに送り返す応答は Rasa の外部で生成されます。

アシスタントは、ユーザーにメッセージを送信すると、定義した外部 HTTP サーバーを呼び出します。

## ご依頼への対応

### 要求形式

モデルがボットがユーザーに応答を送信する必要があると予測すると、サーバーに要求を送信し、応答を選択または生成するために必要な情報を提供します。

NLG エンドポイントに送信される `POST` 要求の本文は、次のように構成されます。

> [!info] 3.6 の新機能
> リクエスト本文に `id` フィールドを追加しました。このフィールドには、応答バリエーションの ID が含まれます。この情報を使用して、NLG サーバーで適切な応答バリエーションを作成/選択できます。

```json
{
  "response":"utter_what_can_do",
  "arguments":{
    
  },
  "id": "<response_variation_id>",
  "tracker":{
    "sender_id":"user_0",
    "slots":{
      
    },
    "latest_message":{
      "intent":{
        "id":3014457480322877053,
        "name":"greet",
        "confidence":0.9999994039535522
      },
      "entities":[
        
      ],
      "text":"Hello",
      "message_id":"94838d6f49ff4366b254b6f6d23a90cf",
      "metadata":{
        
      },
      "intent_ranking":[
        {
          "id":3014457480322877053,
          "name":"greet",
          "confidence":0.9999994039535522
        },
        {
          "id":8842445304628198686,
          "name":"ask_forget_reminders",
          "confidence":5.675940428773174e-07
        },
        {
          "id":-2566831912141022859,
          "name":"bye",
          "confidence":3.418941929567154e-08
        },
        {
          "id":8340513453672591403,
          "name":"ask_id",
          "confidence":2.5274500714544956e-08
        },
        {
          "id":5822154213939471096,
          "name":"ask_remind_call",
          "confidence":2.4177523982871207e-08
        }
      ]
    },
    "latest_event_time":1599476297.694504,
    "followup_action":null,
    "paused":false,
    "events":[
      {
        "event":"action",
        "timestamp":1599476297.68784,
        "name":"action_session_start",
        "policy":null,
        "confidence":null
      },
      {
        "event":"session_started",
        "timestamp":1599476297.6878452
      },
      {
        "event":"action",
        "timestamp":1599476297.6878562,
        "name":"action_listen",
        "policy":null,
        "confidence":null
      },
      {
        "event":"user",
        "timestamp":1599476297.694504,
        "text":"Hello",
        "parse_data":{
          "intent":{
            "id":3014457480322877053,
            "name":"greet",
            "confidence":0.9999994039535522
          },
          "entities":[
            
          ],
          "text":"Hello",
          "message_id":"94838d6f49ff4366b254b6f6d23a90cf",
          "metadata":{
            
          },
          "intent_ranking":[
            {
              "id":3014457480322877053,
              "name":"greet",
              "confidence":0.9999994039535522
            },
            {
              "id":8842445304628198686,
              "name":"ask_forget_reminders",
              "confidence":5.675940428773174e-07
            },
            {
              "id":-2566831912141022859,
              "name":"bye",
              "confidence":3.418941929567154e-08
            },
            {
              "id":8340513453672591403,
              "name":"ask_id",
              "confidence":2.5274500714544956e-08
            },
            {
              "id":5822154213939471096,
              "name":"ask_remind_call",
              "confidence":2.4177523982871207e-08
            }
          ]
        },
        "input_channel":"rest",
        "message_id":"94838d6f49ff4366b254b6f6d23a90cf",
        "metadata":{
          
        }
      }
    ],
    "latest_input_channel":"rest",
    "active_loop":{
      
    },
    "latest_action_name":"action_listen"
  },
  "channel":{
    "name":"collector"
  }
}
```

POST リクエストの高レベルキーの概要は次のとおりです。

| 鍵 | 形容 |
| --- | --- |
| response | Rasaが予測した応答の名前。 |
| id | 応答バリエーション ID を表すオプションの文字列は、null にすることができます。 |
| arguments | カスタムアクションで指定できるオプションのキーワード引数。 |
| tracker | 会話履歴全体を含む辞書。 |
| channel | このメッセージの送信先の出力チャネル。 |

この情報の一部またはすべてを使用して、応答の生成方法を決定できます。

### 応答形式

エンドポイントは、生成された応答で応答する必要があります。その後、Rasa はこの応答をユーザーに送り返します。

以下は、応答の可能なキーとその (空の) 型です。

```json
{
    "text": "Some text",
    "buttons": [],
    "image": null,  # string of image URL
    "elements": [],
    "attachments": [], 
    "custom": {}
}
```

テキストのみを提供するか、さまざまなタイプのリッチ レスポンスを組み合わせて提供するかを選択できます。[ドメインファイルで定義されている応答](./responses.md)と同様に、有効な応答であるためには、応答に少なくとも`テキスト`または`カスタム`が含まれている必要があります。

> [!caution] 
> ストーリーからの応答の呼び出し外部 NLG サービスを使用する場合は、ドメインの`応答`で応答を指定する必要はありません。ただし、ストーリーから直接応答名を呼び出す場合は、ドメインの`アクション`リストに応答名を追加する必要があります。

## サーバー URL の設定

NLG サーバーの場所を Rasa に指示するには、`endpoints.yml`に URL を追加します。

```yaml-rasa
nlg:
  url: http://localhost:5055/nlg
```

NLG サーバーが保護されており、Rasa がアクセスするために認証が必要な場合は、エンドポイントで認証を構成できます。

```yaml-rasa
nlg:
  url: http://localhost:5055/nlg
  # 
  # You can also specify additional parameters, if you need them:
  # headers:
  #   my-custom-header: value
  # token: "my_authentication_token"  # will be passed as a GET parameter
  # basic_auth:
  #   username: user
  #   password: pass
```