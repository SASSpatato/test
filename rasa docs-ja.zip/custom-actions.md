---
id: custom-actions
sidebar_label: Custom Actions
title: Custom Actions
abstract: A custom action can run any code you want, including API calls, database queries etc. They can turn on the lights, add an event to a calendar, check a user's bank balance, or anything else you can imagine.
---

カスタムアクションの実装方法の詳細については、[SDKのドキュメント](./action-server/running-action-server.md)を参照してください。ストーリーで使用するカスタム アクションは、[ドメイン](./domain.md)のアクション セクションに追加する必要があります。

ダイアログエンジンは、実行されるカスタムアクションを予測すると、次の情報を使用してアクションサーバーを呼び出します。

```json
{
  "next_action": "string",
  "sender_id": "string",
  "tracker": {
    "conversation_id": "default",
    "slots": {},
    "latest_message": {},
    "latest_event_time": 1537645578.314389,
    "followup_action": "string",
    "paused": false,
    "events": [],
    "latest_input_channel": "rest",
    "active_loop": {},
    "latest_action": {}
  },
  "domain": {
    "config": {},
    "session_config": {},
    "intents": [],
    "entities": [],
    "slots": {},
    "responses": {},
    "actions": [],
    "forms": {},
    "e2e_actions": []
  },
  "version": "version"
}
```

アクションサーバーは、イベントと応答のリストで応答する必要があります。

```json
{
  "events": [{}],
  "responses": [{}]
}
```