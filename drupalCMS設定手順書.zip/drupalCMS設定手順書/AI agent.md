## 1. 概要説明
DrupalのAIエージェント機能については、モジュール開発者が提供する検証動画によると（[https://www.youtube.com/watch?v=hptyElqmo6Q&t=255s]()）、OpenAIのChatGPTやAnthropicのClaudeなどの高性能大規模言語モデル(LLM)でのみ有効活用が可能です。検証結果としては以下が確認されています：

●Ollamaでデプロイしたローカルモデルではエージェント機能の実現が困難
●Azure AIサービスの場合は機能実現が可能

■前提: AI AssistentのAgent Actionを有効化する([[AI Assistant Configuration#2.1Agent Action]])
![[Pasted image 20250617110807.png]]



■補足: また、モジュール開発者によると、AIエージェント機能を本番環境で使用せず、ローカル開発環境に限定することが推奨されています


## 2. 基本設定説明

■例選択：AIエージェント設定に関する構成項目については、taxonomy_agent の設定を例に挙げて解説する

![[image18.png]]

---

![[image19.png]]

- **Metadata**: エージェントの基本仕様と能力境界を定義する

- **Usage instructions**: タスクの実行ロジックを定義する

- **Prompts configuration**:  タスクごとの具体的な動作ロジックを定義する


---

![[image20.png]]

![[image21.png]]

- **introduction**: AIが担うべき役割と実行タスクを明示的に定義する

- **is_triage**:
	- true: AIはユーザー入力に基づき、リクエストを以下に定義する可能アクション　カテゴリへ分類する必要があります。
	- false: 分類ステージをスキップし、入力を直接最終リクエストとして処理します

- **formats**: 出力形式を標準化する

- **one_shot_learning_examples**: タスクパターン理解のための入力-出力ペア事例を提供する

■補足:このYAML設定により、プロンプトエンジニアリング（Prompt Engineering）を介して直接AIの挙動を制御することが可能です。

## 3. 実際の試し

- 目標：AI Chat でタクソノミーを構築し、中身の設定もする。
- 実際操作：
	- Step1：作成が必要なvocabularyとそれに含まれるtermの設計を策定する
	  ![[Pasted image 20250617154154.png]]
	- Step2：Drupalのchatbotに指令を入力する
	  ![[Pasted image 20250617154214.png]]
	- Step3：結果の確認
	  ![[Pasted image 20250617154239.png]]