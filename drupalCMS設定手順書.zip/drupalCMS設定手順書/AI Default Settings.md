# 1.概要説明
これらは、外部モジュールが使用したり、その設定ページに表示したりできる、各操作タイプのデフォルト・プロバイダです。AIモジュールのホームページからプロバイダを選び、プロジェクトに追加し、まずインストールして設定します。「https://www.drupal.org/project/ai」でプロジェクトに追加するAIモデルを選択し、「/admin/config/ai/providers」で設定することができる。
# 2.設定手順
### 2.1 設定項目の説明
Image Classification とChat の設定を例に挙げて解説する。
##### 2.1.1 Image Classification
![[Pasted image 20250618094756.png]]
特定のタイプの操作を提供できるプロバイダーがない場合、対応するドロップダウンボックスは「デフォルトなし」にのみ設定できます。
##### 2.1.2 Chat
1. Default Providerを選択する
![[Pasted image 20250618094919.png]]システム上にサービスを提供するプロバイダーがある場合は、ドロップダウンボックスに表示されます。
2. Default Modelを選択する
![[Pasted image 20250618095209.png]]
特定のタイプの操作のためのプロバイダがある場合、デフォルトモデルチェックボックスが下に表示され、プロバイダ内部のモデルを選択して、この操作を実行するためのデフォルトモデルを設定することができます。

### 2.2 プロバイダーを追加する操作の例
Translate Text を例にして、デフォルトのプロバイダを追加して「DeepL」に設定します。
1. **テキストを翻訳（Translate  Text）のデフォルトプロバイダーにDeepLのオプションが含まれていないことを確認します。**
![[Pasted image 20250618111150.png]]
2. **「DeepL Provider」コンポーネントを検索し、インストールします。**[DeepL Provider | Drupal.org](https://www.drupal.org/project/ai_provider_deepl)
![[Pasted image 20250618111435.png]]
3. **「DeepL Provider」 コンポーネントが正常にインストールされていることを確認します。**
![[Pasted image 20250618130423.png]]
4. **「/admin/config/ai/providers」でAIプロバイダを設定する。AI プロバイダーの設定については、AI Provider Settingsを参照してください。**
![[Pasted image 20250618130459.png]]
5. **初めてセットアップするときは、まずキーを作成する必要があります。**
![[Pasted image 20250618130513.png]]
![[Pasted image 20250618130716.png]]
6. **「/admin/config/ai/providers」に戻る、作成したキーを選択する**
![[Pasted image 20250618130756.png]]
7. **「admin/config/ai/settings」に戻ると、「Translate Text」の「Default Provider」選択ボックスに「DeepL」が表示されます。**
![[Pasted image 20250618131816.png]]

# 3.各オペレーションタイプの説明

| 操作の種類                    | 機能                                                                            | 有名なプロバイダー       |
| ------------------------ | ----------------------------------------------------------------------------- | --------------- |
| Image and Audio to Video | 映像は画像と音声を組み合わせて生成できる。                                                         | OpenAI          |
| Image to Video           | 画像を取得し、それに基づいてビデオを生成することができます。                                                | OpenAI          |
| Speech to Speech         | 音声を含むオーディオ・ファイルを取り込み、同じ音声を含む別のオーディオ・ファイルに変換することができる通話です。                      | ElevenLabs      |
| Image Classification     | 画像を取り込み、この画像が分類にどの程度適合しているかの信頼度の重みを与えることができる呼び出しです。                           | Huggingface     |
| Audio to Audio           | オーディオファイルを取り込み、別のオーディオファイルに変換するコールである。                                        | Auphonic        |
| Text To Image            | テキストプロンプトから画像を生成できるコールである。                                                    | Dall-E、Azure    |
| Chat                     | つまり通常LLMとやりとりする方法だ。つまり、メッセージをやりとりして、サービスからメッセージを返す。                           | OpenAI、Gemini   |
| Moderation               | プロンプトが攻撃的であったり、特定のプロバイダーの場合、プロバイダーに送信する条件に反している場合にフィードバックを与えることができるコールのことである。 | OpenAI、Azure    |
| Embeddings               | テキストの重みのベクトル出力を生成することができるコールです。退屈に聞こえるかもしれないが、RAG/ベクトル検索の重要な部分である。            | OpenAI、Azure    |
| Text To Speech           | テキストプロンプトから画像を生成できるコールである。                                                    | Dall-E、Azure    |
| Speech To Text           | 音声ファイルを取り込み、それを聞いてテキストプロンプトを生成することができるコールである。トランスクリビングと呼ばれることもある。             | OpenAI、Deepgram |
| Translate Text           | テキストをある言語から別の言語に翻訳するための呼び出しです。                                                | DeepL           |
| Chat with Image Vision   | 提供された画像に基づいて、対話のベースとなる画像情報を抽出する。                                              | OpenAI、Azure    |
| Chat with Complex JSON   | 提供された複雑なJSONファイルに基づいて会話できる。                                                   | OpenAI、Azure    |

