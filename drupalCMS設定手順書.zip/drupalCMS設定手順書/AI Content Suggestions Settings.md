# 1.概要説明
コンテンツ編集プロセスの様々な側面に対して、支援ツールを追加します。  これにより、コンテンツのトーン調整、本文の要約、ノードのタクソノミー用語の提案、およびモデレーション違反のコンテンツチェックが可能になります。
# 2.依存関係
AIコンテンツ編集ツールは、AI Coreモジュールがインストールおよび設定されており、有効なAI Providerモジュールが有効化および設定されている必要があります。
# 3.注意事項
- 編集ツールはノードの追加および編集フォームに表示されますが、実際に機能するには、レビュー対象のフィールドが入力済みであり、フォームが送信されている必要があります。  新規コンテンツでツールを使用するには、まずドラフトバージョンを作成し、非公開で保存してから編集する必要があります。

- このモジュールは現在、ノードの編集時にのみツールを提供します。他のフィールドを持つコンテンツエンティティでは、現在のところ機能しません。
# 4.設定手順
1. フィードバックを受け取りたい項目を有効にしてください。デフォルトではすべて無効になっており、モジュールは何も実行しません。
2. 各オプションについて、プロバイダーから使用したい特定のモデルを選択するか、LLM設定がデフォルトを決定するようにしてください。
### 4.1 Suggest title
LLMがコンテンツのSEOフレンドリーなタイトルを提案できるようにします。
![[Pasted image 20250617145229.png]]
- **Suggest title model**：「Suggest title」に用いるモデルを選択してください。
- **suggest Title prompt**：「Suggest title」用のプロンプト、安易に変更しないでください。
### 4.2 Summarise text
LLMがコンテンツの要約を提供できるようにします。
![[Pasted image 20250617145752.png]]
- **Summarise text model**：「Summarise text」に用いるモデルを選択してください。
- **Suggest summary prompt**：「Summarise text」用のプロンプト、安易に変更しないでください。
### 4.3 Suggest taxonomy tags
LLMがコンテンツのSEOフレンドリーなタクソノミータグを提案できるようにします。
![[Pasted image 20250617145812.png]]
- **Suggest taxonomy tags model**：「Suggest taxonomy tags」に用いるモデルを選択してください。
- **Suggest taxonomy prompt (not limited to vocabulary)**：「Suggest taxonomy tags」用のプロンプト（語彙に限定されない）、安易に変更しないでください。
- **Suggest taxonomy prompt (limited to vocabulary)**：「Suggest taxonomy tags」用のプロンプト（語彙に限定）、安易に変更しないでください。
### 4.4 Evaluate Readability
LLMがコンテンツの可読性を評価できるようにします。
![[Pasted image 20250617145830.png]]
- **Evaluate Readability model：**「Evaluate Readability」に用いるモデルを選択してください。：
- **Evaluate readability prompt：**「Evaluate Readability」用のプロンプト、安易に変更しないでください。
### 4.5 Alter tone
LLMがコンテンツのトーンに関する提案を提供できるようにします。
![[Pasted image 20250617145908.png]]
- **Alter tone model**：「Alter tone」に用いるモデルを選択してください。
- **Tone of voice prompt**：「Alter tone」用のプロンプト、安易に変更しないでください。
- **Choose own vocabulary for tone of voice options**：トーンオプションに独自の語彙を選択します。これを選択しない場合、デフォルトのトーンオプション（フレンドリー、プロフェッショナル、高校生、大学生、5歳児）にフォールバックします。
![[Pasted image 20250617160652.png]]
- **Choose vocabulary for tone options**：トーンオプションに独自の語彙を選択します。
# 5.使用例
AI Content Suggestionsの設定と使用例：ホームページのテキスト要約
1. **まずテキスト要約（Summarise text）を有効にします。**
![[Pasted image 20250617151717.png]]
2. **ホームページに移動し、「編集(Edit)」をクリックします。**
![[Pasted image 20250617151854.png]]
3. **右サイドバーの「Summarise text」にある「Summarize」ボタンをクリックします。**
![[Pasted image 20250617152056.png]]
4. **要約が生成されていることを確認できます。**
これは失敗事例です。失敗の原因は複数考えられます。モデルが対応していない、バージョンが最新ではない、あるいはネットワークの問題などが挙げられます。
![[Pasted image 20250617152327.png]]
正常な戻り値は以下の通りです。
![[Pasted image 20250617173053.png]]
5. **デフォルトでは、すべてのフィールドがLLMに送信されます。一部のフィールドのみを選択したい場合は、リストから選択できます。**
![[Pasted image 20250617152134.png]]

