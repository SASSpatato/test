■前提: AI Assistantを設定しました。[[AI Assistant Configuration]]

## 使用方法
![[Pasted image 20250617155903.png]]




![[Pasted image 20250617155949.png]]




![[Pasted image 20250617160026.png]]

■補足: 現在、この2つのチャットボットはどちらも利用可能です。ただし、次回のバージョンではDeepChatのみが利用可能となります。


---


![[Pasted image 20250617163509.png]]

- **Display title**: タイトルがコンテンツ内に表示されないように、できるだけオフにしておくことをおすすめします。
  
- **AI Assistant**: 使用したいアシスタントを選択する。


---

  ![[Pasted image 20250617163758.png]]

- **Stream**: AIが回答を開始すると、その内容は一文字ずつ表示されますが、現在のところこの機能は効果を発揮していないようです。(現在、この機能を無効にすることを推奨します。この機能は一部のAI Provider衝突し、AIの回答内容が二重に表示される可能性があります。 )
  
- **Show Structured Results**: 結果を整理された形式（例えばJSONなど）で表示する。

- **Toggle state**:
	- **Opened**:AIチャットボットの会話ウィンドウがデフォルトで表示されます。
	  ![[Pasted image 20250617170255.png]]
	- **Closed**:AIチャットボットの会話ウィンドウは、デフォルトで表示されません。
	  ![[Pasted image 20250617170306.png]]
	- **Remember**:以前のチャットウィンドウの開く/閉じる状態を復元する