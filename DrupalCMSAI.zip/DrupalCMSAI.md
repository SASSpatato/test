- 基本環境構成図

  ![image-20250228133753922](image/DrupalCMSAI/image-20250228133753922.png)



# 1. Ollamaのインストール

- 環境構築

```
# 公式Dockerイメージのプル
docker pull ollama/ollama

# コンテナの起動
# CPU版:
docker run -d --name temp-ollama -p 11434:11434 ollama/ollama
# GPU版:
docker run -d --gpus all --name temp-ollama -p 11434:11434 ollama/ollama

# モデルのダウンロード
docker exec ollama ollama pull yuiseki/rakutenai-2.0-mini:1.5b-instruct
```





- Ollamaが正常に動作しているかテストし、http://localhost:11434 にアクセスする

![image-20250228123007202](image/DrupalCMSAI/image-20250228123007202.png)





# 2. AnythingLLM のインストール

- 環境構築

```
# 公式Dockerイメージのプル
docker pull mintplexlabs/anythingllm


# ストレージをローカル環境に接続し、Dockerコンテナ内でAnythingLLMを動作させる
$env:STORAGE_LOCATION="$HOME\Documents\anythingllm"; `
If(!(Test-Path $env:STORAGE_LOCATION)) {New-Item $env:STORAGE_LOCATION -ItemType Directory}; `
If(!(Test-Path "$env:STORAGE_LOCATION\.env")) {New-Item "$env:STORAGE_LOCATION\.env" -ItemType File};
docker run -d -p 3001:3001 `
--cap-add SYS_ADMIN `
-v "$env:STORAGE_LOCATION`:/app/server/storage" `
-v "$env:STORAGE_LOCATION\.env:/app/server/.env" `
-e STORAGE_DIR="/app/server/storage" `
mintplexlabs/anythingllm;
```









- anythingLLMが正常に動作しているかテストし、http://localhost:3001 にアクセスする


![image-20250228135135957](image/DrupalCMSAI/image-20250228135135957.png)





- Ollamaを選択すると、ローカルのOllamaに自動的に接続される。

![image-20250228140059264](image/DrupalCMSAI/image-20250228140059264.png)



- 新規作成したいワークスペース名を入力後、使用を開始する
  ![image-20250228140511311](image/DrupalCMSAI/image-20250228140511311.png)



- 次に、Webページ上の設定ボタンをクリックし、モードを検索モードに切り替える。

![image-20250228141027372](image/DrupalCMSAI/image-20250228141027372.png)



![image-20250228151358476](image/DrupalCMSAI/image-20250228151358476.png)





# ３.DrupalCMSの関連設定

- 必要なモデル
  - AI Core
  
  - Key
  
  - AI Assistant API
  
  - AI Chatbot
  
  - AnythingLLM Provider
  
    - このモジュールは、composer コマンドを使用してインストールする必要があり、git サポートも必要なため、最初に git をインストールする必要がある。
  
      ```
      #コンテナ内で次のコマンドを実行してください。
      apt install git
      composer require 'drupal/ai_provider_anythingllm:1.0.x-dev@dev'
      ```
  
      



## AnythingLLM Providerの設定

- AnythingLLMのAPIを作成する

  参考URL:http://localhost:3001/settings/api-keys

  ![image-20250228144047282](image/DrupalCMSAI/image-20250228144047282.png)



![image-20250228144104956](image/DrupalCMSAI/image-20250228144104956.png)

- DrupalCMSのAIプロバイダーでAnythingLLMプロバイダーを設定する。
  参考URL：http://localhost:8080/admin/config/ai/providers/anythingllm

  ![image-20250228144809180](image/DrupalCMSAI/image-20250228144809180.png)


​    

​		![image-20250228144856282](image/DrupalCMSAI/image-20250228144856282.png)	

![image-20250228152607285](image/DrupalCMSAI/image-20250228152607285.png)

![image-20250228152802535](image/DrupalCMSAI/image-20250228152802535.png)









## AIアシスタントの設定

- 参考URL：http://localhost:8080/admin/config/ai/ai-assistant

![image-20250228150451650](image/DrupalCMSAI/image-20250228150451650.png)

![image-20250228150722602](image/DrupalCMSAI/image-20250228150722602.png)

![image-20250228150646847](image/DrupalCMSAI/image-20250228150646847.png)

![image-20250228150801710](image/DrupalCMSAI/image-20250228150801710.png)





- Drupalサイトでチャットボットのブロックを配置する

​	参考URL：http://localhost:8080/admin/structure/block/list/gin

![image-20250228150234829](image/DrupalCMSAI/image-20250228150234829.png)



![image-20250228150941143](image/DrupalCMSAI/image-20250228150941143.png)



- **AI が質問に 2 回回答するのを防ぐには、ストリーム オプションをオフにする必要がある。**

![image-20250303185134008](image/DrupalCMSAI/image-20250303185134008.png)






![image-20250228151903220](image/DrupalCMSAI/image-20250228151903220.png)





## AI Search の関連設定

AI が現在の Drupal Web サイトに関する関連する質問のみに回答するには、
AI 検索モジュールを使用する必要がある。以下にその関連構成を示す。



参考URL：http://localhost:8080/admin/config/search/search-api



![image-20250304142205365](image/DrupalCMSAI/image-20250304142205365.png)



![image-20250304142419790](image/DrupalCMSAI/image-20250304142419790.png)



![image-20250304142854189](image/DrupalCMSAI/image-20250304142854189.png)



- **Index は、VDB にアップロードするデータです。AI はこのデータからのみ答えを見つける。**

  VDB にアップロードするデータを選択する

![image-20250304143426400](image/DrupalCMSAI/image-20250304143426400.png)



![image-20250304144713716](image/DrupalCMSAI/image-20250304144713716.png)

![image-20250304144801970](image/DrupalCMSAI/image-20250304144801970.png)



![image-20250304145307344](image/DrupalCMSAI/image-20250304145307344.png)



その後、追加されたすべてのデータにインデックスを付ける

![image-20250304150154651](image/DrupalCMSAI/image-20250304150154651.png)



## Promptの関連設定

- AI Assistant のデフォルト設定ではプロンプトを変更できないため、settings.php を変更する必要がある

  #コンテナ内で次のコマンドを実行してください。

  参考URL：/opt/drupal/web/sites/default/settings.php

  ```
  $settings['ai_assistant_advanced_mode_enabled'] = TRUE;
  ```

  ![image-20250304151200229](image/DrupalCMSAI/image-20250304151200229.png)





- プロンプトを変更する

参考URL：http://localhost:8080/admin/config/ai/ai-assistant

![image-20250304150621174](image/DrupalCMSAI/image-20250304150621174.png)

アクション前のプロンプトに次の内容を追加してください

![image-20250304151510483](image/DrupalCMSAI/image-20250304151510483.png)



その後、anythingllm にアクセスして、アップロードしたデータをワークスペースに固定します

参考URL：http://localhost:3001

![image-20250228141903814](image/DrupalCMSAI/image-20250228141903814.png)

![image-20250304153337065](image/DrupalCMSAI/image-20250304153337065.png)





**保存後、構築は完了です。**



