from typing import Any, Text, Dict, List

from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import SlotSet
from rasa_sdk.events import AllSlotsReset

class ActionResetTansferState(Action):

    def name(self) -> Text:
        return "action_reset_transfer_state"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        # # 获取所有slot的名称
        # slots = tracker.current_slot_values()
        # # 生成 SlotSet 事件列表，将所有Slot设置为None
        # return [SlotSet(slot_name, None) for slot_name in slots]

        # 测试 AllSlotsReset  的功能
        return [AllSlotsReset()]



        # 重置转账流程相关的槽位
        # return [
        #     SlotSet("recipient", None),
        #     SlotSet("amount", None),
        #     SlotSet("final_confirmation", None),
        #     SlotSet("has_sufficient_funds", None),
        #     SlotSet("is_transfer_in_progress", False) # 关键：将流程标记为未进行
        # ]
