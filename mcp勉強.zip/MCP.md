## 1. 基本概念
![[Pasted image 20251119103857.png]]
MCP（Model Context Protocol）是[Anthropic](https://zhida.zhihu.com/search?content_id=257885857&content_type=Article&match_order=1&q=Anthropic&zd_token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ6aGlkYV9zZXJ2ZXIiLCJleHAiOjE3NjM2OTE1MTcsInEiOiJBbnRocm9waWMiLCJ6aGlkYV9zb3VyY2UiOiJlbnRpdHkiLCJjb250ZW50X2lkIjoyNTc4ODU4NTcsImNvbnRlbnRfdHlwZSI6IkFydGljbGUiLCJtYXRjaF9vcmRlciI6MSwiemRfdG9rZW4iOm51bGx9.xFqd_tzf5phF4OS04wB_yN1sf4xyc8LuBoz0Ln2-5eE&zhida_source=entity)（Claude的母公司）在2024年提出的一种协议标准，中文翻译过来的意思是"模型上下文协议"。

MCP的核心作用是**让AI模型能够主动调用外部工具和服务**，从而 大大 扩展AI的 **能力边界**。


MCP定义了应用程序和 AI 模型之间交换上下文信息的方式。
MCP 使得开发者能够**以一致的方式将各种数据源、工具和功能连接到 AI 模型**（一个中间协议层），就像 USB-C 让不同设备能够通过相同的接口连接一样。

![[Pasted image 20251119103745.png]]



可以看出，MCP 就是以更标准的方式让 LLM Chat 使用不同工具，更简单的可视化如下图所示，这样你应该更容易理解“中间协议层”的概念了。

![[Pasted image 20251119104258.png]]


一句话解释就是 MCP 提供给 LLM 所需的上下文：Resources 资源、Prompts 提示词、Tools 工具。

### 1.1为什么需要MCP

我们在构造 prompt （提示词）时，希望能提供一些更具体的信息（比如本地文件，数据库，一些网络实时信息等）给模型，这样模型更容易理解真实场景中的问题。

想象一下没有 MCP 之前我们会怎么做？

我们可能会人工从数据库中筛选或者使用工具检索可能需要的信息，手动的粘贴到 prompt 中。随着我们要解决的问题越来越复杂，手工把信息引入到 prompt 中会变得越来越困难。

为了克服手工 prompt 的局限性，许多 LLM 平台（如 OpenAI、Google）引入了 `function call` （函数调用）功能。

这一机制允许模型在需要时调用预定义的函数来获取数据或执行操作，显著提升了自动化水平。
**更具体的说 MCP 的优势在于：**

- 生态：MCP 提供很多现成的插件，你的 AI 可以直接使用。  
- 统一性：不限制于特定的 AI 模型，任何支持 MCP 的模型都可以灵活切换。  
- 数据安全：你的敏感数据留在自己的电脑上，不必全部上传（因为我们可以自行设计接口确定传输哪些数据）。
![[Pasted image 20251119111028.png]]

> [!NOTE] Function Calling
> 什么是Function Calling？
> Function Calling是对话式大模型中一种让模型能根据对话上下文，自动或半自动生成函数调用意图，并将调用结果融入后续对话的机制，形成可控的闭环。简单说，它给模型加了个“函数接口”，实现两大价值：
> - 当对话需要外部运算或服务支持时，模型无需“凭空想象”结果，而是调用真实函数获取数据；
> - 结构化交互：调用时传入JSON、XML或自定义格式的参数，让对话结果更稳定、可解释。
>   
>   
> Function Calling的工作流程
> 
> 以下是Function Calling在对话流中的典型运作步骤：
> ![[Pasted image 20251119110211.png]]
> - **用户输入**：用户在对话中提出需外部信息或操作的需求，例如“计算这个财务公式”“查下某款产品的库存”。
> - **模型判断**：模型通过分析Prompt（提示词）和对话上下文，确定需调用特定函数才能完成请求。
> - **生成调用意图**：模型输出包含函数名称、结构化参数（如JSON格式）的“调用事件”，返回给系统。
> - **后端执行**：对话引擎或系统架构捕获调用意图，调用对应的后端函数或服务。
> - **结果回传对话**：函数执行完成后，将结果反馈给模型，模型基于结果继续生成回复，传递给用户。
>   
>   但是 function call 也有其局限性， **function call 平台依赖性强**，不同 LLM 平台的 function call API 实现差异较大。
>   例如，OpenAI 的函数调用方式与 Google 的不兼容，开发者在切换模型时需要重写代码，增加了适配成本。除此之外，还有安全性，交互性等问题。


### 1.2 **MCP 和 Function Call 区别？**

**MCP 构建在类似 Function Calling 的机制之上，但旨在解决其痛点，它不能完全取代 Function Calling，而是它的一个进化和发展方向**

|        | MCP                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | Function Call                                                            |
| ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
| 定义     | 模型和其它设备集成的标准接口，包含：工具 Tools、资源 Resources、提示词 Prompts                                                                                                                                                                                                                                                                                                                                                                                                                          | 将模型连接到外部数据和系统，平铺式的罗列 Tools 工具。和 MCP Tool 不同的在于：MCP Tool 的函数约定了输入输出的协议规范。 |
| 协议     | [JSON-RPC](https://zhida.zhihu.com/search?content_id=257885857&content_type=Article&match_order=1&q=JSON-RPC&zd_token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ6aGlkYV9zZXJ2ZXIiLCJleHAiOjE3NjM2OTE1MTcsInEiOiJKU09OLVJQQyIsInpoaWRhX3NvdXJjZSI6ImVudGl0eSIsImNvbnRlbnRfaWQiOjI1Nzg4NTg1NywiY29udGVudF90eXBlIjoiQXJ0aWNsZSIsIm1hdGNoX29yZGVyIjoxLCJ6ZF90b2tlbiI6bnVsbH0.lFaXf67qztPQ8zv2jJhXPAHCGLdtL42_yZL4oG1Bp2Y&zhida_source=entity)，支持双向通信（但目前使用不多）、可发现性、更新通知能力。 | JSON-Schema，静态函数调用。                                                      |
| 调用方式   | Stdio / SSE / 同进程调用                                                                                                                                                                                                                                                                                                                                                                                                                                                          | 同进程调用 / 编程语言对应的函数                                                        |
| 适用场景   | 更适合动态、复杂的交互场景                                                                                                                                                                                                                                                                                                                                                                                                                                                                | 单一特定工具、静态函数执行调用                                                          |
| 系统集成难度 | 高                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | 简单                                                                       |
| 工程化程度  | 高                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | 低                                                                        |

**核心区别：能力 vs 协议**

- **Function Calling (函数调用)** 是 **大模型本身的一种能力**。
    - 它是指：DeepSeek/GPT 能够理解“我可以调用外部函数”，并且能精准地吐出一个 JSON 格式的指令（比如 `{"func": "get_weather", "arg": "Beijing"}`），而不是在那胡言乱语。
    - 这就像是 **人类的手**，拥有“抓取物体”的能力。
- **MCP (Model Context Protocol)** 是一套 **通信协议（标准）**。
    - 它是指：我们规定好，所有的工具（天气、数据库、网页搜索）都要用同一种格式（Schema）来描述自己，都要用同一种方式（Stdio/HTTP）来连接。
    - 这就像是 **把手的通用标准**。它规定所有杯子、锤子、手机都要有一个标准的把手，这样人手抓起来就方便了。

**为什么 MCP 还要用 Function Calling？**

如果没有 Function Calling，AI 只能输出纯文本。你想让它调用工具，你得在 Prompt 里写一大堆复杂的正则规则（比如“如果你想查天气，请回复 [CMD:weather]...”），不仅不稳定，而且容易出错。

**MCP 的工作流正是建立在 Function Calling 之上的：**

1. **MCP Server (你的代码)** 说：“我有 `get_weather` 这个工具，参数是 `city`。”（这是 MCP 协议规定的格式）。
2. **Client (中介)** 把这个描述**翻译**成 OpenAI Function Calling 的格式，扔给大模型。
3. **大模型 (LLM)** 发动它的 **Function Calling 能力**，思考后说：“好，那我要调用 `get_weather`。”
4. **Client** 收到指令，再通过 **MCP 协议** 告诉 Server 去执行。

或者
1. **MCP 客户端** 从所有连接的 MCP 服务器收集可用的工具列表
2. **MCP 客户端** 将这些工具信息**转换**为 LLM 能够理解的 Function Calling schema
3. 当用户提问时，**MCP 客户端** 使用 Function Calling 机制与 LLM 交互
4. LLM 返回要调用的工具和参数
5. **MCP 客户端** 通过 MCP 协议将调用转发给相应的 MCP 服务器




**所以：MCP 统一了“工具怎么定义”和“工具怎么连接”，而 Function Calling 负责“大脑怎么决定调用”。**

- **Function Calling (函数调用)** 是 **大模型本身的一种能力**。
    - 它是指：DeepSeek/GPT 能够理解“我可以调用外部函数”，并且能精准地吐出一个 JSON 格式的指令（比如 `{"func": "get_weather", "arg": "Beijing"}`），而不是在那胡言乱语。
    - 这就像是 **人类的手**，拥有“抓取物体”的能力。
- **MCP (Model Context Protocol)** 是一套 **通信协议（标准）**。
    - 它是指：我们规定好，所有的工具（天气、数据库、网页搜索）都要用同一种格式（Schema）来描述自己，都要用同一种方式（Stdio/HTTP）来连接。
    - 这就像是 **把手的通用标准**。它规定所有杯子、锤子、手机都要有一个标准的把手，这样人手抓起来就方便了。






### **1.3 MCP 架构解构**

![[Pasted image 20251205102957.png]]
![[Pasted image 20251119131038.png]]

MCP 由三个核心组件构成：Host（主机）、Client（客户端） 和 Server（服务器）。
让我们通过一个实际场景来理解这些组件如何协同工作： 假设你正在使用 Claude Desktop (Host) 询问："我桌面上有哪些文档？"

**（1）Host**：主机是期望从服务器获取数据的人工智能应用，例如一个集成开发环境（IDE）、聊天机器人等。主机负责初始化和管理客户端（client）、处理用户授权、管理上下文聚合等。Claude Desktop 作为 Host，负责接收你的提问并与 Claude 模型交互。

**（2）Client**：客户端是主机与服务器之间的桥梁。它与服务器保持一对一的连接，负责消息路由、能力管理、协议协商和订阅管理等。客户端确保主机和服务器之间的通信清晰、安全且高效。当 Claude 模型决定需要访问你的文件系统时，Host 中内置的 MCP Client 会被激活。这个 Client 负责与适当的 MCP Server 建立连接。

**（3）Server**：服务器是提供外部数据和工具的组件。它通过工具、资源和提示模板为大型语言模型提供额外的上下文和功能。例如，一个服务器可以提供与Gmail、Slack等外部服务的API调用。在这个例子中，文件系统 MCP Server 会被调用。它负责执行实际的文件扫描操作，访问你的桌面目录，并返回找到的文档列表。
**MCP Server** 包括：
- **Tools**：使大语言模型能够通过你的 Server 执行操作。
- **Resources**：将 Server 上的数据和内容开放给大语言模型。
- **Prompts**：创建可复用的提示词模板和工作流程。


整个流程是这样的：你的问题 → Claude Desktop(Host) → Claude 模型 → 需要文件信息 → MCP Client 连接 → 文件系统 MCP Server → 执行操作 → 返回结果 → Claude 生成回答 → 显示在 Claude Desktop 上。

![[Pasted image 20251119105233.png]]


另一个例子：Visual Studio Code 作为 MCP 主机。当 Visual Studio Code 建立与 MCP 服务器（如 [Sentry MCP 服务器](https://docs.sentry.io/product/sentry-mcp/) ）的连接时，Visual Studio Code 运行时实例化一个 MCP 客户端对象，以维护与 Sentry MCP 服务器的连接。当 Visual Studio Code 随后连接到另一个 MCP 服务器（如[本地文件系统服务器](https://github.com/modelcontextprotocol/servers/tree/main/src/filesystem) ）时，Visual Studio Code 运行时会实例化一个额外的 MCP 客户端对象以维持该连接，从而保持 MCP 客户端与 MCP 服务器之间的一 一对应关系。

![[Pasted image 20251119140936.png]]




### 原理：模型是如何确定工具的选用的？

在学习的过程中，我一直好奇一个问题：**Claude（模型）是在什么时候确定使用哪些工具的呢**？好在 Anthropic 为我们提供了详细的[解释](https://link.zhihu.com/?target=https%3A//modelcontextprotocol.io/quickstart/server%23what%25E2%2580%2599s-happening-under-the-hood)：

当用户提出一个问题时：

1. 客户端（Claude Desktop / Cursor）将你的问题发送给 Claude。
2. Claude 分析可用的工具，并决定使用哪一个（或多个）。
3. 客户端通过 MCP Server 执行所选的工具。
4. 工具的执行结果被送回给 Claude。
5. Claude 结合执行结果构造最终的 prompt 并生成自然语言的回应。
6. 回应最终展示给用户！



### **客户端与服务器的通信流程**

![[Pasted image 20251209101328.png]]


1) 客户端发送初始请求，获取服务器能力信息
2) 服务器返回其能力信息详情
3) 例如当天气 API 服务器被调用时，它可以返回可用的“tools”、“prompts templates”及其他资源供客户端使用

交换完成后，客户端确认连接成功，然后继续交换消息。

Capability Exchange 流程 具体如何实现呢？ [MCP协议](https://zhida.zhihu.com/search?content_id=257885857&content_type=Article&match_order=1&q=MCP%E5%8D%8F%E8%AE%AE&zd_token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ6aGlkYV9zZXJ2ZXIiLCJleHAiOjE3NjUwNjg5NzEsInEiOiJNQ1DljY_orq4iLCJ6aGlkYV9zb3VyY2UiOiJlbnRpdHkiLCJjb250ZW50X2lkIjoyNTc4ODU4NTcsImNvbnRlbnRfdHlwZSI6IkFydGljbGUiLCJtYXRjaF9vcmRlciI6MSwiemRfdG9rZW4iOm51bGx9.Uzzds3vu-l-Mm7dRMGT8huo-dirweuyhNV2Q4Euj5AQ&zhida_source=entity)官方提供了两种主要通信方式：**stdio**（标准输入输出）和 **SSE** （Server-Sent Events，服务器发送事件）。

这两种方式均采用**全双工通信模式**，通过独立的读写通道实现服务器消息的实时接收和发送。




 **什么是[SSE Transport](https://zhida.zhihu.com/search?content_id=257885857&content_type=Article&match_order=1&q=SSE+Transport&zd_token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ6aGlkYV9zZXJ2ZXIiLCJleHAiOjE3NjUwNjg5NzEsInEiOiJTU0UgVHJhbnNwb3J0IiwiemhpZGFfc291cmNlIjoiZW50aXR5IiwiY29udGVudF9pZCI6MjU3ODg1ODU3LCJjb250ZW50X3R5cGUiOiJBcnRpY2xlIiwibWF0Y2hfb3JkZXIiOjEsInpkX3Rva2VuIjpudWxsfQ.aJF1cJCbu4QpOT3ZanzWFsLgCv9np4CnVpTW9a2PS0M&zhida_source=entity)？**

MCP（Model Context Protocol） 是一个开放协议，旨在标准化应用程序与大型语言模型（LLM）之间的上下文交互。它定义了客户端与服务器如何通过传输层交换消息。

MCP 支持两种标准传输机制：

- **stdio**：通过标准输入输出流进行本地通信。（只能本地）
- **SSE（Server-Sent Events）**：通过 HTTP 协议实现服务器到客户端的实时单向数据推送，结合 HTTP POST 用于客户端到服务器的消息发送。

SSE Transport 是 MCP 中基于 HTTP 的传输方式，利用 SSE 技术实现服务器到客户端的流式消息推送，同时通过 HTTP POST 请求处理客户端到服务器的双向通信。

这种机制特别适合需要实时更新或远程通信的场景。


 **SSE Transport 的工作原理**

SSE（Server-Sent Events）是一种基于 HTTP 协议的服务器推送技术，允许服务器向客户端发送实时更新。

MCP 的 SSE Transport 结合了 SSE 和 HTTP POST，形成了以下工作流程：
![[Pasted image 20251209101932.png]]




### 1.4 层级

MCP 由两层组成：

- **数据层** ：定义基于 JSON-RPC 的客户端-服务器通信协议，包括生命周期管理及基本元素（如工具、资源、提示和通知）。
- **传输层** ：定义支持客户端与服务器之间数据交换的通信机制和通道，包括传输专用连接建立、消息框架和授权。


#### 1.4.1 数据层

The data layer implements a [JSON-RPC 2.0](https://www.jsonrpc.org/) based exchange protocol that defines the message **structure** and **semantics**

MCP primitives 是 MCP 中最重要的概念。它们定义了客户端与服务器之间可提供的功能。这些基本操作明确了可与人工智能应用共享的上下文信息类型，以及可执行的操作范围。

MCP 定义了三种MCP Server暴露的primitives：
- **工具**(tool) ：AI 应用程序可以调用以执行作（如文件作、API 调用、数据库查询）的可执行函数
- **资源**(resource) ：为 AI 应用提供上下文信息的数据源（例如文件内容、数据库记录、API 响应）
- **提示词**(prompt) ：可重复使用的模板，帮助结构化与语言模型的交互（例如，系统提示、少数样本示例）

Each primitive type has associated methods for discovery (`*/list`), retrieval (`*/get`), and in some cases, execution (`tools/call`). MCP clients will use the `*/list` methods to discover available primitives. For example, a client can first list all available tools (`tools/list`) and then execute them.

客户端调用这些服务器暴露出来的端点


MCP 还定义了MCP client暴露的primitives：
- **采样：** 允许服务器向客户端的 AI 应用请求语言模型补全。当服务器作者希望访问语言模型，但又希望保持模型独立性，不包含语言模型 SDK 时，这非常有用。他们可以使用采`样/完整`方法向客户的 AI 应用请求语言模型的补全。
- **信息征求** ：允许服务器向用户请求额外信息。当服务器作者希望从用户那里获取更多信息，或请求确认作时，这非常有用。他们可以使用`请求`方法向用户请求额外信息。
- **日志**记录：使服务器能够向客户端发送日志消息，以便进行调试和监控。


生命周期管理：

MCP is a stateful protocol that requires lifecycle management. The purpose of lifecycle management is to negotiate the capabilities that both client and server support. Detailed information can be found in the [specification](https://modelcontextprotocol.io/specification/2025-06-18/basic/lifecycle), and the [example](https://modelcontextprotocol.io/docs/learn/architecture#example) showcases the initialization sequence.

MCP是一种需要生命周期管理的状态化协议。生命周期管理的目的是协商客户端和服务器双方支持的功能。详细信息可参见规范文档，示例展示了初始化序列。


#### 1.4.2 传输层

传输层负责管理客户端与服务器之间的通信通道和认证。它负责连接建立、消息框架以及 MCP 参与者之间的安全通信。

MCP 支持两种传输机制：
- **Stdio 传输** ：使用标准输入/输出流实现同一机器上本地进程之间的直接进程通信，提供最佳性能且无网络开销。
- **可流式 HTTP 传输** ：使用 HTTP POST 处理客户端到服务器消息，并可选地支持服务器发送事件以实现流媒体功能。该传输支持远程服务器通信，并支持标准的 HTTP 认证方法，包括承载令牌、API 密钥和自定义头部。MCP 建议使用 OAuth 来获取认证令牌。





### 1.5 MCP Server

服务器通过三个构建模块提供功能：
![[Pasted image 20251119144329.png]]

#### Tools

Tools enable AI models to perform actions. Each tool defines a specific operation with typed inputs and outputs. The model requests tool execution based on context.  
工具使人工智能模型能够执行动作。每个工具定义了带有类型输入和输出的特定action。模型请求基于上下文执行工具。

工具是 LLM 可以调用的模式定义接口。MCP 使用 JSON 模式进行验证。每个工具执行单一操作，输入和输出都明确定义。工具可能要求用户在执行前同意，帮助确保用户对模型所采取动作保持控制。

![[Pasted image 20251119150040.png]]



**例子：旅行订票**
![[Pasted image 20251120101116.png]]
```
searchFlights(origin: "NYC", destination: "Barcelona", date: "2024-06-15")
```


**User Interaction Model  用户交互模型**

工具是模型控制的，意味着 AI 模型可以自动发现并调用它们。然而，MCP 强调通过多种机制进行人工监督。

为了信任和安全，应用程序可以通过各种机制实现用户控制，例如：
- 在用户界面中显示可用工具，使用户能够定义该工具是否应在特定交互中开放
- 单个工具执行的审批对话框
- 预先批准某些安全作的权限设置
- 活动日志，显示所有工具执行及其结果






#### Resource

资源为 AI 应用提供了结构化的信息访问，这些信息可以检索并作为上下文提供给模型。

资源会暴露来自文件、API、数据库或其他任何来源的数据，这些数据是人工智能理解上下文所需的。应用程序可以直接访问这些信息并决定如何使用它们——无论是选择相关部分、使用嵌入进行搜索，还是将所有数据传递给模型。

每个资源都有独特的 URI（例如 `file:///path/to/document.md`），并声明其 MIME 类型以便适当处理内容。

资源支持两种发现模式：
- **直接资源** ——指向特定数据的固定 URI。示例：`calendar://events/2024` - 返回 2024 年的日历可用性
- **资源模板** ——带有灵活查询参数的动态 URI。例：
	- `travel://activities/{city}/{category}` - 按城市和类别统计活动

![[Pasted image 20251120101902.png]]

例子：获取旅行规划背景

- **日历数据** （`calendar://events/2024`）——检查用户空闲时间
- **旅行证件** （ `file:///Documents/Travel/passport.pdf` ） - 访问重要文件
- **以往行程** （ `trips://history/barcelona-2023` ）- 参考以往旅行及偏好
AI 应用程序检索这些资源并决定如何处理，无论是通过嵌入或关键词搜索选择部分数据，还是直接将原始数据传递给模型。


![[Pasted image 20251120102136.png]]


**User Interaction Model  用户交互模型**

资源是应用驱动的，赋予它们在检索、处理和呈现可用上下文的方式上具有灵活性。常见的交互模式包括：

- 用于熟悉文件夹式结构的资源浏览树状或列表视图
- 查找和筛选特定资源的界面
- 手动或批量选择界面，用于包含单个或多个资源




#### Prompt

**MCP Server 的职责不是 _执行_ Prompt，而是 _定义和宣告 (Define and Announce)_ Prompt。**

定义： 预先构建好的指令模板，它告诉模型如何使用特定的工具和资源来工作。对MCP而言，它提供了可重复使用的模板。它们允许 MCP 服务器作者为特定领域提供参数化提示，或展示如何最佳使用 MCP 服务器。

- **核心特点**：
    - **指令 (Instruction)**：它是一个命令或请求，明确告诉AI要完成什么任务。
    - **模板化的 (Templates)**：在很多应用中，开发者会预设一些高效的指令模板。当用户提出一个简单请求时，应用会自动套用这个模板，并填入必要的“资源”信息，形成一个更完整、更专业的指令发给AI。
    - **驱动行为 (Drives Action)**：Prompt是驱动AI开始工作的“扳机”。

- **发起方 (Source)**：**User (用户)**。这些任务都是由你——最终用户——提出的。


**问题： Prompt和我与ai聊天输入的内容一样吗？**

**既是，又不是。**

1. **是 (Your input is a prompt)**：  
    从广义上讲，你在任何聊天机器人（like ChatGPT）里输入的任何一句话，都是一个Prompt。比如你输入“你好”，这也是一个Prompt，AI根据这个Prompt给出了回应。
2. **不完全是 (It's often more complex behind the scenes)**：  
    在很多高级AI应用中（比如图片里描述的场景），你输入的简单内容只是“**用户侧的Prompt**。应用程序接收到它之后，会将其**加工**成一个更复杂、更结构化的“**系统侧Prompt**”再发给AI大模型。

**例子：**

- **你输入 (User Prompt)**：`“帮我总结一下今天的会议”`
- **AI应用在后台的真实操作**：
    1. **识别意图**：应用理解到你需要“总结会议”。
    2. **调用Resource**：应用自动访问你的日历（Resource），找到今天的所有会议记录和与会者信息。
    3. **填充Prompt模板**：应用拿出一个预设好的、专门用于会议总结的模板（Pre-built instruction template），然后把从日历（Resource）里读到的信息填进去，形成一个非常详细的Prompt。
    4. **发送给大模型 (System Prompt)**：最终发送给AI大模型的可能是这样的：
               > “你是一个专业的会议助理。请根据以下日历信息：[这里插入今天会议的详细数据，包括时间、主题、与会者、会议纪要链接...]，为用户生成一份简洁的会议摘要，重点突出每个会议的行动要点和决策。”
        

所以，你输入的是一个简单的指令，但应用通过结合**Resource**和**Prompt模板**，让AI能够更精准、更强大地完成任务。



MCP的Prompt  是一个**结构化的模板**。它就像一个**需要填写的表格**，明确定义了它需要哪些信息（输入）才能工作。你作为用户，必须**主动选择**并**启动**（explicit invocation）这个模板，比如通过点击一个按钮或输入一个命令。


![[Pasted image 20251120104122.png]]
- **`prompts/list`**: 想象你的AI应用启动时，它会问服务器：“嘿，你有哪些‘菜单项’（Prompts）可以给我用？” 服务器就会返回一个列表，比如 `["plan-vacation", "summarize-meeting", "draft-email"]`。
- **`prompts/get`**: 当你选择 `/plan-vacation` 时，应用会再次问服务器：“好的，请把‘plan-vacation’这个菜单项的详细‘点餐单’（表格字段）给我。” 服务器就会返回下面那个详细的 JSON 定义。
```
{
  "name": "plan-vacation", // 这是工具的内部ID，像函数名
  "title": "Plan a vacation", // 这是显示给用户看的美观名称
  "description": "Guide through vacation planning process", // 这是帮助说明，告诉用户这个工具有什么用
  
  // 这是最重要的部分！定义了这个工具需要用户填写哪些“表格字段”
  "arguments": [ 
    {
      "name": "destination", // 字段1：目的地
      "type": "string",       // 必须是文本
      "required": true        // 这个是必填项！
    },
    {
      "name": "duration",      // 字段2：时长
      "type": "number",       // 必须是数字
      "description": "days"   // 提示用户单位是“天”
    },
    {
      "name": "budget",        // 字段3：预算
      "type": "number",       // 必须是数字
      "required": false       // 这个是选填项
    },
    {
      "name": "interests",     // 字段4：兴趣点
      "type": "array",        // 必须是一个列表/数组
      "items": { "type": "string" } // 列表里的每一项都必须是文本
    }
  ]
}
```

这个 JSON 对象**就是“Plan a vacation”这个 Prompt 的定义**。它不是发给 LLM 的最终指令，而是**定义这个“工具”本身的蓝图**。这个JSON还会被进一步处理成结构化的文本。




**User Interaction Model (用户交互模型)**

这部分讲的是，应用应该**如何把这些“Prompt工具”展示给用户**。
- **Slash commands**: 输入 `/` 弹出命令列表，就像在 Slack 或 Notion 里一样。这正是你主动“调用”（explicit invocation）的方式。
- **Command palettes**: 按下 `Ctrl+K` 或 `Cmd+K` 弹出一个搜索框，让你快速找到并使用这些工具。
- **Dedicated UI buttons**: 界面上有个“规划假期”的按钮，点击后弹出表单。
- **Context menus**: 你在一段文字上右键，菜单里出现一个“用此内容起草邮件”的选项。










### 1.6 MCP Client

#### Elicitation  

信息征求（Elicitation）使服务器能够在交互中向用户请求特定信息，从而创建更动态且响应灵敏的工作流程。

信息征求为服务器提供了一种结构化的方式，按需收集必要信息。服务器无需事先要求所有信息或数据缺失时失败，而是可以暂停操作，向用户请求特定输入。这创造了更灵活的交互，服务器能够根据用户需求进行调整，而非遵循固定模式。

![[Pasted image 20251120125929.png]]




Elicitation 组件示例：
```
{
  method: "elicitation/requestInput",
  params: {
    message: "Please confirm your Barcelona vacation booking details:",
    schema: {
      type: "object",
      properties: {
        confirmBooking: {
          type: "boolean",
          description: "Confirm the booking (Flights + Hotel = $3,000)"
        },
        seatPreference: {
          type: "string",
          enum: ["window", "aisle", "no preference"],
          description: "Preferred seat type for flights"
        },
        roomType: {
          type: "string",
          enum: ["sea view", "city view", "garden view"],
          description: "Preferred room type at hotel"
        },
        travelInsurance: {
          type: "boolean",
          default: false,
          description: "Add travel insurance ($150)"
        }
      },
      required: ["confirmBooking"]
    }
  }
}
```


示例：

![[Pasted image 20251120130215.png]]


**User Interaction Model  用户交互模型**

**请求呈现** ：客户端通过清晰的上下文显示引发请求，说明是哪台服务器在请求、为何需要这些信息以及如何使用。请求消息解释目的，而模式则提供结构和验证。

**响应选项** ：用户可以通过适当的界面控件（文本字段、下拉选单、复选框）提供所需信息，拒绝提供带有可选解释的信息，或取消整个作。客户端会在返回服务器前验证响应是否符合所提供的模式。

**隐私考虑** ：引诱从不要求密码或 API 密钥。客户端会警告可疑请求，并允许用户在发送前查看数据。



#### Roots  

Roots定义了服务器操作的文件系统边界，允许客户端指定服务器应重点关注的目录。

Roots是客户端向服务器传递文件系统访问边界的一种机制。它们由文件 URI 组成，指示服务器可运行的目录，帮助服务器了解可用文件和文件夹的范围。虽然根传递预期边界，但不强制执行安全限制。实际的安全必须在作系统层面通过文件权限和/或沙箱来强制执行。

![[Pasted image 20251120130929.png]]




**示例：旅行规划**

一个旅行代理在处理多个客户的旅行事务时，会受益于使用“根目录(roots)”来组织对文件系统的访问。我们来设想一个工作空间，其中包含用于旅行规划各个方面的不同目录。

客户端向旅行规划服务器提供文件系统的根目录：

- `file:///Users/agent/travel-planning` - 主工作空间，包含所有旅行文件。
- `file:///Users/agent/travel-templates` - 可复用的行程模板和资源。
- `file:///Users/agent/client-documents` - 客户的护照和旅行证件。

当这个代理（agent）创建一个巴塞罗那的行程时，一个行为规范的服务器会**遵守这些边界**——它只会在指定的根目录内部访问模板、保存新行程以及引用客户文档。服务器通常通过使用**相对于根目录的相对路径**，或利用那些**遵守根目录边界的文件搜索工具**来访问这些根目录中的文件。

如果这个代理打开了一个归档文件夹，比如 `file:///Users/agent/archive/2023-trips`，客户端会通过 `roots/list_changed` 接口来更新这个根目录列表。



**User Interaction Model  用户交互模型**

**自动根检测** ：当用户打开文件夹时，客户端会自动将其暴露为根。打开旅行工作区允许客户端将该目录作为根目录暴露，帮助服务器了解当前工作的行程和文档范围。

**手动根配置** ：高级用户可以通过配置指定根节点。例如，添加/`travel 模板`用于可复用资源，同时排除包含财务记录的目录。






#### Sampling

Sampling (采样) 是一种“角色反转”的机制，它允许 `MCP Server` (服务器) 在处理任务的过程中，“请求” `MCP Client` (客户端) 动用它的 AI 大脑来帮自己完成一个需要“思考”的子任务。

想象一下这个场景：

- **MCP Server (服务器)**：是一位经验丰富的**数据分析专家**。他非常擅长从数据库或文件中快速、准确地提取数据（调用API查询数据），但他不擅长写报告或用通俗的语言解释问题。
- **MCP Client (客户端)**：是这位专家的**聪明助理**。这位助理虽然不会自己去数据库里捞数据，但他手边有一部“魔法电话”，可以直接连接到世界上最聪明的大脑（LLM）。

**现在，一个任务来了：** “请分析这份技术报告，并用一句话总结它的商业价值。”

1. **专家出马 (Server a Action)**：专家（Server）接到了任务，他迅速打开技术报告（Resource），用他专业的技能分析了里面的所有数据和图表，得出了很多技术结论。
2. **专家遇到困难**：他看着满是术语的结论，心想：“我该怎么把这些东西变成一句通俗易懂的‘商业价值’呢？” —— 这超出了他的专业范围。
3. **角色反转的时刻 (The "Sampling" Request)**：这时，专家（Server）没有自己硬着头皮写，而是转身对他的助理（Client）说：
	“**嘿，助理，我这里有一堆技术结论 `[...此处是技术术语...]`，请你用你的‘魔法电话’（LLM）帮我把它们总结成一句有商业价值的话。**”

4. **助理完成任务 (Client Executes)**：助理（Client）接到这个“请求”，立刻拿起“魔法电话”（调用 LLM），把专家的技术结论发过去，并拿回了一句完美的总结。
5. **汇报成果**：助理（Client）把这句总结交还给专家（Server）。专家再把他自己的数据分析结果和这句总结整合在一起，形成一份完美的最终报告，提交上去。

在这个过程中，服务器向客户端发出的那个“请求”，就是一次 **Sampling**。


![[Pasted image 20251120132846.png]]

**Request parameters example:**
```
{
  messages: [
    {
      role: "user",
      content: "Analyze these flight options and recommend the best choice:\n" +
               "[47 flights with prices, times, airlines, and layovers]\n" +
               "User preferences: morning departure, max 1 layover"
    }
  ],
  modelPreferences: {
    hints: [{
      name: "claude-sonnet-4-20250514"  // Suggested model
    }],
    costPriority: 0.3,      // Less concerned about API cost
    speedPriority: 0.2,     // Can wait for thorough analysis
    intelligencePriority: 0.9  // Need complex trade-off evaluation
  },
  systemPrompt: "You are a travel expert helping users find the best flights based on their preferences",
  maxTokens: 1500
}
```




**User Interaction Model  用户交互模型**

**审批控制** ：采样请求可能需要用户明确同意。客户端可以展示服务器想分析的内容及其原因。用户可以批准、拒绝或修改请求。

**透明度功能** ：客户端可以显示精确的提示词、模型选择和令牌限制，允许用户在返回服务器前查看 AI 回复。

**配置选项** ：用户可以设置模型偏好，配置可信作的自动批准，或要求所有作都获得批准。客户端可能会提供遮蔽敏感信息的选项。

**安全考虑** ：客户端和服务器在采样过程中必须适当处理敏感数据。客户端应实现速率限制并验证所有消息内容。这种人机参与设计确保服务器发起的 AI 交互在未经用户明确同意的情况下无法破坏安全或访问敏感数据。






## 2. 简单实践

### MCP server

#### Tool

通过MCP实现调用查询天气的API

##### **环境准备(windows)**

```
# 1. 创建虚拟环境 python -m venv venv 

# 2. 激活环境 
# 注意：如果你看到红色报错说“禁止运行脚本”，请先运行: Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass 

.\venv\Scripts\Activate 

# 3. 成功激活后，你的命令行前面会出现 (venv) 字样 
# 4. 安装依赖 
pip install mcp httpx
```

代码：
```
from mcp.server.fastmcp import FastMCP
import httpx

# 初始化 Server
mcp = FastMCP("My Local Weather Service")

# 请替换为你自己的 API KEY
API_KEY = "你的_WeatherAPI_KEY" 
BASE_URL = "http://api.weatherapi.com/v1/current.json"

@mcp.tool()
async def get_weather(city: str) -> str:
    """
    查询指定城市的当前天气情况。
    Args:
        city: 城市名称 (例如: "Beijing", "Shanghai")
    """
    print(f"正在查询城市: {city}...", flush=True)
    
    url = f"{BASE_URL}?key={API_KEY}&q={city}&aqi=no"
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(url)
            response.raise_for_status()
            data = response.json()
            
            location = data['location']['name']
            temp_c = data['current']['temp_c']
            condition = data['current']['condition']['text']
            
            return f"{location} 的当前天气是: {condition}, 温度: {temp_c}°C"
        except Exception as e:
            return f"查询出错: {str(e)}"

if __name__ == "__main__":
    mcp.run()
```



**测试**

```
npx @modelcontextprotocol/inspector .\venv\Scripts\python.exe weather_server.py

```




##### **编写MCP client 来 调用 MCP server**

代码见 VS code


**为什么不需要手动启动 Server，直接运行 Client 就行了？**

这正是 MCP 协议中 **Stdio（标准输入输出）模式** 的一大特色。

在传统的 Web 开发（比如做个网站）中，你确实需要先打开一个黑窗口运行服务器（比如 `python manage.py runserver`），让它在那一直挂着等待别人连接。

但在 MCP 的 Stdio 模式下，**Client（你的 `weather_client.py`）就是 Server 的“老板”。**

当你运行 Client 脚本时，发生了以下过程：

1. **自动启动**：Client 代码执行到 `async with stdio_client(...)` 这一行时，它会在后台悄悄运行你配置好的命令（即 `python weather_server.py`）。这就像是你双击打开了一个软件，不需要你自己去命令行敲。
2. **建立管道**：Client 会立刻把一根管子插到 Server 的嘴里（Stdin），把耳朵贴在 Server 的嘴边（Stdout）。
3. **对话**：Client 发指令，Server 干活并返回。
4. **自动关闭**：当 Client 代码运行结束（`async with` 代码块结束），它会自动“杀掉”Server 进程。




**与ai集成**

先安装python库
```
pip install openai
```
详细代码见 VScode


#### Resource

实现代码同样见 VScode


`mcp_server_file.py` 中，使用了 `FastMCP` 的 `@mcp.resource("file://{filename}")` 装饰器。  
这意味着他定义了一个 **Resource Template (资源模板)**，而不是一个具体的静态资源列表。


1. **Resources (资源列表)**：是 **静态的**、**具体的**、**已知的一堆东西**。
    - 比如：`file://report_2023.pdf`、`file://logo.png`、`database://users_table`。
    - 特点：Server **确切知道**这些东西存在，并且能把它们像菜单一样列出来给 Client 看。Client 可以直接展示一个列表让用户选。
    - 类比：**餐馆的固定菜单**（宫保鸡丁、鱼香肉丝）。
2. **Resource Templates (资源模板)**：是 **动态的**、**模式化的**、**潜在的无限集合**。
    - 比如：`file://{path}`、`database://{table_name}/row/{id}`。
    - 特点：Server 无法列出所有可能的组合（因为文件可能有无限个，ID 也是无限的），但 Server 告诉 Client：“只要你给我一个符合这个格式的 URI，我就能试着去读它”。
    - 类比：**“我可以做任何炒饭”**（炒饭公式：{食材} + 炒饭）。Client 没法列出所有炒饭，但知道可以点“牛肉炒饭”、“鸡蛋炒饭”。




正如我们之前讨论的，目前的 AI（如 DeepSeek/OpenAI）**原生不懂** 什么是 Resource，它们只懂 **Function Calling (Tools)**。

所以，要在 Client 端实现“AI 读取文件”，我们需要做一个“转换操作”**：  
把 MCP 的 Resource 能力，包装成一个 AI 能听懂的 Tool。






#### Prompt

- **Tools**：AI 觉得需要用，AI 自动调用。
- **Resources**：AI 需要看数据，AI 自动读取。
- **Prompts**：**用户**（你）在界面上点击一个按钮（比如“帮我修 Bug”），Client 就会向 MCP Server 索要一份**“写好的咒语”**，然后自动填入对话框，发给 AI。

简单说：**Prompt 就是服务器端定义好的“快捷指令”或“预制模版”。**

代码见VScode



**调用链：**

##### Phase 1: 握手与菜单 (初始化)

1. **🖥️ Client** 启动，读取配置文件，自动运行 **⚙️ Server**。
2. **🖥️ Client** -> **⚙️ Server**: 发送 `list_prompts` 请求（“你有啥模版？”）。
3. **⚙️ Server** -> **🖥️ Client**: 返回列表 `[{name: "code_doctor", ...}, {name: "blog_outline", ...}]`。
4. **🖥️ Client**: 把这些选项渲染到 UI 界面上（比如当你输入 `/` 时弹出的菜单）。

##### Phase 2: 触发与参数 (用户操作)

5. **👤 User**: 在输入框输入 `/code`，并从菜单中选中 **Code Doctor**。
6. **🖥️ Client**: 检查 `code_doctor` 定义的参数结构。
7. **🖥️ Client**: 弹出一个表单（或者直接读取你剪贴板/选中的代码），让 **👤 User** 填入 `code` 参数的内容。
8. **👤 User**: 填入代码 `print(x)` 并点击“发送”。

##### Phase 3: 生成模版 (Server 工作)

9. **🖥️ Client** -> **⚙️ Server**: 发送 `get_prompt` 请求。
    - Request: `method: prompts/get`, `params: { name: "code_doctor", arguments: { code: "print(x)" } }`
10. **⚙️ Server**: 运行 `def code_doctor(code): ...` 函数。
    - 构造 System Message: "你是一个资深 Python 工程师..."
    - 构造 User Message: "请审查代码: print(x)"
11. **⚙️ Server** -> **🖥️ Client**: 返回生成好的 `Messages` 列表。

##### Phase 4: 发送与回答 (LLM 介入)

12. **🖥️ Client**: 拿到 Messages 后，通常会发生两件事之一：
    - **A (直接发送)**: 直接把 Messages 塞进调用 LLM 的请求里。
    - **B (填充界面)**: 把 Messages 里的文字填到用户的聊天输入框里，让用户再看一眼或修改，然后用户按回车发送。
13. **🖥️ Client** -> **🧠 LLM**: 发送 API 请求（包含 System Prompt 和 User Prompt）。
14. **🧠 LLM**: 进行推理，生成代码审查意见。
15. **🧠 LLM** -> **🖥️ Client**: 返回文本流。
16. **🖥️ Client** -> **👤 User**: 在屏幕上打字显示最终结果。

![[Pasted image 20251205102556.png]]






### MCP Client


#### Elicitation/Sampling

**Elicitation (诱出/询问)** 和 **Sampling (采样)**。

在目前的 MCP Python SDK (`mcp`) 的实现中，这两个功能在代码层面通常都通过 **Sampling Protocol (`sampling/createMessage`)** 来实现或者与其紧密相关。

- **普通模式 (Client -> Server)**: 客户端问，服务器答。
- **Sampling/Elicitation (Server -> Client)**: 服务器反过来说：“嘿，Client，我不知道这个问题的答案，或者是我的算力不够，**请你调用你的 LLM (或者问你的用户)** 帮我生成一下内容，然后把结果通过回调传给我。”



代码依旧看Vscode



之前代码一直失败，需要安装并更新FastMcp


- **`mcp` (官方 SDK)**: 它是**地基**。提供了协议最底层的通信能力，功能最全，但写起来比较繁琐，需要自己处理很多连接细节。
- **`fastmcp` (第三方增强库)**: 它是**精装房**。它基于 `mcp` 构建，把复杂的底层逻辑都封装好了，提供了像 `roots=["path"]` 这样超级简单的接口，让你能专注于业务逻辑。


[用户征询 - FastMCP](https://fastmcp.wiki/zh/servers/elicitation)

![[Pasted image 20251208140736.png]]






#### Roots

代码见VScode


静态Root

这里使用的是 FastMCP， 不是基于官方的包

```
from fastmcp import Client

client = Client(
    "my_mcp_server.py", 
    roots=["/path/to/root1", "/path/to/root2"]
)
```

roots=[

            "file:///C:/lutao/study/第一次项目学习/ai/MCP_demo/notes/test.txt"
        ]



动态Root
```
from fastmcp import Client
from fastmcp.client.roots import RequestContext

async def roots_callback(context: RequestContext) -> list[str]:
    print(f"服务器请求根 (请求 ID: {context.request_id})")
    return ["/path/to/root1", "/path/to/root2"]

client = Client(
    "my_mcp_server.py", 
    roots=roots_callback
)
```












## 3. 安全认证

当客户端想要连接到你受保护的 MCP 服务器时会发生什么？

（1）初次握手
当您的 MCP 客户端首次尝试连接时，服务器会回复 `401 未授权`信息，并告诉客户端授权信息的来源，这些信息被记录在[受保护的资源元数据（PRM）文档](https://datatracker.ietf.org/doc/html/rfc9728)中。该文档由 MCP 服务器托管，遵循可预测的路径模式，并在 `WWW-Authenticate` 头部的 `resource_metadata` 参数中提供给客户端。
```
HTTP/1.1 401 Unauthorized
WWW-Authenticate: Bearer realm="mcp",
  resource_metadata="https://your-server.com/.well-known/oauth-protected-resource"
```

（2）受保护资源元数据发现
通过指向 PRM 文档的 URI 指针，客户端获取元数据以了解授权服务器、支持的范围及其他资源信息。数据通常封装在一个 JSON blob 中，类似于下面的。

```
{
  "resource": "https://your-server.com/mcp",
  "authorization_servers": ["https://auth.your-server.com"],
  "scopes_supported": ["mcp:tools", "mcp:resources"]
}
```

（3）授权服务器发现
接着，客户端通过获取其元数据来发现授权服务器能做什么。如果 PRM 文档列出了多个授权服务器，客户端可以决定使用哪一个。选择授权服务器后，客户端将构建标准元数据 URI，向 [OpenID Connect（OIDC）发现](https://openid.net/specs/openid-connect-discovery-1_0.html)端或 [OAuth 2.0 认证服务器元数据](https://datatracker.ietf.org/doc/html/rfc8414)端点（取决于授权服务器支持）发出请求，并获取另一组元数据属性，使其能够知道完成授权流程所需的端点。
```
{
  "issuer": "https://auth.your-server.com",
  "authorization_endpoint": "https://auth.your-server.com/authorize",
  "token_endpoint": "https://auth.your-server.com/token",
  "registration_endpoint": "https://auth.your-server.com/register"
}
```

（4）客户注册
在所有元数据都处理完毕后，客户端现在需要确保它已向授权服务器注册。这可以通过两种方式实现。首先，客户端可以预**注册**给指定的授权服务器，此时它可以嵌入客户端注册信息，用于完成授权流程。或者，客户端可以使用**动态客户端注册** （DCR）来向授权服务器动态注册自己。后一种情况要求授权服务器支持 DCR。如果授权服务器支持 DCR，客户端会向 `registration_endpoint` 发送包含其信息的请求：
```
{
  "client_name": "My MCP Client",
  "redirect_uris": ["http://localhost:3000/callback"],
  "grant_types": ["authorization_code", "refresh_token"],
  "response_types": ["code"]
}
```
如果注册成功，授权服务器将返回包含客户端注册信息的 JSON blob。

（5）用户授权
客户端现在需要打开浏览器访问 `/authorize` 端点，用户可以登录并授予所需的权限。授权服务器随后会重定向给客户端，并传递一个授权码，客户端将该代码交换为令牌：
```
{
  "access_token": "eyJhbGciOiJSUzI1NiIs...",
  "refresh_token": "def502...",
  "token_type": "Bearer",
  "expires_in": 3600
}
```
访问令牌是客户端用来认证向 MCP 服务器请求的。此步骤遵循[标准 OAuth 2.1 授权代码及 PKCE](https://oauth.net/2/grant-types/authorization-code/) 惯例。

（6）发送认证请求
最后，客户端可以使用嵌入`授权头部`的访问令牌向你的 MCP 服务器发出请求：
```
GET /mcp HTTP/1.1
Host: your-server.com
Authorization: Bearer eyJhbGciOiJSUzI1NiIs...
```
MCP 服务器需要验证令牌，并在令牌有效且拥有所需权限时处理请求。




### Keycloak 简介

**Keycloak** 是一个开源的**身份和访问管理（IAM）解决方案**，由 Red Hat 开发维护。它提供了完整的身份认证、授权、单点登录（SSO）和用户管理功能。
- ✅ **单点登录（SSO）**：一次登录，访问所有应用
- ✅ **多种认证方式**：OAuth 2.0、OpenID Connect、SAML
- ✅ **用户联邦**：集成 LDAP、Active Directory、社交登录
- ✅ **细粒度授权**：基于角色的访问控制（RBAC）
- ✅ **管理界面**：Web 控制台管理用户和权限
- ✅ **可扩展**：支持自定义认证流程



 **Keycloak 的使用流程**
 1. **你** 打开浏览器，访问 Keycloak 的登录页，输入用户名密码。
2. **Keycloak** 验证通过，返回给你一串乱码一样的字符（Token）。
3. **你** 把这串字符复制到 Python Client 代码里。
4. **Client** 带着 Token 连接 **Server**。
5. **Server** 收到 Token，去问 Keycloak：“这串字符是你签名的吗？”
6. **Keycloak** 说：“是的。”
7. **Server** 放行，执行工具。


![[Pasted image 20251209140006.png]]



### 简易实现

实际实现demo，按照官方的手顺来执行


**疑问解析**

1.**Client Scope** 是 Keycloak 中的一个核心概念，它定义了**一组可重用的权限和声明（claims）**，可以被分配给多个客户端（应用）。
- 就像 **"权限套餐"** 或 **"功能包"**
- 多个应用可以订阅同一个套餐
- 简化权限管理，避免重复配置

 ![[Pasted image 20251209140928.png]]
 **Type 类型详解**
- **Default**：自动分配给所有新客户端
- **Optional**：客户端可选择是否使用
- **Mandatory**：客户端必须使用（强制）
![[Pasted image 20251209141605.png]]












2.**Protocol Mapper** 是 Keycloak 中**将用户信息映射到令牌（Token）** 的组件。它决定了：
- **哪些信息**会包含在令牌中
- **如何格式化**这些信息
- **在哪种令牌**中包含这些信息

![[Pasted image 20251209150942.png]]



理解:
- 从用户数据库 → 提取数据 → 放入令牌
- 客户端从令牌 → 读取数据 → 使用


| 配置项                          | 含义       | 你的配置                    | 解释             |
| ---------------------------- | -------- | ----------------------- | -------------- |
| **Name**                     | 映射器名称    | `audience-config`       | ✅ 描述性名称        |
| **Included Client Audience** | 包含的客户端受众 | 空                       | 可以填写客户端ID      |
| **Included Custom Audience** | 自定义受众    | `http://localhost:3000` | ✅ 你的 MCP 服务器地址 |

 **令牌类型配置**

|开关|含义|你的配置|建议|
|---|---|---|---|
|**Add to ID token**|添加到 ID 令牌|Off|✅ ID 令牌用于身份验证|
|**Add to access token**|添加到访问令牌|On|✅ **正确！** MCP 用访问令牌|
|**Add to lightweight access token**|轻量级访问令牌|Off|特定场景使用|
|**Add to token introspection**|令牌内省端点|On|✅ 允许服务器验证令牌|



**Client Scope** 就像一个**空的容器**或**权限包**，而 **Protocol Mapper** 就是往这个容器里**放什么东西**。

```
Client Scope (容器)
├── Protocol Mapper 1 (放什么数据)
├── Protocol Mapper 2 (放什么数据)
├── Protocol Mapper 3 (放什么数据)
└── 其他配置...
```

图中的数据:
- **`Included Client Audience`** - 选择已有的客户端作为受众
- **`Included Custom Audience`** - 自定义受众值（你填的 `http://localhost:3000`）

```
配置流程：
1. 定义信息内容 → "audience 应该是 http://localhost:3000"
   ↓
2. 选择令牌类型 → "这个信息要出现在 Access Token 和内省响应中"
   ↓
3. 生成结果 → 当客户端请求包含此 Scope 的令牌时：
   - Access Token 中包含：aud: "http://localhost:3000"
   - ID Token 中不包含 audience
   - 内省查询时会返回 audience
```



在 **Client Scope 的编辑页面** 创建 Mapper，这意味着：

1. **这个 Mapper 属于这个 Client Scope**
    - 不是全局的
    - 不是客户端特有的
    - 是**这个 Scope 的一部分**
2. **当客户端使用这个 Scope 时**
```
客户端 → 请求令牌 → Keycloak 检查：
↓
1. 客户端有哪些 Scope？
↓
2. 这些 Scope 包含哪些 Mapper？
↓
3. 应用这些 Mapper 到令牌
```

**受众（Audience）** 就是 **"这个令牌是给谁用的"**。






 **Token Introspection（令牌内省）详解**

**Token Introspection** 是 OAuth 2.0 的一个标准协议（RFC 7662），允许资源服务器（如 MCP 服务器）向授权服务器（Keycloak）查询令牌的详细信息。


 通俗解释:
```
 你拿着信用卡（令牌）去商店消费
收银员不直接相信信用卡本身
而是打电话给银行（Keycloak）：
"这张卡号XXXX的信用卡有效吗？余额够吗？"
银行回复："有效，余额500元"
收银员才让你刷卡
```












### Oauth2 理解
#### 第一部分：通俗易懂的例子（住酒店）

想象你要去住一家高级酒店。

1. **你 (User)**：就是你自己。
2. **前台 (Authorization Server)**：负责核实你的身份证，确认你是谁。
3. **房卡 (Access Token)**：前台给你的一张卡，这是一串凭证。
4. **电梯/房间 (Resource Server)**：你需要刷卡才能进入的区域（资源）。
5. **你的钱包/卡包 (Client)**：用来替你保管房卡，并拿着房卡去刷电梯的东西。

**流程是这样的：**  
你走到前台 -> 出示身份证 -> 前台给你一张**房卡** -> 你把房卡交给你的**钱包**（或者你自己拿着） -> 走到电梯口 -> **刷卡** -> 电梯检查卡有效 -> 让你进去。
#### 第二部分：映射到 MCP 和 OAuth2

现在我们把上面的角色对应到你的 MCP 架构中：

|OAuth2 标准角色|对应是谁？|说明|
|---|---|---|
|**Resource Owner (资源拥有者)**|**你 (User)**|操作电脑的人。数据和权限归你所有。|
|**Authorization Server (认证服务器)**|**Keycloak** (或 Google/Github)|那个运行在 8080 端口的服务。它负责颁发“令牌 (Token)”。|
|**Client (客户端)**|**MCP Client** (Claude Desktop / Cursor)|这里最容易晕！在 OAuth 里，**MCP Client 就是 OAuth Client**。它是“代替”你去请求服务的软件。|
|**Resource Server (资源服务器)**|**MCP Server** (你的 Python 代码)|你的 MCP Server 手里握着工具（Tools/Prompts），它需要保护这些资源，只让有“令牌”的人用。|

 **为什么你的 MCP Server 代码里有 `CLIENT_ID` 和 `SECRET`？**

这正是你困惑的地方。既然 MCP Server 是“资源服务器”，为什么配置里还要填 `OAUTH_CLIENT_ID`（客户端ID）？

**原因：为了“验票”。**

在企业级 OAuth（如 Keycloak）中，流程通常是这样的：

1. **Claude (MCP Client)** 找 Keycloak 拿到了一张“票”（Token）。
2. **Claude** 拿着这张票请求你的 **MCP Server**：“我要运行 `get_weather` 工具”。
3. 你的 **MCP Server** 拿到票，心想：“我怎么知道这票是真的还是假的？是不是伪造的？”
4. 于是，你的 **MCP Server** 需要拿着这张票，去问 **Keycloak**：“大哥，这张票是你发的吗？过期了吗？”
    - _注意：_ 去问 Keycloak 这个动作，需要权限。Keycloak 不会随便回答陌生人的问题。
    - 因此，你的 **MCP Server** 在向 Keycloak 提问时，必须表明身份：“我是 `mcp-server`，密码是 `xxx`，请帮我查查这张票。”

**结论：**  
虽然你在架构上是 **Resource Server**（被访问者），但在与 Keycloak 通信进行“验票”这个**动作**中，你是 Keycloak 的一个特殊客户端。所以你需要配置 `CLIENT_ID` 和 `SECRET`。

#### 第三部分：完整流程

让我们把这个流程在 MCP 的场景下跑一遍：

1. **登录请求**：  
    你告诉 **Claude (MCP Client)**：“我要连那个需要认证的 MCP Server”。
2. **获取令牌 (Token)**：  
    Claude 弹出一个窗口让你去 **Keycloak (Auth Server)** 登录。你输完账号密码，Keycloak 给 Claude 发了一个 **Access Token**（一串乱码字符串）。
3. **携带令牌调用**：  
    Claude 想调用你写的 Python 工具，它发送请求给你的 **MCP Server**：
    
     请求：请运行 `get_weather`  
     附带：Header [Authorization: Bearer <Token字符串>]
    
4. **验票 (Introspection)**：  
    你的 **MCP Server** (Python代码) 收到请求，拦截下来：
    
     “等等，我要查查这 Token 对不对。”
    
    它读取你配置的 `OAUTH_CLIENT_ID` 和 `SECRET`，连接 Keycloak：
    
     “Keycloak 大哥，我是 `mcp-server`，这个 Token 有效吗？”
    
5. **放行或拒绝**：
    - Keycloak 回复：“有效，是合法的。” -> **MCP Server** 运行工具，返回天气结果。
    - Keycloak 回复：“无效/过期。” -> **MCP Server** 报错 401 Unauthorized。







## 4. 代码理解

两种不同代码的区别？
![[Pasted image 20251209111248.png]]

![[Pasted image 20251209111258.png]]

![[Pasted image 20251208162655.png]]




官方示例代码解析:
[quickstart-resources/weather-server-python/weather.py at main · modelcontextprotocol/quickstart-resources](https://github.com/modelcontextprotocol/quickstart-resources/blob/main/weather-server-python/weather.py)

```
from typing import Any
import httpx
from mcp.server.fastmcp import FastMCP

# Initialize FastMCP server
mcp = FastMCP("weather")
```

- 使用 `FastMCP` 创建一个名为 "weather" 的 MCP 服务器
- `httpx` 用于异步 HTTP 请求


```
async def make_nws_request(url: str) -> dict[str, Any] | None:
    """Make a request to the NWS API with proper error handling."""
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "application/geo+json"
    }
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(url, headers=headers, timeout=30.0)
            response.raise_for_status()
            return response.json()
        except Exception:
            return None
```

- 封装了向 NWS API 发送请求的逻辑
- 设置了必要的请求头（User-Agent 和 Accept）
- 使用 `httpx.AsyncClient` 进行异步请求
- 包含错误处理，发生异常时返回 `None`


```
def format_alert(feature: dict) -> str:
    """Format an alert feature into a readable string."""
    props = feature["properties"]
    return f"""
Event: {props.get('event', 'Unknown')}
Area: {props.get('areaDesc', 'Unknown')}
Severity: {props.get('severity', 'Unknown')}
Description: {props.get('description', 'No description available')}
Instructions: {props.get('instruction', 'No specific instructions provided')}
"""
```
- 将 NWS API 返回的警报数据格式化为易读的字符串
- 提取事件名称、区域、严重程度、描述和指令等信息







```
mcp = FastMCP("Root Inspector Server")

@mcp.tool()

async def inspect_roots(ctx: Context) -> str:
```


这里和java不一样， @mcp.tool 前面的mcp只是个变量名，如果是
app = FastMCP("Root Inspector Server")
那么下面就是 @app.tool()